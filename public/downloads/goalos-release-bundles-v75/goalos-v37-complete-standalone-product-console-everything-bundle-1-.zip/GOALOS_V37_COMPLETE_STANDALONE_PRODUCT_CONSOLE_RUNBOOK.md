# GoalOS V37 Complete Standalone Product Console Runbook

1. Open `goalos-v37-complete-standalone-product-console.html` locally.
2. Type one objective.
3. Click Generate from scratch.
4. Inspect jobs, graphs, docs, and artifacts.
5. Download Complete Generated ZIP from the standalone.

## Boundary
GoalOS V37 local mode boundary:
No backend. No project data sent to GoalOS. No wallet in local mode. No transaction in local mode. No user funds. No live settlement. No production authority. Human review required for high-impact outcomes.

