# Optional AGIJobManager Live Console Reference

This folder is intentionally separate from the local GoalOS standalone. It may involve wallet connection, terms acceptance, token approvals, job posting, validation, disputes, and settlement actions. Use only with explicit human confirmation.

GoalOS V36 local standalone emits transaction intents and ProofBundle templates; it does not sign or submit transactions.
