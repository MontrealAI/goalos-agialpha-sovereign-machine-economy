# GoalOS V36 — Dynamic Production Final

Open `01_STANDALONE_WEBSITE/goalos-v36-production-final-dynamic-autonomous-proof-gated-open-ended-work-machine.html`.

Type two different objectives and run the Diversity Regression Test. The generated domains, proof debt, AGI Jobs, JobSpecURI materials, ProofBundle templates, Evidence Docket, and Chronicle gates should differ.

This package includes the standalone website, documentation series, sample dynamic runs, schemas, GitHub Action pack, optional AGIJobManager live console reference, seller kit, validation report, and file tree.
