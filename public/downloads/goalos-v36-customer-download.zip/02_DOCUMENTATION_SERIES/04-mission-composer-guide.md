# Mission Composer Guide

GoalOS V36 is the Dynamic Production Final Autonomous Proof-Gated Open-Ended Work Machine.

## Purpose

This document explains **Mission Composer Guide** inside the V36 package. V36 is designed to avoid the static-demo failure mode: the standalone engine classifies the user objective, derives objective-specific proof debt, generates objective-specific AGI Jobs, and exports a fresh dossier each run.

## Core invariant

No proof, no memory. No replay, no promotion. No validation, no capability.

## How this doc relates to the standalone

The standalone HTML includes the same documentation series in its generated export and produces Mission Contracts, Mission Benchmark Contracts, Proof Debt Registers, AGIJobManager-compatible JobSpecs, transaction intents, ProofBundle templates, Evidence Docket 6.1, RSI/ECI/Move-37 gates, Proof Economy Ledger, Chronicle HOLD, reviewer room, schemas, and GitHub Action pack files.

## Production boundary

The local standalone is browser-only: no backend, no wallet, no external assets, no automatic transactions. Live AGIJobManager usage remains human-confirmed through a separate console.

## Operator checklist

1. Type a real objective.
2. Start a fresh mission.
3. Inspect the domain classification and proof debt.
4. Verify the generated AGI Jobs differ from unrelated objectives.
5. Inspect JobSpecURI materials and ProofBundle templates.
6. Export the dynamic dossier.
7. Use the reviewer room and external replay kit before promoting Chronicle memory.
