# GoalOS V36 GitHub Action Pack

This pack publishes the V36 dynamic standalone engine and generates objective-specific evidence artifacts under `evidence/`.

The Action accepts an `objective` input. Different objectives generate different domains, proof debt, AGI Jobs, JobSpecs, ProofBundle templates, and Evidence Dockets.

Boundary: this pack does not submit transactions or use a wallet.
