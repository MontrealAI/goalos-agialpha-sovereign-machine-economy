import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const engine = require('../engine/goalos-v36-engine.js');
const objective = process.argv.slice(2).join(' ') || 'Evaluate whether an AI vendor trust room is buyer-ready for enterprise procurement.';
const run = engine.buildRun(objective);
fs.mkdirSync('public', {recursive:true});
fs.copyFileSync('public/index.html', 'public/index.html');
fs.mkdirSync('evidence', {recursive:true});
for (const [p, content] of Object.entries(run.artifacts)) {
  const fp = path.join('evidence', p);
  fs.mkdirSync(path.dirname(fp), {recursive:true});
  fs.writeFileSync(fp, content);
}
fs.mkdirSync('reports', {recursive:true});
fs.writeFileSync('reports/generate-report.json', JSON.stringify({status:'generated', run_id:run.run_id, objective:run.objective, domain:run.domain.label, jobs:run.jobs.map(j=>j.job_id)}, null, 2));
