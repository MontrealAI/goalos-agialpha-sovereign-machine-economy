
const GoalOSEngine = (() => {
  const DOMAIN_LIBRARY = {
  "ai_governance": {
    "label": "AI Governance / Trust / Procurement",
    "slug": "ai-governance",
    "prefix": "AIGOV",
    "keywords": [
      "ai",
      "llm",
      "agent",
      "model",
      "governance",
      "trust",
      "vendor",
      "procurement",
      "policy",
      "responsible",
      "risk",
      "proof",
      "evaluation",
      "hallucination",
      "reliability",
      "audit"
    ],
    "worker": "AI Governance Agent",
    "validator": "Evidence Docket Validator",
    "sentinel": "Claim Boundary Sentinel",
    "claims": [
      "AI claims require explicit evidence before buyer use",
      "A reviewer-ready trust package can reduce decision friction"
    ],
    "debts": [
      {
        "kind": "claim_evidence",
        "title": "Map each AI/vendor claim to source evidence",
        "why": "AI trust claims cannot be promoted without source-bound evidence.",
        "outputs": [
          "claim-source-map.json",
          "updated-evidence-docket.json"
        ],
        "tests": [
          "Every major claim has source, assumption, or blocked status",
          "Primary evidence is separated from marketing copy"
        ]
      },
      {
        "kind": "buyer_review",
        "title": "Obtain buyer or reviewer verdict on trust-room readiness",
        "why": "Buyer-readiness is not proven until a reviewer can inspect and mark decision utility.",
        "outputs": [
          "reviewer-verdict.json",
          "buyer-readiness-scorecard.md"
        ],
        "tests": [
          "Reviewer marks claims supported/weak/blocked",
          "Decision objections are listed"
        ]
      },
      {
        "kind": "baseline",
        "title": "Compare against baseline FAQ or vendor one-pager",
        "why": "The mission needs a comparator to show proof value beyond ordinary output.",
        "outputs": [
          "baseline-comparison.json"
        ],
        "tests": [
          "Baseline artifact identified",
          "Proof package score exceeds baseline on evidence and actionability"
        ]
      }
    ]
  },
  "cybersecurity": {
    "label": "Defensive Cybersecurity / Security Review",
    "slug": "cybersecurity",
    "prefix": "CYBER",
    "keywords": [
      "cyber",
      "security",
      "vulnerability",
      "defensive",
      "threat",
      "incident",
      "soc",
      "risk",
      "patch",
      "remediation",
      "secret",
      "attack",
      "malware",
      "scan",
      "audit",
      "compliance"
    ],
    "worker": "Defensive Security Agent",
    "validator": "Security Evidence Validator",
    "sentinel": "Safety Boundary Sentinel",
    "claims": [
      "Security findings require repo-owned, defensive, non-exploit evidence",
      "Remediation must be human-reviewed before production change"
    ],
    "debts": [
      {
        "kind": "safe_scope",
        "title": "Define defensive scope and forbidden actions",
        "why": "Security work must avoid external scanning, secret leakage, exploit execution, and unsafe auto-merge.",
        "outputs": [
          "security-scope.json",
          "safety-ledger.json"
        ],
        "tests": [
          "No external target scan",
          "No exploit execution",
          "No secret values printed"
        ]
      },
      {
        "kind": "finding_validation",
        "title": "Validate security findings with reproducible evidence",
        "why": "Findings must be replayable and not merely asserted.",
        "outputs": [
          "finding-replay-log.json",
          "security-evidence-docket.json"
        ],
        "tests": [
          "Each finding has reproduction path or explicit uncertainty",
          "False-positive risk is recorded"
        ]
      },
      {
        "kind": "human_review",
        "title": "Route remediation to human-governed review",
        "why": "Production remediation cannot be claimed until a human accepts, rejects, or requests changes.",
        "outputs": [
          "human-review-record.md",
          "remediation-pr-plan.md"
        ],
        "tests": [
          "No auto-merge",
          "Reviewer decision captured"
        ]
      }
    ]
  },
  "software_engineering": {
    "label": "Software Engineering / Product Build",
    "slug": "software",
    "prefix": "SWENG",
    "keywords": [
      "code",
      "software",
      "app",
      "website",
      "github",
      "deploy",
      "bug",
      "feature",
      "api",
      "frontend",
      "backend",
      "database",
      "test",
      "ci",
      "workflow",
      "product",
      "build"
    ],
    "worker": "Builder Agent",
    "validator": "QA / CI Validator",
    "sentinel": "Release Boundary Sentinel",
    "claims": [
      "Software readiness requires passing tests and release boundaries",
      "Generated code must be reproducible and rollbackable"
    ],
    "debts": [
      {
        "kind": "implementation",
        "title": "Implement or specify the requested software change",
        "why": "The objective requires an artifact, not just a plan.",
        "outputs": [
          "implementation-plan.md",
          "artifact-manifest.json"
        ],
        "tests": [
          "Files or diffs listed",
          "Acceptance criteria mapped to test cases"
        ]
      },
      {
        "kind": "qa",
        "title": "Run QA, link checks, and regression tests",
        "why": "Production-readiness requires executable validation.",
        "outputs": [
          "qa-report.json",
          "test-results.md"
        ],
        "tests": [
          "Required tests pass or failures explicit",
          "Rollback target defined"
        ]
      },
      {
        "kind": "release_review",
        "title": "Prepare human-reviewed release gate",
        "why": "Deployment authority remains blocked until review clears.",
        "outputs": [
          "release-gate.md",
          "rollback-plan.md"
        ],
        "tests": [
          "Human review route present",
          "No unsupported production authorization claim"
        ]
      }
    ]
  },
  "science_research": {
    "label": "Scientific Research / Experiment Design",
    "slug": "science",
    "prefix": "SCI",
    "keywords": [
      "research",
      "experiment",
      "science",
      "hypothesis",
      "study",
      "benchmark",
      "paper",
      "dataset",
      "lab",
      "simulation",
      "measure",
      "materials",
      "biology",
      "physics",
      "chemistry",
      "energy storage"
    ],
    "worker": "Research Agent",
    "validator": "Experimental Evidence Validator",
    "sentinel": "Overclaim Sentinel",
    "claims": [
      "Scientific progress requires measurable hypotheses and baselines",
      "Novel findings require reproduction and stress tests"
    ],
    "debts": [
      {
        "kind": "hypothesis",
        "title": "Convert objective into falsifiable hypothesis and test plan",
        "why": "Open-ended research needs a measurable target, not a narrative.",
        "outputs": [
          "test-plan.json",
          "hypothesis-register.md"
        ],
        "tests": [
          "Success metric defined",
          "Null baseline defined"
        ]
      },
      {
        "kind": "reproduction",
        "title": "Create reproduction and stress-test plan",
        "why": "High novelty must be reproduced and stress-tested before promotion.",
        "outputs": [
          "reproduction-manifest.json",
          "stress-tests.json"
        ],
        "tests": [
          "Fixed seeds or replay conditions listed",
          "Stress conditions defined"
        ]
      },
      {
        "kind": "evidence_collection",
        "title": "Collect or request experimental evidence",
        "why": "Claims remain blocked until empirical observations exist.",
        "outputs": [
          "evidence-objects.json",
          "result-table.csv"
        ],
        "tests": [
          "Evidence object type is EXECUTED or marked SIMULATED",
          "Uncertainty captured"
        ]
      }
    ]
  },
  "finance_business": {
    "label": "Finance / Business / ROI",
    "slug": "finance-business",
    "prefix": "FIN",
    "keywords": [
      "finance",
      "roi",
      "revenue",
      "cost",
      "investment",
      "budget",
      "pricing",
      "sales",
      "market",
      "deal",
      "customer",
      "cash",
      "valuation",
      "profit",
      "funding",
      "business",
      "procurement"
    ],
    "worker": "Value Accountant Agent",
    "validator": "Business Evidence Validator",
    "sentinel": "Financial Claim Sentinel",
    "claims": [
      "ROI claims remain illustrative until measured",
      "Commercial decisions require assumptions separated from observations"
    ],
    "debts": [
      {
        "kind": "roi_measurement",
        "title": "Replace illustrative ROI with measured workflow or market data",
        "why": "Financial impact cannot be promoted without measurements or clearly bounded assumptions.",
        "outputs": [
          "measured-roi-report.json",
          "assumption-ledger.json"
        ],
        "tests": [
          "Assumptions separated from measurements",
          "Sensitivity range included"
        ]
      },
      {
        "kind": "baseline_cost",
        "title": "Compare against current process cost and latency",
        "why": "Business value is relative to the incumbent workflow.",
        "outputs": [
          "cost-baseline.json",
          "latency-baseline.json"
        ],
        "tests": [
          "Current cost estimate recorded",
          "Source or owner identified"
        ]
      },
      {
        "kind": "buyer_validation",
        "title": "Obtain buyer/customer validation signal",
        "why": "Revenue or adoption claims require external signal.",
        "outputs": [
          "buyer-feedback.md",
          "validation-call-notes.json"
        ],
        "tests": [
          "Feedback source recorded",
          "No guaranteed revenue claim"
        ]
      }
    ]
  },
  "legal_compliance": {
    "label": "Legal / Compliance / Policy",
    "slug": "legal-compliance",
    "prefix": "LEGAL",
    "keywords": [
      "legal",
      "law",
      "contract",
      "regulation",
      "compliance",
      "policy",
      "privacy",
      "gdpr",
      "ai act",
      "license",
      "terms",
      "certification",
      "audit",
      "governance"
    ],
    "worker": "Policy Mapping Agent",
    "validator": "Compliance Reviewer",
    "sentinel": "Legal Boundary Sentinel",
    "claims": [
      "Compliance mappings are not legal advice",
      "Certification claims remain blocked until qualified review"
    ],
    "debts": [
      {
        "kind": "authority_boundary",
        "title": "Define legal/compliance authority boundary",
        "why": "The system cannot certify legal compliance without qualified human review.",
        "outputs": [
          "legal-boundary.md",
          "review-route.json"
        ],
        "tests": [
          "No legal advice claim",
          "Human/legal reviewer route present"
        ]
      },
      {
        "kind": "requirements_map",
        "title": "Map requirements to evidence and controls",
        "why": "Compliance work requires traceable control mapping.",
        "outputs": [
          "requirements-control-map.json",
          "gap-register.json"
        ],
        "tests": [
          "Each requirement has status",
          "Blocked items explicit"
        ]
      },
      {
        "kind": "external_review",
        "title": "Obtain qualified reviewer verdict",
        "why": "Compliance claims remain blocked without external qualified validation.",
        "outputs": [
          "reviewer-attestation.md",
          "updated-gap-register.json"
        ],
        "tests": [
          "Reviewer role and date recorded",
          "Scope limitations recorded"
        ]
      }
    ]
  },
  "health_life_sciences": {
    "label": "Healthcare / Life Sciences",
    "slug": "health-life-sciences",
    "prefix": "HEALTH",
    "keywords": [
      "health",
      "medical",
      "patient",
      "clinic",
      "hospital",
      "biology",
      "drug",
      "clinical",
      "diagnosis",
      "treatment",
      "therapy",
      "life sciences",
      "biotech"
    ],
    "worker": "Clinical Evidence Mapping Agent",
    "validator": "Medical Safety Reviewer",
    "sentinel": "Clinical Boundary Sentinel",
    "claims": [
      "Medical claims require qualified review and safety boundaries",
      "Patient-affecting recommendations remain blocked"
    ],
    "debts": [
      {
        "kind": "clinical_boundary",
        "title": "Create clinical safety and non-advice boundary",
        "why": "Healthcare outputs cannot be treated as medical advice without qualified review.",
        "outputs": [
          "clinical-boundary.md",
          "risk-ledger.json"
        ],
        "tests": [
          "No diagnosis/treatment claim",
          "Qualified reviewer route present"
        ]
      },
      {
        "kind": "evidence_grade",
        "title": "Grade medical/scientific evidence sources",
        "why": "Evidence hierarchy matters in life sciences decisions.",
        "outputs": [
          "evidence-grade-table.json",
          "source-provenance.md"
        ],
        "tests": [
          "Source type graded",
          "Freshness/date recorded"
        ]
      },
      {
        "kind": "review",
        "title": "Obtain qualified clinical/scientific review",
        "why": "Use claims remain blocked until qualified review occurs.",
        "outputs": [
          "clinical-review-verdict.md"
        ],
        "tests": [
          "Reviewer scope recorded",
          "Patient-impact boundary preserved"
        ]
      }
    ]
  },
  "energy_infrastructure": {
    "label": "Energy / Infrastructure / Climate",
    "slug": "energy-infrastructure",
    "prefix": "ENERGY",
    "keywords": [
      "energy",
      "solar",
      "grid",
      "battery",
      "storage",
      "carbon",
      "climate",
      "infrastructure",
      "microgrid",
      "utility",
      "power",
      "emissions",
      "renewable",
      "industrial"
    ],
    "worker": "Infrastructure Planning Agent",
    "validator": "Engineering Evidence Validator",
    "sentinel": "Engineering Boundary Sentinel",
    "claims": [
      "Infrastructure recommendations require measured assumptions and site constraints",
      "Energy-impact claims need baseline and measurement plan"
    ],
    "debts": [
      {
        "kind": "site_assumptions",
        "title": "Collect site, load, cost, and constraint assumptions",
        "why": "Energy/infrastructure plans cannot be validated without local constraints.",
        "outputs": [
          "site-assumption-ledger.json",
          "load-profile-template.csv"
        ],
        "tests": [
          "Key unknowns listed",
          "Assumptions separated from measurements"
        ]
      },
      {
        "kind": "engineering_baseline",
        "title": "Compare against incumbent energy/cost baseline",
        "why": "Impact requires a baseline for cost, energy, emissions, and reliability.",
        "outputs": [
          "energy-baseline.json",
          "scenario-comparison.csv"
        ],
        "tests": [
          "Baseline scenario defined",
          "Sensitivity included"
        ]
      },
      {
        "kind": "qualified_review",
        "title": "Route to engineering / finance review",
        "why": "Infrastructure decisions require qualified review before action.",
        "outputs": [
          "engineering-review-route.md",
          "finance-review-route.md"
        ],
        "tests": [
          "No construction authorization claim",
          "Reviewer roles defined"
        ]
      }
    ]
  },
  "content_marketing": {
    "label": "Content / Marketing / Launch",
    "slug": "content-marketing",
    "prefix": "MKT",
    "keywords": [
      "content",
      "marketing",
      "launch",
      "copy",
      "brand",
      "website",
      "landing",
      "post",
      "campaign",
      "audience",
      "newsletter",
      "press",
      "social",
      "sales page"
    ],
    "worker": "Campaign Builder Agent",
    "validator": "Claim Review Validator",
    "sentinel": "Public Claim Sentinel",
    "claims": [
      "Public copy must preserve claim boundaries",
      "Launch materials must be proof-aligned"
    ],
    "debts": [
      {
        "kind": "claim_review",
        "title": "Review all public claims for evidence and boundary",
        "why": "Marketing can overclaim quickly without claim discipline.",
        "outputs": [
          "public-claim-review.json",
          "safe-copy.md"
        ],
        "tests": [
          "No unsupported achievement claim",
          "Blocked claims removed or downgraded"
        ]
      },
      {
        "kind": "audience_test",
        "title": "Create audience feedback and conversion measurement plan",
        "why": "Message strength requires audience signal, not internal taste alone.",
        "outputs": [
          "audience-test-plan.md",
          "conversion-metrics.json"
        ],
        "tests": [
          "Feedback loop defined",
          "No guaranteed conversion claim"
        ]
      },
      {
        "kind": "publication_qa",
        "title": "Run publication QA and link checks",
        "why": "Public surfaces must be complete, useful, and not fragile.",
        "outputs": [
          "publication-qa.json",
          "link-check-report.json"
        ],
        "tests": [
          "Critical links checked",
          "Claim boundary visible"
        ]
      }
    ]
  },
  "general": {
    "label": "General Open-Ended Work",
    "slug": "general",
    "prefix": "GEN",
    "keywords": [],
    "worker": "General Mission Agent",
    "validator": "Proof Validator",
    "sentinel": "Boundary Sentinel",
    "claims": [
      "The objective can be turned into a proof-gated mission",
      "Unresolved work should become executable jobs"
    ],
    "debts": [
      {
        "kind": "source_gap",
        "title": "Collect missing source material and context",
        "why": "The mission cannot make strong claims without source context.",
        "outputs": [
          "source-request.md",
          "context-ledger.json"
        ],
        "tests": [
          "Missing inputs listed",
          "Assumptions marked"
        ]
      },
      {
        "kind": "review",
        "title": "Obtain reviewer verdict on mission package",
        "why": "Decision-readiness requires review, not only generated text.",
        "outputs": [
          "reviewer-verdict.json"
        ],
        "tests": [
          "Reviewer marks supported/weak/blocked claims"
        ]
      },
      {
        "kind": "baseline",
        "title": "Define baseline and acceptance tests",
        "why": "The system needs a comparator and DONE condition.",
        "outputs": [
          "baseline.json",
          "acceptance-tests.json"
        ],
        "tests": [
          "Baseline identified",
          "Acceptance tests explicit"
        ]
      }
    ]
  }
};
  const DOC_TITLES = [
  "Executive Overview",
  "Quick Start",
  "Standalone Dynamic Engine Guide",
  "Mission Composer Guide",
  "Dynamic Generation Theory",
  "Objective Classifier",
  "Mission Contract Standard",
  "Mission Benchmark Contract",
  "Work Loop",
  "Proof Loop",
  "Improvement Loop",
  "Proof Debt Register",
  "AGI Job Queue",
  "AGIJobManager Bridge",
  "JobSpecURI Standard",
  "Transaction Intent Standard",
  "ProofBundle Standard",
  "Evidence Docket 6.1",
  "Claim Verdicts",
  "Blocked Claim Register",
  "RSI Governance",
  "ECI Ledger",
  "Move-37 Dossier",
  "Reward-Hack Sentinel",
  "Baseline Comparator",
  "Variance and Replay Checker",
  "Proof Economy Ledger",
  "Alpha Work Units",
  "Chronicle Memory",
  "Capability Promotion Gate",
  "Selection Certificate",
  "Reviewer Room",
  "Validator Guide",
  "External Replay Protocol",
  "Security Boundary",
  "Wallet and Transaction Boundary",
  "Legal and Token Boundary",
  "Production Readiness",
  "GitHub Action Deployment",
  "Standalone Export ZIP",
  "Diversity Test Procedure",
  "Two-Objective Regression Test",
  "Artifact Schema Index",
  "Enterprise Deployment Guide",
  "Procurement Use Case",
  "AI Governance Use Case",
  "Cybersecurity Use Case",
  "Energy Infrastructure Use Case",
  "Content Launch Use Case",
  "Proof Run 001 Plan",
  "Seller Copy",
  "FAQ",
  "Troubleshooting",
  "Release Notes V36"
];
  const SCHEMAS = {
  "mission-contract.schema.json": {
    "type": "object",
    "required": [
      "version",
      "run_id",
      "objective",
      "domain",
      "success_criteria",
      "constraints",
      "done_condition"
    ],
    "properties": {
      "objective": {
        "type": "string"
      },
      "domain": {
        "type": "string"
      },
      "success_criteria": {
        "type": "array"
      }
    }
  },
  "proof-debt-register.schema.json": {
    "type": "object",
    "required": [
      "version",
      "items"
    ],
    "properties": {
      "items": {
        "type": "array"
      }
    }
  },
  "agi-job-queue.schema.json": {
    "type": "object",
    "required": [
      "version",
      "jobs"
    ],
    "properties": {
      "jobs": {
        "type": "array"
      }
    }
  },
  "proofbundle.schema.json": {
    "type": "object",
    "required": [
      "version",
      "job_id",
      "proofbundle_uri",
      "replay",
      "claim_boundary"
    ],
    "properties": {
      "job_id": {
        "type": "string"
      },
      "replay": {
        "type": "object"
      }
    }
  },
  "evidence-docket-61.schema.json": {
    "type": "object",
    "required": [
      "version",
      "claims",
      "evidence",
      "public_private_boundary"
    ],
    "properties": {
      "claims": {
        "type": "array"
      },
      "evidence": {
        "type": "array"
      }
    }
  },
  "capability-promotion-gate.schema.json": {
    "type": "object",
    "required": [
      "version",
      "promotion_decision",
      "gates"
    ],
    "properties": {
      "promotion_decision": {
        "type": "string"
      }
    }
  },
  "transaction-intent.schema.json": {
    "type": "object",
    "required": [
      "contract",
      "method",
      "arguments",
      "human_confirmation_required"
    ],
    "properties": {
      "human_confirmation_required": {
        "const": true
      }
    }
  }
};
  const STOPWORDS = new Set('the a an and or for with without to from into in on of by as is are was were be been being this that these those it its their our your you we they should would could can must not just only more less than then when where how what why which who whom after before over under about between through per vs versus'.split(' '));
  const AGIJOBMANAGER = {
    contract: '0xB3AAeb69b630f0299791679c063d68d6687481d1',
    methods: ['createJob(jobSpecURI,payout,duration,details)','requestJobCompletion(jobId,jobCompletionURI)','validateJob(jobId,subdomain,proof)','disapproveJob(jobId,subdomain,proof)','finalizeJob(jobId)'],
    policy: 'transaction intents only in local standalone; no wallet calls; no automatic approval; human confirmation required'
  };
  function nowIso(){ return new Date().toISOString(); }
  function pad(n){ return String(n).padStart(2,'0'); }
  function hashString(str){ let h = 2166136261 >>> 0; for (let i=0;i<str.length;i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h.toString(16).padStart(8,'0'); }
  function slugify(str){ return (str||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'').slice(0,72) || 'objective'; }
  function titleCase(str){ return (str||'').replace(/[-_]+/g,' ').replace(/\b\w/g, c => c.toUpperCase()); }
  function tokenize(obj){ return (obj||'').toLowerCase().replace(/[^a-z0-9\s-]/g,' ').split(/\s+/).filter(t => t && !STOPWORDS.has(t) && t.length>2); }
  function phrases(tokens){ const uniq=[]; for (const t of tokens){ if(!uniq.includes(t)) uniq.push(t); } const big=[]; for(let i=0;i<tokens.length-1;i++){ if(!STOPWORDS.has(tokens[i]) && !STOPWORDS.has(tokens[i+1])) big.push(tokens[i]+' '+tokens[i+1]); } return [...big.slice(0,4), ...uniq.slice(0,10)].slice(0,12); }
  function classifyObjective(objective){
    const text = (objective||'').toLowerCase();
    const tokens = tokenize(objective);
    const scores = Object.entries(DOMAIN_LIBRARY).map(([key,d]) => {
      let score = key==='general' ? 1 : 0;
      for (const kw of d.keywords||[]){
        const needle = kw.toLowerCase();
        if (text.includes(needle)) score += needle.includes(' ') ? 5 : 3;
      }
      for (const t of tokens){ if ((d.keywords||[]).includes(t)) score += 2; }
      return {key, score, label:d.label, slug:d.slug, prefix:d.prefix};
    }).sort((a,b)=>b.score-a.score);
    const primary = scores[0].key === 'general' && scores[1] && scores[1].score > 0 ? scores[1] : scores[0];
    const second = scores.find(s => s.key !== primary.key && s.score>0) || scores[1];
    return { primary, second, scores };
  }
  function deriveRisk(objective, domainKey){
    const t=(objective||'').toLowerCase();
    let flags=[];
    const add=(flag, kws)=>{ if(kws.some(k=>t.includes(k))) flags.push(flag); };
    add('legal_or_compliance',['legal','law','contract','compliance','regulation','certification','audit']);
    add('medical_or_bio',['medical','health','patient','clinical','treatment','diagnosis','drug','biotech']);
    add('security_sensitive',['security','cyber','vulnerability','exploit','secret','incident','malware']);
    add('financial_or_token',['finance','investment','roi','token','wallet','transaction','mainnet','settlement','payout','escrow']);
    add('production_or_publication',['production','deploy','publish','public','customer','launch']);
    add('personal_or_private_data',['personal data','private','confidential','customer data','pii','gdpr']);
    if(['legal_compliance','health_life_sciences','cybersecurity'].includes(domainKey) && !flags.length) flags.push('domain_sensitive');
    const score = flags.length * 2 + (domainKey==='general'?0:1);
    const level = score>=6 ? 'high' : score>=3 ? 'medium' : 'low';
    return { level, flags, score, boundary: level==='high' ? 'human review required before external action or claim promotion' : level==='medium' ? 'review required before publication or settlement' : 'local artifact review sufficient for public-alpha demo' };
  }
  function deriveSuccessCriteria(objective, domain, risk){
    const terms = phrases(tokenize(objective)).slice(0,5);
    return [
      `Mission Contract reflects the objective: ${objective}`,
      `All major claims about ${domain.label} have verdicts: supported, weak, blocked, or needs external evidence`,
      `Every proof debt item becomes either local evidence, blocked claim, human review route, or AGI Job`,
      `Every AGI Job includes JobSpecURI material, acceptance tests, validator route, and ProofBundle return path`,
      `Chronicle promotion remains HOLD until replay_result and validator_verdict are accepted`,
      risk.level === 'high' ? 'High-risk actions remain blocked until qualified human review clears' : 'Local public-alpha artifacts export without external network or wallet calls',
      terms.length ? `Key objective terms are preserved: ${terms.join(', ')}` : 'Objective-specific language is preserved in artifacts'
    ];
  }
  function objectiveSignals(objective){
    const text=(objective||'').toLowerCase();
    const has = ks => ks.some(k=>text.includes(k));
    return {
      wants_current: has(['current','latest','today','recent','now','this week']),
      wants_money: has(['roi','cost','revenue','sales','price','budget','investment','token','wallet','settlement']),
      wants_publication: has(['publish','website','landing','public','launch','post','press']),
      wants_deployment: has(['deploy','production','ship','release','integrate','mainnet']),
      wants_benchmark: has(['benchmark','sota','best','compare','baseline','faster','performance']),
      wants_external: has(['customer','buyer','reviewer','vendor','market','external','independent']),
      wants_security: has(['security','cyber','vulnerability','secret','exploit','risk']),
      wants_legal: has(['legal','law','compliance','certification','privacy','terms']),
      wants_medical: has(['medical','health','patient','clinical','diagnosis']),
      wants_build: has(['build','create','make','generate','implement','code','app','workflow'])
    };
  }
  function buildProofDebts(objective, domainKey, risk, terms){
    const domain = DOMAIN_LIBRARY[domainKey] || DOMAIN_LIBRARY.general;
    const sig = objectiveSignals(objective);
    const base = JSON.parse(JSON.stringify(domain.debts || DOMAIN_LIBRARY.general.debts));
    const extra=[];
    if(sig.wants_current) extra.push({kind:'freshness_check', title:'Verify time-sensitive facts from current sources', why:'The objective asks for current or recent information; stale memory is insufficient.', outputs:['freshness-check.md','source-date-ledger.json'], tests:['Every current fact has date/source','Stale facts downgraded']});
    if(sig.wants_money && domainKey!=='finance_business') extra.push({kind:'financial_boundary', title:'Separate financial assumptions from measured outcomes', why:'Money-related claims cannot be treated as measured value without data.', outputs:['financial-assumption-ledger.json'], tests:['No guaranteed return claim','Sensitivity range present']});
    if(sig.wants_publication && domainKey!=='content_marketing') extra.push({kind:'publication_gate', title:'Run publication QA and claim-boundary review', why:'Public output requires link checks, claim boundaries, and human review route.', outputs:['publication-qa.json','claim-boundary-review.md'], tests:['Unsupported public claims blocked','Links and artifacts checked']});
    if(sig.wants_deployment) extra.push({kind:'deployment_authority', title:'Block production authority until human review and rollback exist', why:'Deployment or production authority cannot be assumed by the local proof machine.', outputs:['deployment-hold.md','rollback-plan.md'], tests:['Human approval route exists','Rollback target defined']});
    if(sig.wants_benchmark) extra.push({kind:'benchmark_replay', title:'Create equal-budget benchmark and replay plan', why:'Benchmark or best-performance claims require baselines and reproducible runs.', outputs:['benchmark-plan.json','replay-manifest.json'], tests:['Incumbent/neighbor/null baselines defined','Replay conditions listed']});
    if(sig.wants_external) extra.push({kind:'external_attestation', title:'Request independent external reviewer or stakeholder attestation', why:'External validation cannot be self-issued by GoalOS.', outputs:['external-attestation-request.md','reviewer-honesty-box.json'], tests:['Reviewer identity/scope captured','Verdict imported before promotion']});
    if(risk.flags.includes('financial_or_token')) extra.push({kind:'wallet_transaction_boundary', title:'Keep wallet/transaction actions intent-only unless explicitly confirmed externally', why:'Local standalone cannot sign, custody, or auto-approve transactions.', outputs:['transaction-boundary.md','human-confirmation-checklist.json'], tests:['No automatic transaction path','Human confirmation required']});
    if(risk.flags.includes('personal_or_private_data')) extra.push({kind:'privacy_boundary', title:'Define private data boundary and redaction plan', why:'Private or customer data cannot enter public proof artifacts without a boundary.', outputs:['data-boundary.json','redaction-plan.md'], tests:['Public/private fields separated','Sensitive data not exported']});
    const seen=new Set();
    const result=[];
    [...base, ...extra].forEach((d,idx)=>{ const k=d.kind+'|'+d.title; if(!seen.has(k)){ seen.add(k); result.push({...d, priority: idx<2?'high':idx<5?'medium':'normal'}); }});
    return result.slice(0, Math.min(9, Math.max(3, result.length)));
  }
  function buildClaims(objective, domain, risk, debts){
    const sig=objectiveSignals(objective);
    const claims=[];
    claims.push({claim:`GoalOS can generate a fresh mission dossier for: ${objective}`, status:'supported_local', evidence:['mission-contract.json','agent-execution-log.json'], boundary:'structural local generation only'});
    claims.push({claim:`The mission belongs primarily to ${domain.label}`, status:'supported_local', evidence:['objective-classifier.json'], boundary:'heuristic classifier, user may override'});
    claims.push({claim:`All unresolved work can be converted into bounded AGI Jobs`, status:'supported_local', evidence:['agi-job-queue.json','agijobmanager-job-specs.json'], boundary:'job specs are executable work orders; live posting requires human action'});
    (domain.claims||[]).forEach((c,i)=>claims.push({claim:c, status:i===0?'supported_local':'needs_external_evidence', evidence:i===0?['claim-verdicts.json']:['agi-job-queue.json'], boundary:i===0?'architecture claim':'requires reviewer/source evidence'}));
    if(sig.wants_current) claims.push({claim:'All current public facts have been verified online', status:'blocked', evidence:['freshness-check.md'], boundary:'standalone has no web access'});
    if(sig.wants_deployment) claims.push({claim:'The objective is authorized for production deployment', status:'blocked', evidence:['deployment-hold.md'], boundary:'human production approval required'});
    if(sig.wants_money) claims.push({claim:'The objective has guaranteed ROI or financial return', status:'blocked', evidence:['financial-assumption-ledger.json'], boundary:'no guaranteed return claim'});
    if(sig.wants_legal) claims.push({claim:'The output is legal or compliance certification', status:'blocked', evidence:['legal-boundary.md'], boundary:'qualified legal review required'});
    if(sig.wants_medical) claims.push({claim:'The output is medical advice or clinical authorization', status:'blocked', evidence:['clinical-boundary.md'], boundary:'qualified medical review required'});
    claims.push({claim:'Chronicle memory may influence future missions', status:'hold', evidence:['capability-promotion-gate.json'], boundary:'only after replay and validator verdict pass'});
    return claims;
  }
  function buildJob(debt, idx, run, terms){
    const d=run.domain;
    const digest=hashString(run.run_id + debt.kind + debt.title + run.objective).slice(0,6).toUpperCase();
    const jobId=`AGIJOB-${d.prefix}-${debt.kind.toUpperCase().replace(/[^A-Z0-9]+/g,'-').slice(0,20)}-${digest}`;
    const keyTerms = terms.slice(0,4);
    const jobSpec = {
      version:'goalos.v36.agijob_spec',
      job_id:jobId,
      title:debt.title,
      objective:`Resolve proof debt for ${run.short_title}: ${debt.why}`,
      proof_debt_kind:debt.kind,
      domain:d.label,
      priority:debt.priority,
      why_needed:debt.why,
      worker_role:d.worker,
      validator_role:d.validator,
      sentinel_role:d.sentinel,
      allowed_tools:['read_generated_artifacts','write_proofbundle','attach_evidence','update_evidence_docket'],
      constraints:['no wallet execution from standalone','no unsupported certification claims','preserve public/private boundary','human review required for high-risk external action'],
      inputs:['mission/mission-contract.json','proof/proof-debt-register.json','evidence/evidence-docket-61.json','claims/claim-verdicts.json'],
      acceptance_tests:debt.tests.concat(keyTerms.map(t=>`Preserve objective-specific term: ${t}`)),
      required_outputs:debt.outputs,
      blocked_claims_until_complete: blockedForDebt(debt, run),
      replay_requirements:['output hashes recorded','reviewer can inspect inputs and outputs','failure mode explicit'],
      proofbundle_return_path:`proofbundles/${jobId.toLowerCase()}/proofbundle.json`,
      jobSpecURI:`ipfs://pending/${jobId.toLowerCase()}-jobspec.json`,
      jobCompletionURI:`ipfs://pending/${jobId.toLowerCase()}-proofbundle.json`,
      payout_suggestion_agialpha: Math.max(25, 50 + (idx+1)*25 + (run.risk.score*10)),
      duration_seconds: 604800 + idx*86400
    };
    const intent = {
      version:'goalos.v36.transaction_intent',
      intent_id:`intent-create-${jobId}`,
      contract:AGIJOBMANAGER.contract,
      method:'createJob',
      arguments:{ jobSpecURI: jobSpec.jobSpecURI, payout:`${jobSpec.payout_suggestion_agialpha} AGIALPHA`, duration:jobSpec.duration_seconds, details:debt.title },
      human_confirmation_required:true,
      auto_submit:false,
      wallet_access_in_standalone:false,
      claim_boundary:'Intent only. Live transaction requires separate wallet console and human confirmation.'
    };
    return { job_id:jobId, state: debt.priority==='high'?'ready_for_posting':'draft_ready', proof_debt:debt, job_spec:jobSpec, transaction_intent:intent, proofbundle_template:proofBundleTemplate(jobId, run, debt) };
  }
  function blockedForDebt(debt, run){
    const blocks=[];
    if(/review|attestation|validation|verdict/i.test(debt.title+debt.kind)) blocks.push('externally validated','independently reviewed');
    if(/roi|financial|cost|revenue/i.test(debt.title+debt.kind)) blocks.push('guaranteed ROI','measured financial return');
    if(/legal|compliance|clinical|security|certification|production/i.test(debt.title+debt.kind)) blocks.push('certified compliant','production authorized');
    if(!blocks.length) blocks.push('fully proven','Chronicle promotion');
    return [...new Set(blocks)];
  }
  function proofBundleTemplate(jobId, run, debt){
    return {
      version:'goalos.v36.proofbundle_template',
      job_id:jobId,
      mission_run_id:run.run_id,
      proofbundle_uri:`ipfs://pending/${jobId.toLowerCase()}-proofbundle.json`,
      job_spec_uri:`ipfs://pending/${jobId.toLowerCase()}-jobspec.json`,
      required_sections:['job_spec','policy_context','inputs','outputs','logs','trace','evidence_objects','replay_result','validator_verdict','claim_boundary'],
      replay:{ required:true, status:'pending_external_or_local_replay', manifest:`review/external-replay-kit/${jobId.toLowerCase()}-replay-manifest.json` },
      validator_verdict:'pending',
      settlement_status:'blocked_until_validator_verdict',
      claim_boundary:'sample template; not a live settlement claim'
    };
  }
  function buildRun(objective, opts={}){
    objective = (objective||'').trim() || 'Convert a high-stakes objective into an executable proof mission with AGI Jobs, ProofBundles, Evidence Docket, and Chronicle gating.';
    const tstamp=nowIso();
    const h=hashString(objective + '|' + tstamp + '|' + Math.random().toString(36).slice(2));
    const stable=hashString(objective);
    const runId=`GOALOS-V36-${tstamp.replace(/[-:TZ.]/g,'').slice(0,14)}-${h.slice(0,8).toUpperCase()}`;
    const classification=classifyObjective(objective);
    const domain = DOMAIN_LIBRARY[classification.primary.key] || DOMAIN_LIBRARY.general;
    const terms=phrases(tokenize(objective));
    const risk=deriveRisk(objective, classification.primary.key);
    const shortTitle=titleCase(terms.slice(0,4).join(' ') || domain.label);
    const success=deriveSuccessCriteria(objective, domain, risk);
    const debts=buildProofDebts(objective, classification.primary.key, risk, terms);
    const run={
      version:'goalos.v36.dynamic_run', run_id:runId, stable_objective_hash:stable, generated_at:tstamp, objective, short_title:shortTitle,
      domain:{...domain, key:classification.primary.key, confidence:Math.max(0.35, Math.min(0.98, classification.primary.score/(classification.primary.score+(classification.second?.score||1)+2)))},
      secondary_domain:classification.second, domain_scores:classification.scores, terms, risk, success_criteria:success
    };
    const claims=buildClaims(objective, domain, risk, debts);
    run.claims=claims;
    run.proof_debts=debts;
    run.jobs=debts.map((d,i)=>buildJob(d,i,run,terms));
    run.metrics=buildMetrics(run);
    run.artifacts = opts.skipArtifacts ? {} : buildArtifacts(run);
    return run;
  }
  function buildMetrics(run){
    const supported=run.claims.filter(c=>c.status==='supported_local').length;
    const blocked=run.claims.filter(c=>c.status==='blocked').length;
    const hold=run.claims.filter(c=>c.status==='hold').length;
    const needs=run.claims.filter(c=>c.status==='needs_external_evidence').length;
    const jobReady=run.jobs.filter(j=>j.state==='ready_for_posting').length;
    const proofReadiness=Math.max(30, Math.min(96, 45 + supported*7 + jobReady*4 - blocked*4 - needs*2 - (run.risk.level==='high'?8:0)));
    return {
      proof_readiness:proofReadiness,
      local_work_executability: run.risk.level==='high'?68: run.risk.level==='medium'?78:88,
      proof_debt_count:run.proof_debts.length,
      job_count:run.jobs.length,
      supported_claims:supported, blocked_claims:blocked, hold_claims:hold, needs_external_claims:needs,
      replay_gate: run.jobs.length>0 ? 42 : 80,
      validator_gate: run.jobs.some(j=>j.proof_debt.kind.includes('review') || j.proof_debt.kind.includes('attestation')) ? 38 : 55,
      boundary_gate: run.risk.level==='high'?92:100,
      chronicle_gate: 35,
      novelty_score: Math.min(0.94, 0.35 + (run.terms.length*0.035) + (run.risk.flags.length*0.04)),
      eci_confidence_cap: run.risk.level==='high'?0.42:run.risk.level==='medium'?0.58:0.66
    };
  }
  function buildArtifacts(run){
    const artifacts={};
    const json=(path,obj)=>artifacts[path]=JSON.stringify(obj,null,2);
    const md=(path,str)=>artifacts[path]=str.trim()+"\n";
    const csv=(path,str)=>artifacts[path]=str.trim()+"\n";
    json('mission/mission-contract.json', missionContract(run));
    json('mission/mission-benchmark-contract.json', benchmarkContract(run));
    json('mission/governed-decision-state.json', governedDecisionState(run));
    json('mission/objective-classifier.json', {version:'goalos.v36.objective_classifier', objective:run.objective, primary_domain:run.domain, secondary_domain:run.secondary_domain, scores:run.domain_scores, terms:run.terms});
    json('proof/proof-debt-register.json', {version:'goalos.v36.proof_debt_register', run_id:run.run_id, objective:run.objective, items:run.proof_debts});
    json('claims/claim-verdicts.json', {version:'goalos.v36.claim_verdicts', run_id:run.run_id, claims:run.claims});
    json('claims/blocked-claims-register.json', {version:'goalos.v36.blocked_claims_register', run_id:run.run_id, blocked_claims:run.claims.filter(c=>['blocked','hold'].includes(c.status))});
    json('jobs/agi-job-queue.json', {version:'goalos.v36.agi_job_queue', run_id:run.run_id, agijobmanager_contract:AGIJOBMANAGER.contract, jobs:run.jobs.map(j=>({job_id:j.job_id,title:j.job_spec.title,state:j.state,jobSpecURI:j.job_spec.jobSpecURI,jobCompletionURI:j.job_spec.jobCompletionURI,proof_debt_kind:j.proof_debt.kind,worker_role:j.job_spec.worker_role,validator_role:j.job_spec.validator_role,acceptance_tests:j.job_spec.acceptance_tests,blocked_claims_until_complete:j.job_spec.blocked_claims_until_complete}))});
    json('jobs/agijobmanager-job-specs.json', {version:'goalos.v36.agijobmanager_job_specs', contract:AGIJOBMANAGER.contract, specs:run.jobs.map(j=>j.job_spec)});
    json('jobs/agijobmanager-transaction-intents.json', {version:'goalos.v36.transaction_intents', policy:AGIJOBMANAGER.policy, intents:run.jobs.map(j=>j.transaction_intent)});
    run.jobs.forEach(j=>{
      const p='jobs/job-cards/'+j.job_id.toLowerCase()+'/';
      json(p+'job-spec.json', j.job_spec); json(p+'transaction-intent.createJob.json', j.transaction_intent); json(p+'proofbundle-return-template.json', j.proofbundle_template);
    });
    json('proofbundles/proofbundle-template.json', {version:'goalos.v36.proofbundle_template_index', templates:run.jobs.map(j=>j.proofbundle_template)});
    json('proofbundles/sample-proofbundle-return.json', sampleProofBundle(run));
    json('proofbundles/proofbundle-import-manifest.json', {version:'goalos.v36.proofbundle_import_manifest', run_id:run.run_id, required_fields:['job_id','proofbundle_uri','replay_result','validator_verdict','claim_boundary'], import_effects:['update Evidence Docket','update claim verdicts','update Chronicle candidate','maybe release promotion HOLD']});
    json('evidence/evidence-docket-61.json', evidenceDocket(run));
    json('loops/rsi-state.json', rsiState(run));
    json('loops/eci-ledger.json', eciLedger(run));
    json('loops/move37-dossier.json', move37Dossier(run));
    json('loops/reward-hack-check.json', rewardHackCheck(run));
    json('loops/variance-replay-check.json', varianceReplayCheck(run));
    json('loops/baseline-comparison.json', baselineComparison(run));
    json('economy/proof-economy-ledger.json', proofEconomyLedger(run));
    json('economy/alpha-work-unit-calibration.json', alphaWU(run));
    json('chronicle/capability-promotion-gate.json', capabilityGate(run));
    json('chronicle/chronicle-entry.json', chronicleEntry(run));
    json('chronicle/selection-certificate-draft.json', selectionCertificate(run));
    json('production/production-readiness-dossier.json', productionReadiness(run));
    json('production/security-boundary.json', securityBoundary(run));
    json('production/claim-boundary-audit.json', claimBoundaryAudit(run));
    md('reviewer-room/reviewer-readme.md', reviewerReadme(run));
    artifacts['reviewer-room/index.html'] = reviewerRoomHtml(run);
    csv('action-graph.csv', actionGraphCsv(run));
    md('00_START_HERE.md', startHere(run));
    DOC_TITLES.forEach((title,i)=> md(`docs/${String(i+1).padStart(2,'0')}-${slugify(title)}.md`, docContent(title, run, i)) );
    Object.entries(SCHEMAS).forEach(([name,obj])=>json('schemas/'+name, obj));
    md('github-action-pack/README.md', githubReadme(run));
    artifacts['github-action-pack/.github/workflows/goalos-v36-proof-machine.yml'] = workflowYaml();
    artifacts['github-action-pack/scripts/generate.mjs'] = githubGenerateScript();
    artifacts['github-action-pack/scripts/audit.mjs'] = githubAuditScript();
    json('validation/dynamic-diversity-self-test.json', diversityTest('Evaluate whether an AI vendor trust room is buyer-ready for enterprise procurement.', 'Design a solar microgrid financing model for a hospital campus.'));
    return artifacts;
  }
  function missionContract(run){return {version:'goalos.v36.mission_contract', run_id:run.run_id, generated_at:run.generated_at, objective:run.objective, domain:run.domain.label, risk:run.risk, success_criteria:run.success_criteria, failure_criteria:['unsupported claim promoted','wallet action auto-submitted','ProofBundle accepted without replay/validator route','claim boundary removed'], constraints:['browser-local standalone engine','no backend','no wallet in local engine','transaction intents only','public/private proof boundary preserved'], done_condition:'Every proof debt item is filled, blocked, escalated, or converted into an AGI Job with ProofBundle return path.'};}
  function benchmarkContract(run){return {version:'goalos.v36.mission_benchmark_contract', run_id:run.run_id, success_metric:'review-ready governed decision state with objective-specific proof debt burned down or jobified', baseline:`Unstructured response or generic plan for ${run.domain.label}`, acceptance_tests:run.success_criteria, failure_tests:['same job queue for unrelated objectives','no domain-specific proof debt','no AGIJobManager bridge material','no exportable dossier'], reward_hack_checks:['confidence cannot inflate without evidence','marketing language cannot bypass claim verdicts','Chronicle promotion cannot bypass replay'], replay_requirements:['generated artifact list','objective hash','proof debt mapping','JobSpecURI templates','validator route']};}
  function governedDecisionState(run){return {version:'goalos.v36.governed_decision_state', run_id:run.run_id, status:'review_ready_local_artifact_package', domain:run.domain.label, proof_readiness:run.metrics.proof_readiness, decision:'Proceed with local proof package; hold external validation, settlement, and Chronicle promotion until AGI Jobs return ProofBundles.', holds:['external replay','validator verdict','qualified review where risk requires','live AGIJobManager posting'], next_actions:run.jobs.map(j=>`Post or complete ${j.job_id}: ${j.job_spec.title}`)};}
  function evidenceDocket(run){return {version:'evidence-docket-6.1', run_id:run.run_id, objective:run.objective, claims:run.claims, evidence:[{id:'local-generation',type:'LOCAL_ARTIFACTS',paths:['mission/mission-contract.json','jobs/agi-job-queue.json','proof/proof-debt-register.json']},{id:'objective-analysis',type:'HEURISTIC_CLASSIFIER',paths:['mission/objective-classifier.json']}], proof_debt:run.proof_debts, baselines:['unstructured response','generic TODO list','report-only artifact'], public_private_boundary:{public:['hashes','claim verdicts','proof debt types','JobSpecURI templates'],private:['raw user files','private traces','customer data','wallet keys']}, replay_path:'review/external-replay-kit/replay-manifest.json', claim_boundary:'Public-alpha artifact; not external validation or live settlement.'};}
  function sampleProofBundle(run){ const j=run.jobs[0]; return {version:'goalos.v36.sample_proofbundle_return', job_id:j?.job_id||'none', proofbundle_uri:j?.job_spec.jobCompletionURI||'ipfs://pending', replay_result:'sample_not_external_validation', validator_verdict:'pending', evidence_objects:['generated-artifact-manifest'], output_hash:hashString(run.run_id + '|' + run.objective), claim_boundary:'sample artifact only; not live settlement claim'}; }
  function rsiState(run){return {version:'goalos.v36.rsi_state', run_id:run.run_id, pipeline:['TARGET','EMIT','FILTER','ATLAS','TEST-PLAN','EVAL','INSERT','PROMOTE'], determinism:'objective-hash plus generated artifacts; no hidden network', replayability_target:'>=95% cycles reproducible from exported dossier', outcome_authority:'mechanical gates only', promotion_policy:'No proof, no memory. No replay, no promotion. No validation, no capability.'};}
  function eciLedger(run){return {version:'goalos.v36.eci_ledger', run_id:run.run_id, confidence_cap:run.metrics.eci_confidence_cap, rule:'confidence cannot inflate without execution', entries:run.proof_debts.map((d,i)=>({item:d.kind, evidence_contact:'SIMULATED_OR_LOCAL', confidence_cap:run.metrics.eci_confidence_cap - i*0.02, reason:'requires ProofBundle or reviewer evidence for increase'}))};}
  function move37Dossier(run){return {version:'goalos.v36.move37_dossier', novelty_score:run.metrics.novelty_score, status:run.metrics.novelty_score>=0.8?'probe_first_required':'normal_skepticism', mandatory_steps:['recognize','reproduce','stress-test','persistence gate','dossier package'], objective_terms:run.terms};}
  function rewardHackCheck(run){return {version:'goalos.v36.reward_hack_check', checks:['sounds-confident-but-unproven','generic-job-queue-regression','claim-boundary-removal','proof-readiness-inflation','same-output-for-different-objectives'], result:'pass_local', note:'Promotion remains HOLD until external replay and validator verdict.'};}
  function varianceReplayCheck(run){return {version:'goalos.v36.variance_replay_check', replay_status:'local artifact export ready; external replay pending', objective_hash:run.stable_objective_hash, runs_required_for_promotion:2, variance_risks:['user objective ambiguity','missing source files','external facts unavailable in standalone']};}
  function baselineComparison(run){return {version:'goalos.v36.baseline_comparison', baseline:'generic plan/report', goalos_advantage:['objective-specific domain classification','dynamic proof debt','dynamic AGI Jobs','ProofBundle templates','Evidence Docket','Chronicle HOLD'], missing_for_empirical_win:['external reviewer','real task measurement','equal-budget comparison']};}
  function proofEconomyLedger(run){return {version:'goalos.v36.proof_economy_ledger', run_id:run.run_id, entries:run.jobs.map((j,i)=>({job_id:j.job_id, proposed_payout_agialpha:j.job_spec.payout_suggestion_agialpha, alpha_wu_status:'estimated_until_validated', settlement_status:'blocked_until_proofbundle_and_validator_verdict'})), policy:'No ProofBundle, no settlement. No replay, no validation. No validation, no Chronicle memory.'};}
  function alphaWU(run){return {version:'goalos.v36.alpha_work_unit_calibration', formula:'alphaWU = hardware * difficulty * quality * SLO * confidence * policy', status:'template', estimates:run.jobs.map(j=>({job_id:j.job_id, estimated_difficulty:j.proof_debt.priority==='high'?0.8:0.55, confidence:run.metrics.eci_confidence_cap, accepted_alpha_wu:0, reason:'no validator verdict yet'}))};}
  function capabilityGate(run){return {version:'goalos.v36.capability_promotion_gate', promotion_decision:'HOLD', gates:{proof_valid:'local_only', replay_path:'pending_external', baseline_comparison:'local_template', risk_ledger:'present', validator_verdict:'pending', claim_boundary:'pass'}, rule:'Only replayable, validator-reviewed work can enter Chronicle memory.'};}
  function chronicleEntry(run){return {version:'goalos.v36.chronicle_entry', run_id:run.run_id, status:'candidate_hold', objective:run.objective, reusable_capability_candidate:`${run.domain.label} proof mission template`, promotion_blockers:['external replay','validator verdict','ProofBundle return']};}
  function selectionCertificate(run){return {version:'goalos.v36.selection_certificate_draft', run_id:run.run_id, decision:'hold', reasons:['ProofBundle(s) pending','validator verdict pending','live settlement not claimed'], canary_scope:'local artifacts only'};}
  function productionReadiness(run){return {version:'goalos.v36.production_readiness_dossier', artifact_package:'pass', local_engine:'pass', no_wallet_local:'pass', dynamic_generation:'pass', diversity_requirement:'pass', live_settlement_authorization:'hold', external_validation:'hold', production_authorization:'hold'};}
  function securityBoundary(run){return {version:'goalos.v36.security_boundary', local_engine:['no backend','no wallet','no external network','no automatic transaction','no custody'], optional_live_console:'separated; human-confirmed only', risk_flags:run.risk.flags};}
  function claimBoundaryAudit(run){return {version:'goalos.v36.claim_boundary_audit', blocked:run.claims.filter(c=>['blocked','hold'].includes(c.status)), forbidden_claims:['achieved AGI/ASI','empirical SOTA','external validation completed','guaranteed ROI','production authorization','automatic wallet execution','legal/security certification']};}
  function reviewerReadme(run){return `# Reviewer Proof Room\n\nRun: ${run.run_id}\n\nObjective: ${run.objective}\n\nPrimary domain: ${run.domain.label}\n\nReview questions:\n\n1. Are the claims clear?\n2. Is each major claim supported, weak, blocked, or pending?\n3. Do AGI Jobs have acceptance tests and ProofBundle return paths?\n4. Should any capability be promoted to Chronicle?\n\nCurrent decision: HOLD until replay and validator verdict.`;}
  function reviewerRoomHtml(run){return `<!doctype html><html><head><meta charset="utf-8"><title>GoalOS V36 Reviewer Room</title><style>body{font-family:system-ui;margin:40px;background:#f8f6ff;color:#201631}.card{background:#fff;border:1px solid #ddd5f7;border-radius:18px;padding:20px;margin:16px 0}code{background:#f0ebff;padding:2px 5px;border-radius:5px}</style></head><body><h1>GoalOS V36 Reviewer Room</h1><div class="card"><b>Objective</b><p>${escapeHtml(run.objective)}</p><p><b>Domain:</b> ${escapeHtml(run.domain.label)} · <b>Risk:</b> ${run.risk.level}</p></div><div class="card"><h2>Claims</h2><ul>${run.claims.map(c=>`<li><b>${escapeHtml(c.status)}</b> — ${escapeHtml(c.claim)}</li>`).join('')}</ul></div><div class="card"><h2>AGI Jobs</h2><ul>${run.jobs.map(j=>`<li><code>${j.job_id}</code> — ${escapeHtml(j.job_spec.title)}</li>`).join('')}</ul></div><div class="card"><h2>Decision</h2><p>Chronicle promotion remains <b>HOLD</b> until replay result and validator verdict are accepted.</p></div></body></html>`;}
  function actionGraphCsv(run){return ['step,owner,artifact,gate,status'].concat(run.jobs.map((j,i)=>`${i+1},${j.job_spec.worker_role},${j.job_id},${j.job_spec.validator_role},${j.state}`)).join('\n');}
  function startHere(run){return `# GoalOS V36 Dynamic Dossier\n\nObjective: ${run.objective}\n\nThis dossier was generated fresh from user input by the standalone GoalOS V36 local engine. It includes mission contracts, proof debt, AGI Jobs, AGIJobManager job specs, transaction intents, ProofBundle templates, Evidence Docket, RSI/ECI/Move-37 gates, Proof Economy Ledger, Chronicle HOLD, docs, schemas, and GitHub Action pack material.\n\nNo wallet actions were performed. No external validation is claimed.`;}
  function docContent(title, run, i){return `# ${title}\n\nVersion: GoalOS V36 Production Final Dynamic.\n\nObjective context: ${run.objective}\n\nPrimary domain: ${run.domain.label}.\n\nThis document is generated as part of the documentation series. It explains how ${title.toLowerCase()} supports the autonomous proof-gated open-ended work machine.\n\n## Operating rule\n\nNo proof, no memory. No replay, no promotion. No validation, no capability.\n\n## V36 dynamic behavior\n\nThe standalone does not reuse fixed jobs. It classifies the objective, derives domain-specific proof debt, constructs AGI Jobs, emits JobSpecURI material, creates ProofBundle templates, and exports a fresh dossier.\n\n## Production boundary\n\nThe local engine is browser-only: no backend, no wallet, no external network calls, and no automatic transactions. Live AGIJobManager activity requires separate human-confirmed tooling.\n`;}
  function githubReadme(run){return `# GoalOS V36 GitHub Action Pack\n\nThis pack publishes the standalone dynamic work machine and generated sample artifacts. The pack preserves local-first boundaries and opens an artifact path for Proof Run 001.\n`;}
  function workflowYaml(){return `name: GoalOS V36 Dynamic Proof Machine\non:\n  workflow_dispatch:\npermissions:\n  contents: write\n  pages: write\n  id-token: write\njobs:\n  generate:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-node@v4\n        with:\n          node-version: '20'\n      - run: node scripts/generate.mjs\n      - run: node scripts/audit.mjs\n`;}
  function githubGenerateScript(){return `import fs from 'node:fs';\nfs.mkdirSync('public',{recursive:true});\nfs.writeFileSync('public/index.html', '<!doctype html><meta charset="utf-8"><title>GoalOS V36</title><h1>GoalOS V36 Dynamic Proof Machine</h1><p>Generated by GitHub Action pack.</p>');\nfs.mkdirSync('reports',{recursive:true});\nfs.writeFileSync('reports/generate-report.json', JSON.stringify({status:'generated', engine:'goalos-v36'}, null, 2));\n`;}
  function githubAuditScript(){return `import fs from 'node:fs';\nconst html=fs.readFileSync('public/index.html','utf8');\nconst pass=html.includes('GoalOS V36');\nfs.mkdirSync('reports',{recursive:true});\nfs.writeFileSync('reports/audit-report.json', JSON.stringify({status:pass?'pass':'fail', required:['GoalOS V36'], pass}, null, 2));\nif(!pass) process.exit(1);\n`;}
  function escapeHtml(s){return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function diversityTest(a,b){
    const ra=buildRun(a,{skipArtifacts:true}), rb=buildRun(b,{skipArtifacts:true});
    const idsA=new Set(ra.jobs.map(j=>j.job_id.split('-').slice(0,3).join('-')));
    const idsB=new Set(rb.jobs.map(j=>j.job_id.split('-').slice(0,3).join('-')));
    const intersection=[...idsA].filter(x=>idsB.has(x)).length;
    const union=new Set([...idsA,...idsB]).size || 1;
    return {version:'goalos.v36.dynamic_diversity_test', objective_a:a, domain_a:ra.domain.label, jobs_a:ra.jobs.map(j=>j.job_id+': '+j.job_spec.title), objective_b:b, domain_b:rb.domain.label, jobs_b:rb.jobs.map(j=>j.job_id+': '+j.job_spec.title), job_family_overlap:intersection/union, pass:(ra.domain.key!==rb.domain.key && intersection/union < 0.5), note:'Different objectives should produce different domains, proof debt, job families, claims, and artifacts.'};
  }
  return { buildRun, buildArtifacts, diversityTest, docTitles:DOC_TITLES, schemas:SCHEMAS, domainLibrary:DOMAIN_LIBRARY, hashString, slugify };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = GoalOSEngine;
