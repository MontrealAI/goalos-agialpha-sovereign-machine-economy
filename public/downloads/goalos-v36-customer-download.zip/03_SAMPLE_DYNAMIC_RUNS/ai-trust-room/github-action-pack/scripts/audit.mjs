import fs from 'node:fs';
const html=fs.readFileSync('public/index.html','utf8');
const pass=html.includes('GoalOS V36');
fs.mkdirSync('reports',{recursive:true});
fs.writeFileSync('reports/audit-report.json', JSON.stringify({status:pass?'pass':'fail', required:['GoalOS V36'], pass}, null, 2));
if(!pass) process.exit(1);
