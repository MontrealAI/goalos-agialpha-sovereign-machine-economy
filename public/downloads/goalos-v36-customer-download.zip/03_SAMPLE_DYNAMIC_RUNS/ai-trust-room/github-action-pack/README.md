# GoalOS V36 GitHub Action Pack

This pack publishes the standalone dynamic work machine and generated sample artifacts. The pack preserves local-first boundaries and opens an artifact path for Proof Run 001.
