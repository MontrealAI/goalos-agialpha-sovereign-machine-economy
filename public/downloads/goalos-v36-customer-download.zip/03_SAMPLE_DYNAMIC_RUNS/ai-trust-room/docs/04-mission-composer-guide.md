# Mission Composer Guide

Version: GoalOS V36 Production Final Dynamic.

Objective context: Evaluate whether an AI vendor trust room is buyer-ready for enterprise procurement.

Primary domain: AI Governance / Trust / Procurement.

This document is generated as part of the documentation series. It explains how mission composer guide supports the autonomous proof-gated open-ended work machine.

## Operating rule

No proof, no memory. No replay, no promotion. No validation, no capability.

## V36 dynamic behavior

The standalone does not reuse fixed jobs. It classifies the objective, derives domain-specific proof debt, constructs AGI Jobs, emits JobSpecURI material, creates ProofBundle templates, and exports a fresh dossier.

## Production boundary

The local engine is browser-only: no backend, no wallet, no external network calls, and no automatic transactions. Live AGIJobManager activity requires separate human-confirmed tooling.
