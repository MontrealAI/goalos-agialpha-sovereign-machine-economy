GoalOS V36 — Dynamic Production Final

A browser-local proof machine that turns one objective into an exportable proof dossier: Mission Contract, proof debt, AGI Jobs, AGIJobManager JobSpecs, ProofBundle templates, Evidence Docket, docs, schemas, and GitHub Action pack.
