# Security Boundary

The standalone local engine has no backend, no wallet access, no external assets, and no automatic transactions. AGIJobManager live usage is separated and requires explicit human confirmation.
