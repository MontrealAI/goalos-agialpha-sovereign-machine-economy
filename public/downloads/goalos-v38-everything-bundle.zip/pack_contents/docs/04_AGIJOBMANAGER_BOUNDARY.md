# AGIJobManager Boundary

Local GoalOS mode creates job specs and packets only. Live posting, escrow, wallet signing, validator voting, disputes, and settlement require a separate dApp boundary.
