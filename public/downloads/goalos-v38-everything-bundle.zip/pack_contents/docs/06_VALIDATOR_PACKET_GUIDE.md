# Validator Packet Guide

Validator packets give AGI Nodes clear pass/fail criteria, blocked claims, and ProofBundle import requirements.
