# Quick Start

Open the standalone HTML, choose or type an objective, add proof debt, click Generate from scratch, inspect AGI Jobs, then download the reviewer room or complete ZIP.
