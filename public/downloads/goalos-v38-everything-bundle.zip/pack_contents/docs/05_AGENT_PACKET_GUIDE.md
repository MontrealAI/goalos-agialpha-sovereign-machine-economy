# Agent Packet Guide

Agent packets are machine-readable work orders for AGI Agents. They include inputs, deliverables, acceptance tests, and completion URI templates.
