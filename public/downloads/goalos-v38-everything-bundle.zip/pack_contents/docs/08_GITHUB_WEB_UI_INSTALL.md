# GitHub Web UI Install

Upload the pack ZIP to .goalos/packs/ and run the included workflow. Do not embed giant payloads in workflow YAML.
