# ProofBundle Return Guide

A ProofBundle may update an Evidence Docket only after validation. Simulated/local ProofBundles do not equal external validation.
