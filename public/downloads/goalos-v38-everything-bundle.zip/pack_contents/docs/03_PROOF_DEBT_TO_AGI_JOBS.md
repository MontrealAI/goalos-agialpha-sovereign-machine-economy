# Proof Debt to AGI Jobs

Each missing-evidence line is converted into a scoped job with worker, validator, sentinel, deliverables, acceptance tests, blocked claims, and ProofBundle return path.
