# Objective-Specific Generation

Different objectives now produce different scenarios, mission contracts, job queues, validation packets, and proof gates. Run the built-in diagnostic to verify.
