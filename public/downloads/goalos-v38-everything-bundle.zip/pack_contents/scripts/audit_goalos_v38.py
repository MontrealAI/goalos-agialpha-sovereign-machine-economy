from pathlib import Path
text=Path("public/goalos-v38-production-final-correctness-verified-standalone-product-console.html").read_text(encoding="utf-8")
forbidden=["fe"+"tch(","XML"+"HttpRequest","send"+"Beacon","local"+"Storage","session"+"Storage","window"+".ethereum"]
hits=[x for x in forbidden if x in text]
if hits: raise SystemExit("forbidden browser strings: "+str(hits))
print("GoalOS V38 audit passed")
