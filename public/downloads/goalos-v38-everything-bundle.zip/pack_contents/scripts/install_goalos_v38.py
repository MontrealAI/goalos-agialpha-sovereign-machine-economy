from pathlib import Path
Path("public").mkdir(exist_ok=True)
print("GoalOS V38 installed")
