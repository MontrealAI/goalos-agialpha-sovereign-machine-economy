# PROOF_LOOPS.md

## Field Notes on Machines That Turn Work Into Capability

*A short list of rules for proof-gated autonomous work.*

---

## Quick Start

Use this file when you need to turn an AI objective into a governed proof loop.

The loop is:

```text
Objective
→ Proof Mission
→ AGI Jobs
→ Evidence
→ Chronicle
→ Validated Skill
→ On-chain Graph Root
→ Future Mission Improvement
```

Expanded GoalOS form:

```text
Objective
→ Mission Contract
→ Proof Debt
→ Custom AGI Jobs
→ ProofBundles
→ Evidence Docket
→ Verifier Mesh
→ Chronicle Gate
→ Validated Skill Graph
→ On-chain Graph Root
→ Future Mission Improvement
```

The rule is simple:

```text
AI creates output.
GoalOS creates proof.

No proof, no memory.
No replay, no settlement.
No rollback, no release.
No Chronicle entry, no future mission influence.
```

---

## What This Is

`PROOF_LOOPS.md` is the operating note for GoalOS-style autonomous work.

It exists because AI agents can generate impressive output long before that output deserves trust. A proof loop keeps the system from confusing fluent text with institutional capability.

A normal agent platform says:

```text
Give me a task.
I will try to do it.
```

A proof loop says:

```text
Give me an objective.
I will convert it into proof work.
I will show what was attempted.
I will show what evidence exists.
I will show what failed.
I will show what is blocked.
I will preserve only validated skill.
```

---

## One-Page Operating Law

```text
Objective creates the mission.
Mission creates proof debt.
Proof debt creates AGI Jobs.
AGI Jobs create evidence.
Evidence creates Chronicle candidates.
Chronicle admits validated skills.
Validated skills create graph roots.
Graph roots create trusted memory.
Trusted memory improves the next mission.
```

Or shorter:

```text
GoalOS is the loop that turns autonomous work into proof,
proof into skill,
skill into memory,
and memory into better future work.
```

---

## The Visual Loop

```mermaid
flowchart LR
    O[Objective] --> PM[Proof Mission]
    PM --> J[AGI Jobs]
    J --> E[Evidence]
    E --> C[Chronicle]
    C --> S[Validated Skill]
    S --> R[On-chain Graph Root]
    R --> F[Future Mission Improvement]
    F -. capability prior .-> O

    E -. incomplete .-> D[Proof Debt]
    D --> J
    C -. reject / repair .-> D
```

---

# I. Write the Proof Loop, Not the Prompt

A prompt is a request.

A proof loop is a procedure.

The prompt asks the model to answer. The loop forces the system to decide what must be proven before the answer can matter.

```text
ask
→ draft
→ extract claims
→ identify proof debt
→ create jobs
→ collect evidence
→ gate memory
→ improve future work
```

If the system cannot explain what proof is missing, it is not doing GoalOS work yet. It is still chatting.

### Operator check

Ask:

```text
What claims did the system make?
Which claims are supported?
Which claims need evidence?
Which claims are blocked?
Which claims can influence future work?
```

If the answer is unclear, stop and write the loop.

---

# II. Start With the Objective, Not the Agent

Do not start by choosing agents.

Start by defining the objective.

Good objective:

```text
Determine whether this vendor claim is supportable enough for enterprise review,
produce an Evidence Docket,
identify blocked claims,
and capture any reusable reviewer skill.
```

Weak objective:

```text
Research this and tell me what you think.
```

The objective must say what the work is for.

```text
What decision must this support?
What claim must this prove?
What future work should improve if this succeeds?
What is explicitly out of scope?
```

Only after the objective is clear should the system create:

```text
Mission Contract
Proof Debt Register
AGI Jobs
ProofBundle requirements
Evidence Docket
Chronicle criteria
Validated Skill candidate
```

---

# III. Keep the Workbench Empty Until the Mission Exists

The AGI Job workbench should open empty.

```text
No canned jobs.
No fake graph.
No preloaded authority.
No default Chronicle memory.
```

Jobs appear only after the user enters an objective and GoalOS derives proof debt.

This matters because preloaded jobs make the system feel impressive but untrustworthy. A real proof system generates the exact jobs needed by the current mission, claim boundary, proof level, and validator route.

### Clean boot invariant

```json
{
  "agi_jobs": [],
  "proofbundles": [],
  "validated_skills": [],
  "chronicle_entries": [],
  "graph_roots": []
}
```

---

# IV. Convert Unsupported Claims Into Proof Debt

A weak system hides uncertainty inside fluent output.

GoalOS surfaces it.

Every claim should become one of:

```text
supported
needs evidence
needs replay
needs reviewer
needs boundary
blocked
out of scope
```

Proof Debt is not failure.

Proof Debt is the job factory's fuel.

### Proof Debt item

```json
{
  "proof_debt_id": "debt-001",
  "claim": "The workflow is externally validated.",
  "status": "needs-reviewer",
  "why_it_matters": "The claim affects buyer trust and future mission reuse.",
  "required_evidence": [
    "reviewer verdict",
    "source replay",
    "claim boundary",
    "risk ledger"
  ],
  "blocked_until": "ProofBundle returned and Chronicle Gate passes"
}
```

---

# V. Create AGI Jobs as Executable Proof Objects

An AGI Job is not a todo item.

It is a proof contract.

```json
{
  "job_id": "agi-job-external-review-001",
  "source_claim": "The capability is ready for enterprise trust review.",
  "proof_category": "validation",
  "why_needed": "The claim cannot enter Chronicle without independent review.",
  "worker_role": "Reviewer Agent or Human Reviewer",
  "validator_role": "AGI Node Validator + Human Review",
  "sentinel_role": "Boundary Sentinel",
  "acceptance_tests": [
    "claim boundary preserved",
    "reviewer verdict attached",
    "evidence docket updated",
    "rollback condition recorded"
  ],
  "blocked_claims": [
    "certified",
    "legally approved",
    "guaranteed ROI",
    "production authorized"
  ],
  "proofbundle_return_path": "proofbundles/agi-job-external-review-001.json"
}
```

If a job does not say what evidence would satisfy it, it is not a job.

It is a wish.

---

# VI. Evidence Must Become a Docket, Not a Pile

A folder of artifacts is not an Evidence Docket.

An Evidence Docket is a proof room.

It should show:

```text
claims
sources
proof debt
ProofBundles
reviewer verdicts
replay manifests
baseline comparisons
risk ledger
blocked claims
validator notes
decision state
rollback conditions
```

### Evidence Docket skeleton

```json
{
  "evidence_docket_id": "docket-001",
  "mission_id": "mission-001",
  "claims_matrix": [],
  "proof_debt_resolved": [],
  "proofbundles": [],
  "reviewer_verdicts": [],
  "replay_manifest": {},
  "risk_ledger": [],
  "blocked_claims": [],
  "chronicle_recommendation": "hold | admit | repair | reject",
  "decision_state": "reviewer-ready"
}
```

The point is not to store more files.

The point is to make trust inspectable.

---

# VII. Chronicle Is the Memory Firewall

Nothing enters memory because it sounds useful.

A candidate capability enters Chronicle only if it passes:

```text
support
replay
validation
scope
risk
utility
rollback
proof level
```

The Chronicle Gate turns evidence into authority.

### Chronicle decision

```json
{
  "chronicle_entry_id": "chronicle-001",
  "candidate_skill_id": "skill-candidate-001",
  "decision": "admit | repair | reject | quarantine",
  "proof_level": "L3 External Review",
  "passed": [
    "support",
    "validation",
    "scope",
    "risk",
    "rollback"
  ],
  "missing": [
    "baseline replay"
  ],
  "reuse_allowed_for": [
    "future Mission Contract drafting",
    "reviewer-room creation",
    "AGI Job generation"
  ],
  "blocked_extensions": [
    "legal certification",
    "guaranteed ROI",
    "live settlement"
  ],
  "rollback_condition": "retire if reviewer verdict is invalidated"
}
```

This is the non-contamination rule:

```text
Unsupported claims may remain visible as Proof Debt.
They may not influence future missions through memory.
```

---

# VIII. A Skill Is Not a Note

A note says:

```text
This worked once.
```

A validated skill says:

```text
This may be reused under these conditions because it survived proof.
```

A skill is a governed capability object.

```json
{
  "skill_id": "skill-vision-to-proof-001",
  "type": "VisionToProof",
  "scope": {
    "mission_class": "AI Trust Room",
    "proof_level": "L3 External Review",
    "allowed_use": "convert claims into proof missions"
  },
  "method": "Convert visionary claims into claim matrix, proof debt, AGI Jobs, Evidence Docket, and reviewer route.",
  "evidence_set": [
    "proofbundle://agi-job-external-review-001",
    "evidence-docket://docket-001"
  ],
  "validators": [
    "Human Reviewer",
    "AGI Node Validator"
  ],
  "replay_manifest": "replay://mission-001",
  "risk_ledger": [
    "overclaiming",
    "stale evidence",
    "scope drift"
  ],
  "limits": [
    "not certification",
    "not legal advice",
    "not live settlement"
  ],
  "utility_score": 0.84,
  "rollback": "retire if proof or scope fails"
}
```

The Validated Skill Graph is not a prompt library.

It is proof-gated capability memory.

---

# IX. Use Proof Levels to Match the Mission

Not every mission needs the same proof burden.

A brainstorming mission, internal review, public claim, mainnet handoff, and Chronicle-grade capability should not share the same gate.

| Level | Name | Use | Memory Effect |
|---|---|---|---|
| L1 | Structural / Demo | Learn the loop; show proof debt. | No durable Chronicle influence. |
| L2 | Internal Review | Operator confirms usefulness and scope. | Temporary reuse, clearly labeled. |
| L3 | External Review | Reviewer or AGI Node validates support. | Scoped reusable skill. |
| L4 | Mainnet Handoff | Prepare job specs and validator route. | May inform external execution preparation. |
| L5 | Chronicle / Formal | Multi-validator evidence, replay, rollback. | Durable future mission influence. |

The proof level is not decoration.

It changes:

```text
job granularity
validator burden
Evidence Docket strictness
ProofBundle requirements
Chronicle threshold
handoff readiness
```

---

# X. Store Roots, Not Plaintext Private Intelligence

The on-chain graph should not expose private method, reviewer notes, raw traces, secret evidence, or sensitive operational context.

The correct pattern is:

```text
private skill capsule → encrypted
graph → commitment root
Evidence Docket → root
ProofBundle → root
policy → hash
attestations → root
ZK proof → verifies hidden predicates
ENS agent → authorizes write
```

### On-chain graph root record

```json
{
  "skill_id": "skill-vision-to-proof-001",
  "agent_node": "john.agent.agi.eth",
  "graph_root": "0x...",
  "evidence_root": "0x...",
  "proofbundle_root": "0x...",
  "ciphertext_hash": "0x...",
  "policy_hash": "0x...",
  "schema_hash": "0x...",
  "attestation_root": "0x...",
  "zk_proof_hash": "0x...",
  "proof_level": 3,
  "version": 1,
  "status": "registered"
}
```

Private intelligence is never plaintext on-chain.

If it must be on-chain, it is ciphertext plus commitments. Zero-knowledge proves policy satisfaction without revealing the capsule.

---

# XI. Only Authorized AGI Agents Write the Graph

The graph root is not a public scratchpad.

Only direct AGI Agent identities should write their own skill commitments.

```text
john.agent.agi.eth      ✅ direct authorized name
research.agent.agi.eth  ✅ direct authorized name
x.john.agent.agi.eth    ❌ nested name; not direct
```

The authorization law:

```text
wallet owns label.agent.agi.eth
→ wallet may register, supersede, or revoke that agent's skill commitments
```

The direct-subname rule prevents ambiguous authority.

A deeper subname may exist, but it does not inherit registry update rights.

---

# XII. The On-chain Root Is Not the Skill

The on-chain graph root is a public commitment.

The full skill lives as:

```text
encrypted capsule
Evidence Docket
ProofBundles
validator attestations
replay manifests
risk ledgers
Chronicle decision
```

Ethereum coordinates proof.

It should not expose private intelligence.

---

# XIII. Future Missions Learn Only From Admitted Skills

This is the compounding law:

```text
No Chronicle entry → no future mission influence.
No validated skill → no RSI leverage.
No proof root → no mainnet memory claim.
```

A future mission can improve only from capability that survived the gate.

### Future mission seed

```json
{
  "future_mission_id": "mission-002",
  "seeded_by": "skill-vision-to-proof-001",
  "allowed_influence": [
    "claim extraction",
    "proof debt creation",
    "reviewer route selection",
    "Evidence Docket scaffolding"
  ],
  "blocked_influence": [
    "certification claims",
    "financial advice",
    "production authorization",
    "live settlement"
  ],
  "required_recheck": [
    "scope match",
    "evidence freshness",
    "risk posture"
  ]
}
```

That is how the loop compounds without becoming contaminated.

---

# XIV. Read the Traces

Every serious debugging insight comes from reading the traces.

A proof loop should write logs that a reviewer can inspect.

Minimum traces:

```text
mission trace
claim trace
job trace
tool trace
evidence trace
validator trace
decision trace
rollback trace
```

Trace rule:

```text
If the system cannot reconstruct what happened,
the result cannot become trusted memory.
```

---

# XV. Delete the Harness When the Model Improves

Harnesses exist to compensate for weak models, weak tools, and weak validators.

As models improve, parts of the harness should shrink.

Do not let the proof system become ceremonial.

Keep:

```text
evidence
replay
risk boundary
validator route
rollback
claim boundary
```

Delete:

```text
redundant scaffolds
stale checklists
obsolete prompts
manual steps the system now performs reliably
fake complexity
```

The harness should become smaller as proof becomes stronger.

---

# XVI. The Bottleneck Always Moves

At first, the bottleneck is generation.

Then it becomes proof.

Then validation.

Then replay.

Then skill admission.

Then on-chain commitment.

Then external review.

Then real-world outcome.

Then governance.

The loop's job is not to pretend the bottleneck is gone.

The loop's job is to reveal the next bottleneck fast enough that the system can improve.

---

# XVII. What to Export After Every Run

A complete GoalOS run should export:

```text
Mission Contract
Proof Debt Register
AGI Job Queue
ProofBundle Manifest
Evidence Docket
Verifier Report
Chronicle Gate Decision
Validated Skill Capsule
Validated Skill Graph Update
On-chain Graph Root Record
Reviewer Room
Action Graph
Claim Boundary
Rollback Plan
```

High-rigor runs add:

```text
baseline comparison
replay manifest
stress tests
validator attestations
ZK policy proof
attestation root
cost ledger
risk ledger
external reviewer notes
delayed-outcome monitor
```

---

# XVIII. The Minimal PROOF_LOOPS Checklist

Before a result can influence future work, answer:

```text
1. What was the objective?
2. What proof mission was created?
3. What claims were extracted?
4. What proof debt existed?
5. What AGI Jobs retired that debt?
6. What evidence was returned?
7. What did the Evidence Docket say?
8. What did the Chronicle Gate decide?
9. What skill was admitted?
10. What scope limits apply?
11. What rollback exists?
12. What on-chain graph root commits to the skill?
13. What future mission may use it?
14. What claims remain blocked?
```

If any answer is missing, the loop is not complete.

---

# XIX. Templates

## Mission Contract

```json
{
  "mission_id": "mission-001",
  "objective": "",
  "decision_to_support": "",
  "success_criteria": [],
  "failure_criteria": [],
  "constraints": [],
  "proof_level": "L3 External Review",
  "risk_class": "medium",
  "allowed_tools": [],
  "required_validators": [],
  "blocked_claims": [],
  "rollback_obligations": []
}
```

## Proof Debt Register

```json
{
  "proof_debt_register_id": "proof-debt-001",
  "mission_id": "mission-001",
  "items": [
    {
      "claim": "",
      "status": "needs-evidence",
      "required_evidence": [],
      "job_required": true,
      "blocked_until": ""
    }
  ]
}
```

## AGI Job

```json
{
  "job_id": "agi-job-001",
  "proof_debt_id": "debt-001",
  "worker": "",
  "validator": "",
  "sentinel": "",
  "deliverables": [],
  "acceptance_tests": [],
  "proofbundle_return_path": "proofbundles/agi-job-001.json",
  "status": "ready-for-execution"
}
```

## ProofBundle

```json
{
  "proofbundle_id": "proofbundle-001",
  "job_id": "agi-job-001",
  "proof_level": "L3 External Review",
  "artifacts": [],
  "claim_verdicts": [],
  "replay_manifest": {},
  "validator_attestations": [],
  "rollback_condition": ""
}
```

## Evidence Docket

```json
{
  "evidence_docket_id": "docket-001",
  "mission_id": "mission-001",
  "claims_matrix": [],
  "proofbundles": [],
  "risk_ledger": [],
  "blocked_claims": [],
  "verifier_report": {},
  "chronicle_recommendation": "hold"
}
```

## Chronicle Decision

```json
{
  "chronicle_decision_id": "chronicle-decision-001",
  "candidate_skill_id": "skill-candidate-001",
  "decision": "admit | repair | reject | quarantine",
  "passed_gates": [],
  "missing_gates": [],
  "reuse_scope": [],
  "rollback_condition": ""
}
```

## Validated Skill

```json
{
  "skill_id": "skill-001",
  "type": "",
  "scope": {},
  "method": "",
  "evidence_set": [],
  "validators": [],
  "replay_manifest": "",
  "risk_ledger": [],
  "limits": [],
  "utility_score": 0,
  "rollback": ""
}
```

## On-chain Graph Root

```json
{
  "agent": "john.agent.agi.eth",
  "skill_id": "skill-001",
  "graph_root": "0x...",
  "evidence_root": "0x...",
  "proofbundle_root": "0x...",
  "policy_hash": "0x...",
  "schema_hash": "0x...",
  "attestation_root": "0x...",
  "version": 1
}
```

---

# XX. Claim Boundary

This document defines an operating pattern.

It does not claim:

```text
achieved AGI
achieved ASI
empirical SOTA
legal certification
financial advice
security certification
live wallet support
live settlement
production authority
```

It defines the loop required to make such claims reviewable, falsifiable, replayable, and governed.

---

# Final Line

```text
Do not remember what was merely said.
Remember what was proven, bounded, replayable, and safe to reuse.
```

```text
Proof today.
Capability forever.
```
