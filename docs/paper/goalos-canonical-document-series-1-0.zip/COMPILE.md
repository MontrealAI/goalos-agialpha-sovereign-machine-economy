# Compile the document series

Compile each booklet from the `booklets/` directory with two LaTeX passes. Then combine in order:

```bash
pdfunite \
  00_EXECUTIVE_CHARTER.pdf \
  01_PROOF_LOOPS_STANDARD.pdf \
  02_PROOF_MISSION_OPERATIONS.pdf \
  03_EVIDENCE_CHRONICLE_SKILL_GRAPH.pdf \
  04_MERKLE_ZK_AGENT_AUTHORITY.pdf \
  05_GOVERNANCE_SECURITY_RSI.pdf \
  06_PRODUCT_MASTERCLASS_DEPLOYMENT.pdf \
  07_EVALUATION_PROOF_RUN_001.pdf \
  ../GOALOS_CANONICAL_DOCUMENT_SERIES_1_0.pdf
```
