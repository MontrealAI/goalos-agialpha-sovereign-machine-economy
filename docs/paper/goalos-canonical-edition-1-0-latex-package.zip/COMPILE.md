# Compile

From this directory:

```bash
pdflatex -interaction=nonstopmode GOALOS_CANONICAL_EDITION_1_0_PROOF_CARRYING_AUTONOMY.tex
pdflatex -interaction=nonstopmode GOALOS_CANONICAL_EDITION_1_0_PROOF_CARRYING_AUTONOMY.tex
```

The second pass resolves the table of contents, links, and final page count.
