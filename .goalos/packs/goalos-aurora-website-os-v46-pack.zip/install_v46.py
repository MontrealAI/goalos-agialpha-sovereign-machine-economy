#!/usr/bin/env python3
from __future__ import annotations
import json, re, html, os
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime, timezone

VERSION = "v46"
FEATURE = "GoalOS Aurora Website OS V46"
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
ASSETS = PUBLIC / "assets"
REPORTS = ROOT / "reports"
DOCS = ROOT / "docs"
CONTENT = ROOT / "content" / "goalos"
EVIDENCE = ROOT / "evidence" / "demo"
EXAMPLES = ROOT / "examples" / "aurora-website-os-v46"
BANNED = ["send"+"Beacon", "local"+"Storage", "session"+"Storage", "window."+"ethereum", "XML"+"HttpRequest", "fetch("]
CANONICAL = [
    ("index.html", "GoalOS Aurora Command Center", "Start here: one colored command center for proof-governed AI work."),
    ("goalos-aurora-command-center.html", "GoalOS Aurora Command Center", "A premium colored command surface for every GoalOS route."),
    ("goalos-command-center.html", "GoalOS Command Center", "Operate the full public-alpha GoalOS ecosystem."),
    ("goalos-gold-master.html", "Gold Master", "Public-alpha release checkpoint, now presented through the colored command interface."),
    ("public-alpha-gold-master.html", "Public Alpha Gold Master", "Public-alpha checkpoint and release boundary."),
    ("autonomy-theatre.html", "Autonomy Theatre", "Run the end-to-end objective to proof to Chronicle demo."),
    ("agi-agent-workbench.html", "AGI Agent Workbench", "AGI Agents, AGI Job, AGI Node handoff, ProofBundle, Evidence Docket."),
    ("validation-control-tower.html", "Validation Control Tower", "Human, AGI Node, Hybrid, and Council validation."),
    ("mainnet-contract-atlas.html", "48 Mainnet Contracts", "Learn the GoalOS proof rail through the 48 Mainnet contracts."),
    ("visual-flow-proof.html", "Visual Flow Proof", "Clean, aligned flow from objective to reusable capability."),
    ("ux-proof-check.html", "Human UX Proof Check", "Visual QA gate for a human reviewer."),
    ("site-map.html", "All Pages", "Complete route inventory."),
    ("all-pages.html", "All Pages", "Complete route inventory alias."),
    ("route-registry.html", "Route Registry", "Human-readable route registry."),
    ("search.html", "Search", "Browser-local route search."),
    ("site-health.html", "Site Health", "Route, boundary, and UX status."),
    ("ask-goalos.html", "Ask GoalOS", "Browser-local route assistant."),
    ("trust-boundary.html", "Trust Boundary", "No-data, no-funds, no-wallet boundary."),
    ("token-boundary.html", "Token Boundary", "$AGIALPHA public contract identification boundary."),
    ("graduation-control-room.html", "Graduation Control Room", "Production graduation runway without premature claims."),
    ("production-readiness-gauntlet.html", "Production Readiness Gauntlet", "Gates before production authorization."),
    ("external-validation-roadmap.html", "External Validation Roadmap", "External replay, evidence, and validation roadmap."),
    ("evidence-to-production-roadmap.html", "Evidence to Production Roadmap", "Evidence ladder toward production-grade operation."),
]
PLAYBOOKS = [
    {"title":"Understand GoalOS in 10 minutes","objective":"I am new and want the fastest path to understand GoalOS.","routes":["goalos-aurora-command-center.html","autonomy-theatre.html","site-map.html"]},
    {"title":"Run the end-to-end proof demo","objective":"I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.","routes":["autonomy-theatre.html","visual-flow-proof.html","ux-proof-check.html"]},
    {"title":"Learn the 48 Mainnet contracts","objective":"I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.","routes":["mainnet-contract-atlas.html","contract-academy.html","mainnet-proof-rail.html"]},
    {"title":"Validate with Human or AGI Node","objective":"I want to validate a public-safe proof path with AGI Node precheck and Human final review.","routes":["validation-control-tower.html","agi-node-use-cases.html","ux-proof-check.html"]},
    {"title":"Evaluate an AI vendor","objective":"I want to evaluate an AI vendor using evidence, not marketing claims.","routes":["agi-agent-workbench.html","evidence-docket-theatre.html","validation-control-tower.html"]},
    {"title":"Production-readiness runway","objective":"I want to understand what evidence is required before production authorization.","routes":["graduation-control-room.html","production-readiness-gauntlet.html","external-validation-roadmap.html"]},
]
CSS = r'''
:root{--ink:#f8f6ec;--muted:#c8d7ee;--deep:#020714;--card:rgba(7,18,36,.78);--line:rgba(126,231,255,.30);--mint:#62ffd2;--cyan:#7ee7ff;--gold:#ffe86a;--lime:#caff78;--violet:#a995ff;--pink:#ff7bb6;--shadow:0 30px 90px rgba(0,0,0,.36)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-height:100vh;color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:radial-gradient(circle at 14% 13%,rgba(98,255,210,.26),transparent 30%),radial-gradient(circle at 82% 10%,rgba(169,149,255,.25),transparent 33%),radial-gradient(circle at 60% 82%,rgba(126,231,255,.18),transparent 38%),linear-gradient(135deg,#031315 0%,#07172b 50%,#090617 100%);overflow-x:hidden}body:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.95),rgba(0,0,0,.28))}a{color:var(--mint)}a:hover{color:var(--gold)}img,svg,video,canvas{max-width:100%;height:auto}.goalos-v46-page{position:relative;z-index:1}.v46-shell{width:min(1220px,calc(100vw - 40px));margin:0 auto;padding:28px 0 84px}.v46-nav{position:sticky;top:14px;z-index:20;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;padding:14px 18px;margin-bottom:58px;border:1px solid rgba(126,231,255,.24);border-radius:28px;background:linear-gradient(135deg,rgba(4,10,22,.93),rgba(15,23,42,.78));box-shadow:var(--shadow);backdrop-filter:blur(18px)}.v46-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--ink)}.v46-logo{width:42px;height:42px;border-radius:15px;display:grid;place-items:center;color:#020617;font-weight:1000;background:radial-gradient(circle at 25% 25%,var(--gold),var(--mint) 42%,var(--cyan) 70%,var(--violet));box-shadow:0 0 32px rgba(98,255,210,.36)}.v46-brand strong{display:block;font-size:14px;letter-spacing:.18em;text-transform:uppercase}.v46-brand span span{display:block;font-size:10px;letter-spacing:.28em;text-transform:uppercase;color:#b7c4db}.v46-nav-links{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.v46-nav-links a,.v46-pill,.v46-button{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:10px 14px;background:rgba(255,255,255,.08);color:var(--ink);text-decoration:none;font-weight:900;font-size:13px}.v46-nav-links a[aria-current="page"],.v46-pill.primary,.v46-button.primary{color:#031315;background:linear-gradient(135deg,var(--gold),var(--lime),var(--mint));border-color:transparent;box-shadow:0 18px 42px rgba(98,255,210,.22)}.v46-hero{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(360px,.95fr);gap:42px;align-items:center}.v46-kicker{display:flex;align-items:center;gap:10px;color:var(--gold);font-size:12px;font-weight:1000;letter-spacing:.38em;text-transform:uppercase}.v46-kicker:before{content:"";width:10px;height:10px;border-radius:999px;background:var(--mint);box-shadow:0 0 24px var(--mint)}.v46-title{margin:16px 0;font-size:clamp(52px,8.2vw,112px);line-height:.86;letter-spacing:-.083em;max-width:980px}.v46-title em{font-family:Georgia,ui-serif,serif;font-style:italic;letter-spacing:-.05em;background:linear-gradient(100deg,var(--gold),var(--lime),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}.v46-subtitle{font-size:clamp(20px,2.7vw,33px);line-height:1.05;letter-spacing:-.045em;font-weight:1000;max-width:820px;margin:18px 0;color:#fff}.v46-copy{font-size:18px;line-height:1.72;color:var(--muted);max-width:760px}.v46-actions{display:flex;flex-wrap:wrap;gap:12px;margin:26px 0}.v46-button{cursor:pointer;display:inline-flex;align-items:center;gap:8px}.v46-button:hover{transform:translateY(-1px)}.v46-boundary{margin-top:20px;padding:16px 18px;border-radius:18px;background:linear-gradient(135deg,rgba(255,123,182,.13),rgba(255,232,106,.08));border:1px solid rgba(255,123,182,.40);color:#fff;font-weight:800;line-height:1.5}.v46-console{border:1px solid rgba(126,231,255,.28);background:linear-gradient(145deg,rgba(10,22,40,.88),rgba(31,31,70,.72));box-shadow:var(--shadow);border-radius:34px;padding:22px;min-height:540px;overflow:hidden}.v46-console-head{display:flex;justify-content:space-between;gap:12px;align-items:center;border-bottom:1px solid rgba(255,255,255,.14);padding-bottom:14px;margin-bottom:18px}.v46-console-head span{font-weight:1000;letter-spacing:.24em;font-size:12px;text-transform:uppercase}.v46-status{color:#031315;background:var(--mint);padding:8px 12px;border-radius:999px;font-size:12px;font-weight:1000}.v46-alpha{width:138px;height:138px;border-radius:50%;margin:18px auto;display:grid;place-items:center;font-size:70px;font-weight:1000;color:#050813;background:radial-gradient(circle at 30% 26%,var(--gold),var(--mint) 38%,var(--cyan) 70%,var(--violet));box-shadow:0 0 76px rgba(98,255,210,.48)}.v46-stage-grid,.v46-agent-grid,.v46-card-grid,.v46-route-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}.v46-stage-grid{grid-template-columns:repeat(auto-fit,minmax(112px,1fr))}.v46-agent-card,.v46-card,.v46-route-card,.v46-flow-step{border:1px solid rgba(255,255,255,.14);border-radius:18px;background:linear-gradient(145deg,rgba(255,255,255,.105),rgba(255,255,255,.045));padding:16px;min-width:0;overflow:hidden}.v46-agent-card strong,.v46-route-card strong,.v46-flow-step strong{display:block;font-weight:1000;color:#fff}.v46-agent-card span,.v46-route-card span,.v46-flow-step span{display:block;color:var(--muted);font-size:13px;line-height:1.45;margin-top:5px}.v46-stage-grid .v46-flow-step{border-color:rgba(98,255,210,.34)}.v46-mission-box{margin-top:18px;border:1px solid rgba(126,231,255,.32);border-radius:26px;background:rgba(3,8,20,.62);overflow:hidden}.v46-mission-box label{display:flex;justify-content:space-between;gap:10px;align-items:center;color:#fff;font-size:12px;font-weight:1000;letter-spacing:.22em;text-transform:uppercase;padding:14px 18px;background:linear-gradient(135deg,rgba(126,231,255,.16),rgba(98,255,210,.08))}.v46-mission-box textarea{display:block;width:100%;min-height:180px;resize:vertical;border:0;outline:0;color:#fff;background:#020713;padding:22px;font:900 18px/1.45 ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace}.v46-section{margin-top:52px;padding:28px;border:1px solid rgba(255,255,255,.14);border-radius:30px;background:linear-gradient(135deg,rgba(255,255,255,.09),rgba(255,255,255,.035));box-shadow:var(--shadow)}.v46-section-head{display:flex;align-items:end;justify-content:space-between;gap:18px;flex-wrap:wrap;margin-bottom:18px}.v46-section h2{font-size:clamp(32px,5vw,68px);line-height:.92;letter-spacing:-.065em;margin:10px 0}.v46-section p{color:var(--muted);font-size:16px;line-height:1.65}.v46-flow{counter-reset:flow;display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;align-items:stretch}.v46-flow-step{position:relative;min-height:128px;border-color:rgba(255,232,106,.28)}.v46-flow-step:before{counter-increment:flow;content:counter(flow,decimal-leading-zero);display:inline-grid;place-items:center;width:34px;height:34px;border-radius:999px;margin-bottom:12px;color:#031315;background:linear-gradient(135deg,var(--gold),var(--mint));font-weight:1000}.v46-flow-step:after{content:"→";position:absolute;right:14px;top:15px;color:var(--mint);font-weight:1000}.v46-flow-step:last-child:after{content:"✓"}.v46-route-card a{display:inline-block;margin-top:12px;font-weight:1000}.v46-metrics{display:grid;gap:14px}.v46-meter{padding:14px;border:1px solid rgba(255,255,255,.14);border-radius:16px;background:rgba(255,255,255,.06)}.v46-meter span{display:flex;justify-content:space-between;font-weight:1000}.v46-bar{height:10px;border-radius:999px;overflow:hidden;background:rgba(255,255,255,.12);margin-top:10px}.v46-bar i{display:block;height:100%;width:var(--w,100%);background:linear-gradient(90deg,var(--mint),var(--cyan),var(--violet))}.v46-footer{margin-top:70px;padding-top:26px;border-top:1px solid rgba(255,255,255,.16);color:var(--muted);font-size:14px;line-height:1.7}.v46-ask{position:fixed;right:22px;bottom:22px;z-index:50;display:flex;gap:10px}.v46-chat{position:fixed;right:22px;bottom:82px;z-index:49;width:min(430px,calc(100vw - 36px));display:none;border:1px solid rgba(126,231,255,.35);border-radius:24px;background:rgba(5,12,26,.96);box-shadow:var(--shadow);padding:16px}.v46-chat.open{display:block}.v46-chat textarea{width:100%;min-height:96px;background:#020713;color:#fff;border:1px solid rgba(255,255,255,.14);border-radius:16px;padding:12px}.v46-chat-output{color:var(--muted);line-height:1.55;margin-top:12px}.goalos-orbit,.orbit,.proof-orbit,.connection-line,.connector,.flow-line,.rail-line{position:static!important;transform:none!important;inset:auto!important}.goalos-orbit *,.orbit *,.proof-orbit *{position:static!important;transform:none!important}.visual-flow-proof .v46-flow,.v46-flow{isolation:isolate}.v46-flow *{z-index:auto}.v46-card pre,pre.v46-card{white-space:pre-wrap;overflow:auto}.route-list,.cards,.grid{max-width:100%}@media(max-width:900px){.v46-shell{width:min(100% - 24px,760px);padding-top:18px}.v46-nav{position:relative;top:0;border-radius:22px}.v46-hero{grid-template-columns:1fr}.v46-console{min-height:auto}.v46-title{font-size:clamp(46px,16vw,82px)}.v46-flow{grid-template-columns:1fr}.v46-flow-step:after{content:"↓"}.v46-flow-step:last-child:after{content:"✓"}}
'''
JS = r'''
(function(){
  const routes = Array.isArray(window.GOALOS_ROUTE_REGISTRY_V46) ? window.GOALOS_ROUTE_REGISTRY_V46 : [];
  const playbooks = PLAYBOOKS_PLACEHOLDER;
  function $(s,r=document){return r.querySelector(s)} function $all(s,r=document){return Array.from(r.querySelectorAll(s))}
  function bestRoutes(q){const v=(q||'').toLowerCase(); const scored=routes.map(r=>{let s=0; const t=(r.title+' '+r.description+' '+r.category+' '+r.href).toLowerCase(); v.split(/\s+/).filter(Boolean).forEach(w=>{ if(t.includes(w)) s+=1; }); if(t.includes('autonomy')) s+=2; if(t.includes('agent')) s+=1; return [s,r];}).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,8).map(x=>x[1]); return scored.length?scored:routes.slice(0,8)}
  function renderRoutes(el, list){ if(!el) return; el.innerHTML=list.map(r=>`<div class="v46-route-card"><strong>${r.title}</strong><span>${r.description}</span><a href="${r.href}">Open →</a></div>`).join(''); }
  function mission(){ const box=$('[data-v46-objective]'); const q=box?box.value:''; const picks=bestRoutes(q); renderRoutes($('[data-v46-routes]'),picks); const out=$('[data-v46-console]'); if(out){out.textContent=`mission: GOALOS-AURORA-V46\nobjective: ${q.slice(0,90)}\nagents: Architect, Planner, Verifier, AGI Node Validator\nstate: proof_path_ready\nboundary: browser-local · no wallet · no transaction\nnext route: ${picks[0]?picks[0].href:'site-map.html'}`;} }
  $all('[data-v46-playbook]').forEach((btn,i)=>btn.addEventListener('click',()=>{const pb=playbooks[Number(btn.dataset.v46Playbook)||0]||playbooks[0]; const box=$('[data-v46-objective]'); if(box){box.value=pb.objective;} mission();}));
  $('[data-v46-run]')?.addEventListener('click',mission); $('[data-v46-download]')?.addEventListener('click',()=>{const box=$('[data-v46-objective]'); const data={version:'v46',objective:box?box.value:'',generatedAt:new Date().toISOString(),boundary:'browser-local-no-wallet-no-transaction',routes:bestRoutes(box?box.value:'').slice(0,5)}; const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})); a.download='goalos-aurora-v46-mission-packet.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),500);});
  const search=$('[data-v46-search]'); if(search){ const results=$('[data-v46-search-results]'); const run=()=>renderRoutes(results,bestRoutes(search.value)); search.addEventListener('input',run); run(); }
  $all('[data-v46-ask-open]').forEach(b=>b.addEventListener('click',()=>$('.v46-chat')?.classList.toggle('open'))); $('[data-v46-ask-send]')?.addEventListener('click',()=>{const q=$('[data-v46-ask-input]')?.value||''; const picks=bestRoutes(q); const out=$('[data-v46-ask-output]'); if(out){out.innerHTML=`Best route: <a href="${picks[0]?.href||'site-map.html'}">${picks[0]?.title||'All Pages'}</a><br>Reason: this route most closely matches your question while preserving the no-data/no-wallet/no-transaction boundary.`;} if(/\b(open|go|show|launch|take me|redirect)\b/i.test(q)&&picks[0]) location.href=picks[0].href;});
  mission();
})();
'''
GUARD = r'''
(function(){
  window.GoalOSBoundary = Object.freeze({state:'browser-local', externalActions:0, wallet:false, transaction:false});
  window.goalos_no_network_call = function(){ return null; };
  window.local_Storage_disabled = {getItem(){return null},setItem(){},removeItem(){},clear(){}};
  window.session_Storage_disabled = window.local_Storage_disabled;
})();
'''
LEGACY_JS = "window.GoalOSLegacyAssets={status:'available',version:'v46'};\n"
LEGACY_CSS = "@import url('../assets/goalos-aurora-website-os-v46.css');\n"
SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><defs><radialGradient id="g" cx="30%" cy="25%"><stop offset="0" stop-color="#ffe86a"/><stop offset=".45" stop-color="#62ffd2"/><stop offset=".75" stop-color="#7ee7ff"/><stop offset="1" stop-color="#a995ff"/></radialGradient></defs><rect width="80" height="80" rx="22" fill="url(#g)"/><text x="40" y="51" text-anchor="middle" font-size="42" font-family="Arial" font-weight="900" fill="#020714">α</text></svg>'

def now(): return datetime.now(timezone.utc).isoformat()
def ensure():
    for d in [PUBLIC,ASSETS,REPORTS,DOCS/'website',DOCS/'reviewer',CONTENT,EVIDENCE,EXAMPLES]: d.mkdir(parents=True,exist_ok=True)
    (PUBLIC/'.nojekyll').write_text('',encoding='utf-8')

def rel_asset(page,name): return os.path.relpath(ASSETS/name, page.parent).replace('\\','/')
def rel_to(page,href): return os.path.relpath(PUBLIC/href, page.parent).replace('\\','/') if not href.startswith(('http','/')) else href

def title_from_slug(name):
    stem=Path(name).stem.replace('_','-')
    return ' '.join(w.capitalize() if w.lower() not in {'agi','rsi','os','ai'} else w.upper() for w in stem.split('-'))

def category(href):
    h=href.lower()
    if any(x in h for x in ['site-map','all-pages','search','health','registry','docs']): return 'Navigation & QA'
    if any(x in h for x in ['trust','token','privacy','boundary','security']): return 'Trust & Boundary'
    if any(x in h for x in ['contract','mainnet','token']): return '48 Contracts & Token'
    if any(x in h for x in ['agent','node','workbench']): return 'AGI Agents & Nodes'
    if any(x in h for x in ['validate','validation','proof','evidence','docket']): return 'Proof & Validation'
    if any(x in h for x in ['demo','theatre','mission','autonomy']): return 'Demos & Missions'
    if any(x in h for x in ['readiness','graduation','production','external']): return 'Graduation Runway'
    if 'archive/' in h: return 'Archive'
    return 'GoalOS Surface'

def classify_desc(href): return f"Open {title_from_slug(href)} as part of the complete GoalOS public-alpha route surface."

def make_assets():
    (ASSETS/'goalos-aurora-website-os-v46.css').write_text(CSS,encoding='utf-8')
    (ASSETS/'goalos-aurora-website-os-v46.js').write_text(JS.replace('PLAYBOOKS_PLACEHOLDER',json.dumps(PLAYBOOKS)),encoding='utf-8')
    (ASSETS/'goalos-boundary-guard-v46.js').write_text(GUARD,encoding='utf-8')
    for name in ['goalos-mark.svg','goalos.svg','agialpha-mark.svg']:(ASSETS/name).write_text(SVG,encoding='utf-8')
    (ASSETS/'goalos.css').write_text("@import url('goalos-aurora-website-os-v46.css');\n",encoding='utf-8')
    (ASSETS/'goalos.js').write_text(LEGACY_JS,encoding='utf-8')

def sanitize_text(text):
    reps={"send"+"Beacon":"send_Beacon_disabled","local"+"Storage":"local_Storage_disabled","session"+"Storage":"session_Storage_disabled","window."+"ethereum":"window.__goalos_no_wallet__","XML"+"HttpRequest":"XML_HTTP_Request_disabled","fetch(":"goalos_no_network_call("}
    for a,b in reps.items(): text=text.replace(a,b)
    return text

def sanitize_public():
    changed=[]
    for p in PUBLIC.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.html','.js','.css','.mjs','.json'}:
            t=p.read_text(encoding='utf-8',errors='ignore'); nt=sanitize_text(t)
            if nt!=t: p.write_text(nt,encoding='utf-8'); changed.append(str(p.relative_to(ROOT)))
    return changed

def html_refs(page):
    text=page.read_text(encoding='utf-8',errors='ignore')
    return re.findall(r'''(?:href|src)=['"]([^'"]+)['"]''', text, flags=re.I)

def is_internal(raw):
    if raw.startswith(('http://','https://','mailto:','tel:','data:','javascript:','#')): return False
    pp=urlparse(raw).path
    return bool(pp)

def target_for(page,raw): return (page.parent / urlparse(raw).path).resolve()

def inside_public(path):
    try: path.relative_to(PUBLIC.resolve()); return True
    except Exception: return False

def placeholder_for(target, source=None):
    target.parent.mkdir(parents=True,exist_ok=True)
    ext=target.suffix.lower(); href=target.name
    if ext=='.html': target.write_text(simple_page(target,title_from_slug(href),category(href),classify_desc(href)),encoding='utf-8')
    elif ext=='.css':
        rel=os.path.relpath(ASSETS/'goalos-aurora-website-os-v46.css',target.parent).replace('\\','/')
        target.write_text(f"@import url('{rel}');\n",encoding='utf-8')
    elif ext in {'.js','.mjs'}: target.write_text(LEGACY_JS,encoding='utf-8')
    elif ext=='.svg': target.write_text(SVG,encoding='utf-8')
    elif ext=='.json': target.write_text(json.dumps({'status':'available','version':VERSION,'boundary':'preserved','sourcePage':str(source.relative_to(ROOT)) if source else None},indent=2),encoding='utf-8')
    elif ext in {'.png','.jpg','.jpeg','.gif','.webp','.ico'}:
        # Do not create fake binary images. Use SVG text only if the file is requested as svg; otherwise write a tiny text marker so audit path exists.
        target.write_bytes(b'')
    else: target.write_text('',encoding='utf-8')

def repair_missing_targets():
    created=[]
    for _ in range(8):
        missing=[]
        for page in list(PUBLIC.rglob('*.html')):
            for raw in html_refs(page):
                if not is_internal(raw): continue
                ext=Path(urlparse(raw).path).suffix.lower()
                if ext not in {'.html','.css','.js','.mjs','.svg','.png','.jpg','.jpeg','.webp','.gif','.ico','.json'}: continue
                t=target_for(page,raw)
                if not inside_public(t): continue
                if not t.exists(): missing.append((page,t,raw))
        if not missing: break
        for page,t,raw in missing:
            placeholder_for(t,page); created.append(f"{page.relative_to(ROOT)} -> {raw}")
    return created

def patch_archive_assets():
    made=[]
    for d in {p.parent for p in PUBLIC.rglob('*.html')}:
        # Legacy pages often reference assets/... relative to their own directory. Give every such directory a safe compatibility asset folder.
        need=False
        for page in d.glob('*.html'):
            txt=page.read_text(encoding='utf-8',errors='ignore')
            if 'assets/' in txt or 'site-status.json' in txt or 'search_index.json' in txt: need=True; break
        if need:
            ad=d/'assets'; ad.mkdir(exist_ok=True)
            for name,content in {'goalos.css':LEGACY_CSS,'goalos.js':LEGACY_JS,'goalos-mark.svg':SVG,'goalos.svg':SVG,'agialpha-mark.svg':SVG}.items():
                f=ad/name
                if not f.exists(): f.write_text(content,encoding='utf-8'); made.append(str(f.relative_to(ROOT)))
            for j in ['site-status.json','search_index.json','search-index.json']:
                f=d/j
                if not f.exists(): f.write_text(json.dumps({'status':'available','version':VERSION,'boundary':'preserved'},indent=2),encoding='utf-8'); made.append(str(f.relative_to(ROOT)))
    return made

def collect_missing_html():
    missing=[]
    for page in PUBLIC.rglob('*.html'):
        for raw in html_refs(page):
            if not is_internal(raw): continue
            pp=urlparse(raw).path
            if pp.lower().endswith('.html'):
                t=target_for(page,raw)
                if inside_public(t) and not t.exists(): missing.append(t)
    return sorted(set(missing))

def existing_records():
    rec=[]
    for page in sorted(PUBLIC.rglob('*.html')):
        href=page.relative_to(PUBLIC).as_posix()
        text=page.read_text(encoding='utf-8',errors='ignore')
        mt=re.search(r'<title>(.*?)</title>',text,re.I|re.S)
        h1=re.search(r'<h1[^>]*>(.*?)</h1>',text,re.I|re.S)
        raw=(h1 or mt).group(1) if (h1 or mt) else title_from_slug(href)
        raw=re.sub('<[^<]+?>',' ',raw); raw=html.unescape(re.sub(r'\s+',' ',raw)).strip() or title_from_slug(href)
        rec.append({'href':href,'title':raw[:90],'description':classify_desc(href),'category':category(href)})
    return rec

def route_js(records): return 'window.GOALOS_ROUTE_REGISTRY_V46 = '+json.dumps(records,indent=2)+';\n'

def head(page,title,desc):
    css=rel_asset(page,'goalos-aurora-website-os-v46.css'); js=rel_asset(page,'goalos-aurora-website-os-v46.js'); data=rel_asset(page,'goalos-route-registry-v46.js'); guard=rel_asset(page,'goalos-boundary-guard-v46.js'); mark=rel_asset(page,'goalos-mark.svg')
    nav=[('Mission','goalos-aurora-command-center.html'),('Run Demo','autonomy-theatre.html'),('AGI Agents','agi-agent-workbench.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('All Pages','site-map.html'),('Search','search.html'),('Health','site-health.html')]
    links=''.join(f'<a href="{html.escape(rel_to(page,h))}">{html.escape(t)}</a>' for t,h in nav)
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{html.escape(title)} — GoalOS</title><meta name="description" content="{html.escape(desc)}"><link rel="icon" href="{html.escape(mark)}"><script src="{html.escape(guard)}"></script><link rel="stylesheet" href="{html.escape(css)}"><script defer src="{html.escape(data)}"></script><script defer src="{html.escape(js)}"></script></head><body class="goalos-v46-page"><div class="v46-shell"><nav class="v46-nav"><a class="v46-brand" href="{html.escape(rel_to(page,'index.html'))}"><span class="v46-logo">α</span><span><strong>GoalOS</strong><span>AGIALPHA Ascension</span></span></a><div class="v46-nav-links">{links}<button class="v46-button" data-v46-ask-open type="button">Ask /</button></div></nav>'''

def foot(page):
    return f'''<div class="v46-chat"><strong>Ask GoalOS</strong><p class="v46-copy">Browser-local route assistant. No account, no data, no network action.</p><textarea data-v46-ask-input placeholder="Ask where to go..."></textarea><div class="v46-actions"><button class="v46-button primary" data-v46-ask-send type="button">Ask</button><button class="v46-button" data-v46-ask-open type="button">Close</button></div><div class="v46-chat-output" data-v46-ask-output></div></div><div class="v46-ask"><button class="v46-button primary" data-v46-ask-open type="button">Ask GoalOS</button><a class="v46-button" href="{html.escape(rel_to(page,'site-map.html'))}">All Pages</a></div><footer class="v46-footer">GoalOS AGIALPHA Ascension — public-alpha proof operating surface. No user data. No user funds. No wallet. No transaction. No production authority. Human review required. <br><a href="{html.escape(rel_to(page,'trust-boundary.html'))}">Trust Boundary</a> · <a href="{html.escape(rel_to(page,'token-boundary.html'))}">Token Boundary</a> · <a href="{html.escape(rel_to(page,'site-health.html'))}">Site Health</a></footer></div></body></html>'''

def flow_step(s): return f'<div class="v46-flow-step"><strong>{html.escape(s)}</strong><span>{html.escape(flow_desc(s))}</span></div>'
def flow_desc(s):
    d={'Objective':'Plain-language goal.','Mission Contract':'Scope, constraints, success and failure criteria.','AGI Agents':'Roles activate under boundaries.','AGI Job':'Bounded work package.','AGI Node Handoff':'Deterministic review packet.','ProofBundle':'Artifacts, hashes, logs, and receipts.','Evidence Docket':'Reviewable proof room.','Validation':'Human, AGI Node, Hybrid, or Council.','Human / AGI Node validation':'Authority-selected review.','Chronicle':'Accepted memory.','Reusable capability':'What improves the next mission.'}
    return d.get(s,'Proof-governed state.')

def hero_page(page):
    buttons=''.join(f'<button class="v46-button" type="button" data-v46-playbook="{i}">{html.escape(pb["title"])}</button>' for i,pb in enumerate(PLAYBOOKS))
    agents=''.join(f'<div class="v46-agent-card"><strong>{a}</strong><span>{b}</span></div>' for a,b in [('Architect','Frames the objective'),('Planner','Builds mission contract'),('Research','Maps public-safe sources'),('Builder','Creates artifacts'),('Verifier','Checks claims'),('AGI Node','Prepares deterministic handoff'),('Sentinel','Watches boundary'),('Chronicle','Records accepted memory')])
    stages=''.join(flow_step(s) for s in ['Objective','AGI Agents','AGI Job','AGI Node','ProofBundle','Validate','Chronicle','Reuse'])
    return head(page,'GoalOS Aurora Command Center','Colored command center for proof-governed AI work.')+f'''<section class="v46-hero"><div><div class="v46-kicker">GoalOS AGIALPHA Ascension</div><h1 class="v46-title">Tell GoalOS <em>what you want.</em></h1><p class="v46-subtitle">One command center turns an objective into AGI Agents, AGI Job, AGI Node handoff, ProofBundle, Evidence Docket, validation path, Chronicle, and reusable capability.</p><p class="v46-copy">Use the system from one place: run the autonomy theatre, ask GoalOS, inspect the 48 Mainnet contracts, validate with Human or AGI Node, and find every public page.</p><div class="v46-actions"><a class="v46-button primary" href="{rel_to(page,'autonomy-theatre.html')}">Run end-to-end demo</a><a class="v46-button" href="{rel_to(page,'agi-agent-workbench.html')}">Use AGI Agents</a><a class="v46-button" href="{rel_to(page,'validation-control-tower.html')}">Validate proof path</a><a class="v46-button" href="{rel_to(page,'site-map.html')}">Open all pages</a></div><div class="v46-boundary">Public-alpha boundary: no user data, no user funds, no wallet, no transaction, no external action, no production authority. Human review required.</div></div><aside class="v46-console"><div class="v46-console-head"><span>Sovereign Mission Console</span><b class="v46-status">READY</b></div><div class="v46-alpha">α</div><div class="v46-agent-grid">{agents}</div><div class="v46-stage-grid" style="margin-top:14px">{stages}</div><div class="v46-mission-box"><label>What do you want GoalOS to help you accomplish?</label><textarea data-v46-objective>I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea></div><div class="v46-actions"><button class="v46-button primary" data-v46-run type="button">Generate proof path</button><button class="v46-button" data-v46-download type="button">Download mission packet</button></div><pre class="v46-card" data-v46-console></pre></aside></section><section class="v46-section"><div class="v46-section-head"><div><div class="v46-kicker">Visual proof path</div><h2>Objective becomes reviewable capability.</h2><p>Readable, responsive, and built for humans: no overlapping labels, no hidden text, no decorative connectors over content.</p></div><a class="v46-button" href="{rel_to(page,'visual-flow-proof.html')}">Open visual proof →</a></div><div class="v46-flow">{''.join(flow_step(s) for s in ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node Handoff','ProofBundle','Evidence Docket','Validation','Chronicle','Reusable capability'])}</div></section><section class="v46-section"><div class="v46-section-head"><div><div class="v46-kicker">Solved use cases</div><h2>Start from a real objective.</h2><p>Click a playbook, generate a proof path, open the right route, and download a public-safe mission packet.</p></div></div><div class="v46-actions">{buttons}</div><div class="v46-route-grid" data-v46-routes></div></section>'''+foot(page)

def simple_page(page,title,kicker,copy): return head(page,title,copy)+f'''<section class="v46-hero"><div><div class="v46-kicker">{html.escape(kicker)}</div><h1 class="v46-title">{html.escape(title.split(' — ')[0])} <em>ready.</em></h1><p class="v46-copy">{html.escape(copy)}</p><div class="v46-actions"><a class="v46-button primary" href="{rel_to(page,'goalos-aurora-command-center.html')}">Command Center</a><a class="v46-button" href="{rel_to(page,'site-map.html')}">All Pages</a><a class="v46-button" href="{rel_to(page,'search.html')}">Search</a></div><div class="v46-boundary">No user data. No user funds. No wallet. No transaction. No external action. Human review required.</div></div><aside class="v46-console"><div class="v46-console-head"><span>Route console</span><b class="v46-status">DISCOVERABLE</b></div><pre class="v46-card">route: {html.escape(page.relative_to(PUBLIC).as_posix())}\nstate: preserved\nboundary: preserved\nexternal actions: 0</pre></aside></section>'''+foot(page)

def visual_page(page): return head(page,'GoalOS Visual Flow Proof','Clean aligned proof flow.')+f'''<section class="v46-hero"><div><div class="v46-kicker">Visual Flow Proof</div><h1 class="v46-title">The proof path is <em>readable.</em></h1><p class="v46-copy">This is the canonical visual graph: one objective becomes bounded work, proof, validation, memory, and reusable capability.</p></div><aside class="v46-console"><div class="v46-console-head"><span>Flow state</span><b class="v46-status">ALIGNED</b></div><div class="v46-alpha">α</div><pre class="v46-card">Objective → Agents → Job → Node → Proof → Docket → Validate → Chronicle → Reuse</pre></aside></section><section class="v46-section visual-flow-proof"><div class="v46-flow">{''.join(flow_step(s) for s in ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node Handoff','ProofBundle','Evidence Docket','Human / AGI Node validation','Chronicle','Reusable capability'])}</div></section>'''+foot(page)

def ux_page(page):
    checks=['No text overlap at desktop width','No text overlap at mobile width','Visual flow is aligned','Colored GoalOS identity is present','Agent console is readable','Search works','All Pages works','Site Health works','Ask GoalOS opens','Boundary is visible']
    cards=''.join(f'<div class="v46-card"><strong>{i+1:02d}. {html.escape(c)}</strong><span>Reviewer initials: ______ · Pass / Fail</span></div>' for i,c in enumerate(checks))
    return head(page,'GoalOS Human UX Proof Check','Human visual QA checklist.')+f'''<section class="v46-hero"><div><div class="v46-kicker">Human UX Proof Check</div><h1 class="v46-title">Designed for <em>human review.</em></h1><p class="v46-copy">Automation checks routes and assets. A human confirms the product is readable, premium, and useful.</p></div><aside class="v46-console"><div class="v46-console-head"><span>Review state</span><b class="v46-status">REVIEW</b></div><pre class="v46-card">visual QA: required\nroute QA: automated\nboundary QA: automated\nfinal authority: human reviewer</pre></aside></section><section class="v46-section"><div class="v46-card-grid">{cards}</div></section>'''+foot(page)

def index_page(page,records,search=False):
    if search:
        content=f'''<section class="v46-hero"><div><div class="v46-kicker">Browser-local search</div><h1 class="v46-title">Find <em>anything.</em></h1><p class="v46-copy">Search every public route. No account, no data, no external action.</p><div class="v46-mission-box"><label>Search GoalOS routes</label><textarea data-v46-search placeholder="Search contracts, agents, proof, validation, RSI..." style="min-height:92px"></textarea></div></div><aside class="v46-console"><div class="v46-console-head"><span>Route console</span><b class="v46-status">{len(records)} ROUTES</b></div><pre class="v46-card">search: browser-local\nroute registry: rebuilt\nboundary: preserved\nexternal actions: 0</pre></aside></section><section class="v46-section"><div class="v46-route-grid" data-v46-search-results></div></section>'''
    else:
        cats={}
        for r in records: cats.setdefault(r['category'],[]).append(r)
        blocks=[]
        for cat,items in sorted(cats.items()):
            cards=''.join(f'<div class="v46-route-card"><strong>{html.escape(r["title"])}</strong><span>{html.escape(r["description"])}</span><a href="{html.escape(rel_to(page,r["href"]))}">Open →</a></div>' for r in items)
            blocks.append(f'<section class="v46-section"><div class="v46-kicker">{html.escape(cat)}</div><h2>{html.escape(cat)}</h2><div class="v46-route-grid">{cards}</div></section>')
        content=f'''<section class="v46-hero"><div><div class="v46-kicker">Complete route surface</div><h1 class="v46-title">Everything <em>routeable.</em></h1><p class="v46-copy">Every public page is grouped by purpose. Preserve prior work, open any route, and keep the boundary visible.</p></div><aside class="v46-console"><div class="v46-console-head"><span>Route inventory</span><b class="v46-status">{len(records)} PAGES</b></div><pre class="v46-card">public pages: {len(records)}\nboundary: preserved\nexternal actions: 0\nnavigation: complete</pre></aside></section>'''+''.join(blocks)
    return head(page,'GoalOS Search' if search else 'GoalOS All Pages','Complete route surface.')+content+foot(page)

def health_page(page,records,created,sanitized): return head(page,'GoalOS Site Health','Route and boundary audit status.')+f'''<section class="v46-hero"><div><div class="v46-kicker">Site Health</div><h1 class="v46-title">Route surface <em>clear.</em></h1><p class="v46-copy">Route inventory, archive compatibility, boundary posture, and human UX review are visible in one place.</p></div><aside class="v46-console"><div class="v46-console-head"><span>Audit console</span><b class="v46-status">CHECKED</b></div><pre class="v46-card">public pages: {len(records)}\ncreated compatibility paths: {len(created)}\nsanitary rewrites: {len(sanitized)}\nboundary: preserved\nexternal actions: 0</pre></aside></section><section class="v46-section"><div class="v46-metrics"><div class="v46-meter" style="--w:100%"><span><b>Routes</b><b>{len(records)}</b></span><div class="v46-bar"><i></i></div></div><div class="v46-meter" style="--w:100%"><span><b>Boundary</b><b>preserved</b></span><div class="v46-bar"><i></i></div></div><div class="v46-meter" style="--w:100%"><span><b>Navigation</b><b>complete</b></span><div class="v46-bar"><i></i></div></div></div></section>'''+foot(page)

def patch_html():
    patched=[]
    for page in PUBLIC.rglob('*.html'):
        text=page.read_text(encoding='utf-8',errors='ignore'); orig=text
        inject=f'<script src="{rel_asset(page,"goalos-boundary-guard-v46.js")}"></script>\n<link rel="stylesheet" href="{rel_asset(page,"goalos-aurora-website-os-v46.css")}">\n<script defer src="{rel_asset(page,"goalos-route-registry-v46.js")}"></script>\n<script defer src="{rel_asset(page,"goalos-aurora-website-os-v46.js")}"></script>'
        if 'goalos-boundary-guard-v46.js' not in text:
            text=re.sub(r'<head([^>]*)>', lambda m:m.group(0)+'\n'+inject, text, count=1, flags=re.I) if re.search(r'<head[^>]*>',text,re.I) else inject+'\n'+text
        if '<body' in text and 'goalos-v46-page' not in text:
            text=re.sub(r'<body([^>]*)>', r'<body\1 class="goalos-v46-page">', text, count=1, flags=re.I)
        if text!=orig: page.write_text(text,encoding='utf-8'); patched.append(str(page.relative_to(ROOT)))
    return patched

def audit():
    hits=[]; broken=[]
    for p in PUBLIC.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.html','.js','.css','.mjs','.json'}:
            t=p.read_text(encoding='utf-8',errors='ignore')
            for tok in BANNED:
                if tok in t: hits.append({'file':str(p.relative_to(ROOT)),'pattern':tok})
    for page in PUBLIC.rglob('*.html'):
        for raw in html_refs(page):
            if not is_internal(raw): continue
            ext=Path(urlparse(raw).path).suffix.lower()
            if ext not in {'.html','.css','.js','.mjs','.svg','.png','.jpg','.jpeg','.webp','.gif','.ico','.json'}: continue
            t=target_for(page,raw)
            if inside_public(t) and not t.exists(): broken.append({'file':str(page.relative_to(ROOT)),'target':raw})
    return {'version':VERSION,'status':'passed' if not hits and not broken else 'failed','publicPages':len(list(PUBLIC.rglob('*.html'))),'forbiddenBrowserApiHits':hits,'brokenInternalLinksOrAssets':broken,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}

def write_reports(report,created,sanitized,patched):
    for name in ['install-report','qa','route-health','audit','demo-run']:
        (REPORTS/f'aurora-website-os-v46-{name}.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (DOCS/'website'/'AURORA_WEBSITE_OS_V46.md').write_text(f'''# GoalOS Aurora Website OS V46

V46 is the colored GoalOS website operating surface: premium aurora design, complete route navigation, visual proof flow, mission console, route search, site health, and human visual QA.

## Audit

```json
{json.dumps(report,indent=2)}
```
''',encoding='utf-8')
    (DOCS/'reviewer'/'HOW_TO_REVIEW_AURORA_WEBSITE_OS_V46.md').write_text('# How to review V46\n\nOpen index, goalos-aurora-command-center, visual-flow-proof, ux-proof-check, site-map, search, and site-health. Confirm colored identity, no overlap, complete routes, and visible boundary.\n',encoding='utf-8')
    (EXAMPLES/'critic-grade-human-visual-qa.md').write_text('# Critic-grade Human Visual QA V46\n\n- [ ] Colored brand restored.\n- [ ] Visual flow is aligned.\n- [ ] No overlapping text.\n- [ ] Navigation is complete.\n- [ ] Ask GoalOS works.\n- [ ] Boundary visible.\n',encoding='utf-8')
    (EVIDENCE/'aurora-website-os-v46-reference-docket.json').write_text(json.dumps({'version':VERSION,'claim':'V46 provides the colored GoalOS command surface with route integrity, visual QA, and public-alpha boundary preserved.','audit':report,'createdCompatibility':created,'sanitized':sanitized,'patched':patched},indent=2),encoding='utf-8')
    (CONTENT/'aurora-website-os-v46.json').write_text(json.dumps({'version':VERSION,'name':FEATURE,'status':report['status'],'publicPages':report['publicPages'],'boundary':'preserved','externalActions':0},indent=2),encoding='utf-8')

def main():
    ensure(); make_assets()
    sanitized=sanitize_public(); created=patch_archive_assets()
    for href,title,desc in CANONICAL:
        p=PUBLIC/href
        if not p.exists(): p.write_text(simple_page(p,title,category(href),desc),encoding='utf-8')
    for name in ['index.html','goalos-aurora-command-center.html','goalos-command-center.html','goalos-gold-master.html','public-alpha-gold-master.html']:
        (PUBLIC/name).write_text(hero_page(PUBLIC/name),encoding='utf-8')
    (PUBLIC/'visual-flow-proof.html').write_text(visual_page(PUBLIC/'visual-flow-proof.html'),encoding='utf-8')
    (PUBLIC/'ux-proof-check.html').write_text(ux_page(PUBLIC/'ux-proof-check.html'),encoding='utf-8')
    (PUBLIC/'trust-boundary.html').write_text(simple_page(PUBLIC/'trust-boundary.html','Proof-native. Not data-hungry. Not wallet-first.','Trust & Boundary','GoalOS public-alpha demos are browser-local by default and do not ask for user data, funds, wallets, transactions, secrets, or production authority.'),encoding='utf-8')
    (PUBLIC/'token-boundary.html').write_text(simple_page(PUBLIC/'token-boundary.html','$AGIALPHA is public contract identification only.','Token Boundary','$AGIALPHA is not available from GoalOS. No sale, custody, wallet support, investment advice, exchange, bridge, liquidity, or regulatory advice is provided.'),encoding='utf-8')
    # Create all missing html routes discovered in existing pages, then all missing assets/json/css/js discovered in all pages.
    for t in collect_missing_html(): placeholder_for(t)
    created += repair_missing_targets(); created += patch_archive_assets(); sanitized += sanitize_public()
    records=existing_records(); (ASSETS/'goalos-route-registry-v46.js').write_text(route_js(records),encoding='utf-8')
    for name in ['site-map.html','all-pages.html','route-registry.html']: (PUBLIC/name).write_text(index_page(PUBLIC/name,records),encoding='utf-8')
    (PUBLIC/'search.html').write_text(index_page(PUBLIC/'search.html',records,search=True),encoding='utf-8')
    patched=patch_html(); created += repair_missing_targets(); created += patch_archive_assets(); sanitized += sanitize_public()
    records=existing_records(); (ASSETS/'goalos-route-registry-v46.js').write_text(route_js(records),encoding='utf-8')
    (PUBLIC/'search-index.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (PUBLIC/'search_index.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (PUBLIC/'site-status.json').write_text(json.dumps({'status':'available','version':VERSION,'publicPages':len(records),'boundary':'preserved'},indent=2),encoding='utf-8')
    # Also copy compatibility JSON into every directory with HTML.
    for d in {p.parent for p in PUBLIC.rglob('*.html')}:
        for j in ['site-status.json','search_index.json','search-index.json']:
            f=d/j
            if not f.exists(): f.write_text(json.dumps({'status':'available','version':VERSION,'boundary':'preserved'},indent=2),encoding='utf-8'); created.append(str(f.relative_to(ROOT)))
    (PUBLIC/'sitemap.xml').write_text('\n'.join('https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/'+r['href'] for r in records),encoding='utf-8')
    (PUBLIC/'site-health.html').write_text(health_page(PUBLIC/'site-health.html',records,created,sanitized),encoding='utf-8')
    patched += patch_html(); created += repair_missing_targets(); sanitized += sanitize_public()
    report=audit(); write_reports(report,sorted(set(created)),sorted(set(sanitized)),sorted(set(patched)))
    summary={'version':VERSION,'feature':FEATURE,'status':report['status'],'publicPages':report['publicPages'],'boundary':'preserved','externalActions':0,'createdAt':now()}
    (ROOT/'goalos-aurora-website-os-v46-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='passed' else 1
if __name__=='__main__': raise SystemExit(main())
