window.GOALOS_V24_ROUTES = [
  {
    "href": "agialpha-control-rail.html",
    "title": "$AGIALPHA Control Rail",
    "category": "Additional / Preserved",
    "description": "Review the public contract identification boundary and $AGIALPHA non-availability statement.",
    "system": false,
    "priority": 0
  },
  {
    "href": "adoption.html",
    "title": "Adoption Playbook · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Adoption Playbook · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "agi-alpha-thesis.html",
    "title": "AGI ALPHA Thesis",
    "category": "Additional / Preserved",
    "description": "Open AGI ALPHA Thesis as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "coordination-console.html",
    "title": "Coordination Console",
    "category": "Additional / Preserved",
    "description": "Open Coordination Console as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "data-room.html",
    "title": "Data Room · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "demo-gallery.html",
    "title": "Demo Gallery — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Demo Gallery — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "demo-launcher.html",
    "title": "Demo Launcher — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Demo Launcher — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "demo-safety.html",
    "title": "Demo Safety Boundary — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Demo Safety Boundary — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "enterprise.html",
    "title": "Enterprise Readiness · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Enterprise Readiness · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evaluation-program.html",
    "title": "Evaluation Program",
    "category": "Additional / Preserved",
    "description": "Open Evaluation Program as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evaluation.html",
    "title": "Evaluation · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Evaluation · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "executive-brief.html",
    "title": "Executive Brief · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Executive Brief · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "for-new-users.html",
    "title": "For New Users — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open For New Users — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "frontier-release-case-study.html",
    "title": "Frontier Release Case Study",
    "category": "Additional / Preserved",
    "description": "Open Frontier Release Case Study as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "frontier-release-doctrine.html",
    "title": "Frontier Release Doctrine",
    "category": "Additional / Preserved",
    "description": "Open Frontier Release Doctrine as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "frontier-release-room.html",
    "title": "Frontier Release Room",
    "category": "Additional / Preserved",
    "description": "Open Frontier Release Room as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "action-reason-trace-contract.html",
    "title": "GoalOS Action-Reason Trace Contract — No Action Without Reason",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Action-Reason Trace Contract — No Action Without Reason as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "document-series.html",
    "title": "GoalOS Document Series",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Document Series as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evolution-ledger-control-room.html",
    "title": "GoalOS Evolution Ledger Control Room — Proof, Not Secrets",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Evolution Ledger Control Room — Proof, Not Secrets as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "historical-command-center.html",
    "title": "GoalOS Historical Command Center",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Historical Command Center as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "institutional-deployment-wedge.html",
    "title": "GoalOS Institutional Deployment Wedge — Earn the Right to Scale",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Institutional Deployment Wedge — Earn the Right to Scale as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "launch-narrative.html",
    "title": "GoalOS Launch Narrative",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Launch Narrative as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "open-ended-work-engine.html",
    "title": "GoalOS Open-Ended Work Engine Lab — Generate Tasks. Gate Descendants.",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Open-Ended Work Engine Lab — Generate Tasks. Gate Descendants. as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "console.html",
    "title": "GoalOS Proof Console",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof Console as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-experience-atlas.html",
    "title": "GoalOS Proof Experience Atlas — From output to proof",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof Experience Atlas — From output to proof as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-gradient-lab.html",
    "title": "GoalOS Proof Gradient Lab — No proof, no evolution",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof Gradient Lab — No proof, no evolution as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-mission-forge.html",
    "title": "GoalOS Proof Mission Forge — Turn an objective into a proof mission",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof Mission Forge — Turn an objective into a proof mission as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-backed-upgrade-rights-room.html",
    "title": "GoalOS Proof-Backed Upgrade Rights Room — Earn the Right to Scale",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof-Backed Upgrade Rights Room — Earn the Right to Scale as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-carrying-artifact-foundry.html",
    "title": "GoalOS Proof-Carrying Artifact Foundry — Make Reusable Intelligence Earn Authority",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof-Carrying Artifact Foundry — Make Reusable Intelligence Earn Authority as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-to-action-command-room.html",
    "title": "GoalOS Proof-to-Action Command Room — Governed Decision State",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Proof-to-Action Command Room — Governed Decision State as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "site-health.html",
    "title": "GoalOS Site Health",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Site Health as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "sovereign-experience-stream-lab.html",
    "title": "GoalOS Sovereign Experience Stream Lab — Proof Becomes Governed Experience",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Sovereign Experience Stream Lab — Proof Becomes Governed Experience as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "index.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Additional / Preserved",
    "description": "Front-door one-box interface: enter an objective and receive a mission contract, proof path, route cards, and reviewer package.",
    "system": false,
    "priority": 10
  },
  {
    "href": "governance.html",
    "title": "Governance · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Governance · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "holy-grail-candidate.html",
    "title": "Holy Grail Candidate",
    "category": "Additional / Preserved",
    "description": "Open Holy Grail Candidate as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "archive/index-before-website-experience-os-v2.html",
    "title": "Home · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Home · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "independent-validation.html",
    "title": "Independent Validation · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Independent Validation · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "launch.html",
    "title": "Launch Package · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Launch Package · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "mission-os-canon.html",
    "title": "Mission OS Canon",
    "category": "Additional / Preserved",
    "description": "Open Mission OS Canon as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "mission-os.html",
    "title": "Mission OS · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Mission OS · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "operator-checklist.html",
    "title": "Operator Checklist — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Operator Checklist — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "operators.html",
    "title": "Operator Console Blueprint · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Operator Console Blueprint · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "paper-to-product.html",
    "title": "Paper to Product",
    "category": "Additional / Preserved",
    "description": "Open Paper to Product as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "product.html",
    "title": "Product · GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Product · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-card-studio.html",
    "title": "Proof Card Studio — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Proof Card Studio — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-flight-demo.html",
    "title": "Proof Flight Demo — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Proof Flight Demo — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-mission-slots.html",
    "title": "Proof Mission Slots — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Proof Mission Slots — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-velocity.html",
    "title": "Proof Velocity · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Proof Velocity · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-of-evolution.html",
    "title": "Proof-of-Evolution",
    "category": "Additional / Preserved",
    "description": "Open Proof-of-Evolution as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "public-proof-ledger.html",
    "title": "Public Proof Ledger · GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Public Proof Ledger · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "release-gates.html",
    "title": "Release Gates · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Release Gates · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "repository-map.html",
    "title": "Repository Map · GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Repository Map · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "roadmap.html",
    "title": "Roadmap · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Roadmap · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "run-locally.html",
    "title": "Run Locally — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Run Locally — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "source-lineage.html",
    "title": "Source Lineage · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Source Lineage · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "sovereign-experience-stream.html",
    "title": "Sovereign Experience Stream Lab · GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Sovereign Experience Stream Lab · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "standards.html",
    "title": "Standards · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Standards · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "troubleshooting.html",
    "title": "Troubleshooting · GoalOS Ascension",
    "category": "Additional / Preserved",
    "description": "Open Troubleshooting · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "website-operating-system.html",
    "title": "Website Operating System — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open Website Operating System — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "what-goalos-does.html",
    "title": "What GoalOS Does — GoalOS",
    "category": "Additional / Preserved",
    "description": "Open What GoalOS Does — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "agent-constellation-demo.html",
    "title": "Agent Constellation Demo — GoalOS",
    "category": "Architecture & Research",
    "description": "Open Agent Constellation Demo — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "agents.html",
    "title": "Agent Foundry · GoalOS Ascension",
    "category": "Architecture & Research",
    "description": "Open Agent Foundry · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "agi-alpha-node-v0.html",
    "title": "AGI Alpha Node v0",
    "category": "Architecture & Research",
    "description": "Open AGI Alpha Node v0 as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "jobs.html",
    "title": "AGI Jobs Ledger · GoalOS Ascension",
    "category": "Architecture & Research",
    "description": "Open AGI Jobs Ledger · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "agi-jobs-v0-v2.html",
    "title": "AGI Jobs v0 (v2)",
    "category": "Architecture & Research",
    "description": "Open AGI Jobs v0 (v2) as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "architecture.html",
    "title": "Architecture · GoalOS",
    "category": "Architecture & Research",
    "description": "Open Architecture · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "multi-agent-institution.html",
    "title": "GoalOS Multi-Agent Institution — Not a Swarm. An Institution.",
    "category": "Architecture & Research",
    "description": "Open GoalOS Multi-Agent Institution — Not a Swarm. An Institution. as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "meta-agentic-alpha-agi.html",
    "title": "META-AGENTIC α-AGI",
    "category": "Architecture & Research",
    "description": "Open META-AGENTIC α-AGI as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "node.html",
    "title": "Node Runtime · GoalOS Ascension",
    "category": "Architecture & Research",
    "description": "Open Node Runtime · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "research-spine.html",
    "title": "Research Spine",
    "category": "Architecture & Research",
    "description": "Find every public route and understand how it fits the GoalOS proof curriculum.",
    "system": false,
    "priority": 0
  },
  {
    "href": "capability-stack.html",
    "title": "Capability Stack · GoalOS",
    "category": "Capability & Economy",
    "description": "Open Capability Stack · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "capability-compounding-lab.html",
    "title": "GoalOS Capability Compounding Lab — Verified Work Becomes Reusable Capability",
    "category": "Capability & Economy",
    "description": "Open GoalOS Capability Compounding Lab — Verified Work Becomes Reusable Capability as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "capability-parity.html",
    "title": "GoalOS Capability Parity",
    "category": "Capability & Economy",
    "description": "Open GoalOS Capability Parity as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-settlement-chronicle-lab.html",
    "title": "GoalOS Proof-Settlement Chronicle Lab",
    "category": "Capability & Economy",
    "description": "Open GoalOS Proof-Settlement Chronicle Lab as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "value-realization-control-room.html",
    "title": "GoalOS Value Realization Control Room — Verified Work Becomes Allocable Capacity",
    "category": "Capability & Economy",
    "description": "Open GoalOS Value Realization Control Room — Verified Work Becomes Allocable Capacity as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "local-autopilot-demo.html",
    "title": "Local Autopilot Demo — GoalOS",
    "category": "Capability & Economy",
    "description": "Open Local Autopilot Demo — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "pilot-program.html",
    "title": "Pilot Program · GoalOS",
    "category": "Capability & Economy",
    "description": "Open Pilot Program · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "pilot-proof.html",
    "title": "Pilot Proof · GoalOS Ascension",
    "category": "Capability & Economy",
    "description": "Open Pilot Proof · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-economy.html",
    "title": "Proof Economy · GoalOS Ascension",
    "category": "Capability & Economy",
    "description": "Open Proof Economy · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "metrics.html",
    "title": "Proof Metrics Dashboard · GoalOS",
    "category": "Capability & Economy",
    "description": "Open Proof Metrics Dashboard · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-metrics-dashboard.html",
    "title": "Proof Metrics Dashboard · GoalOS",
    "category": "Capability & Economy",
    "description": "Open Proof Metrics Dashboard · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "public-metrics-ledger.html",
    "title": "Public Metrics Ledger · GoalOS Ascension",
    "category": "Capability & Economy",
    "description": "Open Public Metrics Ledger · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "website-autopilot.html",
    "title": "Website Autopilot · GoalOS",
    "category": "Capability & Economy",
    "description": "Open Website Autopilot · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "commercial-evidence.html",
    "title": "Commercial Evidence · GoalOS",
    "category": "Evidence & Review",
    "description": "Open Commercial Evidence · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "docket-builder.html",
    "title": "Evidence Docket Builder — GoalOS",
    "category": "Evidence & Review",
    "description": "Open Evidence Docket Builder — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evidence.html",
    "title": "Evidence Layer · GoalOS Ascension",
    "category": "Evidence & Review",
    "description": "Open Evidence Layer · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evidence-room.html",
    "title": "Evidence Room · GoalOS Ascension",
    "category": "Evidence & Review",
    "description": "Open Evidence Room · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evidence-to-scale.html",
    "title": "Evidence to Scale · GoalOS Ascension",
    "category": "Evidence & Review",
    "description": "Open Evidence to Scale · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "falsification-box.html",
    "title": "Falsification Box — GoalOS",
    "category": "Evidence & Review",
    "description": "Open Falsification Box — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "for-reviewers.html",
    "title": "For Reviewers — GoalOS",
    "category": "Evidence & Review",
    "description": "Open For Reviewers — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "reviewer-path.html",
    "title": "For Reviewers — GoalOS",
    "category": "Evidence & Review",
    "description": "Open For Reviewers — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "evidence-docket-theatre.html",
    "title": "GoalOS Evidence Docket Theatre — A proof page is not a marketing page",
    "category": "Evidence & Review",
    "description": "Open GoalOS Evidence Docket Theatre — A proof page is not a marketing page as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "external-reviewer-replay-room.html",
    "title": "GoalOS External Reviewer Replay Room — Independent Review Path",
    "category": "Evidence & Review",
    "description": "Open GoalOS External Reviewer Replay Room — Independent Review Path as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "falsification-gauntlet.html",
    "title": "GoalOS Falsification Gauntlet V1.2 — Claim-Sensitive Stress",
    "category": "Evidence & Review",
    "description": "Open GoalOS Falsification Gauntlet V1.2 — Claim-Sensitive Stress as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-mission-control.html",
    "title": "GoalOS Proof Mission Control — From Objective to First Docket",
    "category": "Evidence & Review",
    "description": "Open GoalOS Proof Mission Control — From Objective to First Docket as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-run-001-execution-room.html",
    "title": "GoalOS Proof Run 001 Execution Room",
    "category": "Evidence & Review",
    "description": "Review the Evidence Docket, gates, claims matrix, validator packet, and repository-readiness state.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-ledger.html",
    "title": "GoalOS Public Proof Ledger — Evidence Registry",
    "category": "Evidence & Review",
    "description": "Find every public route and understand how it fits the GoalOS proof curriculum.",
    "system": false,
    "priority": 0
  },
  {
    "href": "real-task-benchmark-bridge.html",
    "title": "GoalOS Real-Task Benchmark Bridge — From Demos to Evidence",
    "category": "Evidence & Review",
    "description": "Open GoalOS Real-Task Benchmark Bridge — From Demos to Evidence as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "validator-council-arena.html",
    "title": "GoalOS Validator Council Arena — Commit, Reveal, Challenge",
    "category": "Evidence & Review",
    "description": "Open GoalOS Validator Council Arena — Commit, Reveal, Challenge as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-run-001.html",
    "title": "Proof Run 001",
    "category": "Evidence & Review",
    "description": "Review the Evidence Docket, gates, claims matrix, validator packet, and repository-readiness state.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-run-001-live.html",
    "title": "Proof Run 001 Live — GoalOS",
    "category": "Evidence & Review",
    "description": "Review the Evidence Docket, gates, claims matrix, validator packet, and repository-readiness state.",
    "system": false,
    "priority": 0
  },
  {
    "href": "proof-run-001-docket.html",
    "title": "Proof Run 001 — GoalOS",
    "category": "Evidence & Review",
    "description": "Review the Evidence Docket, gates, claims matrix, validator packet, and repository-readiness state.",
    "system": false,
    "priority": 0
  },
  {
    "href": "strategic-evidence-scorecard.html",
    "title": "Strategic Evidence Scorecard · GoalOS Ascension",
    "category": "Evidence & Review",
    "description": "Open Strategic Evidence Scorecard · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "validator-room.html",
    "title": "Validator Room — GoalOS",
    "category": "Evidence & Review",
    "description": "Open Validator Room — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "validator-seats.html",
    "title": "Validator Seats",
    "category": "Evidence & Review",
    "description": "Open Validator Seats as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "from-loop-to-rsi-governance.html",
    "title": "GoalOS From Loop to RSI Governance Lab — Sovereign Invention Governance",
    "category": "Loop → RSI",
    "description": "Understand the loop-to-RSI governance path: contract, state, replay, bottleneck, dossiers, baselines, and gates.",
    "system": false,
    "priority": 0
  },
  {
    "href": "from-loop-to-rsi-state-capacity.html",
    "title": "GoalOS From Loop to RSI State-Capacity Command Room",
    "category": "Loop → RSI",
    "description": "Understand the loop-to-RSI governance path: contract, state, replay, bottleneck, dossiers, baselines, and gates.",
    "system": false,
    "priority": 0
  },
  {
    "href": "from-loop-to-rsi-sovereign-console.html",
    "title": "GoalOS From Loop to RSI — Sovereign Invention Console",
    "category": "Loop → RSI",
    "description": "Understand the loop-to-RSI governance path: contract, state, replay, bottleneck, dossiers, baselines, and gates.",
    "system": false,
    "priority": 0
  },
  {
    "href": "loop-bottleneck-observatory.html",
    "title": "GoalOS Loop Bottleneck Observatory — The Bottleneck Always Moves",
    "category": "Loop → RSI",
    "description": "Understand the loop-to-RSI governance path: contract, state, replay, bottleneck, dossiers, baselines, and gates.",
    "system": false,
    "priority": 0
  },
  {
    "href": "loop-contract-lab.html",
    "title": "GoalOS Loop Contract Lab — Write the loop, not the prompt.",
    "category": "Loop → RSI",
    "description": "Understand the loop-to-RSI governance path: contract, state, replay, bottleneck, dossiers, baselines, and gates.",
    "system": false,
    "priority": 0
  },
  {
    "href": "loop-flight-recorder.html",
    "title": "GoalOS Loop Flight Recorder — Restartable Agent Loops",
    "category": "Loop → RSI",
    "description": "Understand the loop-to-RSI governance path: contract, state, replay, bottleneck, dossiers, baselines, and gates.",
    "system": false,
    "priority": 0
  },
  {
    "href": "contract-academy.html",
    "title": "GoalOS Contract Academy — Learn the 48 Contracts",
    "category": "Mainnet Contract Atlas",
    "description": "Plain-language learning path for the 48 GoalOS-created Mainnet contracts.",
    "system": false,
    "priority": 0
  },
  {
    "href": "mainnet-contract-atlas.html",
    "title": "GoalOS Mainnet Contract Atlas V17 — 48 Ethereum Mainnet Contracts",
    "category": "Mainnet Contract Atlas",
    "description": "Search, filter, and learn the 48 GoalOS-created Ethereum Mainnet contracts.",
    "system": false,
    "priority": 0
  },
  {
    "href": "mainnet-proof-rail.html",
    "title": "GoalOS Mainnet Proof Rail — Contract Journey",
    "category": "Mainnet Contract Atlas",
    "description": "Follow the 48-contract proof rail from commitments to ledgers, attestations, gates, and chronicle memory.",
    "system": false,
    "priority": 0
  },
  {
    "href": "ask-goalos.html",
    "title": "Ask GoalOS — Live Route Assistant",
    "category": "Mission Autopilot",
    "description": "Live browser-local route assistant for questions; answers and redirects to the proper GoalOS page when asked.",
    "system": false,
    "priority": 10
  },
  {
    "href": "goalos.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Front-door one-box interface: enter an objective and receive a mission contract, proof path, route cards, and reviewer package.",
    "system": false,
    "priority": 10
  },
  {
    "href": "mission-autopilot.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Open GoalOS Universal Operating Interface V24 as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "mission-command-center.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Open GoalOS Universal Operating Interface V24 as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "mission.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Front-door one-box interface: enter an objective and receive a mission contract, proof path, route cards, and reviewer package.",
    "system": false,
    "priority": 0
  },
  {
    "href": "objective-command-center.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Open GoalOS Universal Operating Interface V24 as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "tell-goalos.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Front-door one-box interface: enter an objective and receive a mission contract, proof path, route cards, and reviewer package.",
    "system": false,
    "priority": 0
  },
  {
    "href": "universal-mission-autopilot.html",
    "title": "GoalOS Universal Operating Interface V24",
    "category": "Mission Autopilot",
    "description": "Open GoalOS Universal Operating Interface V24 as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "try-goalos.html",
    "title": "Try GoalOS — Browser-local Demo",
    "category": "Mission Autopilot",
    "description": "Open Try GoalOS — Browser-local Demo as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "demo-ecosystem-registry.html",
    "title": "Demo Ecosystem Registry — GoalOS",
    "category": "Navigation & Docs",
    "description": "Find every public route and understand how it fits the GoalOS proof curriculum.",
    "system": false,
    "priority": 0
  },
  {
    "href": "docs.html",
    "title": "Docs — GoalOS",
    "category": "Navigation & Docs",
    "description": "Open Docs — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "faq.html",
    "title": "FAQ · GoalOS Ascension",
    "category": "Navigation & Docs",
    "description": "Open FAQ · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "glossary.html",
    "title": "Glossary — GoalOS",
    "category": "Navigation & Docs",
    "description": "Open Glossary — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "help-center.html",
    "title": "Help Center — GoalOS",
    "category": "Navigation & Docs",
    "description": "Open Help Center — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "pathfinder.html",
    "title": "Pathfinder — GoalOS",
    "category": "Navigation & Docs",
    "description": "Choose a beginner-friendly path through the GoalOS proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "schema-registry.html",
    "title": "Schema Registry · GoalOS Ascension",
    "category": "Navigation & Docs",
    "description": "Find every public route and understand how it fits the GoalOS proof curriculum.",
    "system": false,
    "priority": 0
  },
  {
    "href": "search.html",
    "title": "Search — GoalOS",
    "category": "Navigation & Docs",
    "description": "Find every public route and understand how it fits the GoalOS proof curriculum.",
    "system": false,
    "priority": 0
  },
  {
    "href": "site-map.html",
    "title": "Site Map — All GoalOS Pages",
    "category": "Navigation & Docs",
    "description": "Find every public route and understand how it fits the GoalOS proof curriculum.",
    "system": false,
    "priority": 0
  },
  {
    "href": "start-here.html",
    "title": "Start Here — GoalOS",
    "category": "Navigation & Docs",
    "description": "Choose a beginner-friendly path through the GoalOS proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "start.html",
    "title": "Start Here — GoalOS",
    "category": "Navigation & Docs",
    "description": "Choose a beginner-friendly path through the GoalOS proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "quick-tour.html",
    "title": "Try GoalOS — Browser-local Demo",
    "category": "Navigation & Docs",
    "description": "Open Try GoalOS — Browser-local Demo as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "agialpha-token-boundary.html",
    "title": "$AGIALPHA Public-Market Boundary",
    "category": "Trust & Boundary",
    "description": "Review the public contract identification boundary and $AGIALPHA non-availability statement.",
    "system": false,
    "priority": 0
  },
  {
    "href": "token.html",
    "title": "$AGIALPHA Token Boundary",
    "category": "Trust & Boundary",
    "description": "Review the public contract identification boundary and $AGIALPHA non-availability statement.",
    "system": false,
    "priority": 0
  },
  {
    "href": "claim-boundary.html",
    "title": "Claim Boundary · GoalOS",
    "category": "Trust & Boundary",
    "description": "Open Claim Boundary · GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "data-boundary.html",
    "title": "Data Boundary — GoalOS",
    "category": "Trust & Boundary",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "legal.html",
    "title": "Legal Shield — GoalOS",
    "category": "Trust & Boundary",
    "description": "Open Legal Shield — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "no-data-no-funds.html",
    "title": "No Data / No Funds — GoalOS",
    "category": "Trust & Boundary",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "privacy.html",
    "title": "Privacy — GoalOS",
    "category": "Trust & Boundary",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "responsible-use.html",
    "title": "Responsible Use — GoalOS",
    "category": "Trust & Boundary",
    "description": "Open Responsible Use — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "security-boundary.html",
    "title": "Security Boundary — GoalOS",
    "category": "Trust & Boundary",
    "description": "Open Security Boundary — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "security.html",
    "title": "Security · GoalOS Ascension",
    "category": "Trust & Boundary",
    "description": "Open Security · GoalOS Ascension as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "terms.html",
    "title": "Terms of Use — GoalOS",
    "category": "Trust & Boundary",
    "description": "Open Terms of Use — GoalOS as part of the complete GoalOS public proof surface.",
    "system": false,
    "priority": 0
  },
  {
    "href": "investment-token-boundary.html",
    "title": "Token & Investment Boundary",
    "category": "Trust & Boundary",
    "description": "Review the public contract identification boundary and $AGIALPHA non-availability statement.",
    "system": false,
    "priority": 0
  },
  {
    "href": "token-boundary.html",
    "title": "Token Boundary — GoalOS",
    "category": "Trust & Boundary",
    "description": "Review the public contract identification boundary and $AGIALPHA non-availability statement.",
    "system": false,
    "priority": 0
  },
  {
    "href": "trust-boundary.html",
    "title": "Trust Boundary — GoalOS",
    "category": "Trust & Boundary",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "trust.html",
    "title": "Trust Center",
    "category": "Trust & Boundary",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "trust-center.html",
    "title": "Trust Center · GoalOS Ascension",
    "category": "Trust & Boundary",
    "description": "Review the no-data, no-funds, no-wallet, no-transaction, human-review boundary.",
    "system": false,
    "priority": 0
  },
  {
    "href": "404.html",
    "title": "GoalOS Route Not Found",
    "category": "Additional / Preserved",
    "description": "Open GoalOS Route Not Found as part of the complete GoalOS public proof surface.",
    "system": true,
    "priority": 0
  }
];
window.GOALOS_V24_INTENTS = [
  {
    "key": "contracts",
    "label": "48 Mainnet contracts",
    "keywords": [
      "48",
      "contract",
      "contracts",
      "mainnet",
      "ethereum",
      "chain",
      "etherscan",
      "proof rail",
      "aep contract",
      "ledger"
    ],
    "routes": [
      "mainnet-contract-atlas.html",
      "mainnet-proof-rail.html",
      "contract-academy.html",
      "token-boundary.html"
    ],
    "state": "CONTRACT_ATLAS_READY",
    "explain": "GoalOS will route you to the Mainnet Contract Atlas, Proof Rail, and Contract Academy so you can learn the 48 GoalOS-created Ethereum Mainnet contracts without using a wallet."
  },
  {
    "key": "start",
    "label": "New user onboarding",
    "keywords": [
      "start",
      "new",
      "beginner",
      "what is",
      "explain",
      "understand goalos",
      "learn",
      "intro",
      "onboard",
      "quick"
    ],
    "routes": [
      "start-here.html",
      "pathfinder.html",
      "demo-ecosystem-registry.html",
      "proof-run-001-docket.html"
    ],
    "state": "START_PATH_READY",
    "explain": "GoalOS will start with a plain-language path, then route you to the Pathfinder, Registry, and first Proof Run."
  },
  {
    "key": "proof",
    "label": "Public-safe proof mission",
    "keywords": [
      "proof mission",
      "mission",
      "evidence docket",
      "docket",
      "prove",
      "proof run",
      "review",
      "validator",
      "claim",
      "audit"
    ],
    "routes": [
      "proof-run-001-docket.html",
      "proof-run-001.html",
      "evidence-docket-theatre.html",
      "external-reviewer-replay-room.html",
      "demo-ecosystem-registry.html"
    ],
    "state": "PROOF_MISSION_READY",
    "explain": "GoalOS will produce a bounded mission contract, evidence docket plan, claims matrix, reviewer brief, and proof route."
  },
  {
    "key": "rsi",
    "label": "Loop → RSI governance",
    "keywords": [
      "rsi",
      "recursive",
      "self-improvement",
      "loop",
      "move",
      "move-37",
      "omni",
      "baseline",
      "dossier",
      "invention",
      "state capacity",
      "bottleneck"
    ],
    "routes": [
      "from-loop-to-rsi-state-capacity.html",
      "from-loop-to-rsi-sovereign-console.html",
      "from-loop-to-rsi-governance.html",
      "loop-contract-lab.html",
      "loop-flight-recorder.html",
      "loop-bottleneck-observatory.html"
    ],
    "state": "RSI_GOVERNANCE_READY",
    "explain": "GoalOS will guide you from loop contracts to deterministic RSI governance: replay, baselines, ECI, Move-37 dossiers, and outcome authority gates."
  },
  {
    "key": "trust",
    "label": "Trust, privacy, and token boundaries",
    "keywords": [
      "privacy",
      "data",
      "user data",
      "funds",
      "wallet",
      "transaction",
      "token",
      "agialpha",
      "legal",
      "trust",
      "boundary",
      "gdpr",
      "terms",
      "security"
    ],
    "routes": [
      "trust-boundary.html",
      "token-boundary.html",
      "privacy.html",
      "data-boundary.html",
      "no-data-no-funds.html",
      "claim-boundary.html"
    ],
    "state": "BOUNDARY_REVIEW_READY",
    "explain": "GoalOS will route you to the no-data, no-funds, no-wallet, no-transaction, human-review, and token-boundary pages."
  },
  {
    "key": "repo",
    "label": "Repository / developer path",
    "keywords": [
      "github",
      "repo",
      "repository",
      "developer",
      "workflow",
      "action",
      "docs",
      "run",
      "install",
      "source",
      "map"
    ],
    "routes": [
      "docs.html",
      "repository-map.html",
      "website-operating-system.html",
      "site-health.html",
      "run-locally.html"
    ],
    "state": "DEVELOPER_ROUTE_READY",
    "explain": "GoalOS will show where the repository source, workflows, docs, reports, and site-health evidence live."
  },
  {
    "key": "demos",
    "label": "Demo exploration",
    "keywords": [
      "demo",
      "demos",
      "examples",
      "gallery",
      "try",
      "interactive",
      "lab",
      "console"
    ],
    "routes": [
      "demo-ecosystem-registry.html",
      "site-map.html",
      "search.html",
      "capability-compounding-lab.html",
      "multi-agent-institution.html"
    ],
    "state": "DEMO_PATH_READY",
    "explain": "GoalOS will show the demo registry, all pages, search, and the best interactive demos."
  }
];
