#!/usr/bin/env python3
from __future__ import annotations
import os, re, json, html, shutil, math, base64
from pathlib import Path
from urllib.parse import unquote
VERSION='v59'
ASSET_CSS='goalos-autonomous-proof-work-machine-v59.css'
ASSET_JS='goalos-autonomous-proof-work-machine-v59.js'
ROUTE_JS='goalos-v59-routes.js'
ROUTE_JSON='goalos-v59-route-registry.json'
BOUNDARY={'userData':'not_requested','userFunds':'not_requested','wallet':'not_enabled','transaction':'not_enabled','productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','externalActions':0,'autonomy':'browser_local_public_alpha_simulation'}
NAV=[('Autonomous Run','#run'),('Work Machine','autonomous-proof-work-machine.html'),('AGI Agents','agi-agent-workbench.html'),('RSI / Loop','from-loop-to-rsi-state-capacity.html'),('AGI Node','agi-alpha-node-v0.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('All Pages','all-pages.html'),('Search','search.html'),('Health','site-health.html')]
FORBIDDEN=[r'window\.ethereum',r'ethereum\.request',r'\bfetch\s*\(',r'XMLHttpRequest',r'navigator\.sendBeacon',r'\blocalStorage\b',r'\bsessionStorage\b',r'\bindexedDB\b']
REPLACEMENTS={'window.ethereum':'window.__goalos_public_alpha_wallet_disabled__','ethereum.request':'ethereum_request_disabled','fetch(':'__goalos_no_network_fetch__(','XMLHttpRequest':'DisabledXMLHttpRequest','navigator.sendBeacon':'disabledSendBeacon','localStorage':'goalosBrowserSessionMemory','sessionStorage':'goalosBrowserSessionMemory','indexedDB':'disabledIndexedDB'}
TINY_PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=')

def esc(x): return html.escape(str(x),quote=True)
def pack_root(): return Path(__file__).resolve().parent
def ensure_dirs(root):
    d={'public':root/'public','assets':root/'public'/'assets','reports':root/'reports','evidence':root/'evidence'/'demo','content':root/'content'/'goalos','docs':root/'docs'/'website'}
    for p in d.values(): p.mkdir(parents=True,exist_ok=True)
    return d

def load_manifest(): return json.loads((pack_root()/'canonical-manifest-v59.json').read_text(encoding='utf-8'))
def title_from_route(route):
    name=route.rsplit('/',1)[-1].replace('.html','')
    if name=='index': return 'GoalOS Autonomous Command Center'
    return ' '.join(w.capitalize() for w in re.split(r'[-_]+',name) if w)
def classify_route(route):
    s=route.lower()
    if route.startswith('archive/'): return 'Preserved Archive'
    if 'move37' in s or 'move-37' in s: return 'Move-37'
    if 'rsi' in s or 'loop' in s or 'bottleneck' in s: return 'RSI / Loop'
    if 'playbook' in s or 'agent' in s or 'foundry' in s: return 'AGI Agents'
    if 'node' in s: return 'AGI Node'
    if 'valid' in s or 'review' in s or 'council' in s: return 'Validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return '48 Contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s or 'ledger' in s: return 'Proof / Evidence'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'Trust / Boundary'
    if 'search' in s or 'map' in s or 'pages' in s or 'registry' in s or 'health' in s or '404' in s: return 'Navigation / Health'
    if 'autonomous' in s or 'machine' in s or 'holy' in s or 'grail' in s: return 'Autonomous Work Machine'
    if 'index' in s or 'command' in s or 'phase' in s: return 'Command Center'
    return 'Additional'
def kind_from_route(route):
    s=route.lower()
    if 'playbook' in s: return 'playbooks'
    if 'move37' in s or 'move-37' in s: return 'move37'
    if 'rsi' in s: return 'rsi'
    if 'loop' in s or 'bottleneck' in s: return 'loop'
    if 'agent' in s or 'foundry' in s: return 'agents'
    if 'node' in s: return 'node'
    if 'valid' in s or 'review' in s or 'council' in s: return 'validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return 'contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s or 'ledger' in s: return 'proof'
    if 'ask' in s: return 'ask'
    if 'search' in s or 'map' in s or 'pages' in s or 'registry' in s or 'health' in s or '404' in s: return 'navigation'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'boundary'
    if 'autonomous' in s: return 'autonomous'
    return 'work'
def list_routes(public):
    rows=[]
    for p in sorted(public.rglob('*.html')):
        rel=p.relative_to(public).as_posix()
        rows.append({'route':rel,'title':title_from_route(rel),'category':classify_route(rel),'kind':kind_from_route(rel),'description':'Open '+title_from_route(rel)+' as part of the complete GoalOS autonomous proof surface.'})
    return rows

def nav_html():
    out=[]
    for label,href in NAV:
        if href=='#run': out.append('<button class="v59-pill" data-v59-run>'+esc(label)+'</button>')
        else: out.append('<a class="v59-pill" href="'+esc(href)+'">'+esc(label)+'</a>')
    return ''.join(out)
def orbit_html():
    labels=['ARC','PLAN','RES','BUILD','VERIFY','NODE','VALID','DOCKET','CHRON','SETTLE','REINVEST','NEXT']
    out=['<div class="v59-orbit"><div class="v59-core">α</div>']
    for i,l in enumerate(labels):
        ang=2*math.pi*i/len(labels)-math.pi/2; x=50+40*math.cos(ang); y=50+40*math.sin(ang)
        out.append('<span class="v59-node" style="left:calc({:.3f}% - 29px);top:calc({:.3f}% - 29px)">{}</span>'.format(x,y,esc(l)))
    out.append('</div>')
    return ''.join(out)
def canonical_page(page,routes_json,list_page=False):
    cards=''.join('<article class="v59-card"><span class="num">'+esc(n)+'</span><h3>'+esc(t)+'</h3><p>'+esc(b)+'</p></article>' for n,t,b in page.get('cards',[]))
    flow=''.join('<span class="v59-step">'+esc(x)+'</span>' for x in ['Mission','Work','Proof','Validation','Verified Experience','Chronicle','Capability','Settlement Simulation','Reinvestment','Harder Mission'])
    list_block=''
    if list_page:
        list_block='<section class="v59-section"><span class="v59-eyebrow">Route Inventory</span><h2>Everything remains discoverable.</h2><input class="v59-searchbox" data-v59-page-filter placeholder="Filter all GoalOS pages..." aria-label="Filter pages"><div class="v59-page-list" data-v59-page-list></div></section>'
    objective=page.get('objective','I want GoalOS to autonomously turn a public-safe objective into verified work, with AGI Agents doing the work and AGI Nodes validating the proof.')
    inline='<section class="v59-live-machine" data-v59-inline><div class="v59-live-head"><div><span class="v59-eyebrow">Browser-local Autonomy</span><h2>Run until proof is done.</h2><p class="v59-sub">The page-specific mission runs in the browser: no account, no wallet, no transaction, no backend call.</p></div><button class="v59-btn primary" data-v59-inline-run data-v59-run>Start autonomous run</button></div><div class="v59-live-grid"><textarea>'+esc(objective)+'</textarea><pre class="v59-live-output" data-v59-inline-output>Ready. Click Start autonomous run.</pre></div></section>'
    return '''<!doctype html><html lang="en" data-goalos-page="{kind}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{title} · GoalOS AGIALPHA Ascension</title><meta name="description" content="{desc}"><meta name="goalos:autonomous-proof-work-machine" content="v59"><link rel="stylesheet" href="assets/{css}"><script src="assets/{routes}" defer></script><script src="assets/{js}" defer></script><script type="application/json" data-goalos-v59-routes>{routes_json}</script></head><body class="goalos-v59" data-goalos-v59-kind="{kind}"><nav class="v59-nav v59-wrap"><a class="v59-brand" href="index.html"><span class="v59-mark">α</span><span><strong>GOALOS</strong><small>AGIALPHA ASCENSION</small></span></a><div class="v59-navlinks">{nav}</div></nav><main class="v59-wrap"><section class="v59-hero"><div><span class="v59-eyebrow">{eyebrow}</span><h1 class="v59-title">{headline} <em>{accent}</em></h1><p class="v59-lead">{lead}</p><p class="v59-sub">GoalOS is now presented as an autonomous proof-gated open-ended work machine: AGI Agents coordinate the work, AGI Jobs bound it, AGI Nodes can validate it, and Evidence Dockets decide what becomes trusted, reusable, settlement-ready proof.</p><div class="v59-actions"><button class="v59-btn primary" data-v59-run>Run end-to-end demo</button><button class="v59-btn dark" data-v59-run>Tell GoalOS what you want</button><a class="v59-btn dark" href="all-pages.html">Explore the system</a></div><div class="v59-composer"><label>What should GoalOS autonomously accomplish?<span>browser-local</span></label><textarea class="v59-objective" data-goalos-objective>{objective}</textarea></div></div><aside class="v59-console"><div class="v59-console-head"><b>Sovereign Autonomous Console</b><span class="v59-status">READY</span></div>{orbit}<div class="v59-mini-grid"><div class="v59-mini"><strong>Agents</strong>Plan, build, verify, remember.</div><div class="v59-mini"><strong>Jobs</strong>Bound and package work.</div><div class="v59-mini"><strong>Nodes</strong>Worker / validator / sentinel.</div><div class="v59-mini"><strong>Proof</strong>Dockets before trust.</div></div><div class="v59-terminal" data-v59-terminal>route console loading...</div></aside></section>{inline}<section class="v59-section"><span class="v59-eyebrow">Autonomous Compounding Loop</span><h2>Mission → Work → Proof → Harder Mission.</h2><div class="v59-flow">{flow}</div></section><section class="v59-section"><span class="v59-eyebrow">What the user can do</span><h2>One objective becomes a proof package.</h2><div class="v59-grid">{cards}</div></section>{list_block}<section class="v59-boundary"><b>Public-alpha boundary.</b> No user data. No user funds. No wallet. No transaction. No backend call. No production authority. No achieved AGI/ASI/SOTA claim. $AGIALPHA is public-contract / protocol context only; no sale, custody, wallet support, investment, trading, legal, tax, exchange, bridge, liquidity, or regulatory advice.</section></main></body></html>'''.format(kind=esc(page.get('kind','autonomous')),title=esc(title_from_route(page['route'])),desc=esc(page.get('lead','')),css=ASSET_CSS,routes=ROUTE_JS,js=ASSET_JS,routes_json=routes_json,nav=nav_html(),eyebrow=esc(page.get('eyebrow','Autonomous GoalOS')),headline=esc(page.get('title','Autonomous proof-gated work.')),accent=esc(page.get('accent','It runs until proof is done.')),lead=esc(page.get('lead','')),objective=esc(objective),orbit=orbit_html(),inline=inline,flow=flow,cards=cards,list_block=list_block)
def fallback_page(route):
    page={'route':route,'kind':'navigation','title':'Route not found.','accent':'Use GoalOS.','eyebrow':'GoalOS route helper','lead':'Use Ask GoalOS, Search, or All Pages to continue.','objective':'I want GoalOS to route me to the right public proof surface.','cards':[['01','Search','Find the relevant route.'],['02','All Pages','Browse the complete route surface.'],['03','Ask GoalOS','Get browser-local route guidance.']]}
    return canonical_page(page,'[]',False)

def write_assets(dirs):
    shutil.copy2(pack_root()/'assets'/ASSET_CSS, dirs['assets']/ASSET_CSS)
    shutil.copy2(pack_root()/'assets'/ASSET_JS, dirs['assets']/ASSET_JS)
    # legacy safe aliases
    (dirs['assets']/'goalos.css').write_text('@import url("'+ASSET_CSS+'");\n',encoding='utf-8')
    (dirs['assets']/'goalos.js').write_text('window.GOALOS_LEGACY_COMPAT=true;\n',encoding='utf-8')
    (dirs['assets']/'goalos-mark.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><radialGradient id="g"><stop stop-color="#fff06b"/><stop offset=".45" stop-color="#60ffd6"/><stop offset="1" stop-color="#a98bff"/></radialGradient></defs><rect width="100" height="100" rx="26" fill="url(#g)"/><text x="50" y="64" text-anchor="middle" font-size="56" font-family="Arial" font-weight="900" fill="#061018">α</text></svg>',encoding='utf-8')
def sanitize_file(path):
    try: txt=path.read_text(encoding='utf-8')
    except UnicodeDecodeError: return
    new=txt
    for k,v in REPLACEMENTS.items(): new=new.replace(k,v)
    if new!=txt: path.write_text(new,encoding='utf-8')
def is_external(u):
    u=u.strip().lower()
    return (not u) or u.startswith('#') or u.startswith('http:') or u.startswith('https:') or u.startswith('//') or u.startswith('mailto:') or u.startswith('tel:') or u.startswith('data:') or u.startswith('javascript:')
def target_for(basefile,u,public):
    u=unquote(u.split('#',1)[0].split('?',1)[0])
    if is_external(u): return None
    if u.startswith('/'):
        # GitHub pages project absolute paths may include repository slug; keep tail after known slug if present
        parts=Path(u.lstrip('/')).parts
        if 'goalos-agialpha-sovereign-machine-economy' in parts:
            idx=parts.index('goalos-agialpha-sovereign-machine-economy')
            u='/'.join(parts[idx+1:])
        else:
            u=u.lstrip('/')
        return public/u
    return (basefile.parent/u).resolve()
def create_compat(target,public):
    target.parent.mkdir(parents=True,exist_ok=True)
    suf=target.suffix.lower()
    if suf=='.html': target.write_text(fallback_page(target.relative_to(public).as_posix()),encoding='utf-8')
    elif suf=='.css': target.write_text('/* GoalOS compatibility asset */\n@import url("/goalos-agialpha-sovereign-machine-economy/assets/'+ASSET_CSS+'");\n',encoding='utf-8')
    elif suf=='.js': target.write_text('window.GOALOS_COMPATIBILITY_ASSET=true;\n',encoding='utf-8')
    elif suf=='.svg': target.write_text((public/'assets'/'goalos-mark.svg').read_text(encoding='utf-8'),encoding='utf-8')
    elif suf=='.json': target.write_text(json.dumps({'goalos':'compatibility','version':VERSION,'boundary':BOUNDARY},indent=2),encoding='utf-8')
    elif suf in ['.png','.jpg','.jpeg','.webp','.gif']: target.write_bytes(TINY_PNG)
    else: target.write_text('GoalOS compatibility asset '+VERSION+'\n',encoding='utf-8')
def scan_links(html_text):
    vals=[]
    for m in re.finditer(r'\b(?:href|src)\s*=\s*["\']([^"\']+)["\']',html_text,re.I): vals.append(m.group(1))
    for m in re.finditer(r'url\(["\']?([^\)"\']+)["\']?\)',html_text,re.I): vals.append(m.group(1))
    return vals
def repair_links(public):
    made=[]
    for f in sorted(public.rglob('*.html')):
        try: txt=f.read_text(encoding='utf-8')
        except UnicodeDecodeError: continue
        for u in scan_links(txt):
            t=target_for(f,u,public)
            if t is None: continue
            try: rel=t.relative_to(public)
            except ValueError: continue
            if not t.exists():
                create_compat(t,public); made.append({'file':f.relative_to(public).as_posix(),'target':rel.as_posix()})
    return made
def inject_assets(public,routes_json):
    route_tag='<script src="assets/'+ROUTE_JS+'" defer></script><script src="assets/'+ASSET_JS+'" defer></script><script type="application/json" data-goalos-v59-routes>'+routes_json+'</script>'
    css_tag='<link rel="stylesheet" href="assets/'+ASSET_CSS+'">'
    for f in sorted(public.rglob('*.html')):
        try: txt=f.read_text(encoding='utf-8')
        except UnicodeDecodeError: continue
        if ASSET_CSS not in txt:
            txt=txt.replace('</head>',css_tag+'\n</head>') if '</head>' in txt else css_tag+'\n'+txt
        if ASSET_JS not in txt:
            txt=txt.replace('</head>',route_tag+'\n</head>') if '</head>' in txt else route_tag+'\n'+txt
        if 'data-goalos-v59-route=' not in txt:
            rel=f.relative_to(public).as_posix()
            txt=re.sub(r'<body\b', '<body data-goalos-v59-route="'+esc(rel)+'"', txt, count=1, flags=re.I)
        f.write_text(txt,encoding='utf-8')
def audit(public):
    forbidden=[]; broken=[]
    for f in list(public.rglob('*.html'))+list((public/'assets').rglob('*.js')):
        try: txt=f.read_text(encoding='utf-8')
        except Exception: continue
        for pat in FORBIDDEN:
            if re.search(pat,txt): forbidden.append({'file':f.relative_to(public).as_posix(),'pattern':pat})
    for f in sorted(public.rglob('*.html')):
        try: txt=f.read_text(encoding='utf-8')
        except UnicodeDecodeError: continue
        for u in scan_links(txt):
            t=target_for(f,u,public)
            if t is None: continue
            try: rel=t.relative_to(public)
            except ValueError: continue
            if not t.exists(): broken.append({'file':f.relative_to(public).as_posix(),'target':rel.as_posix()})
    return forbidden,broken

def main():
    root=Path.cwd(); dirs=ensure_dirs(root); public=dirs['public']; manifest=load_manifest(); write_assets(dirs)
    # sanitize old surfaces before generation
    for f in list(public.rglob('*.html'))+list(public.rglob('*.js')): sanitize_file(f)
    # initial route JSON placeholder for generated canonical pages
    routes_seed=list_routes(public)
    routes_json=json.dumps(routes_seed,separators=(',',':'))
    for page in manifest['pages']:
        list_page=page['route'] in ['all-pages.html','site-map.html','route-registry.html','search.html','site-health.html']
        dest=public/page['route']; dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(canonical_page(page,routes_json,list_page),encoding='utf-8')
    # aliases for central autonomous surface
    for alias in ['mission-control.html','goalos-command-center.html','goalos-aurora-command-center.html']:
        if not (public/alias).exists(): (public/alias).write_text(canonical_page(manifest['pages'][0],routes_json,False),encoding='utf-8')
    created=repair_links(public)
    routes=list_routes(public); routes_json=json.dumps(routes,separators=(',',':'))
    (dirs['assets']/ROUTE_JSON).write_text(json.dumps(routes,indent=2),encoding='utf-8')
    (dirs['assets']/ROUTE_JS).write_text('window.GOALOS_V59_ROUTES='+json.dumps(routes,separators=(',',':'))+';\n',encoding='utf-8')
    inject_assets(public,routes_json)
    created += repair_links(public)
    # sanitize any injected/compat code issues from older files, but not our own safe code
    for f in list(public.rglob('*.html'))+list(public.rglob('*.js')): sanitize_file(f)
    forbidden,broken=audit(public)
    status='passed' if not forbidden and not broken else 'failed'
    report={'version':VERSION,'status':status,'publicPages':len(list(public.rglob('*.html'))),'currentRoutesIndexed':len([r for r in routes if not r['route'].startswith('archive/')]),'createdCompatibilityAssets':created,'forbiddenBrowserApiHits':forbidden,'brokenInternalLinksOrAssets':broken,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled','autonomousProofWorkMachine':True,'pageSpecificAutonomousDemos':True}
    for name in ['install-report','qa','route-health','audit','demo-run']:
        (dirs['reports']/('autonomous-proof-work-machine-v59-'+name+'.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')
    (dirs['evidence']/'autonomous-proof-work-machine-v59-reference-docket.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (dirs['content']/'public-proof-navigation-v59.json').write_text(json.dumps(routes,indent=2),encoding='utf-8')
    (dirs['content']/'autonomous-mission-profiles-v59.json').write_text(json.dumps({'version':VERSION,'profiles':['autonomous','work','agents','playbooks','rsi','loop','move37','node','validation','contracts','proof','navigation','boundary']},indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if status!='passed': raise SystemExit(1)
if __name__=='__main__': main()
