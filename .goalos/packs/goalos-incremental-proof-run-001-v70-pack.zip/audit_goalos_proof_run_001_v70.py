#!/usr/bin/env python3
from pathlib import Path
import json, os, re

ROOT = Path.cwd()
FAIL = os.getenv("FAIL_ON_AUDIT_ERROR", "true").lower() == "true"
MANAGED = "goalos-proof-run-001-v70"
NOW = __import__('datetime').datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

required = [
"public/proof-run-001-command-center-v70.html",
"public/evidence-docket-61-public-room-v70.html",
"public/agijobs-dispatch-rail-v70.html",
"public/proofbundle-return-gate-v70.html",
"public/chronicle-capability-library-v70.html",
"public/agialpha-settlement-thermostat-v70.html",
"public/external-replay-reviewer-room-v70.html",
"public/rsi-move37-dossier-gate-v70.html",
"public/autonomous-publication-health-v70.html",
"public/now-we-prove-it-v70.html",
"public/goalos-proof-run-001-v70-capability-index.json",
"evidence/proof-run-001-v70/mission-contract.json",
"evidence/proof-run-001-v70/proof-debt-register.json",
"evidence/proof-run-001-v70/agi-job-queue.json",
"evidence/proof-run-001-v70/proofbundle-template.json",
"evidence/proof-run-001-v70/evidence-docket-61.json",
"evidence/proof-run-001-v70/capability-promotion-gate.json",
"reports/goalos-proof-run-001-v70-install-report.md"
]
errors, warnings = [], []
for r in required:
    if not (ROOT/r).exists():
        errors.append(f"missing required file: {r}")

for html in (ROOT/"public").glob("*-v70.html") if (ROOT/"public").exists() else []:
    txt = html.read_text(encoding="utf-8", errors="ignore")
    lower = txt.lower()
    for phrase in ["does not claim achieved agi", "does not claim achieved asi", "no backend", "no wallet", "no transaction", "no user funds", "human review"]:
        if phrase not in lower:
            errors.append(f"{html}: missing boundary phrase `{phrase}`")
    for forbidden in ["fetch(", "XMLHttpRequest", "sendBeacon", "window.ethereum", "localStorage", "sessionStorage", "<script src=", "fonts.googleapis"]:
        if forbidden.lower() in lower:
            errors.append(f"{html}: forbidden local/remote API or external asset reference `{forbidden}`")
    if MANAGED not in txt:
        warnings.append(f"{html}: missing managed marker")

try:
    docket = json.loads((ROOT/"evidence/proof-run-001-v70/evidence-docket-61.json").read_text())
    blocked = " ".join(docket.get("blocked_claims_register", [])).lower()
    for term in ["achieved agi", "achieved asi", "empirical sota", "guaranteed roi", "live settlement"]:
        if term not in blocked:
            errors.append(f"evidence docket blocked claims missing `{term}`")
except Exception as e:
    errors.append(f"could not parse evidence docket: {e}")

try:
    gate = json.loads((ROOT/"evidence/proof-run-001-v70/capability-promotion-gate.json").read_text())
    if "HOLD" not in gate.get("status", ""):
        errors.append("Capability Promotion Gate must remain HOLD until proof/replay/validation return")
except Exception as e:
    errors.append(f"could not parse capability gate: {e}")

result = {"managed_by": MANAGED, "generated_at": NOW, "status": "pass" if not errors else "fail", "errors": errors, "warnings": warnings, "required_files_checked": len(required), "claim_boundary_preserved": not errors}
Path("reports").mkdir(exist_ok=True)
(Path("reports")/"goalos-proof-run-001-v70-audit.json").write_text(json.dumps(result, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
md = "# GoalOS Proof Run 001 v70 Audit Report\n\nStatus: **{}**\n\nGenerated: {}\n\n## Errors\n{}\n\n## Warnings\n{}\n".format(result["status"].upper(), NOW, "\n".join(f"- {e}" for e in errors) or "None", "\n".join(f"- {w}" for w in warnings) or "None")
(Path("reports")/"goalos-proof-run-001-v70-audit.md").write_text(md, encoding="utf-8")
print(json.dumps(result, indent=2, ensure_ascii=False))
if errors and FAIL:
    raise SystemExit(1)
