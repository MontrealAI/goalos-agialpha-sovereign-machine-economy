#!/usr/bin/env python3
from pathlib import Path
import json, os, re, hashlib, datetime

ROOT = Path.cwd()
VERSION = "v70"
MANAGED = "goalos-proof-run-001-v70"
MARK = "GOALOS_PROOF_RUN_001_V70"
ALLOW_OVERWRITE = os.getenv("ALLOW_OVERWRITE", "false").lower() == "true"
UPDATE_NAVIGATION = os.getenv("UPDATE_NAVIGATION", "true").lower() == "true"
PATCH_EXISTING_PAGES = os.getenv("PATCH_EXISTING_PAGES", "true").lower() == "true"
RUN_ID = os.getenv("GOALOS_RUN_ID", "local")
REPO = os.getenv("GOALOS_REPOSITORY", "MontrealAI/goalos-agialpha-sovereign-machine-economy")
SHA = os.getenv("GOALOS_SHA", "local")
NOW = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

added, updated, skipped, patched = [], [], [], []

def rel(path):
    try:
        return str(Path(path).relative_to(ROOT)).replace('\\', '/')
    except Exception:
        return str(path).replace('\\', '/')

def dump_json(obj):
    return json.dumps(obj, indent=2, ensure_ascii=False) + "\n"

def safe_write(path, content):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    content = content.rstrip() + "\n"
    if path.exists():
        old = path.read_text(encoding="utf-8", errors="ignore")
        if old == content:
            skipped.append(rel(path))
            return "unchanged"
        managed_old = (f"managed-by: {MANAGED}" in old) or (MARK in old) or ("goalos-proof-run-001-v70" in old)
        if managed_old or ALLOW_OVERWRITE:
            path.write_text(content, encoding="utf-8")
            updated.append(rel(path))
            return "updated"
        skipped.append(rel(path))
        return "skipped_existing_unmanaged"
    path.write_text(content, encoding="utf-8")
    added.append(rel(path))
    return "added"

def canonical_hash(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

claim_boundary = """Public-alpha claim boundary: this page does not claim achieved AGI, does not claim achieved ASI, does not claim empirical SOTA, does not claim legal/security/compliance certification, does not claim guaranteed ROI, does not claim live settlement in local mode, does not claim wallet execution, does not claim user-fund handling, does not claim autonomous production authorization, and does not claim completed external validation. Stronger claims require real Proof Runs, returned ProofBundles, replay logs, validator reports, cost/risk ledgers, delayed outcomes, and independent review."""
local_boundary = """Local/website boundary: no backend, no wallet, no transaction, no user funds, no live settlement, no private intelligence on-chain, and human review required for high-impact outcomes."""

def page_template(slug, title, eyebrow, subtitle, sections, cta):
    card_html = "\n".join(f"""
        <article class=\"card\">
          <h2>{s['title']}</h2>
          <p>{s['body']}</p>
          <ul>{''.join(f'<li>{x}</li>' for x in s.get('points', []))}</ul>
        </article>""" for s in sections)
    links = "".join(f"<a href=\"{p['slug']}\">{p['short']}</a>" for p in PAGES)
    return f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>{title} · GoalOS</title>
  <!-- managed-by: {MANAGED} -->
  <!-- {MARK}: public-safe incremental capability page -->
  <style>
    :root {{ color-scheme: dark; --bg:#070914; --panel:#101827; --panel2:#14223a; --line:#29415f; --text:#f6fbff; --muted:#b9c8d9; --gold:#ffe48a; --mint:#66ffd1; --blue:#70b7ff; --violet:#b58cff; --danger:#ff8da1; }}
    * {{ box-sizing:border-box }}
    body {{ margin:0; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; background: radial-gradient(circle at 18% 8%, rgba(102,255,209,.18), transparent 28%), radial-gradient(circle at 82% 18%, rgba(181,140,255,.19), transparent 30%), linear-gradient(135deg,#061412,#090b1a 58%,#11142d); color:var(--text); line-height:1.55; }}
    a {{ color:var(--mint); text-decoration:none }}
    header {{ max-width:1180px; margin:0 auto; padding:32px 22px 18px; }}
    nav {{ display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin-bottom:26px; padding:14px; border:1px solid rgba(255,255,255,.14); border-radius:24px; background:rgba(5,10,20,.72); backdrop-filter: blur(16px); box-shadow:0 18px 70px rgba(0,0,0,.38); }}
    nav strong {{ margin-right:auto; letter-spacing:.16em; color:var(--mint); font-size:.78rem; text-transform:uppercase }}
    nav a {{ padding:8px 11px; border:1px solid rgba(255,255,255,.16); border-radius:999px; color:#dff; background:rgba(255,255,255,.05); font-weight:700; font-size:.86rem }}
    .hero {{ padding:58px 44px; border:1px solid rgba(255,255,255,.14); border-radius:36px; background:linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.035)); box-shadow:inset 0 0 0 1px rgba(255,255,255,.03), 0 30px 90px rgba(0,0,0,.34); position:relative; overflow:hidden; }}
    .hero:before {{ content:\"\"; position:absolute; inset:auto -15% -40% 35%; height:340px; background:radial-gradient(circle, rgba(102,255,209,.24), transparent 58%); transform:rotate(-9deg); }}
    .eyebrow {{ color:var(--gold); text-transform:uppercase; letter-spacing:.22em; font-weight:900; font-size:.76rem; }}
    h1 {{ margin:.18em 0 .2em; font-size:clamp(2.55rem,8vw,6.7rem); line-height:.92; letter-spacing:-.07em; max-width:940px; }}
    .hero p {{ max-width:850px; color:#e6f4ff; font-size:clamp(1.02rem,2vw,1.34rem); }}
    .cta {{ display:flex; flex-wrap:wrap; gap:12px; margin-top:24px }}
    .cta a, .cta span {{ border-radius:999px; padding:12px 16px; font-weight:900; border:1px solid rgba(255,255,255,.18); background:rgba(255,255,255,.07) }}
    .cta .primary {{ background:linear-gradient(90deg,var(--mint),var(--gold)); color:#071018 }}
    main {{ max-width:1180px; margin:0 auto; padding:26px 22px 64px; }}
    .grid {{ display:grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap:16px; }}
    .card {{ border:1px solid rgba(255,255,255,.13); border-radius:26px; padding:22px; background:rgba(9,17,31,.72); min-height:220px; box-shadow:0 18px 70px rgba(0,0,0,.18); }}
    .card h2 {{ margin:0 0 10px; color:var(--mint); font-size:1.08rem }}
    .card p {{ color:#dbe8f5; margin:.2em 0 .6em }}
    .card li {{ margin:.35em 0; color:#cbd9e8 }}
    .flow {{ margin:22px 0; display:grid; grid-template-columns: repeat(5,minmax(0,1fr)); gap:10px; }}
    .step {{ padding:16px; border-radius:20px; text-align:center; background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.13); font-weight:900; color:#fff }}
    .boundary {{ margin-top:24px; border:1px solid rgba(255,228,138,.34); border-radius:26px; padding:22px; background:rgba(255,228,138,.08); color:#fff4cf }}
    .boundary strong {{ color:var(--gold) }}
    footer {{ max-width:1180px; margin:0 auto; padding:22px; color:#aebed0; border-top:1px solid rgba(255,255,255,.12) }}
    @media(max-width:820px) {{ .hero {{ padding:36px 24px }} .grid {{ grid-template-columns:1fr }} .flow {{ grid-template-columns:1fr 1fr }} nav strong {{ width:100%; }} }}
  </style>
</head>
<body>
<header>
  <nav><strong>GoalOS · Proof Run 001 v70</strong>{links}</nav>
  <section class=\"hero\">
    <div class=\"eyebrow\">{eyebrow}</div>
    <h1>{title}</h1>
    <p>{subtitle}</p>
    <div class=\"cta\"><a class=\"primary\" href=\"proof-run-001-command-center-v70.html\">Open Proof Run 001</a><a href=\"evidence-docket-61-public-room-v70.html\">Evidence Docket</a><a href=\"agijobs-dispatch-rail-v70.html\">AGI Jobs</a><span>{cta}</span></div>
  </section>
</header>
<main>
  <section class=\"flow\" aria-label=\"GoalOS proof-gated loop\">
    <div class=\"step\">Mission</div><div class=\"step\">Work</div><div class=\"step\">Proof</div><div class=\"step\">Validation</div><div class=\"step\">Chronicle</div>
  </section>
  <section class=\"grid\">{card_html}</section>
  <section class=\"boundary\"><p><strong>Claim boundary.</strong> {claim_boundary}</p><p><strong>Local boundary.</strong> {local_boundary}</p><p><strong>Operating rule.</strong> No ProofBundle, no settlement. No replay, no validation. No validation, no Chronicle memory. Now we prove it.</p></section>
</main>
<footer>GoalOS AGIALPHA Ascension · Sovereign Machine Economy · managed-by: {MANAGED} · generated {NOW}</footer>
</body>
</html>"""

PAGES = [
  {"slug":"proof-run-001-command-center-v70.html","short":"Proof Run 001","title":"Proof Run 001 Command Center","eyebrow":"First public proof loop","subtitle":"Turn the Holy Grail candidate thesis into an inspectable public run: objective, Mission Contract, Proof Debt, AGI Jobs, ProofBundles, Evidence Docket, reviewer path, and Chronicle hold.","cta":"Now we prove it.","sections":[
    {"title":"Mission contract first","body":"The run starts by writing down what must be proven before any result becomes authority.","points":["Objective and decision to support","Success and failure criteria","Risk class and review requirement"]},
    {"title":"Proof debt becomes work","body":"Unsupported claims are converted into explicit AGI Jobs rather than left as vague TODOs.","points":["Claim support gaps","Replay requirements","External reviewer questions"]},
    {"title":"Promotion stays held","body":"Chronicle memory and reusable capability stay on hold until ProofBundles and reviewer verdicts return.","points":["No replay, no promotion","No validation, no capability","No ProofBundle, no settlement"]}
  ]},
  {"slug":"evidence-docket-61-public-room-v70.html","short":"Evidence Docket","title":"Evidence Docket 6.1 Public Room","eyebrow":"Claims become inspectable","subtitle":"A public-safe proof room for claims, source provenance, proof debt, blocked claims, baselines, cost/risk ledgers, replay path, and reviewer questions.","cta":"Evidence before authority.","sections":[
    {"title":"Claims matrix","body":"Every public claim is labeled as supported, needs evidence, blocked, or reviewer-ready.","points":["No unsupported certainty","Blocked claims visible","Public/private boundary explicit"]},
    {"title":"Verifier mesh","body":"The docket asks whether sources are real, assumptions are explicit, contradictions are surfaced, and risks are reviewable.","points":["Source provenance slots","Risk and cost ledger","Replay / audit path"]},
    {"title":"Claim boundary ledger","body":"Architecture and strategic horizons remain separate from empirical claims until evidence returns.","points":["No achieved AGI/ASI claim","No empirical SOTA claim","No guaranteed ROI claim"]}
  ]},
  {"slug":"agijobs-dispatch-rail-v70.html","short":"AGI Jobs","title":"Proof Debt to AGI Jobs Dispatch Rail","eyebrow":"Missing evidence becomes executable","subtitle":"GoalOS converts unresolved proof into bounded, testable, validator-reviewable AGI Jobs with acceptance tests, ProofBundle return paths, and promotion rules.","cta":"Jobify proof debt.","sections":[
    {"title":"Dispatch matrix","body":"Each AGI Job says why it exists, who should execute it, who validates it, and what proof must return.","points":["Worker role","Validator role","Sentinel role"]},
    {"title":"AGIJobManager-ready specs","body":"Local mode prepares job specs and transaction intents but does not submit transactions or touch wallets.","points":["Intent-only in local mode","Future dApp boundary separated","Human confirmation required"]},
    {"title":"Acceptance tests","body":"Jobs are bounded by explicit tests so a fluent answer cannot masquerade as completed proof.","points":["Replay requirements","Blocked claims until complete","Required outputs"]}
  ]},
  {"slug":"proofbundle-return-gate-v70.html","short":"ProofBundle Gate","title":"ProofBundle Return Gate","eyebrow":"Returned work must carry proof","subtitle":"A ProofBundle is the evidence object returned from a completed AGI Job: job spec, outputs, logs or trace summary, replay result, validator verdict, risk ledger, and attestation.","cta":"No replay, no promotion.","sections":[
    {"title":"Minimum bundle","body":"A returned bundle must identify the job, objective, acceptance tests, outputs, evidence, replay result, and validator verdict.","points":["job_id and job_spec_uri","output hashes or artifact pointers","worker attestation"]},
    {"title":"Validator verdict","body":"Missing replay_result or validator_verdict keeps the Capability Promotion Gate in HOLD.","points":["approved","needs-review","rejected"]},
    {"title":"Evidence update","body":"Accepted bundles update the Evidence Docket; rejected or incomplete bundles create new proof debt.","points":["claim updates","risk notes","reviewer questions"]}
  ]},
  {"slug":"chronicle-capability-library-v70.html","short":"Chronicle","title":"Verified Experience Chronicle","eyebrow":"Only validated capability compounds","subtitle":"Chronicle memory is not a scratchpad. It is the accepted institutional memory of missions whose proof, replay, validation, and claim boundary passed.","cta":"Memory after proof.","sections":[
    {"title":"Capability promotion","body":"Reusable capability is admitted only after Mission Contract, Evidence Docket, ProofBundle path, reviewer route, and boundary checks exist.","points":["reviewer-ready","blocked pending proof","promotable after review"]},
    {"title":"Reusable capability package","body":"Accepted work becomes a package with scope, initiation conditions, evidence history, replay path, rollback notes, and next mission queue.","points":["scope-limited","rollback-aware","lineage-linked"]},
    {"title":"No contagious uncertainty","body":"Unsupported claims remain blocked so unverified output cannot silently influence future work.","points":["critical blockers stay visible","public-safe memory","challengeable history"]}
  ]},
  {"slug":"agialpha-settlement-thermostat-v70.html","short":"$AGIALPHA Thermostat","title":"$AGIALPHA Proof Economy Thermostat","eyebrow":"Proof becomes economically consequential","subtitle":"$AGIALPHA is framed as the economic control rail around verified intelligence: mission budgets, stakes, validator pressure, proof bonds, rewards, slashing, α-Work Units, and reinvestment signals.","cta":"Settlement only after proof.","sections":[
    {"title":"Thermostat signals","body":"The economy should respond to proof quality, false acceptance, replay failure, validator latency, risk, and external validation status.","points":["proof quality up → budget can flow","replay failure → settlement holds","risk up → mission class pauses"]},
    {"title":"Utility boundary","body":"This page does not present $AGIALPHA as equity, profit rights, dividends, ownership, investment advice, or guaranteed return.","points":["utility-only framing","simulated local mode","future dApp separated"]},
    {"title":"α-Work Units","body":"α-WU should count verified work only; failed acceptance tests or missing proof should produce zero settlement-grade work units.","points":["validated work","policy-weighted quality","reviewer evidence"]}
  ]},
  {"slug":"external-replay-reviewer-room-v70.html","short":"External Replay","title":"External Replay and Reviewer Room","eyebrow":"Independent review path","subtitle":"The reviewer room prepares the first external replay path: what to inspect, what to reproduce, what evidence is missing, and what would falsify the claim.","cta":"Reviewer-ready, not overclaimed.","sections":[
    {"title":"Replay packet","body":"A reviewer receives the mission contract, evidence docket, proof bundles, replay instructions, cost/risk ledger, and claim boundary.","points":["public-safe artifacts","private appendix boundary","failure cases"]},
    {"title":"Honesty box","body":"The reviewer is asked what failed, what could not be reproduced, what remains unsupported, and what stronger evidence is needed.","points":["accepted","changes requested","rejected"]},
    {"title":"Falsification route","body":"The system becomes stronger when it can state what would prove it wrong or incomplete.","points":["generic jobs fail","missing replay fails","claim boundary removal fails"]}
  ]},
  {"slug":"rsi-move37-dossier-gate-v70.html","short":"RSI / Move-37","title":"RSI Move-37 Dossier Gate","eyebrow":"High novelty raises skepticism","subtitle":"Open-ended discovery is allowed, but outcome authority remains mechanical: risk, evidence, baseline, replay, persistence, validator gate, and dossier packaging.","cta":"No breakthrough by narrative.","sections":[
    {"title":"Search control ≠ outcome authority","body":"Interestingness can suggest where to explore, but it cannot promote, settle, or override evidence gates.","points":["OMNI as allocation input","risk gate","evidence gate"]},
    {"title":"Move-37 handling","body":"A high-novelty result must be recognized, reproduced, stress-tested, checked for persistence, and packaged as a dossier.","points":["recognize","reproduce","stress-test","persist"]},
    {"title":"Baseline discipline","body":"No advantage claim without incumbent, nearest-neighbor, null, or workflow baselines.","points":["comparative deltas","cost-adjusted value","safety no worse than incumbent"]}
  ]},
  {"slug":"autonomous-publication-health-v70.html","short":"Publication Health","title":"Autonomous Publication Health Room","eyebrow":"The website must prove its own discipline","subtitle":"This page documents the safe publication law: generated source, audit, non-destructive patching, human-reviewable report, optional issue, and GitHub Pages deploy.","cta":"Website changes are proof-gated too.","sections":[
    {"title":"Non-destructive installer","body":"The action writes new managed pages and appends marked navigation blocks without deleting existing content.","points":["allow_overwrite false","deletion refusal","managed markers"]},
    {"title":"Audit before deploy","body":"Required files, claim boundaries, local/no-wallet boundary, route index, and report artifacts are checked before deployment.","points":["HTML present","boundary present","no forbidden local APIs"]},
    {"title":"Deployment boundary","body":"The workflow may publish Pages but must not move tokens, broadcast transactions, auto-merge unsafe claims, or remove claim boundaries.","points":["GitHub Pages only","no secrets","public-safe issue summary"]}
  ]},
  {"slug":"now-we-prove-it-v70.html","short":"Now We Prove It","title":"Now We Prove It","eyebrow":"The strongest final wording","subtitle":"GoalOS is architecturally pointed at proof-gated open-ended work. The next sentence is not a bigger claim. The next sentence is: now we prove it.","cta":"Proof before prestige.","sections":[
    {"title":"Holy Grail candidate, bounded","body":"The prize is not raw Turing completeness; it is proof-gated open-ended work that can produce verified experience and reusable capability.","points":["mission","work","proof","validation","verified experience"]},
    {"title":"No hype shortcut","body":"The system does not claim achieved AGI, ASI, superintelligence, guaranteed compounding, or completed settlement.","points":["public alpha","Proof Run 001 needed","external replay needed"]},
    {"title":"The proof path","body":"The public path is repeated missions, Evidence Dockets, replayability, validator reports, accepted α-Work Units, settlement simulation, and harder future missions.","points":["real tasks","baselines","independent review"]}
  ]}
]

# public pages
for p in PAGES:
    html = page_template(p['slug'], p['title'], p['eyebrow'], p['subtitle'], p['sections'], p['cta'])
    safe_write(f"public/{p['slug']}", html)

route_index = {
    "version": "goalos.proof_run_001.v70",
    "managed_by": MANAGED,
    "generated_at": NOW,
    "repository": REPO,
    "source_sha": SHA,
    "pages": [{"title": p['title'], "slug": p['slug'], "url": f"https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/{p['slug']}", "public_safe": True} for p in PAGES],
    "boundaries": {
        "claim_boundary": claim_boundary,
        "local_boundary": local_boundary,
        "settlement_boundary": "Local GoalOS prepares job specs and proof artifacts only. Live posting, escrow, validation, disputes, and settlement require a separate human-confirmed dApp boundary."
    }
}
safe_write("public/goalos-proof-run-001-v70-capability-index.json", dump_json(route_index))

# evidence artifacts
objective = "Evaluate whether GoalOS can turn a high-stakes objective into proof-gated open-ended work that is reviewer-ready, evidence-docketed, and held until replay and validation pass."
mission_contract = {
    "id": "proof-run-001-v70",
    "version": "goalos.proof_run_001.v70",
    "created_at": NOW,
    "objective": objective,
    "decision_to_support": "Whether GoalOS can publicly demonstrate the proof path without overclaiming achieved AGI or live settlement.",
    "success_criteria": ["Mission Contract exists", "Proof Debt Register exists", "AGI Jobs are generated", "ProofBundle template exists", "Evidence Docket 6.1 exists", "External replay path exists", "Claim boundary remains visible"],
    "failure_criteria": ["Unsupported claims promoted", "No replay path", "No validator/reviewer route", "Wallet or transaction behavior implied in local mode", "Existing site content deleted"],
    "constraints": ["public-alpha", "no backend", "no wallet in local mode", "no transaction in local mode", "human review required", "no achieved AGI/ASI claim"],
    "done_condition": "human-review-ready proof package emitted and promotion held until ProofBundles/replay/validation return"
}
proof_debt = [
    {"id":"pd-001","claim":"GoalOS can compile objectives into mission contracts and evidence dockets.","missing_evidence":"First public mission run with generated artifacts and QA report.","agi_job_id":"agi-job-001"},
    {"id":"pd-002","claim":"GoalOS can convert missing evidence into AGI Jobs.","missing_evidence":"AGI Job queue with acceptance tests, validator route, and ProofBundle templates.","agi_job_id":"agi-job-002"},
    {"id":"pd-003","claim":"GoalOS capability can compound safely.","missing_evidence":"Returned ProofBundles, replay logs, validator verdicts, and Chronicle promotion gate.","agi_job_id":"agi-job-003"},
    {"id":"pd-004","claim":"$AGIALPHA settlement can respond to proof quality.","missing_evidence":"Settlement simulation with no wallet/local boundary and no live fund movement.","agi_job_id":"agi-job-004"},
    {"id":"pd-005","claim":"External reviewers can replay the proof path.","missing_evidence":"Reviewer instructions, honesty box, falsification tests, and replay bundle.","agi_job_id":"agi-job-005"}
]
agi_jobs = [
    {"job_id":"agi-job-001","title":"Compile Proof Run 001 mission contract and claims matrix","worker_role":"Planner Agent","validator_role":"AGI Node Validator / Human Reviewer","sentinel_role":"AGI Node Sentinel","why_needed":"The public proof loop needs a bounded objective and success/failure tests before work begins.","acceptance_tests":["Mission Contract present", "Claims matrix present", "Claim boundary present"],"required_outputs":["mission-contract.json", "claims-matrix.md"],"promotion_rule":"No Chronicle promotion unless replay and validation pass."},
    {"job_id":"agi-job-002","title":"Convert proof debt into executable AGI Jobs","worker_role":"Evidence Docket Agent","validator_role":"AGI Node Validator / Human Reviewer","sentinel_role":"AGI Node Sentinel","why_needed":"Missing evidence must become executable work, not vague uncertainty.","acceptance_tests":["Each proof debt item links to a job", "Each job has acceptance tests", "Each job has ProofBundle return template"],"required_outputs":["proof-debt-register.json", "agi-job-queue.json"],"promotion_rule":"No ProofBundle, no settlement."},
    {"job_id":"agi-job-003","title":"Prepare ProofBundle return and replay validator packet","worker_role":"Verifier Agent","validator_role":"External Reviewer","sentinel_role":"AGI Node Sentinel","why_needed":"Returned work must contain evidence sufficient to update the Evidence Docket.","acceptance_tests":["ProofBundle schema present", "replay_result field required", "validator_verdict field required"],"required_outputs":["proofbundle-template.json", "reviewer-report-template.md"],"promotion_rule":"Missing replay_result or validator_verdict keeps gate HOLD."},
    {"job_id":"agi-job-004","title":"Model $AGIALPHA settlement thermostat without live transactions","worker_role":"Value Accountant Agent","validator_role":"Protocol Reviewer","sentinel_role":"Token Boundary Sentinel","why_needed":"The economic rail should respond to proof quality without implying investment returns or live local settlement.","acceptance_tests":["Utility boundary visible", "No wallet local mode", "No user funds", "Simulation only"],"required_outputs":["settlement-thermostat.json", "token-boundary.md"],"promotion_rule":"Live settlement remains separated and human-confirmed."},
    {"job_id":"agi-job-005","title":"Create external replay and falsification packet","worker_role":"Reviewer Room Agent","validator_role":"External Reviewer","sentinel_role":"Claim Boundary Sentinel","why_needed":"The proof run must be challengeable, replayable, and falsifiable.","acceptance_tests":["Replay instructions present", "Honesty box present", "What would falsify this documented"],"required_outputs":["external-replay-room.md", "falsification-tests.md"],"promotion_rule":"No external validation claim without reviewer evidence."}
]
proofbundle_template = {
    "version":"goalos.proofbundle.v70",
    "job_id":"agi-job-001",
    "job_spec_uri":"local://evidence/proof-run-001-v70/agijobs_queue.json#agi-job-001",
    "job_completion_uri":"local://proofbundles/proof-run-001-v70/agi-job-001-completion.json",
    "objective": objective,
    "acceptance_tests": ["mission contract exists", "proof debt register exists", "evidence docket exists"],
    "policy_context": {"claim_boundary":"public-alpha", "local_mode":"no backend, no wallet, no transaction"},
    "inputs": [],
    "outputs": [],
    "output_hashes_or_artifact_pointers": [],
    "logs_or_trace_summary": "required before promotion",
    "replay_result": "required: pass | fail | not-run",
    "validator_verdict": "required: approved | needs-review | rejected",
    "claim_boundary": claim_boundary,
    "risk_ledger": [],
    "worker_signature_or_attestation": "required",
    "created_at": NOW
}
evidence_docket = {
    "id":"evidence-docket-61-proof-run-001-v70",
    "title":"Evidence Docket 6.1 — Proof Run 001 v70",
    "objective": objective,
    "claims_matrix": [
        {"claim":"GoalOS can organize a public proof path.","status":"supported structurally","evidence":"this generated package","boundary":"requires actual run artifacts for empirical claim"},
        {"claim":"GoalOS has achieved AGI or ASI.","status":"blocked","evidence":"none","boundary":"do not claim"},
        {"claim":"Proof Run 001 is externally validated.","status":"needs evidence","evidence":"external reviewer verdict pending","boundary":"blocked until reviewer report returns"}
    ],
    "proof_debt_register": proof_debt,
    "agi_jobs_created": [j["job_id"] for j in agi_jobs],
    "blocked_claims_register": ["achieved AGI", "achieved ASI", "empirical SOTA", "guaranteed ROI", "live settlement in local mode", "legal/security/compliance certification"],
    "risk_ledger": ["overclaim risk", "replay gap risk", "validator availability risk", "local-vs-dApp boundary confusion risk"],
    "baseline_comparison": {"B0":"ordinary LLM report", "B1":"static agent demo", "B2":"GoalOS proof-gated package with Evidence Docket and AGI Jobs"},
    "replay_audit_path": "evidence/proof-run-001-v70/reviewer_report_template.md",
    "public_private_boundary": "Public pages contain claim summaries and proof pointers; private traces, customer data, secrets, and privileged review notes remain out of public site.",
    "claim_boundary": claim_boundary
}
capability_gate = {
    "gate_id":"capability-promotion-gate-proof-run-001-v70",
    "status":"HOLD_PENDING_PROOFBUNDLES_AND_REVIEW",
    "required_before_promotion":["returned ProofBundles", "replay_result", "validator_verdict", "reviewer report", "cost/risk ledger", "claim boundary pass"],
    "forbidden_promotions":["achieved AGI", "achieved ASI", "empirical SOTA", "live settlement", "guaranteed ROI"],
    "rule":"Only validated results can enter Chronicle memory or influence future missions."
}
settlement_thermostat = {
    "mode":"simulation_only_local_boundary",
    "token_boundary":"$AGIALPHA described only as a utility/control rail, not equity or investment claim.",
    "signals":["proof_quality", "false_acceptance_rate", "replay_failure_rate", "validator_latency", "risk_class", "external_validation_status"],
    "actuators":["mission_budget", "validator_quorum", "proof_bond", "challenge_window", "slashing_parameter", "reinvestment_queue"],
    "live_actions":"none in local/website mode"
}

safe_write("evidence/proof-run-001-v70/mission-contract.json", dump_json(mission_contract))
safe_write("evidence/proof-run-001-v70/proof-debt-register.json", dump_json(proof_debt))
safe_write("evidence/proof-run-001-v70/agi-job-queue.json", dump_json(agi_jobs))
safe_write("evidence/proof-run-001-v70/proofbundle-template.json", dump_json(proofbundle_template))
safe_write("evidence/proof-run-001-v70/evidence-docket-61.json", dump_json(evidence_docket))
safe_write("evidence/proof-run-001-v70/capability-promotion-gate.json", dump_json(capability_gate))
safe_write("evidence/proof-run-001-v70/agialpha-settlement-thermostat.json", dump_json(settlement_thermostat))
safe_write("evidence/proof-run-001-v70/manifest.json", dump_json({"managed_by": MANAGED, "generated_at": NOW, "mission_contract_hash": canonical_hash(mission_contract), "evidence_docket_hash": canonical_hash(evidence_docket), "capability_gate": capability_gate["status"], "pages": [p['slug'] for p in PAGES]}))

claims_md = """# Proof Run 001 v70 Claims Matrix\n\n| Claim | Status | Evidence needed | Boundary |\n|---|---|---|---|\n| GoalOS can structure a proof-gated public mission. | Supported structurally | Generated mission, evidence docket, AGI Jobs, reports | Architectural/public-alpha. |\n| GoalOS has achieved AGI or ASI. | Blocked | Not applicable | Do not claim. |\n| GoalOS is externally validated. | Needs evidence | External reviewer replay report | Blocked until reviewer evidence returns. |\n| GoalOS can settle live work locally. | Blocked | Not applicable | Local mode is no-wallet/no-transaction/no-user-funds. |\n\nA model can answer. An agent can act. An institution must prove.\n"""
safe_write("evidence/proof-run-001-v70/claims-matrix.md", claims_md)
reviewer_md = """# Proof Run 001 v70 External Reviewer Packet\n\n## What to inspect\n\n1. Mission Contract.\n2. Proof Debt Register.\n3. AGI Job Queue.\n4. ProofBundle Template.\n5. Evidence Docket 6.1.\n6. Capability Promotion Gate.\n7. Claim Boundary.\n\n## Reviewer honesty box\n\n- What passed?\n- What failed?\n- What could not be replayed?\n- Which claims remain blocked?\n- What evidence is required before external validation can be claimed?\n\n## Falsification\n\nThis proof run fails if it removes claim boundaries, promotes without replay, implies live wallet/settlement in local mode, produces generic jobs for unrelated objectives, or deletes existing website content.\n"""
safe_write("evidence/proof-run-001-v70/reviewer_report_template.md", reviewer_md)

# docs
DOCS = {
"00_PROOF_RUN_001_OVERVIEW.md":"""# Proof Run 001 v70 Overview\n\nGoalOS Proof Run 001 is the first public-safe command path from architecture to inspectable evidence. The purpose is not to claim achieved AGI or ASI. The purpose is to show the proof path: objective, mission, proof debt, AGI Jobs, ProofBundles, Evidence Docket, reviewer path, and Chronicle hold.\n\nAI creates output. GoalOS creates proof. AGIJobs completes missing proof. Only validated capability compounds.\n""",
"01_HOLY_GRAIL_CANDIDATE_BOUNDARY.md":"""# Holy Grail Candidate Boundary\n\nThe precise claim is not that GoalOS has achieved the Holy Grail. The precise claim is that GoalOS is architecturally pointed at proof-gated open-ended work: computation plus proof, governance, memory, settlement, and reinvestment.\n\nThe next step is proof, not overclaiming.\n""",
"02_PROOF_DEBT_TO_AGI_JOBS.md":"""# Proof Debt to AGI Jobs\n\nWhat an LLM cannot reliably prove, verify, replay, source, audit, or certify becomes proof debt. GoalOS converts that proof debt into executable AGI Jobs with worker roles, validator roles, acceptance tests, required outputs, and ProofBundle return templates.\n""",
"03_PROOFBUNDLE_RETURN_GATE.md":"""# ProofBundle Return Gate\n\nA ProofBundle is the evidence package returned from completed AGI Jobs. If replay_result or validator_verdict is missing, the Capability Promotion Gate remains HOLD. No ProofBundle, no settlement. No replay, no validation.\n""",
"04_EVIDENCE_DOCKET_61_PUBLIC_ROOM.md":"""# Evidence Docket 6.1 Public Room\n\nThe Evidence Docket is a proof room, not a marketing page. It contains claims, source provenance, proof packets, proof debt, blocked claims, risk ledger, baseline comparison, replay path, reviewer questions, public/private boundary, and claim boundary.\n""",
"05_AGIALPHA_SETTLEMENT_THERMOSTAT.md":"""# $AGIALPHA Settlement Thermostat\n\n$AGIALPHA is framed as an economic control rail around verified intelligence. In this local/website layer, all settlement behavior is simulated or described. No wallet, no transaction, no user funds, and no live settlement occur here.\n""",
"06_EXTERNAL_REPLAY_PROTOCOL.md":"""# External Replay Protocol\n\nExternal replay asks whether the public proof path can be reproduced by a reviewer from the mission contract, evidence docket, proof bundles, logs, ledgers, and instructions. No external validation claim is allowed until reviewer evidence exists.\n""",
"07_RSI_MOVE37_GOVERNANCE_GATE.md":"""# RSI Move-37 Governance Gate\n\nOpen-ended search is allowed, but outcome authority is mechanical. High novelty raises skepticism. Move-37 candidates require recognize, reproduce, stress-test, persistence gate, and dossier packaging before promotion.\n""",
"08_PUBLICATION_HEALTH_LAW.md":"""# Autonomous Publication Health Law\n\nThe website is incrementally extended by generated source, audited reports, non-destructive patching, and GitHub Pages deployment. The workflow must not delete existing content, move tokens, broadcast transactions, publish unsupported claims, or remove claim boundaries.\n"""
}
for name, body in DOCS.items():
    safe_write(f"docs/proof-run-001-v70/{name}", f"---\ntitle: {name[:-3].replace('_',' ').title()}\nstatus: public-alpha\nmanaged_by: {MANAGED}\nclaim_level: architectural\n---\n\n{body}\n\n## Boundary\n\n{claim_boundary}\n\n{local_boundary}\n")

# examples and schemas
example_a = {"objective":"Evaluate whether an AI vendor trust room is buyer-ready for enterprise procurement.","expected_domain":"AI Governance / Trust / Procurement","expected_jobs":["vendor claim evidence map","privacy/security boundary review","buyer-readiness reviewer packet","external reviewer attestation"]}
example_b = {"objective":"Design a solar microgrid financing model for a hospital campus.","expected_domain":"Energy / Infrastructure / Climate","expected_jobs":["site/load assumptions","tariff and interconnection proof debt","financing sensitivity model","resilience and hospital operations risk"]}
safe_write("examples/proof-run-001-v70/objective-diversity-ai-vendor.json", dump_json(example_a))
safe_write("examples/proof-run-001-v70/objective-diversity-solar-microgrid.json", dump_json(example_b))

schema = {"$schema":"https://json-schema.org/draft/2020-12/schema","title":"GoalOS ProofBundle v70","type":"object","required":["version","job_id","job_spec_uri","objective","acceptance_tests","replay_result","validator_verdict","claim_boundary","created_at"],"properties":{"version":{"type":"string"},"job_id":{"type":"string"},"job_spec_uri":{"type":"string"},"objective":{"type":"string"},"acceptance_tests":{"type":"array"},"replay_result":{"type":"string"},"validator_verdict":{"type":"string"},"claim_boundary":{"type":"string"},"created_at":{"type":"string"}}}
safe_write("schemas/goalos-v70/proofbundle-v70.schema.json", dump_json(schema))
safe_write("schemas/goalos-v70/evidence-docket-61-v70.schema.json", dump_json({"$schema":"https://json-schema.org/draft/2020-12/schema","title":"Evidence Docket 6.1 v70","type":"object","required":["id","title","objective","claims_matrix","proof_debt_register","claim_boundary"],"properties":{"id":{"type":"string"},"title":{"type":"string"},"objective":{"type":"string"},"claims_matrix":{"type":"array"},"proof_debt_register":{"type":"array"},"claim_boundary":{"type":"string"}}}))

content_manifest = {"managed_by": MANAGED, "generated_at": NOW, "capability_layer":"Proof Run 001 Evidence Autopilot v70", "routes": [p['slug'] for p in PAGES], "evidence": "evidence/proof-run-001-v70/manifest.json"}
safe_write("content/goalos-proof-run-001-v70/manifest.json", dump_json(content_manifest))

# issue body
issue_body = f"""# GoalOS Proof Run 001 v70 installed\n\nThis autonomous action added an incremental, non-destructive Proof Run 001 capability layer.\n\n## New pages\n\n""" + "\n".join(f"- `{p['slug']}` — {p['title']}" for p in PAGES) + f"""\n\n## Safety boundary\n\n{claim_boundary}\n\n{local_boundary}\n\n## Operator note\n\nOpen `proof-run-001-command-center-v70.html`, then inspect the Evidence Docket and AGI Jobs. Promotion remains HOLD until ProofBundles, replay, validation, and reviewer evidence return.\n"""
safe_write("issue-bodies/goalos-proof-run-001-v70.md", issue_body)

# patch navigation blocks on existing public pages
if UPDATE_NAVIGATION and PATCH_EXISTING_PAGES:
    nav_block = """\n<!-- GOALOS_PROOF_RUN_001_V70_NAV_BEGIN -->\n<section id=\"goalos-proof-run-001-v70\" style=\"margin:24px auto;padding:20px;border:1px solid rgba(102,255,209,.28);border-radius:22px;background:rgba(5,15,25,.72);color:#eaffff;max-width:1120px\">\n  <strong style=\"color:#66ffd1;letter-spacing:.12em;text-transform:uppercase\">New · Proof Run 001 v70</strong>\n  <h2 style=\"margin:.35em 0;color:#fff\">GoalOS is proof-gated open-ended work. Now we prove it.</h2>\n  <p style=\"color:#cfe7ef\">This incremental layer adds Proof Run 001, Evidence Docket 6.1, AGI Jobs dispatch, ProofBundle return gates, Chronicle hold, $AGIALPHA settlement thermostat, RSI Move-37 governance, external replay, and publication health — without deleting existing pages.</p>\n  <p><a href=\"proof-run-001-command-center-v70.html\" style=\"color:#66ffd1;font-weight:800\">Open Proof Run 001</a> · <a href=\"evidence-docket-61-public-room-v70.html\" style=\"color:#66ffd1;font-weight:800\">Evidence Docket</a> · <a href=\"agijobs-dispatch-rail-v70.html\" style=\"color:#66ffd1;font-weight:800\">AGI Jobs</a> · <a href=\"now-we-prove-it-v70.html\" style=\"color:#66ffd1;font-weight:800\">Now We Prove It</a></p>\n</section>\n<!-- GOALOS_PROOF_RUN_001_V70_NAV_END -->\n"""
    targets = ["public/index.html", "public/goalos.html", "public/all-pages.html", "public/site-map.html", "public/search.html"]
    begin = "<!-- GOALOS_PROOF_RUN_001_V70_NAV_BEGIN -->"
    end = "<!-- GOALOS_PROOF_RUN_001_V70_NAV_END -->"
    for target in targets:
        path = ROOT / target
        if not path.exists():
            continue
        txt = path.read_text(encoding="utf-8", errors="ignore")
        if begin in txt and end in txt:
            new = re.sub(re.escape(begin) + r".*?" + re.escape(end), nav_block.strip(), txt, flags=re.S)
        elif "</body>" in txt.lower():
            idx = txt.lower().rfind("</body>")
            new = txt[:idx] + nav_block + txt[idx:]
        else:
            new = txt.rstrip() + "\n" + nav_block + "\n"
        if new != txt:
            path.write_text(new, encoding="utf-8")
            patched.append(rel(path))

# reports
report = {
    "managed_by": MANAGED,
    "version": VERSION,
    "generated_at": NOW,
    "run_id": RUN_ID,
    "repository": REPO,
    "source_sha": SHA,
    "added": added,
    "updated": updated,
    "skipped": skipped,
    "patched": patched,
    "required_pages": [f"public/{p['slug']}" for p in PAGES],
    "claim_boundary_preserved": True,
    "local_boundary_preserved": True,
    "deletion_policy": "workflow refuses destructive deletions",
    "publication_mode": os.getenv("PUBLICATION_MODE", "workflow input")
}
safe_write("reports/goalos-proof-run-001-v70-install-report.json", dump_json(report))
md = f"""# GoalOS Proof Run 001 v70 Install Report\n\nGenerated: {NOW}\n\n## Summary\n\n- Added files: {len(added)}\n- Updated managed files: {len(updated)}\n- Patched existing pages/manifests: {len(patched)}\n- Skipped existing unmanaged files: {len(skipped)}\n\n## New public pages\n\n""" + "\n".join(f"- `public/{p['slug']}` — {p['title']}" for p in PAGES) + f"""\n\n## Boundary\n\n{claim_boundary}\n\n{local_boundary}\n\n## Next action\n\nOpen `proof-run-001-command-center-v70.html` and review the Evidence Docket, AGI Jobs, ProofBundle Gate, and External Replay room.\n"""
safe_write("reports/goalos-proof-run-001-v70-install-report.md", md)
print(dump_json(report))
