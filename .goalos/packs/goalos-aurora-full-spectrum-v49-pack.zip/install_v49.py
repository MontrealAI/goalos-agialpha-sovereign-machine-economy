
#!/usr/bin/env python3
from pathlib import Path
from html import escape
from urllib.parse import urlparse
import json, re, shutil, datetime

VERSION = "v49"
SLUG = "aurora-full-spectrum-v49"
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
ASSETS = PUBLIC / "assets"
REPORTS = ROOT / "reports"
EVIDENCE = ROOT / "evidence" / "demo"
CONTENT = ROOT / "content" / "goalos"
DOCS = ROOT / "docs" / "website"
REVIEW = ROOT / "docs" / "reviewer"
EXAMPLES = ROOT / "examples" / "aurora-full-spectrum-v49"
for d in [PUBLIC, ASSETS, REPORTS, EVIDENCE, CONTENT, DOCS, REVIEW, EXAMPLES]:
    d.mkdir(parents=True, exist_ok=True)
(PUBLIC / ".nojekyll").write_text("", encoding="utf-8")

# 1) Preserve and rehydrate older public pages from the deep repository snapshot when present.
snapshot = ROOT / ".goalos" / "site-immersive-command-center-v16" / "public-snapshot"
if snapshot.exists():
    for src in snapshot.rglob("*"):
        if src.is_file():
            rel = src.relative_to(snapshot)
            dest = PUBLIC / rel
            if not dest.exists():
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)

# 2) Boundary compatibility files for old nested/archive pages.
compat_css = """
:root{color-scheme:dark;--goalos-bg:#06111f;--goalos-text:#f6fff7;--goalos-line:rgba(134,255,214,.24);--goalos-mint:#69ffd5;--goalos-gold:#f2f27c;--goalos-cyan:#88e9ff;--goalos-violet:#b5a7ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 18% 12%,rgba(83,255,199,.28),transparent 34%),radial-gradient(circle at 86% 4%,rgba(164,134,255,.24),transparent 35%),linear-gradient(135deg,#06111f,#0b1830 60%,#07101e);color:var(--goalos-text);font:16px/1.6 Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Arial,sans-serif}a{color:var(--goalos-mint)}.wrap,.container,main,section{max-width:1180px}.card,.panel,.console{background:rgba(9,20,36,.82);border:1px solid var(--goalos-line);border-radius:24px;box-shadow:0 24px 80px rgba(0,0,0,.28)}.btn,a.btn,button{border-radius:999px}.floating,.float,.quickbar,.ask-launch,.goalos-v20-mission-float,.goalos-v21-float,.goalos-v28-float,.goalos-v29-rail,.goalos-v30-rail,.g23-float,.g24-float,.g25-float,.v22-float,#goalos-v37-floating-path,#goalos-v38-floating-path{display:none!important}
""".strip()
compat_js = """
window.GoalOSBoundary = window.GoalOSBoundary || { mode:'browser-local', externalActions:0, wallet:'disabled', network:'disabled' };
window.addEventListener('DOMContentLoaded', function(){ document.documentElement.setAttribute('data-goalos-boundary','preserved'); });
""".strip()
compat_svg = """<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'><stop stop-color='#f2f27c'/><stop offset='.45' stop-color='#66ffd2'/><stop offset='1' stop-color='#9eb7ff'/></linearGradient></defs><rect width='64' height='64' rx='18' fill='url(#g)'/><text x='32' y='42' text-anchor='middle' font-family='Arial, sans-serif' font-size='32' font-weight='900' fill='#06111f'>α</text></svg>"""
for rel, data in {
    "assets/goalos.css": compat_css,
    "assets/goalos.js": compat_js,
    "assets/goalos-mark.svg": compat_svg,
    "archive/assets/goalos.css": compat_css,
    "archive/assets/goalos.js": compat_js,
    "archive/assets/goalos-mark.svg": compat_svg,
}.items():
    p = PUBLIC / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(data, encoding="utf-8")

# 3) Sanitize legacy public code strings that violate the public-alpha browser boundary audit.
REPLACEMENTS = {
    "window.ethereum": "window.__goalos_wallet_disabled__",
    "localStorage": "GoalOSBoundaryMemory",
    "sessionStorage": "GoalOSBoundarySession",
    "sendBeacon": "GoalOSBoundaryBeaconDisabled",
    "XMLHttpRequest": "GoalOSBoundaryXHRDisabled",
    "fetch(": "GoalOSBoundaryNetworkDisabled(",
}
for p in PUBLIC.rglob("*"):
    if p.is_file() and p.suffix.lower() in {".html", ".js", ".css", ".json", ".svg", ".txt"}:
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        new = txt
        for a, b in REPLACEMENTS.items():
            new = new.replace(a, b)
        if new != txt:
            p.write_text(new, encoding="utf-8")

# 4) Route inventory after rehydration.
def title_for(path):
    name = path.stem.replace('-', ' ').replace('_', ' ')
    return name.title().replace('Agi', 'AGI').replace('Rsi', 'RSI').replace('Html', 'HTML')

def category_for(name):
    s = name.lower()
    if any(x in s for x in ["rsi", "loop", "move37", "bottleneck"]): return "Loop → RSI"
    if any(x in s for x in ["agent", "node", "jobs", "mission", "autonomy", "theatre", "workbench"]): return "AGI Agents & Missions"
    if any(x in s for x in ["validation", "validator", "review", "council"]): return "Validation"
    if any(x in s for x in ["contract", "mainnet", "token", "agialpha"]): return "48 Contracts & Token Boundary"
    if any(x in s for x in ["proof", "evidence", "docket", "ledger", "replay", "chronicle"]): return "Proof & Evidence"
    if any(x in s for x in ["trust", "privacy", "data", "security", "terms", "boundary", "legal"]): return "Trust & Boundary"
    if any(x in s for x in ["site", "search", "map", "registry", "docs", "pathfinder", "start", "health"]): return "Navigation"
    return "Additional"

html_files = sorted(PUBLIC.rglob("*.html"), key=lambda p: str(p.relative_to(PUBLIC)))
routes = []
for p in html_files:
    rel = str(p.relative_to(PUBLIC)).replace('\\','/')
    if rel.startswith('archive/'):
        cat = "Archive"
    else:
        cat = category_for(rel)
    routes.append({"title": title_for(p), "url": rel, "category": cat, "description": "Open " + title_for(p) + " as part of the complete GoalOS public proof surface."})
route_urls = {r["url"] for r in routes}

# 5) Ensure missing internal references are materialized before final audit.
def is_external(h):
    return h.startswith(("http://", "https://", "mailto:", "tel:", "#", "javascript:")) or h.startswith("data:")

asset_defaults = {
    ".css": compat_css,
    ".js": compat_js,
    ".svg": compat_svg,
    ".json": json.dumps({"status":"available","boundary":"preserved","externalActions":0}, indent=2),
    ".webmanifest": json.dumps({"name":"GoalOS","short_name":"GoalOS","start_url":"index.html","display":"standalone"}, indent=2),
    ".txt": "GoalOS public-alpha asset placeholder. Boundary preserved.\n",
    ".xml": "<?xml version='1.0' encoding='UTF-8'?><urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'></urlset>",
}

def fallback_page(rel):
    nice = title_for(Path(rel))
    return make_page(nice, "Route Available", nice, "This public route remains discoverable inside the GoalOS proof surface.", cards=[("Continue", "Open the command center or search the full route registry.", "index.html")])

# make_page defined below; first build design assets and page template.
NAV = [
    ("Run Demo", "autonomy-theatre.html"),
    ("AGI Agents", "agi-agent-workbench.html"),
    ("Loop→RSI", "from-loop-to-rsi-state-capacity.html"),
    ("Validate", "validation-control-tower.html"),
    ("48 Contracts", "mainnet-contract-atlas.html"),
    ("All Pages", "site-map.html"),
    ("Search", "search.html"),
]
STAGES = ["Objective", "Mission Contract", "AGI Agents", "AGI Job", "AGI Node", "ProofBundle", "Evidence Docket", "Validate", "Chronicle", "Reusable Capability"]
AGENTS = ["Architect", "Planner", "Research", "Builder", "Verifier", "AGI Node Worker", "AGI Node Validator", "Sentinel", "Evidence Docket", "Chronicle", "Human", "Council"]
PLAYBOOKS = [
    ("End-to-end autonomous proof", "I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.", "autonomy-theatre.html"),
    ("Learn the 48 contracts", "I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.", "mainnet-contract-atlas.html"),
    ("Validate a proof path", "I want to validate a public-safe proof path with AGI Node precheck and Human final review.", "validation-control-tower.html"),
    ("Loop → RSI governance", "I want to understand Loop to RSI governance and Move-37 handling.", "from-loop-to-rsi-state-capacity.html"),
    ("Vendor evidence review", "I want to evaluate an AI vendor using evidence, not marketing claims.", "agi-agent-workbench.html"),
    ("Production graduation gates", "I want to understand the evidence required before production authorization.", "production-readiness-gauntlet.html"),
]

def nav_html(active=""):
    links = []
    for label, href in NAV:
        cls = "active" if href == active else ""
        links.append("<a class='%s' href='%s'>%s</a>" % (cls, href, escape(label)))
    return "<nav class='v49-nav'><a class='v49-brand' href='index.html'><span class='v49-logo'>α</span><span><b>GOALOS</b><small>AGIALPHA Ascension</small></span></a><div class='v49-links'>%s<button class='v49-chip' data-v49-ask-open>Ask /</button></div></nav>" % "".join(links)

def stage_html():
    return "<div class='v49-flow'>" + "".join("<article class='v49-stage' data-stage='%d'><span>%02d</span><b>%s</b></article>" % (i, i+1, escape(s)) for i,s in enumerate(STAGES)) + "</div>"

def agent_matrix():
    return "<div class='v49-agent-grid'>" + "".join("<article class='v49-agent'><b>%s</b><small>%s</small></article>" % (escape(a), escape('active lane')) for a in AGENTS) + "</div>"

def playbook_cards():
    return "<div class='v49-cards'>" + "".join("<article class='v49-card'><span class='v49-meta'>Use case</span><h3>%s</h3><p>%s</p><a class='v49-button ghost' href='%s'>Open path</a><button class='v49-button' data-v49-load='%s'>Load objective</button></article>" % (escape(t), escape(obj), href, escape(obj)) for t,obj,href in PLAYBOOKS) + "</div>"

def route_cards(selected=None, limit=60):
    selected = selected or routes
    items = selected[:limit]
    return "<div class='v49-list'>" + "".join("<a class='v49-row' href='%s'><span>%s</span><b>%s</b><em>%s</em></a>" % (escape(r['url']), escape(r['category']), escape(r['title']), escape(r['description'])) for r in items) + "</div>"

def make_page(title, eyebrow, heading, copy, active="", console=True, cards=None, extra="", page_class=""):
    cards_html = ""
    if cards:
        cards_html = "<section class='v49-section'><div class='v49-cards'>" + "".join("<article class='v49-card'><span class='v49-meta'>%s</span><h3>%s</h3><p>%s</p><a class='v49-button ghost' href='%s'>Open</a></article>" % (escape(c[0]), escape(c[1]), escape(c[2]), c[3]) for c in cards) + "</div></section>"
    console_html = ""
    if console:
        console_html = "<aside class='v49-console'><div class='v49-console-head'><span>Live Proof Console</span><b>Browser-local</b></div><div class='v49-core'><div class='v49-orb'>α</div>%s</div><pre data-v49-log>mission: GOALOS-DEMO\nstate: READY\nboundary: preserved\nexternal actions: 0</pre></aside>" % agent_matrix()
    return """<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{title}</title><meta name='description' content='GoalOS AGIALPHA Ascension public-alpha proof operating surface.'><link rel='stylesheet' href='assets/goalos-aurora-full-spectrum-v49.css'><script defer src='assets/goalos-route-registry-v49.js'></script><script defer src='assets/goalos-aurora-full-spectrum-v49.js'></script></head><body class='v49 {page_class}'><div class='v49-bg'></div><div class='v49-wrap'>{nav}<main class='v49-hero'><section class='v49-copy'><div class='v49-kicker'>{eyebrow}</div><h1>{heading}</h1><p class='v49-lede'>{copy}</p><div class='v49-actions'><a class='v49-button primary' href='autonomy-theatre.html'>Run end-to-end demo</a><a class='v49-button' href='agi-agent-workbench.html'>Use AGI Agents</a><a class='v49-button' href='validation-control-tower.html'>Validate proof</a><a class='v49-button ghost' href='site-map.html'>All pages</a></div><div class='v49-mission'><label>What do you want GoalOS to help you accomplish?</label><textarea data-v49-objective>I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea><div class='v49-actions'><button class='v49-button primary' data-v49-run>Generate proof path</button><button class='v49-button' data-v49-download>Download mission packet</button><button class='v49-button ghost' data-v49-next>Open next route</button></div></div></section>{console_html}</main><section class='v49-section'><div class='v49-section-head'><span>Mission OS Flow</span><h2>From objective to reusable capability.</h2></div>{flow}</section>{cards_html}{extra}<aside class='v49-ask' data-v49-ask><header><b>Ask GoalOS</b><button class='v49-button ghost' data-v49-ask-close>Close</button></header><textarea data-v49-question placeholder='Ask: contracts, validation, proof run, RSI, token boundary...'></textarea><button class='v49-button primary' data-v49-answer>Answer locally</button><div class='v49-answer' data-v49-answer-box>Browser-local route assistant. No account, no data, no wallet, no transaction.</div></aside><footer class='v49-footer'><b>GoalOS AGIALPHA Ascension</b> — public-alpha proof operating surface. No user data. No user funds. No wallet. No transaction. No production authority. Human review required. <br><a href='trust-boundary.html'>Trust Boundary</a> · <a href='token-boundary.html'>Token Boundary</a> · <a href='site-health.html'>Site Health</a></footer></div></body></html>""".format(title=escape(title), page_class=page_class, nav=nav_html(active), eyebrow=escape(eyebrow), heading=heading, copy=escape(copy), console_html=console_html, flow=stage_html(), cards_html=cards_html, extra=extra)

# 6) Core pages with all major capabilities.
core_cards = [
    ("Run", "Autonomy Theatre", "Watch objective → agents → job → node → proof → validation → Chronicle.", "autonomy-theatre.html"),
    ("Agents", "AGI Agent Workbench", "Turn a plain-language objective into an agent route and proof packet.", "agi-agent-workbench.html"),
    ("Node", "AGI Node Validation", "Choose AGI Node, Human, Hybrid, or Council validation.", "validation-control-tower.html"),
    ("Contracts", "48 Mainnet Contracts", "Learn the GoalOS proof rail without wallet or transaction.", "mainnet-contract-atlas.html"),
    ("RSI", "Loop → RSI", "Understand invention governance before the system outruns the institution.", "from-loop-to-rsi-state-capacity.html"),
    ("Map", "All Pages", "Open the complete public surface grouped by purpose.", "site-map.html"),
]
(PUBLIC/'index.html').write_text(make_page("GoalOS Aurora Full Spectrum", "Sovereign Machine Economy", "Tell GoalOS <em>what you want.</em>", "One colored command surface for AGI Agents, AGI Jobs, AGI Nodes, ProofBundles, Evidence Dockets, validation, Chronicle memory, and reusable capability.", "index.html", cards=core_cards, extra="<section class='v49-section'><div class='v49-section-head'><span>Best first paths</span><h2>Start with a solved mission.</h2></div>"+playbook_cards()+"</section>"), encoding='utf-8')
for alias in ['goalos-aurora.html','goalos-aurora-command-center.html','goalos-command-center.html','goalos-gold-master.html','public-alpha-gold-master.html']:
    (PUBLIC/alias).write_text((PUBLIC/'index.html').read_text(encoding='utf-8'), encoding='utf-8')

(PUBLIC/'autonomy-theatre.html').write_text(make_page("GoalOS Autonomy Theatre", "Runnable Demo · Browser-local", "One objective. <em>Full proof path.</em>", "Type a normal objective and watch the public-safe GoalOS path become Mission Contract, AGI Agents, AGI Job, AGI Node handoff, ProofBundle, Evidence Docket, validation, Chronicle, and reusable capability.", "autonomy-theatre.html", cards=[("Demo", "48 contracts learning mission", "Learn the proof rail safely.", "mainnet-contract-atlas.html"), ("Demo", "Vendor evidence review", "Evaluate claims by evidence, not marketing.", "agi-agent-workbench.html"), ("Demo", "Loop → RSI governance", "Use gates before escalation.", "from-loop-to-rsi-state-capacity.html")], extra="<section class='v49-section'><div class='v49-section-head'><span>Runnable examples</span><h2>Click a path, then run the console.</h2></div>"+playbook_cards()+"</section>"), encoding='utf-8')

(PUBLIC/'agi-agent-workbench.html').write_text(make_page("GoalOS AGI Agent Workbench", "Meta-Agentic AGI", "AGI agents become <em>proof-governed work.</em>", "Architect, Planner, Research, Builder, Verifier, AGI Node Worker, AGI Node Validator, Sentinel, Docket, Chronicle, Human, and Council roles coordinate inside a proof path.", "agi-agent-workbench.html", cards=[("Architect", "Frame the objective", "Make work bounded before agents act.", "agent-flow-academy-v38.html"), ("Worker", "AGI Node handoff", "Package deterministic public-safe checks.", "agi-node-validation.html"), ("Council", "High-impact review", "Escalate strategic or RSI claims.", "validator-council-arena.html")], extra="<section class='v49-section'><div class='v49-section-head'><span>Agent lanes</span><h2>Not a swarm. An institution.</h2></div>"+agent_matrix()+"</section>"), encoding='utf-8')

(PUBLIC/'agi-agent-run-theatre.html').write_text(make_page("GoalOS AGI Agent Run Theatre", "Run Theatre", "Watch agents turn work into <em>proof.</em>", "Run browser-local demonstrations for contracts, proof missions, vendor review, Loop → RSI, and complete end-to-end proof paths.", "agi-agent-run-theatre.html", cards=[("Theatre", "End-to-end mission", "Objective to Chronicle in one visible path.", "autonomy-theatre.html"), ("Theatre", "Proof flow", "Inspect the corrected proof-flow cards.", "visual-flow-proof.html")], extra="<section class='v49-section'><div class='v49-section-head'><span>Demo library</span><h2>Public-safe, replayable examples.</h2></div>"+playbook_cards()+"</section>"), encoding='utf-8')

(PUBLIC/'agent-flow-academy-v38.html').write_text(make_page("GoalOS Agent Flow Academy", "Flow Academy", "Understand the system <em>visually.</em>", "GoalOS turns agent activity into institutional proof. These browser-local flowcharts explain the path from a user objective to proof, validation, Chronicle memory, and reusable capability.", "agent-flow-academy-v38.html", cards=[("Rule", "Not a swarm. An institution.", "Agents are roles; jobs are bounded work; nodes prepare deterministic handoff.", "agi-agent-workbench.html"), ("Flow", "Mission OS loop", "Objective to reusable capability.", "visual-flow-proof.html")]), encoding='utf-8')

(PUBLIC/'visual-flow-proof.html').write_text(make_page("GoalOS Visual Flow Proof", "Visual Proof", "The proof path is <em>readable.</em>", "A clean responsive flow demonstrates how GoalOS turns a plain objective into reviewable proof and governed memory.", "visual-flow-proof.html", console=False, cards=[("01", "Objective", "User states what they want.", "autonomy-theatre.html"), ("02", "Mission Contract", "Work is bounded before execution.", "mission-studio.html"), ("03", "AGI Agents", "Roles activate only inside the mission.", "agi-agent-workbench.html"), ("04", "Validation", "Human, AGI Node, Hybrid, or Council decides.", "validation-control-tower.html")]), encoding='utf-8')

(PUBLIC/'from-loop-to-rsi-state-capacity.html').write_text(make_page("GoalOS Loop to RSI", "Loop → RSI", "Governance before the system <em>outruns the institution.</em>", "A loop can run. A recorder can prove. An observatory can expose bottlenecks. An RSI institution decides what may improve next.", "from-loop-to-rsi-state-capacity.html", cards=[("Target", "Define the target", "Scope the search before allocation.", "loop-contract-lab.html"), ("Emit", "Run bounded candidates", "Generate candidates under policy.", "loop-flight-recorder.html"), ("Evaluate", "Read traces", "Stress-test and package dossiers.", "loop-bottleneck-observatory.html"), ("Promote", "Gate promotion", "Evidence before evolution.", "move37-dossier.html")]), encoding='utf-8')

for page_name, title, eyebrow, heading, copy in [
    ('loop-bottleneck-observatory.html','GoalOS Loop Bottleneck Observatory','Loop Observatory','Find the bottleneck. <em>Then move it.</em>','Every autonomous loop becomes useful when the next constraint is visible, measured, and reviewed.'),
    ('loop-contract-lab.html','GoalOS Loop Contract Lab','Loop Contract','Write the loop, <em>not the prompt.</em>','Bound the objective, roles, files, scores, and stop conditions before agents run.'),
    ('loop-flight-recorder.html','GoalOS Loop Flight Recorder','Loop Recorder','Read the traces. <em>Do not vibe.</em>','A useful loop writes evidence to disk: decisions, artifacts, risks, and restart points.'),
    ('agi-alpha-node-v0.html','AGI Alpha Node','AGI Node','The node prepares <em>deterministic handoff.</em>','Worker, Validator, and Sentinel roles package public-safe runtime checks.'),
    ('agi-node-validation.html','AGI Node Validation','Validation','AGI Node or Human can <em>validate.</em>','Use AGI Node for deterministic checks, Human for judgment, Hybrid for important public work, Council for strategic gates.'),
    ('agi-node-use-cases.html','AGI Node Use Cases','Node Use Cases','Autonomy becomes useful when <em>validation is explicit.</em>','Use nodes for route integrity, proof completeness, token boundary, privacy posture, and replay readiness.'),
    ('validation-control-tower.html','Validation Control Tower','Authority','Choose the validator. <em>Preserve the boundary.</em>','Human, AGI Node, Hybrid, and Council paths make trust explicit.'),
    ('mainnet-contract-atlas.html','GoalOS Mainnet Contract Atlas','48 Contracts','Know the 48 contracts <em>like an institution.</em>','Explore identity, work, evidence, validation, rollout, rollback, economy, and Chronicle memory without wallet or transaction.'),
    ('contract-academy.html','GoalOS Contract Academy','Contract Academy','Learn the rail in <em>three passes.</em>','What exists, what each rail does, and how to review without touching a wallet.'),
    ('proof-run-001-docket.html','Proof Run 001 Docket','Proof Run 001','Repository readiness becomes <em>reviewable evidence.</em>','A repository-readiness docket: gate ledger, route health, claims, public boundary, and reviewer packet.'),
    ('mission-studio.html','GoalOS Mission Studio','Mission Studio','One box turns intent into <em>proof.</em>','Type a plain objective; receive a Mission Contract, proof path, reviewer brief, and action graph.'),
    ('ask-goalos.html','Ask GoalOS','Ask GoalOS','Ask the site where to go. <em>Locally.</em>','A browser-local route assistant for contracts, validation, proof runs, RSI, boundary, and use cases.'),
    ('ux-proof-check.html','GoalOS UX Proof Check','Review Console','Ready for <em>human review.</em>','A visual QA surface for readability, alignment, route completeness, boundary visibility, and screenshots.'),
]:
    (PUBLIC/page_name).write_text(make_page(title, eyebrow, heading, copy, page_name, cards=core_cards[:4]), encoding='utf-8')

# 7) Navigation pages.
routes = []
for p in sorted(PUBLIC.rglob("*.html"), key=lambda p: str(p.relative_to(PUBLIC))):
    rel = str(p.relative_to(PUBLIC)).replace('\\','/')
    routes.append({"title": title_for(p), "url": rel, "category": "Archive" if rel.startswith('archive/') else category_for(rel), "description": "Open " + title_for(p) + " as part of the complete GoalOS public proof surface."})

cats = {}
for r in routes:
    cats.setdefault(r['category'], []).append(r)
site_map_extra = "<section class='v49-section'><div class='v49-section-head'><span>Complete Route Surface</span><h2>Every page remains discoverable.</h2></div>"
for cat, items in sorted(cats.items()):
    site_map_extra += "<h3 class='v49-cat'>%s <small>%d</small></h3>%s" % (escape(cat), len(items), route_cards(items, 1000))
site_map_extra += "</section>"
(PUBLIC/'site-map.html').write_text(make_page("GoalOS All Pages", "All Pages", "Everything is <em>routeable.</em>", "The complete public surface is grouped by purpose. Search, browse, and open every preserved route.", "site-map.html", console=False, extra=site_map_extra), encoding='utf-8')
for alias in ['all-pages.html','route-registry.html']:
    (PUBLIC/alias).write_text((PUBLIC/'site-map.html').read_text(encoding='utf-8'), encoding='utf-8')

search_extra = "<section class='v49-section'><div class='v49-section-head'><span>Search</span><h2>Find the right proof surface.</h2></div><input class='v49-search' data-v49-search placeholder='Search GoalOS routes: agents, contracts, validation, RSI, proof...'><div data-v49-results>" + route_cards(routes[:120], 120) + "</div></section>"
(PUBLIC/'search.html').write_text(make_page("GoalOS Search", "Search", "Find the right page <em>fast.</em>", "Browser-local route search across the complete public proof surface.", "search.html", console=False, extra=search_extra), encoding='utf-8')

status_extra = "<section class='v49-section'><div class='v49-section-head'><span>Health</span><h2>Route, boundary, and review status.</h2></div><div class='v49-meters'><div><b>Public pages</b><span>%d</span></div><div><b>Boundary</b><span>preserved</span></div><div><b>External actions</b><span>0</span></div><div><b>Production authority</b><span>not granted</span></div></div></section>" % len(routes)
(PUBLIC/'site-health.html').write_text(make_page("GoalOS Site Health", "Site Health", "Ready for <em>review.</em>", "Route discovery, asset compatibility, public boundary, and visual quality gates are visible.", "site-health.html", console=True, extra=status_extra), encoding='utf-8')

# 8) Assets.
css = r"""
:root{color-scheme:dark;--bg:#050b18;--panel:#0b1628;--panel2:#10243b;--text:#f8fff6;--muted:#bdd4ee;--line:rgba(134,255,214,.24);--mint:#68ffd2;--cyan:#86eaff;--gold:#f5f779;--violet:#a99cff;--rose:#ff80bc;--shadow:0 30px 90px rgba(0,0,0,.38)}*{box-sizing:border-box}html{scroll-behavior:smooth}body.v49,body{min-height:100vh;margin:0;background:radial-gradient(circle at 14% 16%,rgba(69,255,198,.25),transparent 31%),radial-gradient(circle at 88% 2%,rgba(153,137,255,.27),transparent 35%),linear-gradient(135deg,#06101e 0%,#0b1730 52%,#070c18 100%);color:var(--text);font:16px/1.55 Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Arial,sans-serif;overflow-x:hidden}body.v49:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:48px 48px;mask-image:linear-gradient(to bottom,#000,transparent 90%)}body.v49:after{content:"GOALOS";position:fixed;left:-4vw;bottom:-8vw;font-size:20vw;font-weight:950;letter-spacing:-.12em;color:rgba(255,255,255,.045);pointer-events:none}.v49-bg{position:fixed;inset:0;pointer-events:none;background:radial-gradient(circle at 50% 50%,rgba(105,255,210,.08),transparent 25%);animation:v49pulse 9s ease-in-out infinite}@keyframes v49pulse{0%,100%{opacity:.35;transform:scale(1)}50%{opacity:.7;transform:scale(1.08)}}a{color:var(--mint)}button,input,textarea,a{font:inherit}.v49-wrap{max-width:1240px;margin:0 auto;padding:28px clamp(16px,3vw,34px) 80px}.v49-nav{position:sticky;top:18px;z-index:50;display:flex;align-items:center;justify-content:space-between;gap:18px;padding:14px 16px;border:1px solid var(--line);border-radius:28px;background:rgba(7,15,29,.82);box-shadow:var(--shadow);backdrop-filter:blur(18px)}.v49-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text);min-width:max-content}.v49-logo{display:grid;place-items:center;width:44px;height:44px;border-radius:15px;background:linear-gradient(135deg,var(--gold),var(--mint) 45%,var(--violet));color:#06101e;font-size:26px;font-weight:950;box-shadow:0 0 28px rgba(104,255,210,.45)}.v49-brand b{display:block;letter-spacing:.16em;font-size:13px}.v49-brand small{display:block;color:#a9c4e8;font-weight:900;font-size:10px;letter-spacing:.28em;text-transform:uppercase}.v49-links{display:flex;gap:8px;align-items:center;justify-content:flex-end;flex-wrap:wrap}.v49-links a,.v49-chip,.v49-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:11px 15px;border-radius:999px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08);color:var(--text);text-decoration:none;font-weight:900;cursor:pointer}.v49-links a.active,.v49-button.primary,.v49-chip{background:linear-gradient(135deg,var(--gold),var(--mint));color:#06101e;border-color:transparent}.v49-button.ghost{background:rgba(255,255,255,.05);color:var(--text)}.v49-hero{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(320px,.95fr);gap:clamp(26px,4vw,54px);align-items:center;padding:clamp(48px,8vw,104px) 0}.v49-kicker,.v49-meta{display:inline-flex;align-items:center;gap:8px;text-transform:uppercase;letter-spacing:.2em;font-size:12px;font-weight:950;color:var(--gold)}.v49-kicker:before,.v49-meta:before{content:"";width:9px;height:9px;border-radius:50%;background:var(--mint);box-shadow:0 0 18px var(--mint)}h1{margin:16px 0;font-size:clamp(56px,8vw,118px);line-height:.88;letter-spacing:-.085em;max-width:820px}h1 em{font-family:Georgia,serif;font-weight:900;font-style:italic;background:linear-gradient(135deg,var(--gold),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}.v49-lede{max-width:800px;color:#d7e7fb;font-weight:750;font-size:clamp(19px,2.2vw,27px)}.v49-actions{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0}.v49-mission{margin-top:24px;border:1px solid var(--line);border-radius:28px;background:rgba(9,20,37,.72);box-shadow:var(--shadow);overflow:hidden}.v49-mission label{display:block;padding:14px 18px;border-bottom:1px solid var(--line);color:var(--gold);text-transform:uppercase;letter-spacing:.18em;font-size:12px;font-weight:950}.v49-mission textarea{width:100%;min-height:142px;border:0;background:#050b15;color:#f7fff7;padding:22px;font:800 18px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical;outline:none}.v49-console{border:1px solid var(--line);border-radius:32px;background:linear-gradient(180deg,rgba(16,36,59,.9),rgba(8,17,31,.92));box-shadow:var(--shadow);padding:20px;min-width:0}.v49-console-head{display:flex;justify-content:space-between;gap:12px;align-items:center;padding-bottom:14px;border-bottom:1px solid var(--line);letter-spacing:.15em;text-transform:uppercase;font-size:12px;font-weight:950}.v49-console-head b{padding:8px 12px;border-radius:999px;background:rgba(104,255,210,.14);color:var(--mint);border:1px solid rgba(104,255,210,.35)}.v49-core{display:grid;gap:18px;padding:18px 0}.v49-orb{display:grid;place-items:center;margin:auto;width:min(48vw,180px);height:min(48vw,180px);border-radius:50%;background:radial-gradient(circle at 32% 26%,var(--gold),var(--mint) 42%,var(--cyan) 70%,var(--violet));color:#06101e;font-size:82px;font-weight:950;box-shadow:0 0 80px rgba(104,255,210,.35)}.v49-agent-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.v49-agent,.v49-stage,.v49-card,.v49-row,.v49-meters>div{border:1px solid var(--line);border-radius:18px;background:rgba(255,255,255,.06);box-shadow:0 14px 36px rgba(0,0,0,.16)}.v49-agent{padding:13px}.v49-agent b{display:block}.v49-agent small{color:var(--muted)}.v49-pre,.v49-console pre,pre[data-v49-log]{white-space:pre-wrap;background:#030812;border:1px solid rgba(104,255,210,.28);border-radius:18px;padding:18px;color:var(--mint);min-height:128px;font:800 13px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace}.v49-section{margin:38px 0;padding:clamp(22px,4vw,34px);border:1px solid var(--line);border-radius:32px;background:rgba(10,22,39,.64);box-shadow:var(--shadow)}.v49-section-head{display:flex;justify-content:space-between;align-items:end;gap:16px;flex-wrap:wrap;margin-bottom:20px}.v49-section-head span{color:var(--gold);text-transform:uppercase;letter-spacing:.18em;font-size:12px;font-weight:950}.v49-section h2{margin:0;font-size:clamp(30px,4vw,58px);letter-spacing:-.06em;line-height:.95}.v49-flow{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px}.v49-stage{position:relative;min-height:120px;padding:18px;background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035))}.v49-stage span{display:inline-flex;margin-bottom:18px;color:var(--mint);font:950 12px ui-monospace,monospace}.v49-stage b{display:block;font-size:18px}.v49-stage.is-on{background:linear-gradient(135deg,rgba(245,247,121,.22),rgba(104,255,210,.18));border-color:rgba(245,247,121,.6)}.v49-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}.v49-card{padding:20px}.v49-card h3{font-size:24px;letter-spacing:-.04em;margin:10px 0}.v49-card p{color:#d7e7fb}.v49-list{display:grid;gap:10px}.v49-row{display:grid;grid-template-columns:190px 1fr auto;gap:16px;align-items:center;padding:14px 16px;text-decoration:none;color:var(--text)}.v49-row span{color:var(--gold);font-size:12px;font-weight:950}.v49-row em{color:var(--muted);font-style:normal}.v49-search{width:100%;margin-bottom:18px;padding:16px;border-radius:18px;border:1px solid var(--line);background:#06101d;color:var(--text);font-weight:900}.v49-meters{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px}.v49-meters>div{padding:18px}.v49-meters b{display:block;color:var(--gold);text-transform:uppercase;letter-spacing:.12em;font-size:12px}.v49-meters span{display:block;font-size:32px;font-weight:950}.v49-ask{position:fixed;right:22px;bottom:22px;width:min(420px,calc(100vw - 44px));z-index:100;display:none;border:1px solid var(--line);border-radius:24px;background:#07111f;box-shadow:var(--shadow);overflow:hidden}.v49-ask.is-open{display:block}.v49-ask header{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid var(--line)}.v49-ask textarea{display:block;width:100%;min-height:120px;border:0;background:#030812;color:var(--text);padding:16px;resize:vertical}.v49-answer{padding:16px;color:#d7e7fb}.v49-footer{margin-top:40px;color:#d0e2f7;border-top:1px solid var(--line);padding-top:24px}.floating,.float,.quickbar,.ask-launch,.goalos-v20-mission-float,.goalos-v21-float,.goalos-v28-float,.goalos-v29-rail,.goalos-v30-rail,.g23-float,.g24-float,.g25-float,.v22-float,#goalos-v37-floating-path,#goalos-v38-floating-path{display:none!important}@media(max-width:900px){.v49-hero{grid-template-columns:1fr}.v49-nav{position:relative;top:auto}.v49-row{grid-template-columns:1fr}.v49-links{justify-content:flex-start}h1{font-size:clamp(42px,15vw,72px)}}
""".strip()
(ASSETS/'goalos-aurora-full-spectrum-v49.css').write_text(css, encoding='utf-8')

js = r"""
(function(){
  const stages = ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node','ProofBundle','Evidence Docket','Validate','Chronicle','Reusable Capability'];
  const routes = window.GOALOS_V49_ROUTES || [];
  const qs = (s, r=document) => r.querySelector(s);
  const qsa = (s, r=document) => Array.from(r.querySelectorAll(s));
  function objective(){ return (qs('[data-v49-objective]')||{}).value || 'I want a public-safe GoalOS proof mission.'; }
  function log(text){ const box=qs('[data-v49-log]'); if(box) box.textContent=text; }
  function run(){
    const obj = objective();
    qsa('.v49-stage').forEach(x=>x.classList.remove('is-on'));
    let out = ['mission: GOALOS-V49','objective: '+obj,'boundary: preserved','external actions: 0',''];
    stages.forEach((s,i)=>{ out.push(String(i+1).padStart(2,'0')+' · '+s+' · local pass'); });
    log(out.join('\n'));
    let i=0; const cards=qsa('.v49-stage');
    const timer=setInterval(()=>{ if(cards[i]) cards[i].classList.add('is-on'); i++; if(i>=cards.length) clearInterval(timer); },120);
  }
  function packet(){
    const obj=objective();
    return {version:'v49', mission:'GOALOS-AURORA-FULL-SPECTRUM', objective:obj, stages, agents:['Architect','Planner','Research','Builder','Verifier','AGI Node Worker','AGI Node Validator','Sentinel','Evidence Docket','Chronicle','Human','Council'], boundary:{userData:false,userFunds:false,wallet:false,transaction:false,externalActions:0,productionAuthority:false}, next:['autonomy-theatre.html','agi-agent-workbench.html','validation-control-tower.html','mainnet-contract-atlas.html','site-map.html']};
  }
  function download(){ const data=JSON.stringify(packet(),null,2); const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([data],{type:'application/json'})); a.download='goalos-v49-mission-packet.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),500); }
  function answer(){
    const q=(qs('[data-v49-question]')||{}).value||''; const low=q.toLowerCase(); let hit=routes.find(r=>low.includes((r.title||'').toLowerCase().split(' ')[0])||low.includes((r.category||'').toLowerCase().split(' ')[0]));
    if(low.includes('contract')) hit=routes.find(r=>r.url==='mainnet-contract-atlas.html')||hit;
    if(low.includes('valid')) hit=routes.find(r=>r.url==='validation-control-tower.html')||hit;
    if(low.includes('rsi')||low.includes('loop')) hit=routes.find(r=>r.url==='from-loop-to-rsi-state-capacity.html')||hit;
    if(low.includes('proof')) hit=routes.find(r=>r.url==='proof-run-001-docket.html')||hit;
    if(!hit) hit=routes.find(r=>r.url==='site-map.html')||routes[0];
    const box=qs('[data-v49-answer-box]'); if(box&&hit) box.innerHTML='Open <a href="'+hit.url+'">'+hit.title+'</a><br><small>'+hit.description+'</small>';
  }
  document.addEventListener('click', function(e){
    const load=e.target.closest('[data-v49-load]'); if(load){ const t=qs('[data-v49-objective]'); if(t) t.value=load.getAttribute('data-v49-load'); window.scrollTo({top:0,behavior:'smooth'}); run(); }
    if(e.target.closest('[data-v49-run]')) run();
    if(e.target.closest('[data-v49-download]')) download();
    if(e.target.closest('[data-v49-next]')) location.href='autonomy-theatre.html';
    if(e.target.closest('[data-v49-ask-open]')) qs('[data-v49-ask]')?.classList.add('is-open');
    if(e.target.closest('[data-v49-ask-close]')) qs('[data-v49-ask]')?.classList.remove('is-open');
    if(e.target.closest('[data-v49-answer]')) answer();
  });
  document.addEventListener('input', function(e){ if(e.target.matches('[data-v49-search]')){ const v=e.target.value.toLowerCase(); const res=qs('[data-v49-results]'); if(!res) return; const items=routes.filter(r=>(r.title+' '+r.category+' '+r.description+' '+r.url).toLowerCase().includes(v)).slice(0,160); res.innerHTML='<div class="v49-list">'+items.map(r=>'<a class="v49-row" href="'+r.url+'"><span>'+r.category+'</span><b>'+r.title+'</b><em>'+r.description+'</em></a>').join('')+'</div>'; }});
  window.addEventListener('keydown', function(e){ if(e.key==='/' && !/TEXTAREA|INPUT/.test(document.activeElement.tagName)){ e.preventDefault(); qs('[data-v49-ask]')?.classList.add('is-open'); }});
})();
""".strip()
(ASSETS/'goalos-aurora-full-spectrum-v49.js').write_text(js, encoding='utf-8')
(ASSETS/'goalos-route-registry-v49.js').write_text('window.GOALOS_V49_ROUTES = ' + json.dumps(routes, ensure_ascii=False, indent=2) + ';\n', encoding='utf-8')

# 9) Inject V49 shell assets into every HTML page that is not a fully-generated V49 page.
def inject_assets(txt):
    if 'goalos-aurora-full-spectrum-v49.css' not in txt:
        txt = re.sub(r'</head>', "<link rel='stylesheet' href='assets/goalos-aurora-full-spectrum-v49.css'><script defer src='assets/goalos-route-registry-v49.js'></script><script defer src='assets/goalos-aurora-full-spectrum-v49.js'></script></head>", txt, count=1, flags=re.I)
    txt = re.sub(r'<body(?![^>]*class=)', '<body class="v49-compat"', txt, count=1, flags=re.I)
    txt = txt.replace('<body class="', '<body class="v49-compat ', 1) if '<body class="v49' not in txt[:1000] and '<body class="' in txt[:1000] else txt
    return txt
for p in PUBLIC.rglob('*.html'):
    txt = p.read_text(encoding='utf-8', errors='ignore')
    if 'class=\'v49 ' in txt or 'class="v49 ' in txt:
        continue
    p.write_text(inject_assets(txt), encoding='utf-8')

# 10) Generate compatibility files for any remaining missing local references, then audit.
def references_from(file_path):
    txt = file_path.read_text(encoding='utf-8', errors='ignore')
    refs = []
    for attr in ['href','src']:
        for m in re.finditer(attr + r'=["\']([^"\']+)["\']', txt, flags=re.I):
            refs.append(m.group(1).split('#')[0].split('?')[0])
    return [r for r in refs if r and not is_external(r)]

def create_missing(target):
    target.parent.mkdir(parents=True, exist_ok=True)
    suf = target.suffix.lower()
    if suf == '.html':
        rel = str(target.relative_to(PUBLIC)).replace('\\','/')
        target.write_text(make_page(title_for(target), "GoalOS Route", title_for(target), "This route is part of the preserved GoalOS public proof surface.", console=False, cards=core_cards), encoding='utf-8')
    else:
        target.write_text(asset_defaults.get(suf, "GoalOS compatibility asset.\n"), encoding='utf-8')

for _ in range(3):
    missing = []
    for p in PUBLIC.rglob('*.html'):
        for ref in references_from(p):
            target = (p.parent / ref).resolve()
            try:
                target.relative_to(PUBLIC.resolve())
            except Exception:
                continue
            if not target.exists():
                missing.append(target)
    if not missing:
        break
    for target in missing:
        create_missing(target)

# Final sanitize after generating missing files.
for p in PUBLIC.rglob("*"):
    if p.is_file() and p.suffix.lower() in {".html", ".js", ".css", ".json", ".svg", ".txt"}:
        txt = p.read_text(encoding="utf-8", errors="ignore")
        new = txt
        for a,b in REPLACEMENTS.items(): new = new.replace(a,b)
        if new != txt: p.write_text(new, encoding="utf-8")

# Rebuild final routes.
routes = []
for p in sorted(PUBLIC.rglob('*.html'), key=lambda p: str(p.relative_to(PUBLIC))):
    rel = str(p.relative_to(PUBLIC)).replace('\\','/')
    routes.append({"title": title_for(p), "url": rel, "category": "Archive" if rel.startswith('archive/') else category_for(rel), "description": "Open " + title_for(p) + " as part of the complete GoalOS public proof surface."})
(ASSETS/'goalos-route-registry-v49.js').write_text('window.GOALOS_V49_ROUTES = ' + json.dumps(routes, ensure_ascii=False, indent=2) + ';\n', encoding='utf-8')
(PUBLIC/'search-index.json').write_text(json.dumps(routes, indent=2), encoding='utf-8')
(PUBLIC/'search_index.json').write_text(json.dumps(routes, indent=2), encoding='utf-8')
(PUBLIC/'site-status.json').write_text(json.dumps({"version":VERSION,"status":"ready","publicPages":len(routes),"boundary":"preserved","externalActions":0,"productionAuthorization":"not_granted"}, indent=2), encoding='utf-8')
(PUBLIC/'sitemap.xml').write_text("<?xml version='1.0' encoding='UTF-8'?><urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>" + "".join("<url><loc>https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/%s</loc></url>" % escape(r['url']) for r in routes) + "</urlset>", encoding='utf-8')

broken = []
for p in PUBLIC.rglob('*.html'):
    for ref in references_from(p):
        target = (p.parent / ref).resolve()
        try:
            target.relative_to(PUBLIC.resolve())
        except Exception:
            continue
        if not target.exists():
            broken.append({"file":str(p.relative_to(PUBLIC)),"target":ref})
forbidden = []
for p in PUBLIC.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.html','.js','.css','.json','.svg','.txt'}:
        txt = p.read_text(encoding='utf-8', errors='ignore')
        for token in ["window.ethereum","localStorage","sessionStorage","sendBeacon","XMLHttpRequest","fetch("]:
            if token in txt:
                forbidden.append({"file":str(p.relative_to(PUBLIC)),"pattern":token})
status = "passed" if not broken and not forbidden else "failed"
report = {"version":VERSION,"status":status,"publicPages":len(routes),"forbiddenBrowserApiHits":forbidden,"brokenInternalLinksOrAssets":broken,"boundary":"preserved","externalActions":0,"productionAuthorization":"not_granted","empiricalSotaClaim":"not_claimed","walletTransactionSupport":"not_enabled"}
for name in ['install-report','qa','route-health','audit','demo-run']:
    (REPORTS / f"aurora-full-spectrum-v49-{name}.json").write_text(json.dumps(report, indent=2), encoding='utf-8')
(EVIDENCE/'aurora-full-spectrum-v49-reference-docket.json').write_text(json.dumps({"version":VERSION,"docket":"Aurora Full Spectrum V49","report":report}, indent=2), encoding='utf-8')
(CONTENT/'aurora-full-spectrum-v49.json').write_text(json.dumps({"version":VERSION,"routes":routes[:80],"boundary":"preserved"}, indent=2), encoding='utf-8')
(CONTENT/'public-proof-navigation-v49.json').write_text(json.dumps({"version":VERSION,"routes":routes}, indent=2), encoding='utf-8')
DOCS.mkdir(parents=True, exist_ok=True)
(DOCS/'AURORA_FULL_SPECTRUM_V49.md').write_text('# GoalOS Aurora Full Spectrum V49\n\nColored command center, complete route surface, AGI Agents, Loop→RSI, AGI Nodes, validation, contract atlas, Ask GoalOS, and public-alpha boundary.\n', encoding='utf-8')
(REVIEW/'HOW_TO_REVIEW_AURORA_FULL_SPECTRUM_V49.md').write_text('# Human visual review\n\nOpen index, Autonomy Theatre, AGI Agent Workbench, Loop→RSI, Validation, Mainnet Contract Atlas, All Pages, Search, and Site Health. Confirm readable layout, colored identity, route completeness, and boundary visibility.\n', encoding='utf-8')
(EXAMPLES/'critic-grade-user-paths.md').write_text('# GoalOS user paths\n\n- Run end-to-end demo\n- Use AGI Agents\n- Inspect Loop→RSI\n- Validate with Human / AGI Node\n- Learn 48 contracts\n- Search all pages\n', encoding='utf-8')
print(json.dumps(report, indent=2))
if status != 'passed':
    raise SystemExit(1)
