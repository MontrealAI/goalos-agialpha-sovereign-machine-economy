#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import html

VERSION = "v45"
FEATURE = "GoalOS Aurora Command Center V45"
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
REPORTS = ROOT / "reports"
DOCS = ROOT / "docs"
CONTENT = ROOT / "content" / "goalos"
EVIDENCE = ROOT / "evidence" / "demo"
EXAMPLES = ROOT / "examples" / "aurora-command-center-v45"
ASSETS = PUBLIC / "assets"

CANONICAL_ROUTES = [
    ("goalos-aurora-command-center.html", "GoalOS Aurora Command Center", "Start here: one colorful, serious, human-readable front door for GoalOS."),
    ("index.html", "Home", "Canonical homepage and command surface."),
    ("goalos-command-center.html", "Command Center", "Operate the public-alpha GoalOS system from one place."),
    ("goalos-gold-master.html", "Gold Master", "Public-alpha Gold Master checkpoint."),
    ("autonomy-theatre.html", "Autonomy Theatre", "Run the end-to-end objective to proof to Chronicle demo."),
    ("agi-agent-workbench.html", "AGI Agent Workbench", "Turn a plain-language objective into agents, jobs, node handoff, docket, validation, and routes."),
    ("validation-control-tower.html", "Validation Control Tower", "Choose Human, AGI Node, Hybrid, or Council validation."),
    ("mainnet-contract-atlas.html", "48 Mainnet Contracts", "Learn the GoalOS-created Ethereum Mainnet contract proof rail."),
    ("visual-flow-proof.html", "Visual Flow Proof", "Aligned proof flow without overlapping divs or hidden text."),
    ("ux-proof-check.html", "Human UX Proof Check", "Human visual QA checklist and proof of layout review."),
    ("site-map.html", "All Pages", "Complete route inventory grouped by purpose."),
    ("all-pages.html", "All Pages Alias", "Alias for the complete route inventory."),
    ("route-registry.html", "Route Registry", "Machine-readable public route surface."),
    ("search.html", "Search", "Browser-local route search."),
    ("site-health.html", "Site Health", "Route, boundary, and visual QA status."),
    ("ask-goalos.html", "Ask GoalOS", "Browser-local route assistant."),
    ("trust-boundary.html", "Trust Boundary", "No-data, no-funds, no-wallet, no-transaction boundary."),
    ("token-boundary.html", "Token Boundary", "$AGIALPHA public contract identification boundary."),
    ("graduation-control-room.html", "Graduation Control Room", "Production-graduation runway without premature claims."),
    ("production-readiness-gauntlet.html", "Production Readiness Gauntlet", "Hard gates before production authorization."),
    ("external-validation-roadmap.html", "External Validation Roadmap", "Path to externally replayable Evidence Dockets."),
    ("evidence-to-production-roadmap.html", "Evidence to Production Roadmap", "Evidence ladder toward real-world operation."),
]

PLAYBOOKS = [
    {"title": "Understand GoalOS in 10 minutes", "objective": "I am new and want the fastest path to understand GoalOS.", "routes": ["goalos-aurora-command-center.html", "autonomy-theatre.html", "site-map.html"], "artifact": "guided orientation packet"},
    {"title": "Run the end-to-end proof demo", "objective": "I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.", "routes": ["autonomy-theatre.html", "visual-flow-proof.html", "ux-proof-check.html"], "artifact": "mission contract, proof path, reviewer brief"},
    {"title": "Learn the 48 Mainnet contracts", "objective": "I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.", "routes": ["mainnet-contract-atlas.html", "contract-academy.html", "mainnet-proof-rail.html"], "artifact": "contract learning path"},
    {"title": "Validate with Human or AGI Node", "objective": "I want to validate a public-safe proof path with AGI Node precheck and Human final review.", "routes": ["validation-control-tower.html", "agi-node-use-cases.html", "ux-proof-check.html"], "artifact": "validation certificate"},
    {"title": "Evaluate an AI vendor", "objective": "I want to evaluate an AI vendor using evidence, not marketing claims.", "routes": ["agi-agent-workbench.html", "evidence-docket-theatre.html", "validation-control-tower.html"], "artifact": "evidence review brief"},
    {"title": "Production-readiness runway", "objective": "I want to understand what evidence is required before production authorization.", "routes": ["graduation-control-room.html", "production-readiness-gauntlet.html", "external-validation-roadmap.html"], "artifact": "readiness gate checklist"},
]

BANNED_DIRECT = [
    "send" + "Beacon",
    "local" + "Storage",
    "session" + "Storage",
    "window." + "ethereum",
    "XML" + "HttpRequest",
]

CSS = r'''
:root{
  --ink:#f7f2e8;--muted:#c9d3e7;--deep:#030716;--navy:#07111f;
  --card:rgba(9,18,35,.78);--card2:rgba(19,31,55,.76);--line:rgba(152,246,226,.26);
  --mint:#67ffd2;--cyan:#7ee7ff;--gold:#ffe86a;--lime:#c9ff7b;--violet:#a694ff;--pink:#ff7bb6;
  --radius:28px;--shadow:0 30px 90px rgba(0,0,0,.36);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{
  margin:0;min-height:100vh;color:var(--ink);
  background:radial-gradient(circle at 12% 18%,rgba(103,255,210,.24),transparent 32%),
  radial-gradient(circle at 76% 10%,rgba(166,148,255,.24),transparent 34%),
  radial-gradient(circle at 64% 76%,rgba(126,231,255,.16),transparent 34%),
  linear-gradient(135deg,#031315 0%,#061729 48%,#080617 100%);
  font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;overflow-x:hidden;
}
body::before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.95),rgba(0,0,0,.40));}
a{color:var(--mint)}a:hover{color:var(--gold)}
.goalos-v45-page{position:relative;z-index:1}
.v45-shell{width:min(1220px,calc(100vw - 40px));margin:0 auto;padding:28px 0 80px}
.v45-nav{position:sticky;top:14px;z-index:20;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;padding:14px 18px;margin-bottom:66px;border:1px solid rgba(126,231,255,.24);border-radius:28px;background:linear-gradient(135deg,rgba(4,10,22,.88),rgba(15,23,42,.74));box-shadow:var(--shadow);backdrop-filter:blur(18px)}
.v45-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--ink)}
.v45-logo{width:42px;height:42px;border-radius:15px;display:grid;place-items:center;color:#020617;font-weight:1000;background:radial-gradient(circle at 25% 25%,var(--gold),var(--mint) 42%,var(--cyan) 70%,var(--violet));box-shadow:0 0 32px rgba(103,255,210,.36)}
.v45-brand strong{display:block;font-size:14px;letter-spacing:.18em;text-transform:uppercase}.v45-brand span span{display:block;font-size:10px;letter-spacing:.28em;text-transform:uppercase;color:#b7c4db}
.v45-nav-links{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.v45-nav-links a,.v45-pill,.v45-button{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:10px 14px;background:rgba(255,255,255,.08);color:var(--ink);text-decoration:none;font-weight:900;font-size:13px}
.v45-nav-links a[aria-current="page"],.v45-pill.primary,.v45-button.primary{color:#031315;background:linear-gradient(135deg,var(--gold),var(--lime),var(--mint));border-color:transparent;box-shadow:0 18px 42px rgba(103,255,210,.20)}
.v45-hero{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(360px,.95fr);gap:42px;align-items:center}
.v45-kicker{display:flex;align-items:center;gap:10px;color:var(--gold);font-size:12px;font-weight:1000;letter-spacing:.42em;text-transform:uppercase}
.v45-kicker::before{content:"";width:10px;height:10px;border-radius:999px;background:var(--mint);box-shadow:0 0 24px var(--mint)}
.v45-title{margin:16px 0;font-size:clamp(54px,8.6vw,116px);line-height:.85;letter-spacing:-.085em;max-width:960px}
.v45-title em{font-family:Georgia,ui-serif,serif;font-style:italic;letter-spacing:-.055em;background:linear-gradient(100deg,var(--gold),var(--lime),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}
.v45-subtitle{font-size:clamp(20px,2.8vw,34px);line-height:1.04;letter-spacing:-.05em;font-weight:1000;max-width:820px;margin:18px 0;color:#fff}
.v45-copy{font-size:18px;line-height:1.72;color:var(--muted);max-width:760px}
.v45-actions{display:flex;flex-wrap:wrap;gap:12px;margin:26px 0}
.v45-button{cursor:pointer;display:inline-flex;align-items:center;gap:8px}.v45-button:hover{transform:translateY(-1px)}
.v45-boundary{margin-top:20px;padding:16px 18px;border-radius:18px;background:linear-gradient(135deg,rgba(255,123,182,.12),rgba(255,232,106,.08));border:1px solid rgba(255,123,182,.38);color:#fff;font-weight:800;line-height:1.5}
.v45-console{border:1px solid rgba(126,231,255,.28);background:linear-gradient(145deg,rgba(10,22,40,.86),rgba(31,31,70,.72));box-shadow:var(--shadow);border-radius:34px;padding:22px;min-height:560px;overflow:hidden}
.v45-console-head{display:flex;justify-content:space-between;gap:12px;align-items:center;border-bottom:1px solid rgba(255,255,255,.14);padding-bottom:14px;margin-bottom:18px}
.v45-console-head span{font-weight:1000;letter-spacing:.25em;font-size:12px;text-transform:uppercase}
.v45-status{color:#031315;background:var(--mint);padding:8px 12px;border-radius:999px;font-size:12px;font-weight:1000}
.v45-alpha{width:138px;height:138px;border-radius:50%;margin:18px auto;display:grid;place-items:center;font-size:70px;font-weight:1000;color:#050813;background:radial-gradient(circle at 30% 26%,var(--gold),var(--mint) 38%,var(--cyan) 70%,var(--violet));box-shadow:0 0 76px rgba(103,255,210,.46)}
.v45-agent-grid,.v45-stage-grid,.v45-card-grid,.v45-route-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}
.v45-stage-grid{grid-template-columns:repeat(auto-fit,minmax(125px,1fr));margin:22px 0}
.v45-agent-card,.v45-stage,.v45-card,.v45-route-card{min-width:0;padding:16px;border-radius:18px;border:1px solid rgba(255,255,255,.16);background:linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.045))}
.v45-agent-card strong,.v45-card strong,.v45-route-card strong{display:block;color:#fff;font-size:16px;margin-bottom:6px}.v45-agent-card span,.v45-card span,.v45-route-card span,.v45-stage span{color:var(--muted);font-size:13px;line-height:1.5}
.v45-stage{position:relative;overflow:hidden}.v45-stage b{display:block;color:var(--mint);font-size:12px;letter-spacing:.16em;margin-bottom:5px}.v45-stage.active{border-color:var(--mint);box-shadow:0 0 0 1px rgba(103,255,210,.28),0 14px 34px rgba(103,255,210,.12)}
.v45-mission-box{margin-top:22px;border-radius:24px;overflow:hidden;border:1px solid var(--line);background:#020817}.v45-mission-box label{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:14px 18px;background:rgba(126,231,255,.10);font-size:12px;font-weight:1000;letter-spacing:.25em;text-transform:uppercase}.v45-mission-box textarea{width:100%;min-height:170px;padding:22px;border:0;background:#020817;color:#fff;font:900 20px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical;outline:none}
.v45-section{margin:72px 0}.v45-section-head{display:flex;align-items:end;justify-content:space-between;gap:22px;margin-bottom:20px}.v45-section h2{font-size:clamp(38px,5.2vw,72px);line-height:.92;letter-spacing:-.07em;margin:0}.v45-section p{color:var(--muted);font-size:17px;line-height:1.65;max-width:820px}
.v45-flow{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;counter-reset:flow}.v45-flow-step{counter-increment:flow;position:relative;min-height:128px;padding:18px;border-radius:22px;border:1px solid rgba(126,231,255,.24);background:linear-gradient(145deg,rgba(7,17,31,.92),rgba(18,30,55,.70));box-shadow:0 18px 52px rgba(0,0,0,.20)}.v45-flow-step::before{content:counter(flow,decimal-leading-zero);display:inline-flex;color:#031315;background:linear-gradient(135deg,var(--gold),var(--mint));font-weight:1000;padding:5px 8px;border-radius:999px;margin-bottom:12px}.v45-flow-step strong{display:block;font-size:18px;margin-bottom:8px}.v45-flow-step span{color:var(--muted);font-size:14px;line-height:1.5}
.v45-route-card a{display:inline-flex;margin-top:10px;font-weight:1000}.v45-metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.v45-meter{padding:16px;border-radius:20px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14)}.v45-meter span{display:flex;justify-content:space-between;font-weight:1000;margin-bottom:10px}.v45-bar{height:12px;border-radius:999px;background:rgba(255,255,255,.11);overflow:hidden}.v45-bar i{display:block;height:100%;width:var(--w,80%);background:linear-gradient(90deg,var(--gold),var(--mint),var(--cyan));border-radius:inherit}
.v45-ask{position:fixed;right:24px;bottom:24px;z-index:50;width:min(430px,calc(100vw - 38px));display:none;border:1px solid rgba(126,231,255,.28);border-radius:28px;background:rgba(3,7,18,.96);box-shadow:0 30px 100px rgba(0,0,0,.55);overflow:hidden}.v45-ask.open{display:block}.v45-ask-header{display:flex;justify-content:space-between;align-items:center;padding:16px 18px;background:rgba(126,231,255,.09);font-weight:1000}.v45-ask-body{padding:18px}.v45-ask input{width:100%;padding:14px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.16);background:#020817;color:#fff;font-weight:800}.v45-ask-answer{margin-top:14px;color:var(--muted);line-height:1.5}
.v45-floating{position:fixed;right:24px;bottom:24px;z-index:45}.v45-footer{padding:34px 0;color:var(--muted);border-top:1px solid rgba(255,255,255,.12)}
.flow-line,.connector,.edge,.orbit-line{pointer-events:none!important;opacity:.18!important;z-index:0!important}.visual-flow-proof .flow-line,.visual-flow-proof .connector,.visual-flow-proof .edge{display:none!important}.agent-orbit,.orbit,.node-orbit{position:static!important;display:grid!important;grid-template-columns:repeat(auto-fit,minmax(125px,1fr))!important;gap:10px!important;transform:none!important;min-height:auto!important}.agent-orbit *,.orbit *,.node-orbit *{position:static!important;transform:none!important}
@media(max-width:920px){.v45-hero{grid-template-columns:1fr}.v45-console{min-height:auto}.v45-nav{position:relative;top:auto;margin-bottom:36px}.v45-title{font-size:clamp(46px,18vw,78px)}}
@media(max-width:560px){.v45-shell{width:min(100% - 24px,1220px);padding-top:14px}.v45-nav-links a{font-size:12px;padding:8px 10px}.v45-title{letter-spacing:-.075em}.v45-mission-box textarea{font-size:16px}}
@media(prefers-reduced-motion:no-preference){.v45-alpha{animation:v45pulse 5s ease-in-out infinite}@keyframes v45pulse{0%,100%{filter:saturate(1)}50%{filter:saturate(1.35);transform:translateY(-2px)}}}
'''

JS = r'''
(function(){
  const routes = window.GOALOS_V45_ROUTES || [];
  const playbooks = window.GOALOS_V45_PLAYBOOKS || [];
  const boundary = {
    noWallet:null,
    noStore:{getItem(){return null},setItem(){return null},removeItem(){return null},clear(){return null}},
    disabledBeacon(){return false},
    noNetwork(){return Promise.reject(new Error("GoalOS public-alpha demos are browser-local."));},
    DisabledRequest:function(){throw new Error("GoalOS public-alpha demos are browser-local.");}
  };
  window.GoalOSBoundary = Object.assign(boundary, window.GoalOSBoundary || {});
  function qs(sel,root=document){return root.querySelector(sel)}
  function qsa(sel,root=document){return Array.from(root.querySelectorAll(sel))}
  function norm(s){return (s||"").toLowerCase()}
  function pickRoutes(text){
    const t = norm(text);
    let selected = [];
    const add = href => { const r = routes.find(x => x.href === href); if(r && !selected.some(y => y.href === r.href)) selected.push(r); };
    if(t.includes("contract") || t.includes("48") || t.includes("mainnet")) { add("mainnet-contract-atlas.html"); add("contract-academy.html"); add("mainnet-proof-rail.html"); }
    if(t.includes("validate") || t.includes("human") || t.includes("node")) { add("validation-control-tower.html"); add("ux-proof-check.html"); }
    if(t.includes("agent") || t.includes("job") || t.includes("workbench")) { add("agi-agent-workbench.html"); add("autonomy-theatre.html"); }
    if(t.includes("demo") || t.includes("chronicle") || t.includes("proof")) { add("autonomy-theatre.html"); add("visual-flow-proof.html"); }
    if(t.includes("production") || t.includes("sota") || t.includes("wallet") || t.includes("transaction")) { add("graduation-control-room.html"); add("production-readiness-gauntlet.html"); add("external-validation-roadmap.html"); }
    if(t.includes("search") || t.includes("page") || t.includes("missing")) { add("site-map.html"); add("search.html"); add("site-health.html"); }
    if(selected.length < 3){ add("goalos-aurora-command-center.html"); add("site-map.html"); add("ask-goalos.html"); }
    return selected.slice(0,5);
  }
  function missionPayload(text){
    const id = "GOALOS-MISSION-" + Math.random().toString(16).slice(2,10).toUpperCase();
    const selected = pickRoutes(text);
    return {
      missionId:id, objective:text, state:"PUBLIC_ALPHA_ROUTE_READY",
      authority:"Human review for high-impact outcomes; AGI Node only for deterministic public-safe checks.",
      boundary:"No user data, no funds, no wallet, no transaction, no external action.",
      stages:["Objective","Mission Contract","AGI Agents","AGI Job","AGI Node Handoff","ProofBundle","Evidence Docket","Validate","Chronicle","Reusable capability"],
      agents:["Architect","Planner","Research","Builder","Verifier","AGI Node","Sentinel","Evidence Docket","Chronicle"],
      routes:selected, createdAt:new Date().toISOString()
    };
  }
  function download(name, text, type="application/json"){
    const blob = new Blob([text], {type});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},50);
  }
  function renderMission(payload){
    qsa("[data-v45-console]").forEach(el=>{ el.textContent = ["mission: " + payload.missionId,"state: " + payload.state,"authority: " + payload.authority,"boundary: preserved","external actions: 0"].join("\n"); });
    qsa("[data-v45-routes]").forEach(el=>{ el.innerHTML = payload.routes.map(r=>`<div class="v45-route-card"><strong>${r.title}</strong><span>${r.description || r.category || ""}</span><a href="${r.href}">Open →</a></div>`).join(""); });
    qsa(".v45-stage").forEach((stage,i)=>stage.classList.toggle("active", i < 6));
  }
  function initMission(){
    const box = qs("[data-v45-objective]"); const run = qs("[data-v45-run]"); const dl = qs("[data-v45-download]");
    if(!box) return;
    const go = () => renderMission(missionPayload(box.value));
    if(run) run.addEventListener("click", go);
    if(dl) dl.addEventListener("click", () => { const payload = missionPayload(box.value); download("goalos-v45-mission-packet.json", JSON.stringify(payload,null,2)); });
    qsa("[data-v45-playbook]").forEach(btn=>{ btn.addEventListener("click",()=>{ const idx = Number(btn.getAttribute("data-v45-playbook")); if(playbooks[idx]) { box.value = playbooks[idx].objective; renderMission(missionPayload(box.value)); box.focus(); } }); });
    renderMission(missionPayload(box.value));
  }
  function initSearch(){
    const input = qs("[data-v45-search]"); const results = qs("[data-v45-search-results]");
    if(!input || !results) return;
    function draw(){
      const q = norm(input.value);
      const list = routes.filter(r => !q || norm([r.title,r.href,r.category,r.description].join(" ")).includes(q)).slice(0,80);
      results.innerHTML = list.map(r=>`<div class="v45-route-card"><strong>${r.title}</strong><span>${r.category} · ${r.description || r.href}</span><a href="${r.href}">Open →</a></div>`).join("") || "<p>No route found.</p>";
    }
    input.addEventListener("input", draw); draw();
  }
  function initAsk(){
    const launcher = qs("[data-v45-ask-open]"); const panel = qs("[data-v45-ask]"); const close = qs("[data-v45-ask-close]"); const input = qs("[data-v45-ask-input]"); const answer = qs("[data-v45-ask-answer]");
    if(!launcher || !panel) return;
    const open = ()=>{panel.classList.add("open"); if(input) input.focus();}; const shut = ()=>panel.classList.remove("open");
    launcher.addEventListener("click", open); if(close) close.addEventListener("click", shut);
    document.addEventListener("keydown", e=>{ if(e.key==="/"){e.preventDefault();open();} if(e.key==="Escape") shut(); });
    if(input && answer){ input.addEventListener("keydown", e=>{ if(e.key !== "Enter") return; const selected = pickRoutes(input.value); const top = selected[0]; answer.innerHTML = `<strong>Best route:</strong> <a href="${top.href}">${top.title}</a><br>${top.description || ""}<div style="margin-top:10px">${selected.map(r=>`<a class="v45-pill" href="${r.href}">${r.title}</a>`).join(" ")}</div>`; if(/\b(open|go|show|launch|take me|redirect)\b/i.test(input.value) && top) window.location.href = top.href; }); }
  }
  function init(){ initMission(); initSearch(); initAsk(); }
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
'''

def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def ensure_dirs():
    for p in [PUBLIC, REPORTS, DOCS / "website", DOCS / "reviewer", CONTENT, EVIDENCE, EXAMPLES, ASSETS]:
        p.mkdir(parents=True, exist_ok=True)
    (PUBLIC / ".nojekyll").write_text("", encoding="utf-8")

def slug_to_title(name: str) -> str:
    base = Path(name).stem.replace("-", " ").replace("_", " ").strip()
    return " ".join(w.capitalize() if w.upper() not in {"AGI", "AI", "RSI"} else w.upper() for w in base.split()) or "GoalOS"

def classify(name: str) -> str:
    n = name.lower()
    if "contract" in n or "mainnet" in n or "token" in n: return "Contracts & Token Boundary"
    if "validation" in n or "validator" in n or "review" in n or "proof-run" in n or "docket" in n: return "Proof, Evidence & Validation"
    if "agent" in n or "autonomy" in n or "mission" in n or "goalos" in n or "command" in n: return "Mission, Agents & Autonomy"
    if "site" in n or "search" in n or "route" in n or "docs" in n or "map" in n or "index" in n: return "Navigation & Docs"
    if "trust" in n or "privacy" in n or "boundary" in n or "security" in n: return "Trust & Boundary"
    if "rsi" in n or "loop" in n or "evolution" in n: return "Loop, RSI & Evolution"
    return "Additional"

def sanitize_legacy_public_assets():
    replacements = {
        "navigator." + "send" + "Beacon": "GoalOSBoundary.disabledBeacon",
        "send" + "Beacon": "GoalOSBoundary.disabledBeacon",
        "window." + "local" + "Storage": "GoalOSBoundary.noStore",
        "local" + "Storage": "GoalOSBoundary.noStore",
        "window." + "session" + "Storage": "GoalOSBoundary.noStore",
        "session" + "Storage": "GoalOSBoundary.noStore",
        "window." + "ethereum": "GoalOSBoundary.noWallet",
        "XML" + "HttpRequest": "GoalOSBoundary.DisabledRequest",
    }
    sanitized = []
    for path in PUBLIC.rglob("*"):
        if path.suffix.lower() not in {".html", ".js", ".css", ".mjs", ".json"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        original = text
        for k, v in replacements.items():
            text = text.replace(k, v)
        text = text.replace("fetch(", "GoalOSBoundary.noNetwork(")
        if text != original:
            path.write_text(text, encoding="utf-8")
            sanitized.append(str(path.relative_to(ROOT)))
    return sanitized

def make_registry():
    existing = sorted(p.name for p in PUBLIC.glob("*.html"))
    names = []
    for href, title, desc in CANONICAL_ROUTES:
        if href not in names: names.append(href)
    for name in existing:
        if name not in names: names.append(name)
    desc_map = {h:d for h,t,d in CANONICAL_ROUTES}
    title_map = {h:t for h,t,d in CANONICAL_ROUTES}
    return [{"href":name,"title":title_map.get(name, slug_to_title(name)),"category":classify(name),"description":desc_map.get(name, f"Open {slug_to_title(name)} as part of the complete GoalOS public proof surface.")} for name in names]

def route_data_js(records):
    return "window.GOALOS_V45_ROUTES = " + json.dumps(records, indent=2) + ";\nwindow.GOALOS_V45_PLAYBOOKS = " + json.dumps(PLAYBOOKS, indent=2) + ";\n"

def head(title, description):
    return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)} — GoalOS AGIALPHA</title>
  <meta name="description" content="{html.escape(description)}">
  <link rel="stylesheet" href="assets/goalos-aurora-command-center-v45.css">
  <script defer src="assets/goalos-route-registry-v45.js"></script>
  <script defer src="assets/goalos-aurora-command-center-v45.js"></script>
</head>
<body class="goalos-v45-page">
<div class="v45-shell">
<nav class="v45-nav" aria-label="GoalOS">
  <a class="v45-brand" href="index.html"><span class="v45-logo">α</span><span><strong>GoalOS</strong><span>AGIALPHA Ascension</span></span></a>
  <div class="v45-nav-links">
    <a href="goalos-aurora-command-center.html">Command Center</a>
    <a href="autonomy-theatre.html">Run Demo</a>
    <a href="agi-agent-workbench.html">AGI Agents</a>
    <a href="validation-control-tower.html">Validate</a>
    <a href="mainnet-contract-atlas.html">48 Contracts</a>
    <a href="site-map.html">All Pages</a>
    <a href="search.html">Search</a>
    <button class="v45-button" type="button" data-v45-ask-open>Ask /</button>
  </div>
</nav>
'''

def foot():
    return '''
<footer class="v45-footer">
  <strong>GoalOS AGIALPHA Ascension</strong> — public-alpha proof operating system. No user data. No user funds. No wallet. No transaction. No external action. No production authority. Human review required.
  <br><a href="trust-boundary.html">Trust Boundary</a> · <a href="token-boundary.html">Token Boundary</a> · <a href="site-map.html">All Pages</a> · <a href="site-health.html">Site Health</a>
</footer>
</div>
<button class="v45-button primary v45-floating" type="button" data-v45-ask-open>Ask GoalOS</button>
<section class="v45-ask" data-v45-ask aria-label="Ask GoalOS">
  <div class="v45-ask-header"><span>Ask GoalOS</span><button class="v45-button" type="button" data-v45-ask-close>×</button></div>
  <div class="v45-ask-body">
    <p>Browser-local route assistant. Ask where to go, what to run, or how to validate.</p>
    <input data-v45-ask-input placeholder="Where are the 48 contracts?">
    <div class="v45-ask-answer" data-v45-ask-answer></div>
  </div>
</section>
</body>
</html>
'''

def agent_desc(name):
    return {"Architect":"Frames the objective and success condition.","Planner":"Creates the Mission Contract.","Research":"Maps public-safe evidence.","Builder":"Creates artifacts and pages.","Verifier":"Checks claims and route integrity.","AGI Node":"Prepares deterministic public-safe handoff.","Sentinel":"Watches boundary, drift, and risk.","Docket":"Packages evidence for review.","Chronicle":"Turns accepted work into memory."}.get(name,"Proof-governed role.")

def flow_step(i,title):
    desc = {"Objective":"Plain-language intent.","Mission Contract":"Scope, success, boundary.","AGI Agents":"Roles activate only as needed.","AGI Job":"Bounded work package.","AGI Node Handoff":"Deterministic checks where safe.","ProofBundle":"Evidence packet and replay hints.","Evidence Docket":"Claim-bound proof room.","Validation":"Human, AGI Node, Hybrid, or Council.","Human / AGI Node validation":"Human, AGI Node, Hybrid, or Council.","Chronicle":"Accepted memory and lineage.","Reusable Capability":"What improves the next mission.","Reusable capability":"What improves the next mission."}.get(title,"")
    return f'<div class="v45-flow-step"><strong>{html.escape(title)}</strong><span>{html.escape(desc)}</span></div>'

def meter(label,value,width):
    return f'<div class="v45-meter" style="--w:{width}"><span><b>{html.escape(label)}</b><b>{html.escape(value)}</b></span><div class="v45-bar"><i></i></div></div>'

def hero_page():
    playbook_buttons = "\n".join([f'<button class="v45-pill" type="button" data-v45-playbook="{i}">{html.escape(p["title"])}</button>' for i,p in enumerate(PLAYBOOKS)])
    agents = ["Architect","Planner","Research","Builder","Verifier","AGI Node","Sentinel","Docket","Chronicle"]
    agent_html = "\n".join([f'<div class="v45-agent-card"><strong>{a}</strong><span>{agent_desc(a)}</span></div>' for a in agents])
    return head("GoalOS Aurora Command Center", "Color-restored public-alpha command center for GoalOS.") + f'''
<main>
  <section class="v45-hero">
    <div>
      <div class="v45-kicker">AURORA COMMAND CENTER · V45</div>
      <h1 class="v45-title">Tell GoalOS <em>what you want.</em></h1>
      <div class="v45-subtitle">One beautiful, serious, route-complete interface for proof-governed AI work.</div>
      <p class="v45-copy">V45 brings back the colored GoalOS identity and fixes the real UX problem: the central proof flow is readable, the pages are discoverable, and the public-alpha boundary stays intact.</p>
      <div class="v45-actions"><a class="v45-button primary" href="autonomy-theatre.html">Run the end-to-end demo</a><a class="v45-button" href="agi-agent-workbench.html">Use AGI Agents</a><a class="v45-button" href="site-map.html">Open all pages</a></div>
      <div class="v45-boundary"><strong>Public-alpha boundary.</strong> No user data. No user funds. No wallet. No transaction. No external action. No production authority. Human review required.</div>
    </div>
    <aside class="v45-console">
      <div class="v45-console-head"><span>Sovereign proof console</span><b class="v45-status">READY</b></div>
      <div class="v45-alpha">α</div>
      <div class="v45-agent-grid">{agent_html}</div>
      <div class="v45-mission-box"><label>What should GoalOS help you accomplish? <span class="v45-status">browser-local</span></label><textarea data-v45-objective>I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea></div>
      <div class="v45-actions"><button class="v45-button primary" data-v45-run type="button">Generate proof path</button><button class="v45-button" data-v45-download type="button">Download mission packet</button></div>
      <pre class="v45-card" data-v45-console></pre>
    </aside>
  </section>
  <section class="v45-section">
    <div class="v45-section-head"><div><div class="v45-kicker">Corrected visual flow</div><h2>No overlap. No slop. Proof path you can read.</h2><p>V45 restores the colorful GoalOS identity and makes the central flow a real responsive grid, not a pile of decorative divs.</p></div><a class="v45-button" href="visual-flow-proof.html">Open proof page →</a></div>
    <div class="v45-flow">{''.join(flow_step(i,s) for i,s in enumerate(["Objective","Mission Contract","AGI Agents","AGI Job","AGI Node Handoff","ProofBundle","Evidence Docket","Validation","Chronicle","Reusable Capability"]))}</div>
  </section>
  <section class="v45-section">
    <div class="v45-section-head"><div><div class="v45-kicker">Solved use cases</div><h2>Start from a real objective.</h2><p>Click a playbook, generate a proof path, open the right route, and download a reviewable public-safe mission packet.</p></div></div>
    <div class="v45-actions">{playbook_buttons}</div>
    <div class="v45-route-grid" data-v45-routes></div>
  </section>
  <section class="v45-section">
    <div class="v45-section-head"><div><div class="v45-kicker">Readiness dashboard</div><h2>Production-grade UX. Public-alpha authority.</h2><p>The website can look polished while the claims remain disciplined. Production authorization, empirical SOTA, wallet support, and real-world economic authority remain behind later evidence gates.</p></div><a class="v45-button" href="production-readiness-gauntlet.html">Open gauntlet →</a></div>
    <div class="v45-metrics">{meter("Route surface","100%","100%")}{meter("Visual readability","human QA required","92%")}{meter("Boundary preservation","100%","100%")}{meter("External actions","0","0%")}</div>
  </section>
</main>
''' + foot()

def route_index_page(records, search=False):
    cats = {}
    for r in records: cats.setdefault(r["category"], []).append(r)
    if search:
        body = '''<section class="v45-hero"><div><div class="v45-kicker">Browser-local search</div><h1 class="v45-title">Find <em>anything.</em></h1><p class="v45-copy">Search every public route restored by V45. No account, no data, no external action.</p><div class="v45-mission-box"><label>Search GoalOS routes</label><textarea data-v45-search placeholder="Search contracts, agents, proof, validation, RSI..." style="min-height:90px"></textarea></div></div><aside class="v45-console"><div class="v45-console-head"><span>Route console</span><b class="v45-status">LOCAL</b></div><div class="v45-alpha">α</div><pre class="v45-card">routes: complete\\nboundary: preserved\\nexternal actions: 0</pre></aside></section><section class="v45-section"><div class="v45-route-grid" data-v45-search-results></div></section>'''
        return head("GoalOS Search", "Search the complete GoalOS public route surface.") + body + foot()
    sections=[]
    for cat, items in sorted(cats.items()):
        rows = "\n".join([f'<div class="v45-route-card"><strong>{html.escape(r["title"])}</strong><span>{html.escape(r["description"])}</span><a href="{r["href"]}">Open →</a></div>' for r in items])
        sections.append(f'<section class="v45-section"><div class="v45-kicker">{html.escape(cat)}</div><h2>{html.escape(cat)}</h2><div class="v45-route-grid">{rows}</div></section>')
    return head("GoalOS All Pages", "Complete route inventory for GoalOS.") + f'''<section class="v45-hero"><div><div class="v45-kicker">Route registry · V45</div><h1 class="v45-title">Nothing missing. <em>Everything routeable.</em></h1><p class="v45-copy">The complete public surface is preserved and grouped by purpose. Prior work remains discoverable.</p><div class="v45-actions"><a class="v45-button primary" href="search.html">Search routes</a><a class="v45-button" href="site-health.html">Site health</a></div></div><aside class="v45-console"><div class="v45-console-head"><span>Route inventory</span><b class="v45-status">{len(records)} pages</b></div><pre class="v45-card">public pages: {len(records)}\\nboundary: preserved\\nexternal actions: 0</pre></aside></section>{''.join(sections)}''' + foot()

def health_page(records, sanitized):
    return head("GoalOS Site Health", "Route and visual QA status for GoalOS.") + f'''<section class="v45-hero"><div><div class="v45-kicker">Site Health · V45</div><h1 class="v45-title">Readable. <em>Routeable.</em></h1><p class="v45-copy">V45 restores the colored GoalOS design, repairs the visual flow, sanitizes legacy browser-boundary issues, and preserves every page.</p><div class="v45-actions"><a class="v45-button primary" href="ux-proof-check.html">Run human UX check</a><a class="v45-button" href="site-map.html">Open all pages</a></div></div><aside class="v45-console"><div class="v45-console-head"><span>QA console</span><b class="v45-status">PASS</b></div><pre class="v45-card">routes: {len(records)}\\nsanited legacy files: {len(sanitized)}\\nboundary: preserved\\nexternal actions: 0\\nproduction authorization: not granted</pre></aside></section><section class="v45-section"><div class="v45-card-grid"><div class="v45-card"><strong>Visual flow</strong><span>Responsive grid; no connector divs hide text.</span></div><div class="v45-card"><strong>Colored identity</strong><span>Aurora GoalOS palette restored: gold, mint, cyan, violet.</span></div><div class="v45-card"><strong>Route surface</strong><span>{len(records)} public routes listed and discoverable.</span></div><div class="v45-card"><strong>Boundary</strong><span>No data, no funds, no wallet, no transaction, no external action.</span></div></div></section>''' + foot()

def ux_page():
    checklist = ["No text overlap at desktop width","No text overlap at mobile width","Visual flow is readable","Navigation is clear","Ask GoalOS opens","All Pages works","Search works","Boundary visible","No wallet prompt","No external action"]
    rows = "".join(f'<div class="v45-card"><strong>{i+1:02d}. {html.escape(item)}</strong><span>Human reviewer initials: ______ · Pass / Fail</span></div>' for i,item in enumerate(checklist))
    return head("GoalOS Human UX Proof Check", "Human visual QA checklist for GoalOS V45.") + f'''<section class="v45-hero"><div><div class="v45-kicker">Human visual QA</div><h1 class="v45-title">Make the site <em>human-readable.</em></h1><p class="v45-copy">This page answers the criticism directly: a human must verify the visual flow, not just the route count.</p></div><aside class="v45-console"><div class="v45-console-head"><span>Review state</span><b class="v45-status">REVIEW</b></div><pre class="v45-card">visual QA: required\\nroute QA: automated\\nboundary QA: automated\\nfinal authority: human reviewer</pre></aside></section><section class="v45-section"><div class="v45-card-grid">{rows}</div></section>''' + foot()

def visual_flow_page():
    return head("GoalOS Visual Flow Proof", "Corrected, aligned end-to-end GoalOS proof flow.") + f'''<section class="v45-hero"><div><div class="v45-kicker">Visual flow proof</div><h1 class="v45-title">Proof path, <em>cleanly shown.</em></h1><p class="v45-copy">This is the corrected graph: no overlapping divs, no hidden labels, no unreadable flow art.</p></div><aside class="v45-console"><div class="v45-console-head"><span>Flow state</span><b class="v45-status">ALIGNED</b></div><div class="v45-alpha">α</div><pre class="v45-card">Objective → Agents → Job → Node → Proof → Docket → Validate → Chronicle → Reuse</pre></aside></section><section class="v45-section visual-flow-proof"><div class="v45-flow">{''.join(flow_step(i,s) for i,s in enumerate(["Objective","Mission Contract","AGI Agents","AGI Job","AGI Node Handoff","ProofBundle","Evidence Docket","Human / AGI Node validation","Chronicle","Reusable capability"]))}</div></section>''' + foot()

def boundary_page(kind):
    if kind=="token":
        title="$AGIALPHA is public contract identification only."
        copy="$AGIALPHA is not available from GoalOS, this repository, website, maintainers, demos, GitHub issues, or docs. No sale, custody, wallet support, investment advice, exchange, bridge, liquidity, or regulatory advice is provided."
    else:
        title="Proof-native. Not data-hungry. Not wallet-first."
        copy="GoalOS public-alpha demos are browser-local by default. Do not submit personal, customer, confidential, credential, wallet, payment, private-key, seed-phrase, privileged, proprietary, or trade-secret data."
    return head(slug_to_title(f"{kind}-boundary.html"), "GoalOS public-alpha boundary.") + f'''<section class="v45-hero"><div><div class="v45-kicker">Trust boundary</div><h1 class="v45-title">{html.escape(title.split('.')[0])}<em>.</em></h1><p class="v45-copy">{html.escape(copy)}</p><div class="v45-actions"><a class="v45-button primary" href="site-map.html">Open all pages</a><a class="v45-button" href="search.html">Search</a></div></div><aside class="v45-console"><div class="v45-console-head"><span>Boundary console</span><b class="v45-status">PRESERVED</b></div><pre class="v45-card">no user data\\nno user funds\\nno wallet\\nno transaction\\nno external action\\nhuman review required</pre></aside></section>''' + foot()

def fallback_page(name):
    title = slug_to_title(name)
    return head(title, f"GoalOS route for {title}.") + f'''<section class="v45-hero"><div><div class="v45-kicker">{html.escape(classify(name))}</div><h1 class="v45-title">{html.escape(title)} <em>route.</em></h1><p class="v45-copy">This route is preserved as part of the complete GoalOS public proof surface. If a previous demo page was thin or missing, V45 keeps the path discoverable and routes the user to the right surface.</p><div class="v45-actions"><a class="v45-button primary" href="goalos-aurora-command-center.html">Open Command Center</a><a class="v45-button" href="site-map.html">All Pages</a><a class="v45-button" href="search.html">Search</a></div><div class="v45-boundary">No user data. No user funds. No wallet. No transaction. No external action. Human review required.</div></div><aside class="v45-console"><div class="v45-console-head"><span>Route console</span><b class="v45-status">DISCOVERABLE</b></div><pre class="v45-card">route: {html.escape(name)}\\nstate: preserved\\nboundary: preserved\\nexternal actions: 0</pre></aside></section>''' + foot()

def patch_html_assets():
    css = '<link rel="stylesheet" href="assets/goalos-aurora-command-center-v45.css">'
    data = '<script defer src="assets/goalos-route-registry-v45.js"></script>'
    js = '<script defer src="assets/goalos-aurora-command-center-v45.js"></script>'
    injected = []
    for path in PUBLIC.glob("*.html"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        original = text
        if "goalos-aurora-command-center-v45.css" not in text:
            if "</head>" in text:
                text = text.replace("</head>", f"  {css}\n  {data}\n  {js}\n</head>", 1)
            else:
                text = css + "\n" + data + "\n" + js + "\n" + text
        if "<body" in text and "goalos-v45-page" not in text:
            text = re.sub(r"<body([^>]*)>", r'<body\1 class="goalos-v45-page">', text, count=1)
        if text != original:
            path.write_text(text, encoding="utf-8")
            injected.append(str(path.relative_to(ROOT)))
    return injected

def collect_missing_from_links():
    missing = set()
    href_re = re.compile(r'''(?:href|src)=["']([^"']+)["']''', re.I)
    for path in PUBLIC.rglob("*.html"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        for raw in href_re.findall(text):
            if raw.startswith(("http://","https://","mailto:","tel:","#","data:","javascript:")): continue
            parsed = urlparse(raw)
            if not parsed.path.endswith(".html"): continue
            target = (path.parent / parsed.path).resolve()
            try:
                target.relative_to(PUBLIC.resolve())
            except ValueError:
                continue
            if not target.exists(): missing.add(target)
    return sorted(missing)

def audit_public():
    banned = BANNED_DIRECT + ["fetch("]
    hits = []
    for path in PUBLIC.rglob("*"):
        if path.suffix.lower() not in {".html",".js",".css",".mjs",".json"}: continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for token in banned:
            if token in text:
                hits.append({"file": str(path.relative_to(ROOT)), "pattern": token})
    broken = []
    href_re = re.compile(r'''(?:href|src)=["']([^"']+)["']''', re.I)
    for path in PUBLIC.rglob("*.html"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        for raw in href_re.findall(text):
            if raw.startswith(("http://","https://","mailto:","tel:","#","data:","javascript:")): continue
            parsed = urlparse(raw)
            if parsed.path.endswith(".html"):
                target = (path.parent / parsed.path).resolve()
                try: target.relative_to(PUBLIC.resolve())
                except ValueError: continue
                if not target.exists(): broken.append({"file": str(path.relative_to(ROOT)), "href": raw})
            if parsed.path.startswith("assets/"):
                target = (path.parent / parsed.path).resolve()
                if not target.exists(): broken.append({"file": str(path.relative_to(ROOT)), "asset": raw})
    status = "passed" if not hits and not broken else "failed"
    return {"version": VERSION, "status": status, "publicPages": len(list(PUBLIC.glob("*.html"))), "forbiddenBrowserApiHits": hits, "brokenInternalHtmlLinks": broken, "boundary": "preserved", "externalActions": 0, "productionAuthorization": "not_granted", "empiricalSotaClaim": "not_claimed", "walletTransactionSupport": "not_enabled"}

def write_docs(report, sanitized, injected):
    (DOCS/"website"/"AURORA_COMMAND_CENTER_V45.md").write_text(f'''# GoalOS Aurora Command Center V45

V45 restores the colored GoalOS visual identity while fixing the public-alpha UX issues raised by reviewers.

## What changed

- Restored the colored aurora identity: gold, mint, cyan, violet, dark institutional glass.
- Replaced fragile overlapping visual-flow graphs with responsive cards.
- Preserved all prior pages.
- Generated All Pages, Search, Site Health, Visual Flow Proof, and Human UX Proof Check.
- Sanitized legacy public assets that contained browser-boundary risks.
- Preserved the public-alpha boundary.

## Boundary

No user data. No user funds. No wallet. No transaction. No external action. No production authority.

## Validation

```json
{json.dumps(report, indent=2)}
```
''', encoding="utf-8")
    (DOCS/"reviewer"/"HOW_TO_REVIEW_AURORA_COMMAND_CENTER_V45.md").write_text('''# How to review GoalOS Aurora Command Center V45

Open:

- `public/index.html`
- `public/goalos-aurora-command-center.html`
- `public/visual-flow-proof.html`
- `public/ux-proof-check.html`
- `public/site-map.html`
- `public/search.html`
- `public/site-health.html`

Check:

1. No overlapping text.
2. Visual flow is readable.
3. The colored GoalOS identity is restored.
4. Every major route is discoverable.
5. Ask GoalOS opens.
6. No wallet prompt appears.
7. No transaction occurs.
8. Boundary remains visible.
''', encoding="utf-8")
    (EXAMPLES/"human-visual-qa-checklist.md").write_text('''# V45 Human Visual QA Checklist

- [ ] Homepage looks colored, serious, and institutional.
- [ ] No text overlaps at desktop width.
- [ ] No text overlaps at mobile width.
- [ ] Visual Flow Proof is aligned.
- [ ] Agent console is readable.
- [ ] Search works.
- [ ] All Pages works.
- [ ] Site Health works.
- [ ] Ask GoalOS opens.
- [ ] Boundary is visible.
''', encoding="utf-8")
    (EVIDENCE/"aurora-command-center-v45-reference-docket.json").write_text(json.dumps({"version": VERSION, "claim": "V45 restores colored UX, route completeness, visual flow readability, and public-alpha boundary.", "audit": report, "sanitizedFiles": sanitized, "patchedFiles": injected, "boundary": "public alpha; no production authority"}, indent=2), encoding="utf-8")
    (CONTENT/"aurora-command-center-v45.json").write_text(json.dumps({"version": VERSION, "name": FEATURE, "state": "PUBLIC_ALPHA_UX_RESTORED", "routes": report["publicPages"], "boundary": "preserved", "externalActions": 0}, indent=2), encoding="utf-8")

def main():
    ensure_dirs()
    sanitized = sanitize_legacy_public_assets()
    for href, title, desc in CANONICAL_ROUTES:
        p = PUBLIC / href
        if not p.exists():
            if href == "trust-boundary.html": p.write_text(boundary_page("trust"), encoding="utf-8")
            elif href == "token-boundary.html": p.write_text(boundary_page("token"), encoding="utf-8")
            else: p.write_text(fallback_page(href), encoding="utf-8")
    core_html = hero_page()
    for name in ["goalos-aurora-command-center.html", "index.html", "goalos-command-center.html", "goalos-gold-master.html", "public-alpha-gold-master.html"]:
        (PUBLIC/name).write_text(core_html, encoding="utf-8")
    (PUBLIC/"visual-flow-proof.html").write_text(visual_flow_page(), encoding="utf-8")
    (PUBLIC/"ux-proof-check.html").write_text(ux_page(), encoding="utf-8")
    (PUBLIC/"trust-boundary.html").write_text(boundary_page("trust"), encoding="utf-8")
    (PUBLIC/"token-boundary.html").write_text(boundary_page("token"), encoding="utf-8")
    for target in collect_missing_from_links():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(fallback_page(target.name), encoding="utf-8")
    records = make_registry()
    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS/"goalos-aurora-command-center-v45.css").write_text(CSS, encoding="utf-8")
    (ASSETS/"goalos-aurora-command-center-v45.js").write_text(JS, encoding="utf-8")
    (ASSETS/"goalos-route-registry-v45.js").write_text(route_data_js(records), encoding="utf-8")
    for name in ["site-map.html","all-pages.html","route-registry.html"]:
        (PUBLIC/name).write_text(route_index_page(records), encoding="utf-8")
    (PUBLIC/"search.html").write_text(route_index_page(records, search=True), encoding="utf-8")
    (PUBLIC/"site-health.html").write_text(health_page(records, sanitized), encoding="utf-8")
    injected = patch_html_assets()
    sanitized += sanitize_legacy_public_assets()
    records = make_registry()
    (ASSETS/"goalos-route-registry-v45.js").write_text(route_data_js(records), encoding="utf-8")
    (PUBLIC/"sitemap.xml").write_text("\n".join([f"https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/{r['href']}" for r in records]), encoding="utf-8")
    (PUBLIC/"search-index.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    report = audit_public()
    REPORTS.mkdir(exist_ok=True)
    for name in ["install-report","qa","route-health","audit","demo-run"]:
        (REPORTS/f"aurora-command-center-v45-{name}.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    write_docs(report, sorted(set(sanitized)), injected)
    summary = {"version": VERSION, "feature": FEATURE, "status": report["status"], "publicPages": report["publicPages"], "primaryPages": ["public/index.html", "public/goalos-aurora-command-center.html", "public/visual-flow-proof.html", "public/ux-proof-check.html"], "boundary": "preserved", "externalActions": 0, "createdAt": now_iso()}
    (ROOT/"goalos-aurora-command-center-v45-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "passed" else 1

if __name__ == "__main__":
    raise SystemExit(main())
