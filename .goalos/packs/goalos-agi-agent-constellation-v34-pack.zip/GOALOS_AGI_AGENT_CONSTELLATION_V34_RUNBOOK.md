# GoalOS AGI Agent Constellation V34 Runbook

## Purpose

Adds the missing AGI Agents layer as a separate public demo.

Primary page:

```text
public/agi-agent-constellation.html
```

## GitHub Web UI steps

1. Create `.github/workflows/goalos-agi-agent-constellation-v34-autopilot.yml`.
2. Upload `.goalos/packs/goalos-agi-agent-constellation-v34-pack.zip`.
3. Commit: `Add GoalOS AGI Agent Constellation V34`.
4. Run the workflow with `commit_changes=true`, `deploy_pages=true`, `create_issue=true`, `create_release=false`.
5. Open `/agi-agent-constellation.html`.

## Review checklist

- One-box objective works.
- Agent constellation updates.
- Authority modes work.
- Ask GoalOS opens.
- Downloads work.
- All prior pages remain accessible.
- No wallet, transaction, backend call, or user-data form appears.
