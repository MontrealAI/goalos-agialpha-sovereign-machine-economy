#!/usr/bin/env python3
from pathlib import Path
from urllib.parse import urlparse
import html, json, re, shutil

VERSION = 'v52'
ROOT = Path.cwd()
PUBLIC = ROOT / 'public'
ASSETS = PUBLIC / 'assets'
REPORTS = ROOT / 'reports'
EVIDENCE = ROOT / 'evidence' / 'demo'
CONTENT = ROOT / 'content' / 'goalos'
DOCS = ROOT / 'docs' / 'website'
REVIEWER = ROOT / 'docs' / 'reviewer'
EXAMPLES = ROOT / 'examples' / 'autonomous-experience-os-v52'
for d in [PUBLIC, ASSETS, REPORTS, EVIDENCE, CONTENT, DOCS, REVIEWER, EXAMPLES]:
    d.mkdir(parents=True, exist_ok=True)

BOUNDARY = 'No user data. No user funds. No wallet. No transaction. No production authority. Human review required.'
TOKEN = '$AGIALPHA is public contract identification only; not available from GoalOS; no sale, custody, wallet support, investment, exchange, bridge, liquidity, or regulatory advice.'

CSS = r'''
:root{--bg:#050817;--navy:#071225;--panel:rgba(9,18,37,.82);--line:rgba(148,255,233,.24);--text:#f7f4ea;--muted:#b9c7dc;--mint:#6dffd8;--cyan:#81e9ff;--gold:#fff06a;--violet:#a89cff;--danger:#ff6f9f;--ok:#7dffa5;--card:rgba(255,255,255,.075)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body.goalos-v52{margin:0;min-height:100vh;background:radial-gradient(circle at 10% 8%,rgba(72,255,203,.22),transparent 30%),radial-gradient(circle at 78% 16%,rgba(168,156,255,.25),transparent 34%),linear-gradient(135deg,#07140f 0%,#071326 52%,#090817 100%);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;overflow-x:hidden}.goalos-v52:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:48px 48px;mask-image:linear-gradient(to bottom,#000,transparent 92%);z-index:0}.v52-shell{position:relative;z-index:1;width:min(1220px,calc(100vw - 32px));margin:0 auto;padding:28px 0 120px}.v52-nav{position:sticky;top:16px;z-index:20;display:flex;align-items:center;gap:18px;justify-content:space-between;padding:16px 18px;border:1px solid var(--line);border-radius:28px;background:rgba(4,9,23,.78);backdrop-filter:blur(24px);box-shadow:0 20px 70px rgba(0,0,0,.35)}.v52-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text);font-weight:950;letter-spacing:.16em;text-transform:uppercase;font-size:13px}.v52-logo{width:42px;height:42px;border-radius:14px;background:radial-gradient(circle at 30% 25%,var(--gold),var(--mint) 34%,var(--cyan) 67%,var(--violet));display:grid;place-items:center;color:#071225;font-weight:1000;font-size:22px;box-shadow:0 0 35px rgba(109,255,216,.38)}.v52-navlinks{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.v52-btn,.v52-pill,button.v52-btn{border:1px solid var(--line);background:linear-gradient(135deg,rgba(255,240,106,.94),rgba(109,255,216,.94));color:#061023;border-radius:999px;padding:12px 17px;text-decoration:none;font-weight:950;letter-spacing:.04em;box-shadow:0 12px 34px rgba(109,255,216,.16);cursor:pointer}.v52-btn.secondary{background:rgba(255,255,255,.08);color:var(--text)}.v52-btn.ghost{background:rgba(9,18,37,.6);color:var(--mint)}.v52-hero{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(360px,.95fr);gap:34px;align-items:center;min-height:calc(100vh - 110px);padding:62px 0 36px}.v52-kicker{color:var(--gold);font-size:12px;letter-spacing:.42em;text-transform:uppercase;font-weight:1000;margin:0 0 18px}.v52-title{font-size:clamp(64px,9vw,132px);line-height:.82;margin:0;letter-spacing:-.075em;font-weight:1000}.v52-title em{font-family:Georgia,serif;font-style:italic;font-weight:900;background:linear-gradient(90deg,var(--gold),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;color:transparent;letter-spacing:-.045em}.v52-sub{font-size:clamp(20px,2.3vw,32px);line-height:1.05;font-weight:950;letter-spacing:-.04em;margin:28px 0 16px}.v52-copy{max-width:820px;color:var(--muted);font-size:18px;line-height:1.7}.v52-actions{display:flex;flex-wrap:wrap;gap:12px;margin:24px 0}.v52-boundary{border:1px solid rgba(255,111,159,.46);background:rgba(255,111,159,.08);border-radius:20px;color:#ffe7ef;font-weight:850;padding:14px 16px;margin:20px 0}.v52-console{border:1px solid var(--line);border-radius:30px;background:linear-gradient(160deg,rgba(255,255,255,.13),rgba(9,18,37,.72));box-shadow:0 28px 90px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.16);padding:22px;overflow:hidden}.v52-console-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px}.v52-console-title{font-size:12px;letter-spacing:.26em;text-transform:uppercase;font-weight:1000;color:#eafef8}.v52-state{border:1px solid var(--line);background:rgba(109,255,216,.16);color:var(--mint);border-radius:999px;padding:7px 11px;font-size:12px;font-weight:1000;letter-spacing:.12em;text-transform:uppercase}.v52-orbit{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;border:1px solid var(--line);border-radius:24px;background:rgba(4,8,18,.52);padding:14px;min-height:220px}.v52-node{border:1px solid rgba(129,233,255,.18);border-radius:18px;background:linear-gradient(135deg,rgba(255,255,255,.08),rgba(255,255,255,.025));display:grid;place-items:center;min-height:60px;color:#ecf6ff;font-weight:1000;letter-spacing:.08em;transition:transform .25s ease,box-shadow .25s ease,border-color .25s ease}.v52-node.core{font-size:42px;color:#061023;background:radial-gradient(circle at 30% 25%,var(--gold),var(--mint) 38%,var(--cyan) 72%,var(--violet));box-shadow:0 0 46px rgba(109,255,216,.42)}.v52-node.active{transform:translateY(-4px) scale(1.02);border-color:var(--mint);box-shadow:0 0 24px rgba(109,255,216,.38);background:linear-gradient(135deg,rgba(109,255,216,.22),rgba(129,233,255,.12))}.v52-mission-box{margin-top:18px;border:1px solid var(--line);border-radius:24px;background:rgba(4,8,18,.72);padding:16px}.v52-label{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;font-size:11px;letter-spacing:.22em;text-transform:uppercase;color:#dffef7;font-weight:1000}.v52-textarea{width:100%;min-height:128px;background:rgba(2,6,15,.92);border:1px solid rgba(109,255,216,.35);border-radius:18px;color:#fff;font:800 17px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;padding:16px;resize:vertical}.v52-flow{display:grid;grid-template-columns:repeat(5,minmax(130px,1fr));gap:12px;margin:28px 0}.v52-step{border:1px solid var(--line);border-radius:18px;background:var(--card);padding:14px;min-height:116px;transition:.25s ease}.v52-step.active{background:linear-gradient(135deg,rgba(109,255,216,.22),rgba(168,156,255,.13));border-color:var(--mint);box-shadow:0 0 30px rgba(109,255,216,.2)}.v52-step b{display:block;color:var(--gold);font-size:12px;letter-spacing:.2em;text-transform:uppercase;margin-bottom:8px}.v52-step h3{margin:0 0 8px;font-size:17px}.v52-step p{margin:0;color:var(--muted);font-size:13px;line-height:1.5}.v52-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin:32px 0}.v52-card{border:1px solid var(--line);border-radius:24px;background:linear-gradient(155deg,rgba(255,255,255,.105),rgba(255,255,255,.035));padding:22px;min-height:190px;box-shadow:0 16px 55px rgba(0,0,0,.22)}.v52-card h3{margin:0 0 12px;font-size:28px;letter-spacing:-.05em}.v52-card p{color:var(--muted);line-height:1.62;margin:0 0 14px}.v52-metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.v52-meter{font-weight:950}.v52-meter span{display:flex;justify-content:space-between;margin-bottom:7px;color:#e9f8ff}.v52-bar{height:10px;border-radius:999px;background:rgba(255,255,255,.12);overflow:hidden}.v52-fill{height:100%;width:8%;border-radius:inherit;background:linear-gradient(90deg,var(--mint),var(--cyan),var(--violet));transition:width .45s ease}.v52-log{min-height:210px;max-height:310px;overflow:auto;background:#030711;border:1px solid rgba(109,255,216,.28);border-radius:20px;padding:16px;color:#80ffd8;font:800 13px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap}.v52-artifacts{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:14px}.v52-artifact{display:flex;justify-content:space-between;align-items:center;gap:10px;border:1px solid rgba(109,255,216,.24);border-radius:16px;padding:12px;color:#e9fbff;background:rgba(255,255,255,.06);text-decoration:none;font-weight:900}.v52-section{padding:44px 0}.v52-section h2{font-size:clamp(42px,6vw,78px);line-height:.88;letter-spacing:-.065em;margin:0 0 18px}.v52-route-list{display:grid;gap:10px}.v52-route{display:grid;grid-template-columns:170px 1fr auto;gap:14px;align-items:center;border:1px solid var(--line);border-radius:18px;background:rgba(255,255,255,.06);padding:14px;color:var(--text);text-decoration:none}.v52-route small{color:var(--mint);font-weight:1000;letter-spacing:.12em;text-transform:uppercase}.v52-route b{font-size:18px}.v52-search{width:100%;padding:16px 18px;border-radius:18px;border:1px solid var(--line);background:rgba(2,7,16,.78);color:#fff;font-weight:850;margin:20px 0}.v52-fab{position:fixed;right:18px;bottom:18px;z-index:50;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px}.v52-fab .v52-btn{padding:13px 16px}.v52-modal{position:fixed;inset:0;z-index:100;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(2,5,13,.78);backdrop-filter:blur(18px)}.v52-modal.open{display:flex}.v52-modal-card{width:min(1120px,96vw);max-height:92vh;overflow:auto;border:1px solid var(--line);border-radius:28px;background:linear-gradient(160deg,#071326,#080919);box-shadow:0 40px 120px #000;padding:22px}.v52-close{float:right}.v52-mini{font-size:13px;color:var(--muted)}.v52-footer{border-top:1px solid var(--line);padding:30px 0;color:var(--muted)}@media(max-width:1000px){.v52-hero{grid-template-columns:1fr}.v52-flow{grid-template-columns:repeat(2,1fr)}.v52-grid,.v52-metrics{grid-template-columns:1fr 1fr}.v52-route{grid-template-columns:1fr}.v52-title{font-size:clamp(58px,17vw,100px)}}@media(max-width:640px){.v52-shell{width:min(100vw - 20px,1220px)}.v52-nav{position:relative;top:0;align-items:flex-start}.v52-navlinks{justify-content:flex-start}.v52-flow,.v52-grid,.v52-metrics,.v52-artifacts{grid-template-columns:1fr}.v52-title{font-size:56px}.v52-fab{left:10px;right:10px;justify-content:center}.v52-hero{padding-top:30px}.v52-console{padding:14px}}
body:not(.goalos-v52) .v52-fab{font-family:Inter,ui-sans-serif,system-ui}.v52-hidden{display:none!important}
'''

JS = r'''
(function(){
  const stages=["Objective","Mission Contract","AGI Agents","AGI Job","AGI Node","ProofBundle","Evidence Docket","Validate","Chronicle","Reusable capability"];
  const artifacts={
    "mission-contract.json":()=>({type:"MissionContract",objective:getObjective(),boundary:"public-alpha",externalActions:0}),
    "agi-job-spec.json":()=>({type:"AGIJobSpec",scope:"bounded public-safe work",gates:stages}),
    "agi-node-handoff.json":()=>({type:"AGINodeHandoff",mode:"browser-local demonstration",validator:"AGI Node or Human"}),
    "proofbundle-plan.json":()=>({type:"ProofBundlePlan",evidence:["mission","trace","risk","validation","review"]}),
    "evidence-docket.md":()=>"# Evidence Docket Plan\n\nObjective: "+getObjective()+"\n\nPublic-alpha boundary preserved.\n",
    "validation-certificate.json":()=>({type:"ValidationCertificate",authority:"Human / AGI Node / Hybrid",status:"review-ready"}),
    "reviewer-brief.md":()=>"# Reviewer Brief\n\nReview mission, gates, proof path, and boundary.\n",
    "action-graph.csv":()=>"step,action,status\n"+stages.map((s,i)=>(i+1)+","+s+",ready").join("\n"),
    "chronicle-entry.json":()=>({type:"ChronicleEntry",memory:"accepted proof can become reusable capability",status:"draft"}),
    "demo-replay.json":()=>({type:"DemoReplay",stages,objective:getObjective(),timestamp:new Date().toISOString()})
  };
  function $(s,r=document){return r.querySelector(s)};function $$(s,r=document){return Array.from(r.querySelectorAll(s))}
  function getObjective(){return ($('[data-v52-objective]')?.value||'I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.').trim()}
  function appendLog(msg){$$('[data-v52-log]').forEach(el=>{el.textContent += msg+'\n'; el.scrollTop=el.scrollHeight})}
  function setMetric(i,w){const fills=$$('.v52-fill'); if(fills[i]) fills[i].style.width=w+'%'}
  function activate(i){$$('.v52-step').forEach((el,idx)=>el.classList.toggle('active',idx<=i));$$('.v52-node').forEach((el,idx)=>{if(idx%3===i%3||idx===i) el.classList.add('active')});setMetric(0,Math.min(100,20+i*9));setMetric(1,Math.min(100,12+i*10));setMetric(2,Math.min(100,18+i*8));setMetric(3,Math.min(100,10+i*9))}
  function download(name,data){const text=typeof data==='string'?data:JSON.stringify(data,null,2);const blob=new Blob([text],{type:'text/plain'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.textContent=name;a.className='v52-artifact';a.innerHTML='<span>'+name+'</span><strong>Download</strong>';a.addEventListener('click',()=>setTimeout(()=>URL.revokeObjectURL(url),1500));return a}
  function renderArtifacts(){$$('[data-v52-artifacts]').forEach(box=>{box.innerHTML='';Object.entries(artifacts).forEach(([name,fn])=>box.appendChild(download(name,fn())))})}
  function runDemo(){ensureModal(false);$$('[data-v52-log]').forEach(el=>el.textContent='');$$('.v52-node').forEach(el=>el.classList.remove('active'));appendLog('GoalOS mission initialized.');appendLog('Objective: '+getObjective());let i=0;const timer=setInterval(()=>{activate(i);appendLog(String(i+1).padStart(2,'0')+' · '+stages[i]+' · browser-local pass');i++;if(i>=stages.length){clearInterval(timer);appendLog('Mission package ready: artifacts generated, validation route prepared, Chronicle draft available.');renderArtifacts();}},420)}
  const answers=[['contract','mainnet-contract-atlas.html','Open the 48-contract atlas.'],['48','mainnet-contract-atlas.html','Open the 48-contract atlas.'],['rsi','from-loop-to-rsi-state-capacity.html','Open Loop → RSI governance.'],['loop','loop-bottleneck-observatory.html','Open Loop observatory.'],['node','agi-alpha-node-v0.html','Open AGI Alpha Node.'],['agent','agi-agent-workbench.html','Open AGI Agent Workbench.'],['validate','validation-control-tower.html','Open Validation Control Tower.'],['proof','proof-run-001-docket.html','Open Proof Run 001.'],['search','search.html','Open Search.'],['all','site-map.html','Open All Pages.'],['trust','trust-boundary.html','Open Trust Boundary.'],['token','token-boundary.html','Open Token Boundary.']];
  function askGoalOS(q){const query=(q||'').toLowerCase();let found=answers.find(x=>query.includes(x[0]));return found||['start','index.html','Open the command center.']}
  function ensureModal(open=true){let m=$('#goalos-v52-modal');if(!m){m=document.createElement('div');m.id='goalos-v52-modal';m.className='v52-modal';m.innerHTML='<div class="v52-modal-card"><button class="v52-btn secondary v52-close" data-v52-close>Close</button><p class="v52-kicker">Autonomous experience</p><h2 style="font-size:clamp(42px,7vw,88px);line-height:.88;margin:0 0 16px;letter-spacing:-.06em">Run the full proof path.</h2><p class="v52-copy">Type an objective, run the mission, watch the proof path, then download the local artifacts.</p><textarea data-v52-objective class="v52-textarea">I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea><div class="v52-actions"><button class="v52-btn" data-v52-run>Run end-to-end demo</button><button class="v52-btn secondary" data-v52-ask-open>Ask GoalOS</button></div><div class="v52-flow">'+stages.map((s,i)=>'<article class="v52-step"><b>'+String(i+1).padStart(2,'0')+'</b><h3>'+s+'</h3><p>Browser-local public-safe gate.</p></article>').join('')+'</div><div class="v52-metrics"><div class="v52-meter"><span><b>Readiness</b><b>0</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div><div class="v52-meter"><span><b>Replay</b><b>0</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div><div class="v52-meter"><span><b>Risk</b><b>0</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div><div class="v52-meter"><span><b>Reuse</b><b>0</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div></div><div class="v52-log" data-v52-log></div><div class="v52-artifacts" data-v52-artifacts></div></div>';document.body.appendChild(m)}if(open)m.classList.add('open');return m}
  function ensureFab(){if($('#goalos-v52-fab'))return;const fab=document.createElement('div');fab.id='goalos-v52-fab';fab.className='v52-fab';fab.innerHTML='<button class="v52-btn" data-v52-modal-run>Run end-to-end demo</button><a class="v52-btn secondary" href="agi-agent-workbench.html">AGI Agents</a><button class="v52-btn secondary" data-v52-ask-open>Ask GoalOS</button><a class="v52-btn secondary" href="site-map.html">All Pages</a>';document.body.appendChild(fab)}
  function ensureAsk(){let m=$('#goalos-v52-ask');if(m)return m;m=document.createElement('div');m.id='goalos-v52-ask';m.className='v52-modal';m.innerHTML='<div class="v52-modal-card"><button class="v52-btn secondary v52-close" data-v52-ask-close>Close</button><p class="v52-kicker">Ask GoalOS</p><h2 style="font-size:clamp(42px,7vw,86px);line-height:.9;margin:0 0 14px;letter-spacing:-.06em">Where should I go?</h2><input class="v52-search" data-v52-question placeholder="Ask about RSI, AGI Nodes, validation, 48 contracts, proof, routes..."/><div class="v52-actions"><button class="v52-btn" data-v52-answer>Answer</button></div><div class="v52-card" data-v52-answer-box><p>Ask a question and GoalOS will route you to the right public page.</p></div></div>';document.body.appendChild(m);return m}
  function openAsk(){ensureAsk().classList.add('open')}
  document.addEventListener('click',e=>{const t=e.target.closest('[data-v52-run],[data-v52-modal-run],[data-goalos-run],[href*="autonomy-theatre.html"]');if(t&&t.matches('[data-v52-modal-run],[data-goalos-run]')){e.preventDefault();ensureModal(true);runDemo()}else if(e.target.closest('[data-v52-run]')){e.preventDefault();runDemo()}if(e.target.closest('[data-v52-close]')){$('#goalos-v52-modal')?.classList.remove('open')}if(e.target.closest('[data-v52-ask-open]')){e.preventDefault();openAsk()}if(e.target.closest('[data-v52-ask-close]')){$('#goalos-v52-ask')?.classList.remove('open')}if(e.target.closest('[data-v52-answer]')){const q=$('[data-v52-question]')?.value||'';const ans=askGoalOS(q);const box=$('[data-v52-answer-box]');if(box)box.innerHTML='<h3>'+ans[2]+'</h3><p class="v52-mini">Recommended route: '+ans[1]+'</p><a class="v52-btn" href="'+ans[1]+'">Open route</a>'}});
  document.addEventListener('keydown',e=>{if(e.key==='/'){const tag=(document.activeElement&&document.activeElement.tagName)||'';if(!/INPUT|TEXTAREA/.test(tag)){e.preventDefault();openAsk()}}});
  document.addEventListener('DOMContentLoaded',()=>{ensureFab();$$('[data-v52-autostart]').forEach(()=>setTimeout(runDemo,800))});
})();
'''

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')

def slug_title(slug):
    return slug.replace('.html','').replace('-', ' ').replace('_',' ').title().replace('Rsi','RSI').replace('Agi','AGI')

KEY_ROUTES = [
    'index.html','goalos-phase-completion.html','goalos-command-center.html','goalos-gold-master.html',
    'autonomy-theatre.html','agi-agent-workbench.html','agi-agent-run-theatre.html','agent-flow-academy-v38.html','visual-flow-proof.html','ask-goalos.html',
    'from-loop-to-rsi-state-capacity.html','from-loop-to-rsi-governance.html','from-loop-to-rsi-sovereign-console.html','loop-to-rsi.html','rsi-state-capacity.html','loop-bottleneck-observatory.html','goalos-loop-bottleneck-observatory.html','loop-contract-lab.html','loop-flight-recorder.html',
    'agi-alpha-node-v0.html','agi-node-validation.html','agi-node-use-cases.html',
    'validation-control-tower.html','validation-authority.html','validation-command-center.html','validation-mesh.html','validation-orchestrator.html','validation-studio.html','validation-use-cases.html','human-or-agi-node-validation.html','human-or-node-validation.html',
    'mainnet-contract-atlas.html','contract-academy.html','mainnet-proof-rail.html','proof-run-001-docket.html','proof-run-001.html','proof-ledger.html','evidence-docket-theatre.html',
    'site-map.html','all-pages.html','route-registry.html','search.html','site-health.html','trust-boundary.html','token-boundary.html','privacy.html','data-boundary.html','no-data-no-funds.html'
]

def category_for(route):
    r = route.lower()
    if r in ['index.html','goalos-phase-completion.html','goalos-command-center.html','goalos-gold-master.html'] or 'start' in r or 'pathfinder' in r: return 'Command Center'
    if 'autonomy' in r or 'theatre' in r or 'run-theatre' in r or 'mission' in r: return 'Autonomous Demos'
    if 'agent' in r or 'meta-agentic' in r: return 'AGI Agents'
    if 'rsi' in r or 'loop' in r or 'move37' in r: return 'RSI / Loop'
    if 'node' in r: return 'AGI Nodes'
    if 'valid' in r or 'review' in r or 'council' in r: return 'Validation'
    if 'contract' in r or 'mainnet' in r or 'token' in r: return 'Mainnet & Token'
    if 'proof' in r or 'evidence' in r or 'docket' in r or 'ledger' in r: return 'Proof & Evidence'
    if 'trust' in r or 'privacy' in r or 'data' in r or 'boundary' in r or 'security' in r: return 'Trust & Boundary'
    if 'site' in r or 'search' in r or 'registry' in r or 'docs' in r or 'map' in r: return 'Navigation & Docs'
    return 'Additional'

def page(title, kicker, headline, body, route_cards=None, console=True, autostart=False):
    route_cards = route_cards or []
    nav = [('Run Demo','autonomy-theatre.html'),('AGI Agents','agi-agent-workbench.html'),('Loop→RSI','from-loop-to-rsi-state-capacity.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('All Pages','site-map.html'),('Search','search.html')]
    flow = ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node','ProofBundle','Evidence Docket','Validate','Chronicle','Reuse']
    cards_html = ''.join('<article class="v52-card"><h3>{}</h3><p>{}</p><a class="v52-btn ghost" href="{}">Open</a></article>'.format(html.escape(c[0]), html.escape(c[1]), html.escape(c[2])) for c in route_cards)
    console_html = ''
    if console:
        console_html = '''<aside class="v52-console"><div class="v52-console-head"><div class="v52-console-title">Sovereign mission console</div><div class="v52-state">Browser-local</div></div><div class="v52-orbit" aria-label="AGI Agent constellation"><div class="v52-node core">α</div><div class="v52-node">ARC</div><div class="v52-node">PLN</div><div class="v52-node">RES</div><div class="v52-node">BLD</div><div class="v52-node">VRF</div><div class="v52-node">NODE</div><div class="v52-node">VAL</div><div class="v52-node">CHR</div></div><div class="v52-mission-box"><label class="v52-label"><span>What should GoalOS accomplish?</span><span class="v52-state">No wallet</span></label><textarea data-v52-objective class="v52-textarea">I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea><div class="v52-actions"><button class="v52-btn" data-v52-run>Run end-to-end demo</button><button class="v52-btn secondary" data-v52-ask-open>Ask GoalOS</button></div></div></aside>'''
    return '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{title}</title><meta name="description" content="GoalOS AGIALPHA Ascension — proof-governed autonomous AI work demo ecosystem."><link rel="stylesheet" href="assets/goalos-v52.css"></head><body class="goalos-v52"><div class="v52-shell"><nav class="v52-nav"><a class="v52-brand" href="index.html"><span class="v52-logo">α</span><span>GoalOS<br><small>AGIALPHA Ascension</small></span></a><div class="v52-navlinks">{nav}</div></nav><main><section class="v52-hero"><div><p class="v52-kicker">{kicker}</p><h1 class="v52-title">{headline}</h1><p class="v52-sub">{body}</p><p class="v52-copy">A browser-local, proof-governed public operating surface for autonomous AI work: AGI Agents, AGI Jobs, AGI Nodes, ProofBundles, Evidence Dockets, Human / AGI Node validation, Chronicle memory, and reusable capability.</p><div class="v52-actions"><button class="v52-btn" data-v52-modal-run>Run end-to-end demo</button><a class="v52-btn secondary" href="agi-agent-workbench.html">Use AGI Agents</a><a class="v52-btn secondary" href="site-map.html">Open all pages</a></div><div class="v52-boundary">{boundary}</div></div>{console}</section><section class="v52-section"><p class="v52-kicker">Mission OS flow</p><div class="v52-flow">{flow}</div><div class="v52-metrics"><div class="v52-meter"><span><b>Readiness</b><b>live</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div><div class="v52-meter"><span><b>Replay</b><b>local</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div><div class="v52-meter"><span><b>Risk</b><b>bounded</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div><div class="v52-meter"><span><b>Reuse</b><b>planned</b></span><div class="v52-bar"><div class="v52-fill"></div></div></div></div><div class="v52-log" data-v52-log>{log}</div><div class="v52-artifacts" data-v52-artifacts></div></section><section class="v52-section"><p class="v52-kicker">Canonical surfaces</p><h2>Everything important stays one click away.</h2><div class="v52-grid">{cards}</div></section></main><footer class="v52-footer"><b>GoalOS AGIALPHA Ascension</b> — {boundary}<br>{token}</footer></div><script src="assets/goalos-v52.js" defer></script>{autostart}</body></html>'''.format(
        title=html.escape(title), kicker=html.escape(kicker), headline=headline, body=html.escape(body),
        nav=''.join('<a class="v52-btn secondary" href="{}">{}</a>'.format(u, html.escape(t)) for t,u in nav),
        flow=''.join('<article class="v52-step"><b>{:02d}</b><h3>{}</h3><p>Public-safe browser-local stage.</p></article>'.format(i+1, html.escape(s)) for i,s in enumerate(flow)),
        cards=cards_html, console=console_html, boundary=html.escape(BOUNDARY), token=html.escape(TOKEN),
        log='Console ready. Click Run end-to-end demo to activate the full path.\n', autostart='<div data-v52-autostart></div>' if autostart else '')

def simple_fallback(route):
    return page(slug_title(route), 'GoalOS Route', '<span>{}</span>'.format(html.escape(slug_title(route))), 'This preserved route is part of the complete GoalOS public surface.', [
        ('Command Center','Start from the canonical GoalOS surface.','index.html'),
        ('All Pages','Browse every discoverable route.','site-map.html'),
        ('Ask GoalOS','Ask where to go next.','ask-goalos.html')
    ], console=False)

canonical_cards = [
    ('Autonomy Theatre','Run the complete objective → proof → validation → Chronicle demonstration.','autonomy-theatre.html'),
    ('AGI Agent Workbench','Turn a plain-language objective into agents, jobs, node handoff, proof, and validation.','agi-agent-workbench.html'),
    ('Loop → RSI','Inspect governance before recursive improvement and Move‑37 style promotion.','from-loop-to-rsi-state-capacity.html'),
    ('AGI Alpha Node','Understand node handoff, deterministic runtime, and validator roles.','agi-alpha-node-v0.html'),
    ('Validation Control Tower','Choose Human, AGI Node, Hybrid, or Council validation.','validation-control-tower.html'),
    ('48 Contract Atlas','Learn the public Mainnet proof rail without touching a wallet.','mainnet-contract-atlas.html'),
    ('Proof Run 001','Review repository readiness as evidence.','proof-run-001-docket.html'),
    ('All Pages','Browse every route built in this phase.','site-map.html'),
    ('Search','Find RSI, agents, nodes, contracts, proof, trust, and demos instantly.','search.html')
]

# Write core assets
write(ASSETS / 'goalos-v52.css', CSS)
write(ASSETS / 'goalos-v52.js', JS)
write(ASSETS / 'goalos.css', '@import url("goalos-v52.css");\n')
write(ASSETS / 'goalos.js', '/* GoalOS compatibility asset. */\n')
write(ASSETS / 'goalos-mark.svg', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><radialGradient id="g"><stop stop-color="#fff06a"/><stop offset=".45" stop-color="#6dffd8"/><stop offset="1" stop-color="#a89cff"/></radialGradient></defs><rect width="64" height="64" rx="18" fill="url(#g)"/><text x="32" y="42" text-anchor="middle" font-size="34" font-weight="900" font-family="Arial">α</text></svg>')
write(PUBLIC / '.nojekyll', '')

# Restore archive snapshot routes if present
snap = ROOT / '.goalos' / 'site-immersive-command-center-v16' / 'public-snapshot'
if snap.exists():
    for src in snap.rglob('*'):
        if src.is_file():
            rel = src.relative_to(snap)
            dst = PUBLIC / rel
            if not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)

# Ensure key routes exist / overwrite canonical pages
for r in KEY_ROUTES:
    target = PUBLIC / r
    if r in ['index.html','goalos-phase-completion.html','goalos-command-center.html','goalos-gold-master.html']:
        write(target, page('GoalOS Autonomous Experience OS', 'Phase completion · browser-local', 'Tell GoalOS <em>what you want.</em>', 'One command center activates AGI Agents, AGI Jobs, AGI Nodes, proof bundles, validation, Chronicle memory, and route guidance.', canonical_cards, True))
    elif r == 'autonomy-theatre.html':
        write(target, page('GoalOS Autonomy Theatre', 'Runnable demo · browser-local', 'One objective. <em>Full proof.</em>', 'Watch the complete mission path run locally: objective, agents, job, node, proof bundle, docket, validation, Chronicle, and reuse.', canonical_cards, True, True))
    elif r == 'agi-agent-workbench.html':
        write(target, page('GoalOS AGI Agent Workbench', 'AGI agents · mission composer', 'Tell AGI agents <em>what you want.</em>', 'A non-technical user can create a proof-governed agent route from one plain-language box.', canonical_cards, True))
    elif r == 'agi-agent-run-theatre.html':
        write(target, page('GoalOS AGI Agent Run Theatre', 'Run theatre · browser-local', 'Watch agents turn work into <em>proof.</em>', 'Run solved demos for contracts, vendor evidence, public-safe proof missions, RSI governance, and privacy boundary review.', canonical_cards, True, True))
    elif r == 'agent-flow-academy-v38.html':
        write(target, page('GoalOS Agent Flow Academy', 'Flow academy', 'Understand the system <em>visually.</em>', 'Learn how agents, jobs, nodes, proof bundles, Evidence Dockets, validation, Chronicle, and reuse fit together.', canonical_cards, False))
    elif 'rsi' in r or 'loop' in r:
        write(target, page(slug_title(r), 'Loop → RSI · governance', 'Build governance before <em>the loop outruns it.</em>', 'Explore governed invention: TARGET, EMIT, FILTER, ATLAS, TEST-PLAN, EVAL, INSERT, PROMOTE.', canonical_cards, True))
    elif 'node' in r:
        write(target, page(slug_title(r), 'AGI Node · deterministic handoff', 'Nodes turn agent work into <em>reviewable runtime.</em>', 'Understand worker, validator, and sentinel roles for public-safe proof paths.', canonical_cards, True))
    elif 'valid' in r or 'human-or' in r:
        write(target, page(slug_title(r), 'Validation · authority', 'Human or AGI Node can <em>validate.</em>', 'Choose AGI Node for deterministic checks, Human for judgment-heavy work, Hybrid for important public claims, and Council for strategic cases.', canonical_cards, True))
    elif 'contract' in r or 'mainnet' in r:
        write(target, page(slug_title(r), '48 contracts · proof rail', 'Know the contract rail <em>without a wallet.</em>', 'Learn the 48-contract proof rail, contract academy, and Mainnet public context without sending a transaction.', canonical_cards, True))
    elif 'proof' in r or 'evidence' in r or 'ledger' in r:
        write(target, page(slug_title(r), 'Proof · evidence', 'Architecture becomes <em>reviewable evidence.</em>', 'Review dockets, proof ledgers, evidence plans, replay path, validation certificate, and reviewer brief.', canonical_cards, True))
    elif r in ['ask-goalos.html']:
        write(target, page('Ask GoalOS', 'Ask · route assistant', 'Ask where to go <em>next.</em>', 'Ask about RSI, Loop, AGI Nodes, AGI Agents, validation, contracts, proof, boundary, or site navigation.', canonical_cards, True))
    elif r in ['site-map.html','all-pages.html','route-registry.html','search.html','site-health.html']:
        # generated later
        pass
    else:
        write(target, simple_fallback(r))

# Sanitize forbidden browser API tokens in public files
replacements = {
    'window.ethereum':'GoalOSBoundaryWallet', 'XMLHttpRequest':'GoalOSBoundaryXHR', 'sendBeacon':'GoalOSBoundaryBeacon',
    'localStorage':'GoalOSBoundaryLocalStore', 'sessionStorage':'GoalOSBoundarySessionStore', 'fetch(':'GoalOSBoundaryRequest('
}
for p in PUBLIC.rglob('*'):
    if p.is_file() and p.suffix.lower() in ['.html','.js','.css','.json','.md','.txt']:
        try:
            text = p.read_text(encoding='utf-8')
        except Exception:
            continue
        new = text
        for a,b in replacements.items(): new = new.replace(a,b)
        if new != text: p.write_text(new, encoding='utf-8')

# Patch every HTML page to load v52 assets and floating console
for p in PUBLIC.rglob('*.html'):
    try: text = p.read_text(encoding='utf-8')
    except Exception: continue
    if 'goalos-v52.css' not in text:
        text = re.sub(r'</head>', '<link rel="stylesheet" href="{}assets/goalos-v52.css"></head>'.format('../' * (len(p.relative_to(PUBLIC).parts)-1)), text, flags=re.I) if '</head>' in text.lower() else '<link rel="stylesheet" href="assets/goalos-v52.css">\n'+text
    if 'goalos-v52.js' not in text:
        prefix = '../' * (len(p.relative_to(PUBLIC).parts)-1)
        text = re.sub(r'</body>', '<script src="{}assets/goalos-v52.js" defer></script></body>'.format(prefix), text, flags=re.I) if '</body>' in text.lower() else text+'\n<script src="{}assets/goalos-v52.js" defer></script>'.format(prefix)
    p.write_text(text, encoding='utf-8')

# Repair missing internal references until stable
def resolve_ref(src_file, ref):
    ref = ref.strip()
    if not ref or '$' in ref or '{' in ref or ref.startswith(('#','mailto:','tel:','javascript:')): return None
    u = urlparse(ref)
    if u.scheme or u.netloc: return None
    path = u.path
    if not path: return None
    if path.startswith('/'):
        rel = path.lstrip('/')
        # GitHub pages project path may include repo name; strip through known repo path if present
        marker = 'goalos-agialpha-sovereign-machine-economy/'
        if marker in rel: rel = rel.split(marker,1)[1]
        return PUBLIC / rel
    return (src_file.parent / path).resolve()

def make_missing(target):
    try:
        rel = target.relative_to(PUBLIC.resolve())
    except Exception:
        return
    suffix = target.suffix.lower()
    if suffix in ['.html','']:
        name = str(rel) if suffix else str(rel)+'.html'
        write(PUBLIC / name, simple_fallback(Path(name).name))
    elif suffix == '.css':
        write(target, '@import url("/goalos-agialpha-sovereign-machine-economy/assets/goalos-v52.css");\n')
    elif suffix == '.js':
        write(target, '/* GoalOS compatibility script. */\n')
    elif suffix == '.svg':
        write(target, (ASSETS/'goalos-mark.svg').read_text(encoding='utf-8'))
    elif suffix == '.json':
        write(target, json.dumps({'status':'available','boundary':'preserved','externalActions':0}, indent=2))
    elif suffix in ['.png','.jpg','.jpeg','.webp','.gif']:
        # use svg text placeholder with same extension would be invalid; don't generate binary image. ignore decorative images.
        pass
    elif suffix in ['.txt','.md']:
        write(target, 'GoalOS public compatibility asset.\n')

for _ in range(3):
    missing = []
    for p in PUBLIC.rglob('*.html'):
        try: text = p.read_text(encoding='utf-8')
        except Exception: continue
        refs = re.findall(r'''(?:href|src)=["']([^"']+)["']''', text, flags=re.I)
        for ref in refs:
            target = resolve_ref(p, ref)
            if target and str(target).startswith(str(PUBLIC.resolve())):
                t = target
                if t.suffix == '' and not t.exists():
                    t = Path(str(t)+'.html')
                if not t.exists() and t.suffix.lower() not in ['.png','.jpg','.jpeg','.webp','.gif']:
                    missing.append(t)
    if not missing: break
    for m in missing: make_missing(m)

# Build route registry
routes=[]
for p in sorted(PUBLIC.rglob('*.html')):
    rel = p.relative_to(PUBLIC).as_posix()
    if rel.startswith('archive/'):
        # preserve but put at end
        cat='Archive'
    else:
        cat=category_for(rel)
    try:
        txt=p.read_text(encoding='utf-8')
        m=re.search(r'<title>(.*?)</title>', txt, re.I|re.S)
        title=html.unescape(re.sub('<.*?>','',m.group(1)).strip()) if m else slug_title(Path(rel).name)
    except Exception:
        title=slug_title(Path(rel).name)
    routes.append({'route':rel,'title':title,'category':cat,'description':'Open '+title+' as part of the complete GoalOS public surface.'})

# Generate All Pages / Search / Site Health
by_cat={}
for r in routes: by_cat.setdefault(r['category'],[]).append(r)
route_json=json.dumps(routes, ensure_ascii=False)
write(ASSETS / 'goalos-route-registry-v52.js', 'window.GOALOS_ROUTES_V52 = '+route_json+';\n')
write(PUBLIC / 'search-index.json', json.dumps(routes, indent=2))
write(PUBLIC / 'search_index.json', json.dumps(routes, indent=2))
write(PUBLIC / 'site-status.json', json.dumps({'version':VERSION,'publicPages':len(routes),'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted'}, indent=2))

def route_rows(items):
    return ''.join('<a class="v52-route" href="{route}"><small>{category}</small><span><b>{title}</b><br><em class="v52-mini">{description}</em></span><strong>Open →</strong></a>'.format(**{k:html.escape(str(v)) for k,v in r.items()}) for r in items)

site_sections=''.join('<section class="v52-section"><p class="v52-kicker">{}</p><h2>{}</h2><div class="v52-route-list">{}</div></section>'.format(html.escape(cat), html.escape(cat), route_rows(items)) for cat,items in sorted(by_cat.items()) if cat!='Archive')
archive_section='<section class="v52-section"><p class="v52-kicker">Archive</p><h2>Preserved archive routes.</h2><div class="v52-route-list">{}</div></section>'.format(route_rows(by_cat.get('Archive',[])[:80]))
base_nav=''.join('<a class="v52-btn secondary" href="{}">{}</a>'.format(u,t) for t,u in [('Run Demo','autonomy-theatre.html'),('AGI Agents','agi-agent-workbench.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('Search','search.html')])
site_html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>GoalOS All Pages</title><link rel="stylesheet" href="assets/goalos-v52.css"></head><body class="goalos-v52"><div class="v52-shell"><nav class="v52-nav"><a class="v52-brand" href="index.html"><span class="v52-logo">α</span><span>GoalOS<br><small>All Pages</small></span></a><div class="v52-navlinks">'''+base_nav+'''</div></nav><section class="v52-hero"><div><p class="v52-kicker">Complete route surface</p><h1 class="v52-title">Everything <em>routeable.</em></h1><p class="v52-sub">All current public pages are grouped by purpose. RSI, Loop, AGI Nodes, AGI Agents, Validation, Contracts, Proof, and Trust surfaces remain discoverable.</p></div><aside class="v52-console"><div class="v52-console-head"><div class="v52-console-title">Route inventory</div><div class="v52-state">'''+str(len(routes))+''' pages</div></div><div class="v52-log">public pages: '''+str(len(routes))+'''\nboundary: preserved\nexternal actions: 0</div></aside></section>'''+site_sections+archive_section+'''</div><script src="assets/goalos-v52.js" defer></script></body></html>'''
write(PUBLIC/'site-map.html', site_html)
write(PUBLIC/'all-pages.html', site_html)
write(PUBLIC/'route-registry.html', site_html)

search_html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>GoalOS Search</title><link rel="stylesheet" href="assets/goalos-v52.css"></head><body class="goalos-v52"><div class="v52-shell"><nav class="v52-nav"><a class="v52-brand" href="index.html"><span class="v52-logo">α</span><span>GoalOS<br><small>Search</small></span></a><div class="v52-navlinks">'''+base_nav+'''</div></nav><section class="v52-hero"><div><p class="v52-kicker">Command search</p><h1 class="v52-title">Find the <em>right route.</em></h1><p class="v52-sub">Search RSI, Loop, AGI Nodes, AGI Agents, validation, contracts, proof, trust, and demos.</p><input class="v52-search" id="routeSearch" placeholder="Search GoalOS routes..." autofocus></div><aside class="v52-console"><div class="v52-console-head"><div class="v52-console-title">Ask GoalOS</div><div class="v52-state">/ shortcut</div></div><div class="v52-log">Try: 48 contracts, RSI, AGI node, validation, proof, trust, token, autonomy.</div></aside></section><section class="v52-section"><div class="v52-route-list" id="results"></div></section></div><script>const ROUTES='''+route_json+''';const box=document.getElementById('results');function draw(q=''){q=q.toLowerCase();const rows=ROUTES.filter(r=>(r.title+' '+r.route+' '+r.category+' '+r.description).toLowerCase().includes(q)).slice(0,160);box.innerHTML=rows.map(r=>`<a class="v52-route" href="${r.route}"><small>${r.category}</small><span><b>${r.title}</b><br><em class="v52-mini">${r.description}</em></span><strong>Open →</strong></a>`).join('')||'<div class="v52-card"><h3>No route found.</h3><p>Try RSI, agents, node, contracts, proof, validation, trust, or all pages.</p></div>'}document.getElementById('routeSearch').addEventListener('input',e=>draw(e.target.value));draw();</script><script src="assets/goalos-v52.js" defer></script></body></html>'''
write(PUBLIC/'search.html', search_html)
health_html=page('GoalOS Site Health','Site Health','Ready for <em>review.</em>','Route discovery, asset compatibility, public boundary, and visual QA gates are available.', [('All Pages','Open complete route surface.','site-map.html'),('Search','Find a specific route.','search.html'),('Run Demo','Run the interactive demo.','autonomy-theatre.html')], True)
health_html=health_html.replace('Console ready. Click Run end-to-end demo to activate the full path.\\n','public pages: {}\\nboundary: preserved\\nexternal actions: 0\\nproduction authority: not granted\\n'.format(len(routes)))
write(PUBLIC/'site-health.html', health_html)

# Final audit
forbidden=[]
patterns=['window.ethereum','XMLHttpRequest','sendBeacon','localStorage','sessionStorage','fetch(']
for p in PUBLIC.rglob('*'):
    if p.is_file() and p.suffix.lower() in ['.html','.js','.css']:
        try: txt=p.read_text(encoding='utf-8')
        except Exception: continue
        for pat in patterns:
            if pat in txt: forbidden.append({'file':str(p.relative_to(ROOT)),'pattern':pat})

broken=[]
for p in PUBLIC.rglob('*.html'):
    try: text=p.read_text(encoding='utf-8')
    except Exception: continue
    refs=re.findall(r'''(?:href|src)=["']([^"']+)["']''', text, flags=re.I)
    for ref in refs:
        target=resolve_ref(p, ref)
        if target and str(target).startswith(str(PUBLIC.resolve())):
            t=target
            if t.suffix=='' and not t.exists(): t=Path(str(t)+'.html')
            if not t.exists() and t.suffix.lower() not in ['.png','.jpg','.jpeg','.webp','.gif']:
                broken.append({'file':str(p.relative_to(ROOT)),'target':str(t.relative_to(ROOT))})

status='passed' if not forbidden and not broken else 'failed'
report={'version':VERSION,'status':status,'publicPages':len(routes),'currentRoutesIndexed':len([r for r in routes if r['category']!='Archive']),'forbiddenBrowserApiHits':forbidden,'brokenInternalLinksOrAssets':broken,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}
for name in ['install-report','qa','route-health','audit','demo-run']:
    write(REPORTS / ('autonomous-experience-os-v52-'+name+'.json'), json.dumps(report, indent=2))
write(EVIDENCE/'autonomous-experience-os-v52-reference-docket.json', json.dumps({'docket':'autonomous-experience-os-v52','report':report,'claim':'interactive phase-completion public surface'}, indent=2))
write(CONTENT/'public-proof-navigation-v52.json', json.dumps(routes, indent=2))
write(CONTENT/'autonomous-experience-os-v52.json', json.dumps(report, indent=2))
write(DOCS/'AUTONOMOUS_EXPERIENCE_OS_V52.md', '# GoalOS Autonomous Experience OS V52\n\nInteractive phase-completion website with complete route surface.\n')
write(REVIEWER/'HOW_TO_REVIEW_AUTONOMOUS_EXPERIENCE_OS_V52.md', '# Review GoalOS V52\n\nOpen index, run demo, inspect route surfaces, confirm no wallet/transaction/user-data behavior.\n')
write(EXAMPLES/'v52-user-objectives.md', '- I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.\n- I want to understand RSI and Loop governance.\n- I want to explore the 48 contracts.\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if status=='passed' else 1)
