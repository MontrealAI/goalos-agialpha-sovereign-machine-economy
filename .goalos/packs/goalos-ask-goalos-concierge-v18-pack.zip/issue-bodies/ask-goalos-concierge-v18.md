Review Ask GoalOS Concierge V18.
