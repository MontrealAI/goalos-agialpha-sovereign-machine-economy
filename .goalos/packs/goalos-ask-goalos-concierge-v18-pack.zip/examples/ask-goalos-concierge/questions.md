# Example questions

- where are the 48 contracts?
