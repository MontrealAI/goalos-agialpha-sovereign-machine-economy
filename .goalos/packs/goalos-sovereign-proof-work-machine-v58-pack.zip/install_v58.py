#!/usr/bin/env python3
from __future__ import annotations
import os, re, json, html, shutil, math
from pathlib import Path
from urllib.parse import unquote
VERSION='v58'
ASSET_CSS='goalos-proof-gated-work-machine-v58.css'
ASSET_JS='goalos-proof-gated-work-machine-v58.js'
ROUTE_JS='goalos-v58-routes.js'
ROUTE_JSON='goalos-v58-route-registry.json'
BOUNDARY={'userData':'not_requested','userFunds':'not_requested','wallet':'not_enabled','transaction':'not_enabled','productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','externalActions':0}
NAV=[('Run Demo','#run'),('AGI Agents','agi-agent-workbench.html'),('RSI / Loop','from-loop-to-rsi-state-capacity.html'),('AGI Node','agi-alpha-node-v0.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('All Pages','all-pages.html'),('Search','search.html'),('Health','site-health.html')]
FORBIDDEN=[r'window\.ethereum',r'ethereum\.request',r'\bfetch\s*\(',r'XMLHttpRequest',r'navigator\.sendBeacon',r'localStorage',r'sessionStorage',r'indexedDB']
REPLACEMENTS={'window.ethereum':'window.__goalos_public_alpha_wallet_disabled__','ethereum.request':'ethereum_request_disabled','fetch(':'__goalos_no_network_fetch__(','XMLHttpRequest':'DisabledXMLHttpRequest','navigator.sendBeacon':'disabledSendBeacon','localStorage':'goalosBrowserSessionMemory','sessionStorage':'goalosBrowserSessionMemory','indexedDB':'disabledIndexedDB'}

def esc(x): return html.escape(str(x),quote=True)
def pack_root(): return Path(__file__).resolve().parent
def ensure_dirs(root):
    dirs={'public':root/'public','assets':root/'public'/'assets','reports':root/'reports','evidence':root/'evidence'/'demo','content':root/'content'/'goalos','docs':root/'docs'/'website','reviewer':root/'docs'/'reviewer'}
    for p in dirs.values(): p.mkdir(parents=True,exist_ok=True)
    return dirs

def load_manifest(): return json.loads((pack_root()/'canonical-manifest-v58.json').read_text(encoding='utf-8'))
def title_from_route(route):
    name=route.rsplit('/',1)[-1].replace('.html','')
    if name=='index': return 'GoalOS Command Center'
    return ' '.join(part.capitalize() for part in re.split(r'[-_]+',name) if part)
def classify_route(route):
    s=route.lower()
    if 'move37' in s or 'move-37' in s: return 'Move-37'
    if 'rsi' in s or 'loop' in s or 'bottleneck' in s: return 'RSI / Loop'
    if 'playbook' in s or 'agent' in s or 'foundry' in s: return 'AGI Agents'
    if 'node' in s: return 'AGI Node'
    if 'valid' in s or 'review' in s or 'council' in s: return 'Validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return '48 Contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s or 'ledger' in s: return 'Proof / Evidence'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'Trust / Boundary'
    if 'search' in s or 'map' in s or 'pages' in s or 'registry' in s or 'health' in s or '404' in s: return 'Navigation / Health'
    if 'holy' in s or 'grail' in s or 'machine' in s: return 'Proof Work Machine'
    if 'index' in s or 'command' in s or 'phase' in s: return 'Command Center'
    return 'Additional'
def kind_from_route(route):
    s=route.lower()
    if 'move37' in s or 'move-37' in s: return 'move37'
    if 'rsi' in s: return 'rsi'
    if 'loop' in s or 'bottleneck' in s: return 'loop'
    if 'playbook' in s: return 'playbooks'
    if 'agent' in s or 'foundry' in s: return 'agents'
    if 'node' in s: return 'node'
    if 'valid' in s or 'review' in s or 'council' in s: return 'validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return 'contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s or 'ledger' in s: return 'proof'
    if 'ask' in s: return 'ask'
    if 'search' in s: return 'search'
    if 'map' in s or 'pages' in s or 'registry' in s or '404' in s: return 'navigation'
    if 'health' in s: return 'health'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'boundary'
    if 'holy' in s or 'grail' in s: return 'holy-grail'
    return 'work-machine'
def list_routes(public):
    routes=[]
    for p in sorted(public.rglob('*.html')):
        rel=p.relative_to(public).as_posix(); cat='Preserved Archive' if rel.startswith('archive/') else classify_route(rel)
        routes.append({'route':rel,'title':title_from_route(rel),'category':cat,'kind':kind_from_route(rel),'description':'Open '+title_from_route(rel)+' as part of the complete GoalOS public proof surface.'})
    return routes

def nav_html():
    return ''.join('<button class="v58-pill" data-v58-run>{}</button>'.format(esc(label)) if href=='#run' else '<a class="v58-pill" href="{}">{}</a>'.format(esc(href),esc(label)) for label,href in NAV)
def node_ring():
    labels=['ARC','PLN','RES','BLD','VRF','VAL','NODE','SNT','DCK','CHR']; out=['<div class="v58-node-ring"><div class="v58-orb">α</div>']
    for i,l in enumerate(labels):
        ang=2*math.pi*i/len(labels)-math.pi/2; x=50+37*math.cos(ang); y=50+37*math.sin(ang)
        out.append('<span class="v58-node" style="left:calc({:.3f}% - 27px);top:calc({:.3f}% - 27px)">{}</span>'.format(x,y,l))
    out.append('</div>'); return ''.join(out)
def canonical_html(page,routes_json,list_page=False):
    cards=''.join('<article class="v58-card"><span class="num">{}</span><h3>{}</h3><p>{}</p></article>'.format(esc(n),esc(t),esc(b)) for n,t,b in page.get('cards',[]))
    flow=''.join('<span class="v58-step">{}</span>'.format(esc(x)) for x in ['Mission','Work','Proof','Validation','Verified Experience','Chronicle','Reusable Capability','Settlement Simulation','Treasury Reinvestment','Harder Mission'])
    list_block=''
    if list_page: list_block='<section class="v58-section"><span class="v58-eyebrow">Route Inventory</span><h2>Complete public surface.</h2><input class="v58-searchbox" data-v58-page-filter placeholder="Filter GoalOS pages..." aria-label="Filter GoalOS pages"><div class="v58-page-list" data-v58-page-list></div></section>'
    objective=page.get('objective','I want GoalOS to turn my objective into proof-gated autonomous work with AGI Agents and AGI Node validation.')
    inline='<section class="v58-live-machine" data-v58-inline-machine><div class="v58-live-head"><div><span class="v58-eyebrow">Live Browser-Local Mission</span><h2>Run the proof path.</h2></div><button class="v58-btn primary" data-v58-inline-run data-v58-run>Run end-to-end demo</button></div><div class="v58-live-grid"><textarea>'+esc(objective)+'</textarea><pre class="v58-live-output" data-v58-inline-output>Ready. Click Run end-to-end demo.</pre></div></section>'
    return '<!doctype html><html lang="en" data-goalos-page="{kind}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{pagetitle} · GoalOS AGIALPHA Ascension</title><meta name="description" content="{desc}"><meta name="goalos:proof-work-machine" content="v58"><link rel="stylesheet" href="assets/{css}"><script src="assets/{routes}" defer></script><script src="assets/{js}" defer></script><script type="application/json" data-goalos-v58-routes>{routes_json}</script></head><body class="goalos-v58" data-goalos-v58-kind="{kind}"><nav class="v58-nav v58-wrap"><a class="v58-brand" href="index.html"><span class="v58-mark">α</span><span><strong>GOALOS</strong><small>AGIALPHA ASCENSION</small></span></a><div class="v58-navlinks">{nav}</div></nav><main class="v58-wrap"><section class="v58-hero"><div><span class="v58-eyebrow">{eyebrow}</span><h1 class="v58-title">{title} <em>{accent}</em></h1><p class="v58-lead">{lead}</p><p class="v58-sub">GoalOS is a proof-gated open-ended work machine. AGI Agents orchestrate bounded work. AGI Nodes can validate it. Evidence Dockets decide what can be trusted, reused, settled, and improved.</p><div class="v58-actions"><button class="v58-btn primary" data-v58-run>Run end-to-end demo</button><button class="v58-btn dark" data-v58-run>Tell GoalOS what you want</button><a class="v58-btn dark" href="all-pages.html">Explore all pages</a></div><div class="v58-composer"><label>What should GoalOS accomplish?<span>browser-local</span></label><textarea class="v58-objective" data-goalos-objective>{objective}</textarea></div></div><aside class="v58-console"><div class="v58-console-head"><b>Sovereign Work Console</b><span class="v58-status">READY</span></div>{ring}<div class="v58-mini-grid"><div class="v58-mini"><strong>Mission</strong>Bound the objective.</div><div class="v58-mini"><strong>Agents</strong>Orchestrate the work.</div><div class="v58-mini"><strong>Nodes</strong>Validate when authorized.</div><div class="v58-mini"><strong>Proof</strong>Package evidence before trust.</div></div><div data-v58-terminal class="v58-terminal">route console loading...</div></aside></section>{inline}<section class="v58-section"><span class="v58-eyebrow">Proof-Gated Work Loop</span><h2>Mission → Work → Proof → Capability.</h2><div class="v58-flow">{flow}</div></section><section class="v58-section"><span class="v58-eyebrow">What this surface does</span><h2>Useful to non-technical users.</h2><div class="v58-grid">{cards}</div></section>{list_block}<section class="v58-boundary"><b>Public-alpha boundary.</b> No user data. No user funds. No wallet. No transaction. No backend call. No production authority. No achieved AGI/ASI/SOTA claim. $AGIALPHA is public-contract / protocol context only; no sale, custody, wallet support, investment, trading, legal, tax, exchange, bridge, liquidity, or regulatory advice.</section></main></body></html>'.format(kind=esc(page.get('kind','work-machine')),pagetitle=esc(title_from_route(page['route'])),desc=esc(page.get('lead','')),css=ASSET_CSS,routes=ROUTE_JS,js=ASSET_JS,routes_json=routes_json,nav=nav_html(),eyebrow=esc(page.get('eyebrow','GoalOS')),title=esc(page.get('title','GoalOS')),accent=esc(page.get('accent','')),lead=esc(page.get('lead','')),objective=esc(objective),ring=node_ring(),inline=inline,flow=flow,cards=cards,list_block=list_block)

def copy_assets(dirs):
    shutil.copyfile(pack_root()/'assets'/ASSET_CSS, dirs['assets']/ASSET_CSS); shutil.copyfile(pack_root()/'assets'/ASSET_JS, dirs['assets']/ASSET_JS)
    (dirs['assets']/'goalos.css').write_text('/* compatibility alias */\n@import url("'+ASSET_CSS+'");\n',encoding='utf-8')
    (dirs['assets']/'goalos.js').write_text('/* compatibility alias */\n',encoding='utf-8')
    (dirs['assets']/'goalos-mark.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="18" fill="#62ffd6"/><text x="32" y="42" text-anchor="middle" font-family="Arial" font-weight="900" font-size="32" fill="#071124">α</text></svg>',encoding='utf-8')
    for name in ['site-status.json','search_index.json','search-index.json']:(dirs['public']/name).write_text(json.dumps({'version':VERSION,'status':'discoverable','boundary':BOUNDARY},indent=2),encoding='utf-8')
def recover_snapshot(root,public):
    for snap in [root/'.goalos'/'site-immersive-command-center-v16'/'public-snapshot', root/'.goalos'/'public-snapshot']:
        if snap.exists():
            for src in snap.rglob('*.html'):
                dst=public/src.relative_to(snap)
                if not dst.exists(): dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
def sanitize_file(path):
    if path.suffix.lower() not in {'.html','.js'}: return
    text=path.read_text(encoding='utf-8',errors='ignore'); original=text
    for old,new in REPLACEMENTS.items(): text=text.replace(old,new)
    if text!=original: path.write_text(text,encoding='utf-8')
def strip_old_assets(text):
    text=re.sub(r'\s*<script[^>]+assets/goalos-[^"\']*v\d+[^"\']*\.js[^>]*>\s*</script>','',text,flags=re.I)
    text=re.sub(r'\s*<link[^>]+assets/goalos-[^"\']*v\d+[^"\']*\.css[^>]*>','',text,flags=re.I)
    text=re.sub(r'\s*<script[^>]+goalos-v\d+-routes\.js[^>]*>\s*</script>','',text,flags=re.I)
    return text
def patch_html(public):
    for path in public.rglob('*.html'):
        text=strip_old_assets(path.read_text(encoding='utf-8',errors='ignore'))
        rel=os.path.relpath(public/'assets',path.parent).replace(os.sep,'/')
        if rel=='.': rel='assets'
        insert='<link rel="stylesheet" href="{}/{}">\n<script src="{}/{}" defer></script>\n<script src="{}/{}" defer></script>\n'.format(rel,ASSET_CSS,rel,ROUTE_JS,rel,ASSET_JS)
        if ASSET_JS not in text:
            text=re.sub(r'</head>',insert+'</head>',text,count=1,flags=re.I) if re.search(r'</head>',text,re.I) else insert+text
        kind=kind_from_route(path.relative_to(public).as_posix())
        if re.search(r'<body\b',text,re.I):
            def repl(m):
                tag=m.group(0)
                if 'goalos-v58-enhanced' not in tag:
                    if 'class=' in tag: tag=re.sub(r'class=["\']([^"\']*)["\']',lambda cm:'class="'+cm.group(1)+' goalos-v58-enhanced"',tag,count=1)
                    else: tag=tag[:-1]+' class="goalos-v58-enhanced">'
                if 'data-goalos-v58-kind' not in tag: tag=tag[:-1]+' data-goalos-v58-kind="'+kind+'">'
                return tag
            text=re.sub(r'<body\b[^>]*>',repl,text,count=1,flags=re.I)
        path.write_text(text,encoding='utf-8')
def write_routes(dirs):
    routes=list_routes(dirs['public']); data=json.dumps(routes,ensure_ascii=False,indent=2)
    (dirs['assets']/ROUTE_JSON).write_text(data,encoding='utf-8'); (dirs['assets']/ROUTE_JS).write_text('window.GOALOS_V58_ROUTES = '+data+';\n',encoding='utf-8')
    (dirs['content']/'public-proof-navigation-v58.json').write_text(data,encoding='utf-8')
    return routes
def write_canonical(dirs,manifest):
    public=dirs['public']
    for p in manifest['pages']:
        t=public/p['route']; t.parent.mkdir(parents=True,exist_ok=True)
        if not t.exists(): t.write_text('',encoding='utf-8')
    routes=write_routes(dirs); inline=json.dumps(routes,ensure_ascii=False); list_pages={'all-pages.html','site-map.html','search.html','route-registry.html'}
    for p in manifest['pages']:(public/p['route']).write_text(canonical_html(p,inline,p['route'] in list_pages),encoding='utf-8')
    return routes
def is_internal(ref):
    return bool(ref) and not ref.startswith('#') and not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',ref)
def placeholder(path):
    path.parent.mkdir(parents=True,exist_ok=True); suf=path.suffix.lower()
    if suf=='.html': path.write_text('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>GoalOS Route</title><style>body{margin:0;min-height:100vh;background:#071124;color:#f7f2e8;font-family:Inter,Arial,sans-serif;display:grid;place-items:center}main{max-width:860px;padding:40px;border:1px solid rgba(98,255,214,.35);border-radius:28px;background:linear-gradient(135deg,rgba(12,22,45,.95),rgba(20,68,76,.86));box-shadow:0 30px 80px rgba(0,0,0,.3)}h1{font-size:clamp(42px,8vw,88px);line-height:.9;margin:0 0 18px}p{font-size:18px;color:#cbd7ec}a{color:#62ffd6}</style></head><body><main><h1>GoalOS route.</h1><p>This preserved route remains part of the public proof surface. Use the Command Center, All Pages, or Search from the main navigation.</p></main></body></html>',encoding='utf-8')
    elif suf=='.json': path.write_text(json.dumps({'version':VERSION,'status':'compatibility_asset','boundary':BOUNDARY},indent=2),encoding='utf-8')
    elif suf=='.js': path.write_text('/* compatibility asset */\n',encoding='utf-8')
    elif suf=='.css': path.write_text('/* compatibility asset */\n',encoding='utf-8')
    elif suf=='.svg': path.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="18" fill="#62ffd6"/><text x="32" y="42" text-anchor="middle" font-family="Arial" font-weight="900" font-size="32" fill="#071124">α</text></svg>',encoding='utf-8')
    else: path.write_bytes(b'')
def repair_links(public):
    created=[]; exts={'.html','.css','.js','.json','.svg','.png','.jpg','.jpeg','.webp','.ico'}
    for path in list(public.rglob('*.html')):
        text=path.read_text(encoding='utf-8',errors='ignore')
        for ref in re.findall(r'(?:href|src)=["\']([^"\']+)["\']',text,re.I):
            if not is_internal(ref): continue
            clean=unquote(ref.split('#')[0].split('?')[0]);
            if not clean: continue
            if clean.endswith('/'): clean+='index.html'
            target=(path.parent/clean).resolve()
            try: target.relative_to(public.resolve())
            except Exception: continue
            if target.suffix.lower() in exts and not target.exists(): placeholder(target); created.append({'file':path.relative_to(public).as_posix(),'target':clean})
    return created
def audit(public):
    forbidden=[]; broken=[]
    for p in public.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.html','.js'}:
            txt=p.read_text(encoding='utf-8',errors='ignore')
            for pat in FORBIDDEN:
                if re.search(pat,txt): forbidden.append({'file':p.relative_to(public).as_posix(),'pattern':pat})
    for path in public.rglob('*.html'):
        text=path.read_text(encoding='utf-8',errors='ignore')
        for ref in re.findall(r'(?:href|src)=["\']([^"\']+)["\']',text,re.I):
            if not is_internal(ref): continue
            clean=unquote(ref.split('#')[0].split('?')[0]);
            if not clean: continue
            if clean.endswith('/'): clean+='index.html'
            target=(path.parent/clean).resolve()
            try: target.relative_to(public.resolve())
            except Exception: continue
            if target.suffix.lower() and not target.exists(): broken.append({'file':path.relative_to(public).as_posix(),'target':clean})
    return forbidden,broken
def main():
    root=Path.cwd(); dirs=ensure_dirs(root); manifest=load_manifest(); copy_assets(dirs); recover_snapshot(root,dirs['public'])
    for p in dirs['public'].rglob('*'):
        if p.is_file(): sanitize_file(p)
    write_canonical(dirs,manifest); patch_html(dirs['public']); created=repair_links(dirs['public'])
    for p in dirs['public'].rglob('*'):
        if p.is_file(): sanitize_file(p)
    routes=write_routes(dirs); forbidden,broken=audit(dirs['public'])
    report={'version':VERSION,'status':'passed' if not forbidden and not broken else 'failed','publicPages':len(routes),'currentRoutesIndexed':len([r for r in routes if not r['route'].startswith('archive/')]),'createdCompatibilityLinks':created[:100],'forbiddenBrowserApiHits':forbidden,'brokenInternalLinksOrAssets':broken,'pageSpecificAutonomousDemos':True,'canonicalSurfaces':[p['route'] for p in manifest['pages']],'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}
    for name in ['proof-work-machine-v58-install-report.json','proof-work-machine-v58-qa.json','proof-work-machine-v58-route-health.json','proof-work-machine-v58-audit.json']:(dirs['reports']/name).write_text(json.dumps(report,indent=2),encoding='utf-8')
    demo={'version':VERSION,'mission':'Proof-gated open-ended work machine','loop':['Mission','Work','Proof','Validation','Verified Experience','Chronicle','Reusable Capability','Settlement Simulation','Reinvestment','Harder Mission'],'boundary':BOUNDARY}
    (dirs['reports']/'proof-work-machine-v58-demo-run.json').write_text(json.dumps(demo,indent=2),encoding='utf-8')
    (dirs['evidence']/'proof-work-machine-v58-reference-docket.json').write_text(json.dumps({'version':VERSION,'status':'public_alpha_reference_docket','claimBoundary':BOUNDARY,'requiresExternalReplay':True},indent=2),encoding='utf-8')
    (dirs['docs']/'GOALOS_PROOF_WORK_MACHINE_V58.md').write_text('# GoalOS Sovereign Proof Work Machine V58\n\nGoalOS is a proof-gated open-ended work machine.\n',encoding='utf-8')
    (dirs['content']/'goalos-v58-canonical-surface.json').write_text(json.dumps({'version':VERSION,'routes':routes,'canonicalSurfaces':report['canonicalSurfaces'],'boundary':BOUNDARY},indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if report['status']!='passed': raise SystemExit(1)
if __name__=='__main__': main()
