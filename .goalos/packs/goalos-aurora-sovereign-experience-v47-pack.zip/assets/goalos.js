console.log("GoalOS route asset ready");
