(function(){window.GoalOSBoundary=Object.freeze({version:'v47',externalActions:0,wallet:'disabled',transaction:'disabled',data:'not collected'});})();
