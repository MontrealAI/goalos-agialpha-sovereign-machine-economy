
from pathlib import Path
import json, re, html, shutil, time
ROOT = Path.cwd()
PUBLIC = ROOT / 'public'
ASSETS = PUBLIC / 'assets'
PACK_ROOT = Path(__file__).resolve().parents[1]
SRC_PUBLIC = PACK_ROOT / 'public'
REPORTS = ROOT / 'reports'
CONTENT = ROOT / 'content' / 'goalos'
EVIDENCE = ROOT / 'evidence' / 'demo'
for d in [PUBLIC, ASSETS, REPORTS, CONTENT, EVIDENCE]: d.mkdir(parents=True, exist_ok=True)

def copytree_merge(src, dst):
    for item in src.rglob('*'):
        rel = item.relative_to(src); target = dst / rel
        if item.is_dir(): target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            # Always refresh V42 primary pages/assets; do not delete anything else.
            if rel.as_posix().startswith('assets/') or rel.name in {'index.html','goalos-command-center.html','site-map.html','all-pages.html','route-registry.html','search.html','site-health.html','start-here.html','pathfinder.html','demo-ecosystem-registry.html','docs.html','trust-boundary.html','token-boundary.html','privacy.html','data-boundary.html','no-data-no-funds.html'}:
                shutil.copy2(item, target)
            elif not target.exists():
                shutil.copy2(item, target)
copytree_merge(SRC_PUBLIC, PUBLIC)
(PUBLIC/'.nojekyll').write_text('')
registry_js=(ASSETS/'goalos-route-registry-v42.js').read_text(encoding='utf-8')
registry_json=registry_js.split('=',1)[1].rsplit(';',1)[0]
routes=json.loads(registry_json)
route_by_slug={r['slug']:r for r in routes}

def title_of(path):
    txt=path.read_text(encoding='utf-8', errors='ignore')[:4000]
    m=re.search(r'<title>(.*?)</title>', txt, re.I|re.S)
    if m: return re.sub(r'\s+',' ',re.sub('<.*?>','',m.group(1))).replace('— GoalOS','').strip()
    m=re.search(r'<h1[^>]*>(.*?)</h1>', txt, re.I|re.S)
    if m: return re.sub(r'\s+',' ',re.sub('<.*?>','',m.group(1))).strip()
    return path.stem.replace('-',' ').title()

def ensure_injection(path):
    text=path.read_text(encoding='utf-8', errors='ignore')
    changed=False
    if 'goalos-site-recovery-v42.css' not in text:
        text=text.replace('</head>','<link rel="stylesheet" href="assets/goalos-site-recovery-v42.css"><script src="assets/goalos-route-registry-v42.js" defer></script><script src="assets/goalos-site-recovery-v42.js" defer></script></head>') if '</head>' in text else text
        changed=True
    if 'Ask GoalOS' not in text or 'js-ask' not in text:
        flo='<div class="float"><button class="js-ask">Ask GoalOS</button><a href="site-map.html">All Pages</a></div><aside id="ask-panel" class="ask panel"><div class="ask-head"><b>Ask GoalOS</b><button class="js-close-ask">×</button></div><div id="ask-body" class="ask-body"><div class="msg bot">Ask where to go. Example: “Open the 48 contracts” or “Can the AGI Node validate this?”</div></div><div style="padding:12px;display:flex;gap:8px"><input id="ask-input" placeholder="Ask GoalOS…"><button class="btn primary js-send-ask">Send</button></div></aside>'
        text=text.replace('</body>', flo+'</body>') if '</body>' in text else text+flo
        changed=True
    if changed: path.write_text(text, encoding='utf-8')

for p in PUBLIC.glob('*.html'):
    ensure_injection(p)

# Merge all existing html into search index.
entries=[]
for p in sorted(PUBLIC.glob('*.html')):
    slug=p.name
    r=route_by_slug.get(slug, {})
    entries.append({
        'slug': slug,
        'url': slug,
        'title': r.get('title') or title_of(p),
        'category': r.get('category','Existing / Preserved'),
        'description': r.get('desc','Preserved public GoalOS page, kept navigable by V42 route recovery.')
    })
(PUBLIC/'search-index.json').write_text(json.dumps(entries, indent=2), encoding='utf-8')
# sitemap
base='https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/'
xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join(f'  <url><loc>{base}{e["slug"]}</loc></url>\n' for e in entries) + '</urlset>\n'
(PUBLIC/'sitemap.xml').write_text(xml, encoding='utf-8')
# reports
missing=[]
for r in routes:
    if not (PUBLIC/r['slug']).exists(): missing.append(r['slug'])
# internal link audit simple
broken=[]
for p in PUBLIC.glob('*.html'):
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for href in re.findall(r'href=["\']([^"\']+)["\']', txt):
        if href.startswith(('http://','https://','#','mailto:','javascript:')): continue
        clean=href.split('#',1)[0].split('?',1)[0]
        if clean and clean.endswith('.html') and not (PUBLIC/clean).exists():
            broken.append({'page':p.name,'href':href})
forbidden=[]
for p in ASSETS.glob('*.js'):
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for pat in ['fetch(','XMLHttpRequest','sendBeacon','localStorage','sessionStorage','window.ethereum']:
        if pat in txt: forbidden.append({'file':str(p.relative_to(ROOT)),'pattern':pat})
report={'version':'v42','status':'passed' if not missing and not broken and not forbidden else 'needs_review','canonicalRoutes':len(routes),'publicPages':len(entries),'missingCanonicalRoutes':missing,'brokenInternalHtmlLinks':broken,'forbiddenBrowserApiHits':forbidden,'boundary':'preserved','externalActions':0}
for name in ['site-recovery-v42-install-report.json','site-recovery-v42-qa.json','site-recovery-v42-route-health.json','site-recovery-v42-audit.json']:
    (REPORTS/name).write_text(json.dumps(report,indent=2),encoding='utf-8')
(CONTENT/'public-proof-navigation-v42.json').write_text(json.dumps({'version':'v42','routes':entries},indent=2),encoding='utf-8')
(CONTENT/'demo-ecosystem-registry-v42.json').write_text(json.dumps({'version':'v42','demos':[e for e in entries if any(w in e['slug'] for w in ['demo','theatre','workbench','validation','contract','proof'])]},indent=2),encoding='utf-8')
(EVIDENCE/'site-recovery-v42-reference-docket.json').write_text(json.dumps({'version':'v42','claim':'Website route surface restored and all pages kept navigable','status':report['status'],'reports':['reports/site-recovery-v42-route-health.json']},indent=2),encoding='utf-8')
print(json.dumps(report, indent=2))
