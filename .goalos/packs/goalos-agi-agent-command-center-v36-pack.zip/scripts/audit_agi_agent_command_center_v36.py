#!/usr/bin/env python3
import re, json
from pathlib import Path
ROOT=Path.cwd(); PUBLIC=ROOT/'public'
forbidden=['fetch(', 'XMLHttpRequest', 'sendBeacon', 'localStorage', 'sessionStorage', 'window.ethereum']
hits=[]
for p in (PUBLIC/'assets').glob('goalos-agi-agent-*v36*.js'):
    txt=p.read_text(encoding='utf-8', errors='ignore')
    for f in forbidden:
        if f in txt: hits.append({'file':str(p),'hit':f})
broken=[]
for h in PUBLIC.glob('*.html'):
    txt=h.read_text(encoding='utf-8', errors='ignore')
    for href in re.findall(r'href=["\']([^"\']+\.html)(?:#[^"\']*)?["\']', txt):
        if href.startswith('http') or href.startswith('mailto:'): continue
        target=(h.parent/href.split('#')[0]).resolve()
        try: target.relative_to(PUBLIC.resolve())
        except Exception: continue
        if not target.exists(): broken.append({'from':h.name,'href':href})
report={'version':'v36','status':'passed' if not hits and not broken else 'failed','forbiddenBrowserApiHits':hits,'brokenInternalHtmlLinks':broken,'publicPages':len(list(PUBLIC.glob('*.html')))}
Path('reports').mkdir(exist_ok=True)
Path('reports/agi-agent-command-center-v36-audit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
