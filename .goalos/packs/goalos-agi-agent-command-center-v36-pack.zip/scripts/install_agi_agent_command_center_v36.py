#!/usr/bin/env python3
from pathlib import Path
import json, shutil, re, datetime
ROOT = Path.cwd()
PACK = Path(__file__).resolve().parents[1]
VERSION = "v36"
PRIMARY = "agi-agent-command-center.html"
ASSET_CSS = "assets/goalos-agi-agent-command-center-v36.css"
ASSET_DATA = "assets/goalos-agi-agent-routes-v36.js"
ASSET_JS = "assets/goalos-agi-agent-command-center-v36.js"
PUBLIC = ROOT / "public"
PUBLIC.mkdir(exist_ok=True)

def copy_tree(src, dst, overwrite=True):
    src=Path(src); dst=Path(dst)
    if src.is_dir():
        for p in src.rglob('*'):
            if p.is_file():
                rel=p.relative_to(src); target=dst/rel; target.parent.mkdir(parents=True, exist_ok=True)
                if overwrite or not target.exists(): shutil.copy2(p,target)
    elif src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        if overwrite or not dst.exists(): shutil.copy2(src,dst)

# Copy generated files. Public v36 pages overwrite only their own versioned surfaces; existing non-version pages are protected unless listed as safe aliases.
copy_tree(PACK/'public/assets', PUBLIC/'assets', True)
for page in ['agi-agent-command-center.html','agi-agent-use-cases.html','meta-agentic-alpha-agi.html']:
    copy_tree(PACK/'public'/page, PUBLIC/page, True)
for alias in ['agi-agents.html','agent-foundry.html','agent-constellation.html','meta-agentic-agents.html','agi-agent-studio.html','meta-agentic-agent-os.html']:
    copy_tree(PACK/'public'/alias, PUBLIC/alias, False)
for d in ['docs','examples','reports','evidence','content','issue-bodies','.github']:
    copy_tree(PACK/d, ROOT/d, True)

# Ensure fallback routes referenced by the command center exist, without overwriting richer existing pages.
def fallback_page(filename, title, summary, target='agi-agent-command-center.html'):
    p=PUBLIC/filename
    if p.exists(): return
    p.write_text(f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><link rel="stylesheet" href="assets/goalos-agi-agent-command-center-v36.css"></head><body class="goalos-v36"><main class="wrap"><section class="hero"><div><div class="eyebrow">Route preserved</div><h1 class="h1">{title}</h1><p class="lead">{summary}</p><div class="actions"><a class="btn main" href="{target}">Open AGI Agent Command Center</a><a class="btn" href="site-map.html">All Pages</a></div></div><aside class="console"><div class="console-top"><span>GoalOS Route</span><span class="pill">preserved</span></div><div id="agentNodes" class="orb"></div><div class="terminal">This fallback keeps the route navigable until a richer page is installed.</div></aside></section></main><script src="assets/goalos-agi-agent-routes-v36.js"></script><script src="assets/goalos-agi-agent-command-center-v36.js"></script></body></html>""", encoding='utf-8')
for fn,title,summary in [
    ('ask-goalos.html','Ask GoalOS','Browser-local question window and route assistant.'),
    ('goalos.html','Tell GoalOS','One-box mission interface.'),
    ('validation-control-tower.html','Validation Control Tower','Human, AGI Node, Hybrid, or Council validation.'),
    ('site-map.html','All Pages','Complete public route inventory.'),
    ('search.html','Search','Browser-local search and command palette.'),
    ('mainnet-contract-atlas.html','Mainnet Contract Atlas','48 Ethereum Mainnet contracts proof rail.'),
    ('mainnet-proof-rail.html','Mainnet Proof Rail','Contract journey and proof rail.'),
    ('contract-academy.html','Contract Academy','Learn the 48 contracts.'),
    ('trust-boundary.html','Trust Boundary','No user data, no funds, no wallet, no transaction.'),
    ('token-boundary.html','Token Boundary','$AGIALPHA public contract identification only.'),
    ('proof-run-001-docket.html','Proof Run 001 Docket','Repository readiness evidence docket.'),
    ('demo-ecosystem-registry.html','Demo Registry','All demos and routes.'),
    ('from-loop-to-rsi-state-capacity.html','Loop to RSI State Capacity','Long-running loop to deterministic invention governance.')
]: fallback_page(fn,title,summary)

# Patch homepage with front-and-center callout, preserving previous index in place.
index = PUBLIC/'index.html'
callout = """<section id="goalos-v36-agent-front-door" class="v36-home-callout"><div class="eyebrow">New · AGI Agent Command Center</div><h2 style="font-size:clamp(2.2rem,5vw,5rem);letter-spacing:-.06em;line-height:.9;margin:.3em 0">Tell AGI agents what you want.</h2><p class="lead">One box creates a proof-governed agent mission: agent roles, AGI Node handoff, validation path, Evidence Docket plan, Reviewer Brief, Action Graph, and next best route.</p><p><a class="btn main" href="agi-agent-command-center.html">Open AGI Agent Command Center</a> <a class="btn" href="agi-agent-use-cases.html">Solved use cases</a> <a class="btn" href="ask-goalos.html">Ask GoalOS</a></p></section>"""
if index.exists():
    html=index.read_text(encoding='utf-8', errors='ignore')
    if 'goalos-v36-agent-front-door' not in html:
        html = re.sub(r'(<body[^>]*>)', r'\1\n'+callout, html, count=1, flags=re.I) if re.search(r'<body[^>]*>',html,re.I) else callout+html
        index.write_text(html, encoding='utf-8')
else:
    fallback_page('index.html','GoalOS AGIALPHA','Open the AGI Agent Command Center.', PRIMARY)

# Inject assets/floating assistant into all public HTML pages without removing content.
def inject(html):
    if ASSET_CSS not in html:
        html = html.replace('</head>', f'<link rel="stylesheet" href="{ASSET_CSS}">\n</head>') if '</head>' in html else f'<link rel="stylesheet" href="{ASSET_CSS}">\n'+html
    if ASSET_DATA not in html:
        scripts=f'<script src="{ASSET_DATA}"></script>\n<script src="{ASSET_JS}"></script>'
        html = html.replace('</body>', scripts+'\n</body>') if '</body>' in html else html+'\n'+scripts
    return html
for h in PUBLIC.glob('*.html'):
    txt=h.read_text(encoding='utf-8', errors='ignore')
    h.write_text(inject(txt), encoding='utf-8')

# Update search index and sitemap.
new_entries=[
    {"title":"AGI Agent Command Center V36","url":"agi-agent-command-center.html","description":"One-box meta-agentic AGI Agent mission surface with AGI Node handoff and proof path."},
    {"title":"AGI Agent Use Cases V36","url":"agi-agent-use-cases.html","description":"Solved end-to-end AGI Agent and AGI Node playbooks."},
    {"title":"Meta-Agentic Alpha AGI","url":"meta-agentic-alpha-agi.html","description":"Explains the AGI Agent cognition, AGI Jobs, AGI Alpha Node, and GoalOS proof stack."}
]
sidx=PUBLIC/'search-index.json'
try:
    data=json.loads(sidx.read_text(encoding='utf-8')) if sidx.exists() else []
except Exception: data=[]
if isinstance(data,dict):
    arr=data.get('pages') or data.get('items') or []
else: arr=data
seen={x.get('url') for x in arr if isinstance(x,dict)}
for e in new_entries:
    if e['url'] not in seen: arr.append(e)
if isinstance(data,dict): data['pages']=arr
else: data=arr
sidx.write_text(json.dumps(data, indent=2), encoding='utf-8')

smap=PUBLIC/'sitemap.xml'
urls=sorted({p.name for p in PUBLIC.glob('*.html')})
xml="""<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n"""+''.join([f'  <url><loc>https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/{u}</loc></url>\n' for u in urls])+'</urlset>\n'
smap.write_text(xml, encoding='utf-8')
(PUBLIC/'.nojekyll').write_text('', encoding='utf-8')

# README patch.
readme=ROOT/'README.md'
block="""\n\n## GoalOS AGI Agent Command Center V36\n\nA browser-local, public-safe AGI Agent operating surface has been added at `public/agi-agent-command-center.html`. Users type an objective and GoalOS prepares an agent constellation, Mission Contract, AGI Node handoff, Evidence Docket plan, Reviewer Brief, Action Graph, and next best route. No user data, funds, wallet, transaction, network call, or production authority is used.\n"""
if readme.exists():
    txt=readme.read_text(encoding='utf-8', errors='ignore')
    if 'GoalOS AGI Agent Command Center V36' not in txt: readme.write_text(txt+block, encoding='utf-8')
else: readme.write_text('# GoalOS AGIALPHA Ascension\n'+block, encoding='utf-8')

report={"version":"v36","status":"passed","installedAt":datetime.datetime.utcnow().isoformat()+'Z',"primaryPage":"public/agi-agent-command-center.html","publicPages":len(list(PUBLIC.glob('*.html'))),"boundary":"preserved"}
(ROOT/'reports').mkdir(exist_ok=True)
(ROOT/'reports/agi-agent-command-center-v36-install-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
