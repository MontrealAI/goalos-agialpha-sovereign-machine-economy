# GoalOS Public Alpha UX Remediation V44 Runbook

Purpose: correct the public-alpha website after external feedback that the visual flow graph was not aligned, that text could be hidden by overlapping divs, and that human visual QA was not explicit.

## What V44 changes

- Adds `public/assets/goalos-public-alpha-ux-remediation-v44.css` as a global layout-hardening override.
- Adds `public/assets/goalos-public-alpha-ux-remediation-v44.js` for browser-local UX activation.
- Adds `public/ux-proof-check.html` for human visual QA signoff.
- Adds `public/visual-flow-proof.html` as the corrected proof-flow example.
- Patches existing public HTML pages to include the V44 CSS/JS.
- Rebuilds `public/assets/goalos-route-registry-v44.js` from the actual public HTML files.
- Runs audits for route integrity, forbidden browser APIs, and V44 layout signals.

## GitHub Web UI install

1. Create `.github/workflows/goalos-public-alpha-ux-remediation-v44-autopilot.yml`.
2. Upload `goalos-public-alpha-ux-remediation-v44-pack.zip` to `.goalos/packs/goalos-public-alpha-ux-remediation-v44-pack.zip`.
3. Commit: `Add GoalOS Public Alpha UX Remediation V44`.
4. Run workflow: `GoalOS Public Alpha UX Remediation V44 — Human-Readable Site Fix`.

Recommended inputs:

```text
commit_changes: true
deploy_pages: true
create_issue: true
create_release: false
release_tag: v0.64.0-public-alpha-ux-remediation-v44
```

## Manual human QA

Open these pages after deployment:

- `ux-proof-check.html`
- `visual-flow-proof.html`
- `index.html`
- `goalos-gold-master.html`
- `autonomy-theatre.html`
- `agi-agent-workbench.html`
- `validation-control-tower.html`
- `mainnet-contract-atlas.html`
- `site-map.html`
- `search.html`
- `site-health.html`

Confirm:

- no overlapping text;
- the visual flow is aligned;
- nav works;
- text is readable;
- boundary remains visible;
- no wallet prompt;
- no transaction;
- no backend call;
- no user-data form.
