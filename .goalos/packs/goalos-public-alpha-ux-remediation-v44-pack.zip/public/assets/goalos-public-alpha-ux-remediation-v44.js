
(function(){
  'use strict';
  const ready = () => {
    document.documentElement.setAttribute('data-goalos-ux-v44','active');
    document.body.classList.add('ux-v44');
    const main = document.querySelector('main');
    if(main && !document.querySelector('.ux-v44-banner')){
      const banner = document.createElement('section');
      banner.className = 'ux-v44-banner';
      banner.innerHTML = '<strong>V44 visual QA hardening is active.</strong><span>Layout is grid-based, text-first, browser-local, and no-overlap. Human visual review is still required before production claims.</span>';
      main.prepend(banner);
    }
    const flow = document.querySelector('.flowline');
    if(flow){
      flow.setAttribute('aria-label','GoalOS end-to-end proof path: objective, agents, AGI Job, AGI Node, ProofBundle, Evidence Docket, validation, Chronicle, reusable capability.');
    }
    const askButton = document.querySelector('.js-open-ask');
    if(askButton) askButton.setAttribute('aria-label','Open Ask GoalOS route assistant');
  };
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
})();
