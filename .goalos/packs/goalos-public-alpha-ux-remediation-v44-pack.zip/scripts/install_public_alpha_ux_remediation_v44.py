
from pathlib import Path
import json, re, shutil, html, time
ROOT = Path.cwd()
SRC = Path(__file__).resolve().parents[1]
PUBLIC = ROOT/'public'
ASSETS = PUBLIC/'assets'
ASSETS.mkdir(parents=True, exist_ok=True)
for rel in ['public/assets/goalos-public-alpha-ux-remediation-v44.css','public/assets/goalos-public-alpha-ux-remediation-v44.js','public/ux-proof-check.html','public/visual-flow-proof.html','content/goalos/public-alpha-ux-remediation-v44.json']:
    src = SRC/rel
    dst = ROOT/rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
(PUBLIC/'.nojekyll').write_text('', encoding='utf-8')
css_link = '<link rel="stylesheet" href="assets/goalos-public-alpha-ux-remediation-v44.css">'
js_link = '<script src="assets/goalos-public-alpha-ux-remediation-v44.js" defer></script>'
patched = []
for p in sorted(PUBLIC.glob('*.html')):
    text = p.read_text(encoding='utf-8', errors='ignore')
    orig = text
    if 'goalos-public-alpha-ux-remediation-v44.css' not in text:
        text = text.replace('</head>', css_link + js_link + '</head>') if '</head>' in text else css_link + js_link + text
    if '<body' in text and 'ux-v44' not in text.split('<body',1)[1].split('>',1)[0]:
        text = re.sub(r'<body([^>]*)>', lambda m: '<body' + m.group(1).rstrip() + (' class="ux-v44"' if 'class=' not in m.group(1) else '').replace(' class="ux-v44"','') + '>', text, count=1)
        # safer class injection preserving existing class attr
        text = re.sub(r'<body([^>]*?)class="([^"]*)"', lambda m: '<body' + m.group(1) + 'class="' + (m.group(2)+' ux-v44').strip() + '"', text, count=1)
        if '<body' in text and 'class=' not in text.split('<body',1)[1].split('>',1)[0]:
            text = re.sub(r'<body([^>]*)>', r'<body\1 class="ux-v44">', text, count=1)
    if 'assets/goalos-route-registry-v43.js' in text and 'assets/goalos-route-registry-v44.js' not in text:
        text = text.replace('assets/goalos-route-registry-v43.js', 'assets/goalos-route-registry-v44.js')
    if p.name in {'index.html','goalos-gold-master.html','goalos-command-center.html'} and 'ux-proof-check.html' not in text:
        insert = '<div class="ux-v44-banner"><strong>V44 correction:</strong><span>Visual flow, text overlap, and human visual QA hardening are active. <a href="ux-proof-check.html">Open UX proof check</a>.</span></div>'
        text = text.replace('<main>', '<main>'+insert, 1) if '<main>' in text else insert + text
    if text != orig:
        p.write_text(text, encoding='utf-8')
        patched.append(str(p.relative_to(ROOT)))
# build route registry
routes=[]
for p in sorted(PUBLIC.glob('*.html')):
    t = p.read_text(encoding='utf-8', errors='ignore')
    title = re.search(r'<title>(.*?)</title>', t, re.I|re.S)
    h1 = re.search(r'<h1[^>]*>(.*?)</h1>', t, re.I|re.S)
    def clean(x): return re.sub(r'\s+', ' ', re.sub('<.*?>',' ', x or '')).strip()
    name = clean(title.group(1) if title else h1.group(1) if h1 else p.stem.replace('-',' ').title())
    body = clean(re.sub(r'<script.*?</script>|<style.*?</style>', ' ', t, flags=re.I|re.S))[:240]
    cat = 'Navigation & QA' if p.name in {'site-map.html','all-pages.html','route-registry.html','search.html','site-health.html','ux-proof-check.html','visual-flow-proof.html'} else 'GoalOS Surface'
    routes.append({'title':name, 'href':p.name, 'category':cat, 'description':body})
registry_js = 'window.GOALOS_ROUTES_V44 = ' + json.dumps(routes, indent=2) + ';\nwindow.GOALOS_ROUTES = window.GOALOS_ROUTES_V44;\n'
(ASSETS/'goalos-route-registry-v44.js').write_text(registry_js, encoding='utf-8')
# simple search fallback if missing or too thin
if not (PUBLIC/'search.html').exists() or (PUBLIC/'search.html').stat().st_size < 1200:
    (PUBLIC/'search.html').write_text('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GoalOS Search V44</title><link rel="stylesheet" href="assets/goalos-gold-master-v43.css"><link rel="stylesheet" href="assets/goalos-public-alpha-ux-remediation-v44.css"><script src="assets/goalos-route-registry-v44.js" defer></script><script src="assets/goalos-public-alpha-ux-remediation-v44.js" defer></script></head><body class="gold-master ux-v44"><main><section class="hero"><p class="eyebrow">SEARCH</p><h1>Find every GoalOS route.</h1><input id="q" placeholder="Search GoalOS routes..."><div id="results" class="route-cards"></div></section></main><script>addEventListener("DOMContentLoaded",()=>{const q=document.getElementById("q"),r=document.getElementById("results"),routes=window.GOALOS_ROUTES||[];function draw(){const s=(q.value||"").toLowerCase();r.innerHTML=routes.filter(x=>(x.title+x.description+x.category).toLowerCase().includes(s)).slice(0,80).map(x=>`<a class="route-card" href="${x.href}"><strong>${x.title}</strong><span>Open →</span></a>`).join("")||"<p>No route found.</p>"}q.addEventListener("input",draw);draw()})</script></body></html>', encoding='utf-8')
# reports
report = {'version':'v44','status':'installed','patchedPages':patched,'publicPages':len(routes),'primaryPage':'public/ux-proof-check.html','visualFlow':'grid_no_overlap','boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted'}
(ROOT/'reports').mkdir(exist_ok=True)
(ROOT/'reports/public-alpha-ux-remediation-v44-install-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
(ROOT/'evidence/demo').mkdir(parents=True, exist_ok=True)
(ROOT/'evidence/demo/public-alpha-ux-remediation-v44-reference-docket.json').write_text(json.dumps({'version':'v44','claim':'Visual flow and public-alpha UX hardening installed','evidence':['CSS grid override','human visual QA checklist','route audit','browser-local audit'],'boundary':'no user data, no wallet, no transaction, no production authority'}, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
