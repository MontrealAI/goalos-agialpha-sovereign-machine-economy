
from pathlib import Path
import json, re, sys
ROOT = Path.cwd(); PUBLIC = ROOT/'public'
forbidden = ['fetch(', 'XMLHttpRequest', 'sendBeacon', 'localStorage', 'sessionStorage', 'window.ethereum']
hits=[]
for p in PUBLIC.rglob('*'):
    if p.suffix.lower() in {'.html','.js','.css'}:
        t=p.read_text(encoding='utf-8', errors='ignore')
        for f in forbidden:
            if f in t:
                hits.append({'file':str(p.relative_to(ROOT)), 'pattern':f})
# link audit
pages={p.name for p in PUBLIC.glob('*.html')}
broken=[]
for p in PUBLIC.glob('*.html'):
    t=p.read_text(encoding='utf-8', errors='ignore')
    for m in re.finditer(r'href=["\']([^"\']+)["\']', t):
        href=m.group(1)
        if href.startswith(('http:','https:','mailto:','#','javascript:')): continue
        target=href.split('#',1)[0].split('?',1)[0]
        if target.endswith('.html') and Path(target).name not in pages:
            broken.append({'source':p.name, 'target':href})
css=(PUBLIC/'assets/goalos-public-alpha-ux-remediation-v44.css').read_text(encoding='utf-8') if (PUBLIC/'assets/goalos-public-alpha-ux-remediation-v44.css').exists() else ''
checks={
 'cssPresent': bool(css),
 'flowlineGrid': '.flowline{display:grid' in css or '.flowline{display:grid!important' in css,
 'agentOrbitStatic': '.agent-orbit span{position:static' in css,
 'humanQApage': (PUBLIC/'ux-proof-check.html').exists(),
 'visualFlowPage': (PUBLIC/'visual-flow-proof.html').exists(),
 'noForbiddenBrowserApis': len(hits)==0,
 'noBrokenInternalHtmlLinks': len(broken)==0
}
status='passed' if all(checks.values()) else 'failed'
report={'version':'v44','status':status,'checks':checks,'forbiddenBrowserApiHits':hits,'brokenInternalHtmlLinks':broken,'publicPages':len(pages),'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted'}
(ROOT/'reports').mkdir(exist_ok=True)
(ROOT/'reports/public-alpha-ux-remediation-v44-audit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
(ROOT/'reports/public-alpha-ux-remediation-v44-qa.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
if status!='passed': sys.exit(1)
