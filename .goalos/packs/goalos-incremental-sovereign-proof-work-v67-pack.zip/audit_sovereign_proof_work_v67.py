
from pathlib import Path
from datetime import datetime, timezone
import os, json, sys
VERSION = "goalos-incremental-sovereign-proof-work-v67"
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
FAIL = os.environ.get("FAIL_ON_AUDIT_ERROR", "true").lower() == "true"
NOW = datetime.now(timezone.utc).isoformat(timespec="seconds")
ROUTES = [
"sovereign-proof-work-command-center-v67.html",
"holy-grail-candidate-boundary-v67.html",
"proof-debt-to-agijobs-dispatch-v67.html",
"proofbundle-to-chronicle-gate-v67.html",
"agialpha-settlement-thermostat-v67.html",
"proof-run-001-evidence-room-v67.html",
"rsi-move37-governance-room-v67.html",
"alpha-work-units-proof-meter-v67.html",
"external-replay-and-reviewer-room-v67.html",
"sovereign-machine-economy-flywheel-v67.html"
]
required = [f"public/{r}" for r in ROUTES] + [
"public/assets/goalos-incremental-sovereign-proof-work-v67.css",
"public/goalos-sovereign-proof-work-v67-capability-index.json",
"docs/ascension-v67/README.md",
"docs/ascension-v67/PROOF_DEBT_TO_AGIJOBS_DISPATCH.md",
"evidence/proof-run-001-v67/evidence-docket-61.json",
"evidence/proof-run-001-v67/agijobs-seed-queue.json",
"schemas/goalos-v67/proofbundle-v67.schema.json",
"examples/objective-diversity-v67/trust-room-agijobs.json",
"examples/objective-diversity-v67/solar-microgrid-agijobs.json",
"content/goalos-incremental-sovereign-proof-work-v67/manifest.json"
]
missing = [p for p in required if not (ROOT / p).exists()]
forbidden_terms = ["window.ethereum", "fetch(", "XMLHttpRequest", "sendBeacon", "localStorage", "sessionStorage", "https://fonts.googleapis", "<script src=\"http", "<link rel=\"stylesheet\" href=\"http"]
hits = {}
for rel in [f"public/{r}" for r in ROUTES]:
    path = ROOT / rel
    if not path.exists(): continue
    text = path.read_text(encoding="utf-8", errors="ignore")
    for term in forbidden_terms:
        if term in text:
            hits.setdefault(rel, []).append(term)
claim_boundary_ok = True
for rel in [f"public/{r}" for r in ROUTES]:
    path = ROOT / rel
    if path.exists():
        text = path.read_text(encoding="utf-8", errors="ignore").lower()
        if "does not claim achieved agi" not in text or "no wallet" not in text or "no user funds" not in text:
            claim_boundary_ok = False
route_registry_ok = False
rr_error = None
rr = PUBLIC / "route-registry.json"
try:
    data = json.loads(rr.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        route_paths = {item.get("path") for item in data.get("routes", []) if isinstance(item, dict)}
    elif isinstance(data, list):
        route_paths = {item.get("path") for item in data if isinstance(item, dict)}
    else:
        route_paths = set()
    route_registry_ok = all(r in route_paths for r in ROUTES)
except Exception as e:
    rr_error = str(e)
    route_registry_ok = False

status = "pass" if not missing and not hits and claim_boundary_ok and route_registry_ok else "fail"
report = {"version": VERSION, "generated_at": NOW, "status": status, "missing_required_files": missing, "forbidden_or_boundary_hits": hits, "claim_boundary_preserved": claim_boundary_ok, "route_registry_contains_routes": route_registry_ok, "route_registry_error": rr_error}
(REPORTS / "goalos-incremental-sovereign-proof-work-v67-audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
md = f"# GoalOS Incremental Sovereign Proof Work v67 Audit\n\nStatus: **{status.upper()}**\n\nMissing files: {len(missing)}\n\nForbidden hits: {sum(len(v) for v in hits.values())}\n\nClaim boundary preserved: {claim_boundary_ok}\n\nRoute registry contains routes: {route_registry_ok}\n"
(REPORTS / "goalos-incremental-sovereign-proof-work-v67-audit.md").write_text(md, encoding="utf-8")
print(json.dumps(report, indent=2))
if FAIL and status != "pass":
    sys.exit(1)
