
from pathlib import Path
from datetime import datetime, timezone
import os, json, html, shutil

VERSION = "goalos-incremental-sovereign-proof-work-v67"
MARKER_START = "<!-- GOALOS_INCREMENTAL_SOVEREIGN_PROOF_WORK_V67_START -->"
MARKER_END = "<!-- GOALOS_INCREMENTAL_SOVEREIGN_PROOF_WORK_V67_END -->"
NOW = datetime.now(timezone.utc).isoformat(timespec="seconds")
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
PUBLIC.mkdir(exist_ok=True)
(ROOT / ".nojekyll").write_text("", encoding="utf-8")
(PUBLIC / ".nojekyll").write_text("", encoding="utf-8")
ALLOW_OVERWRITE = os.environ.get("ALLOW_OVERWRITE", "false").lower() == "true"
UPDATE_NAVIGATION = os.environ.get("UPDATE_NAVIGATION", "true").lower() == "true"
PATCH_EXISTING = os.environ.get("PATCH_EXISTING_PAGES", "true").lower() == "true"
REPO = os.environ.get("GOALOS_REPOSITORY", "MontrealAI/goalos-agialpha-sovereign-machine-economy")
RUN_ID = os.environ.get("GOALOS_RUN_ID", "local")
SHA = os.environ.get("GOALOS_SHA", "local")
REF = os.environ.get("GOALOS_REF_NAME", "main")

REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
BACKUPS = REPORTS / "backups" / VERSION
BACKUPS.mkdir(parents=True, exist_ok=True)

written, skipped, patched, backups = [], [], [], []

CSS = """
:root{--bg:#07091a;--panel:rgba(11,16,35,.82);--line:rgba(148,163,184,.28);--text:#eef6ff;--muted:#a7b6cf;--gold:#ffd76a;--cyan:#57f0ff;--mint:#67ffbd;--violet:#a78bfa;--rose:#fb7185}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 20% 0,#173a4f 0,#07091a 34%,#040615 100%);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;line-height:1.55}.grid{position:fixed;inset:0;pointer-events:none;opacity:.25;background-image:linear-gradient(rgba(255,255,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.08) 1px,transparent 1px);background-size:32px 32px}.wrap{width:min(1180px,92vw);margin:0 auto;padding:32px 0 80px}.nav{position:sticky;top:14px;z-index:10;display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between;padding:12px 16px;border:1px solid var(--line);border-radius:24px;background:rgba(5,10,25,.78);backdrop-filter:blur(16px);box-shadow:0 20px 80px rgba(0,0,0,.35)}.brand{display:flex;gap:10px;align-items:center;font-weight:900;letter-spacing:.16em;text-transform:uppercase;font-size:12px}.orb{width:34px;height:34px;border-radius:12px;background:radial-gradient(circle at 30% 30%,#fff76b,#65ffc8 35%,#67d6ff 72%,#7c3aed);box-shadow:0 0 38px rgba(87,240,255,.55)}.nav a,.btn{color:var(--text);text-decoration:none;border:1px solid var(--line);border-radius:999px;padding:8px 12px;background:rgba(255,255,255,.07);font-weight:800;font-size:13px}.hero{margin:82px 0 28px;padding:54px;border:1px solid rgba(255,255,255,.18);border-radius:36px;background:linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.04));box-shadow:inset 0 1px 0 rgba(255,255,255,.2),0 40px 140px rgba(0,0,0,.35);position:relative;overflow:hidden}.hero:before{content:"";position:absolute;right:-100px;top:-100px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,var(--cyan),transparent 62%);opacity:.22;filter:blur(3px)}.kicker{color:var(--mint);letter-spacing:.36em;text-transform:uppercase;font-weight:900;font-size:12px}.hero h1{font-size:clamp(42px,7vw,92px);line-height:.92;margin:22px 0 18px;letter-spacing:-.065em}.hero p{font-size:clamp(18px,2vw,24px);color:#d8e5f7;max-width:850px}.gold{color:var(--gold)}.cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:22px 0}.card{border:1px solid var(--line);border-radius:26px;padding:22px;background:var(--panel);box-shadow:0 24px 80px rgba(0,0,0,.26)}.card h2,.card h3{margin:0 0 10px}.card ul{margin:0;padding-left:18px;color:#d7e3f7}.flow{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:24px 0}.step{border:1px solid var(--line);border-radius:18px;padding:12px;text-align:center;font-weight:900;background:rgba(87,240,255,.08)}.wide{grid-column:1/-1}.boundary{border:1px solid rgba(255,215,106,.55);background:linear-gradient(135deg,rgba(255,215,106,.12),rgba(87,240,255,.06));border-radius:26px;padding:22px;margin-top:20px}.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:13px;color:#b9f6ff;white-space:pre-wrap}.footer{color:var(--muted);font-size:13px;margin-top:50px}@media(max-width:850px){.cards,.flow{grid-template-columns:1fr}.hero{padding:30px}.nav{position:relative}}@media(prefers-reduced-motion:no-preference){.orb{animation:pulse 3s ease-in-out infinite}@keyframes pulse{50%{transform:scale(1.06);filter:saturate(1.4)}}}
"""

PAGES = [
    ("sovereign-proof-work-command-center-v67.html", "Sovereign Proof Work Command Center", "The operating map for GoalOS as a proof-gated universal work machine.", ["Objective → mission → work → proof → validation → verified experience.", "Proof debt becomes executable AGI Jobs.", "Only validated capability can enter Chronicle memory."]),
    ("holy-grail-candidate-boundary-v67.html", "Holy Grail Candidate, Claim-Bounded", "A precise public frame: not achieved AGI, but a proof-governed substrate for compounding intelligence.", ["Turing completeness is not the prize; proof-gated open-ended work is.", "Strong claims require Evidence Dockets, replay, validators, and delayed outcomes.", "The next sentence is always: Now we prove it."]),
    ("proof-debt-to-agijobs-dispatch-v67.html", "Proof Debt → AGI Jobs Dispatch", "What the LLM cannot reliably prove becomes structured work for agents, validators, and reviewers.", ["Unsupported claims become proof debt.", "Proof debt becomes job specs, acceptance tests, validator packets, and ProofBundle return templates.", "The system does not guess harder; it dispatches proof."]),
    ("proofbundle-to-chronicle-gate-v67.html", "ProofBundle → Chronicle Gate", "A promotion gate for turning returned evidence into reusable capability without unsafe authority inflation.", ["No ProofBundle, no settlement.", "No replay, no validation.", "No validation, no Chronicle memory."]),
    ("agialpha-settlement-thermostat-v67.html", "$AGIALPHA Settlement Thermostat", "$AGIALPHA is framed as an economic control rail around verified intelligence, not the intelligence itself.", ["Proof quality controls budget flow.", "Replay failure stops settlement and reinvestment.", "Validator pressure rises when false acceptance rises."]),
    ("proof-run-001-evidence-room-v67.html", "Proof Run 001 Evidence Room", "The launch room for the first public Evidence Docket: real mission, baselines, ProofBundles, replay, validator report.", ["Architecture becomes evidence through Proof Run 001.", "The docket separates supported, weak, blocked, and pending claims.", "External replay remains the upgrade path for stronger claims."]),
    ("rsi-move37-governance-room-v67.html", "RSI / Move-37 Governance Room", "High novelty raises skepticism; breakthroughs become audited state transitions, not narratives.", ["Recognize → reproduce → stress-test → persistence gate → dossier.", "OMNI may allocate exploration; it never grants outcome authority.", "Evidence, risk, baselines, replay, and validator gates decide promotion."]),
    ("alpha-work-units-proof-meter-v67.html", "α‑Work Units Proof Meter", "A public-safe explanation of verified work metrology: work counts only when accepted proof survives gates.", ["Raw output is not α‑WU.", "Validated work, replay, policy pass, SLO pass, and validator acceptance define useful work.", "If acceptance fails, the work unit is zero."]),
    ("external-replay-and-reviewer-room-v67.html", "External Replay & Reviewer Room", "A reviewer-first surface for what an independent party should inspect before accepting stronger claims.", ["Reviewer honesty box.", "Replay instructions and falsification tests.", "Human review before high-impact promotion."]),
    ("sovereign-machine-economy-flywheel-v67.html", "Sovereign Machine Economy Flywheel", "Verified machine labor → reusable capability → productive capacity → harder missions → stronger verified labor.", ["The flywheel is a horizon, not an achievement claim.", "Reinvestment follows evidence, not hype.", "The useful unit is governed, replayable, validator-gated work."])
]

CLAIM_BOUNDARY = """This page is public-alpha architecture and implementation scaffolding. It does not claim achieved AGI, achieved ASI, empirical SOTA, legal/security/compliance certification, guaranteed ROI, live settlement in local mode, user-fund handling, autonomous production authorization, or completed external validation. Stronger claims require public Evidence Dockets, real tasks, baselines, ProofBundles, replay logs, validator reports, cost/risk ledgers, delayed outcomes, and independent review."""
GATE_RULE = "No ProofBundle, no settlement. No replay, no validation. No validation, no Chronicle memory."


def backup(path: Path):
    if path.exists():
        safe = str(path.resolve()).replace("/", "__").replace(" ", "_")
        dest = BACKUPS / f"{safe}.bak"
        shutil.copy2(path, dest)
        backups.append(str(dest.relative_to(ROOT)))


def write_file(rel: str, content: str, managed: bool = True):
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not ALLOW_OVERWRITE:
        old = path.read_text(encoding="utf-8", errors="ignore")
        if managed and VERSION in old:
            backup(path)
        else:
            skipped.append(rel)
            return False
    backup(path)
    path.write_text(content, encoding="utf-8")
    written.append(rel)
    return True


def page_html(filename, title, subtitle, bullets):
    nav_links = ''.join(f'<a href="{html.escape(slug)}">{html.escape(name.split(",")[0])}</a>' for slug, name, _, _ in PAGES[:6])
    bullet_html = ''.join(f'<li>{html.escape(b)}</li>' for b in bullets)
    all_steps = ["Mission", "Work", "Proof", "Validation", "Chronicle"]
    flow = ''.join(f'<div class="step">{s}</div>' for s in all_steps)
    cards = f"""
      <div class="card"><h3>What this adds</h3><ul>{bullet_html}</ul></div>
      <div class="card"><h3>Autonomous capability</h3><ul><li>Generates an inspectable proof-work page.</li><li>Adds docs, evidence manifests, schemas, and route entries.</li><li>Patches navigation only inside a marked additive block.</li></ul></div>
      <div class="card"><h3>Safety posture</h3><ul><li>No wallet.</li><li>No user funds.</li><li>No live settlement in local mode.</li><li>No deletions by design.</li></ul></div>
    """
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{html.escape(title)} · GoalOS v67</title>
  <meta name="description" content="{html.escape(subtitle)}">
  <link rel="stylesheet" href="assets/goalos-incremental-sovereign-proof-work-v67.css">
</head>
<body data-goalos-managed="{VERSION}">
<div class="grid"></div>
<main class="wrap">
  <nav class="nav" aria-label="GoalOS v67 navigation"><div class="brand"><span class="orb"></span><span>GoalOS · v67</span></div><div><a href="goalos.html">GoalOS</a><a href="all-pages.html">All Pages</a><a href="site-map.html">Site Map</a>{nav_links}</div></nav>
  <section class="hero">
    <div class="kicker">Incremental sovereign proof-work layer</div>
    <h1>{html.escape(title)} <span class="gold">✨</span></h1>
    <p>{html.escape(subtitle)}</p>
    <p><strong>GoalOS is not merely Turing complete. It is proof-gated open-ended work. Now we prove it.</strong></p>
  </section>
  <section class="cards">{cards}</section>
  <section class="card wide"><h2>Canonical loop</h2><div class="flow">{flow}</div><p class="mono">Objective → Mission Contract → Proof Debt → AGI Jobs → ProofBundles → Evidence Docket 6.1 → Selection Gate → Chronicle Hold → Reusable Capability</p></section>
  <section class="boundary"><h2>Claim boundary</h2><p>{html.escape(CLAIM_BOUNDARY)}</p><p><strong>{html.escape(GATE_RULE)}</strong></p></section>
  <footer class="footer">Generated by {VERSION}. Repository: {html.escape(REPO)} · Run: {html.escape(RUN_ID)} · {NOW}</footer>
</main>
</body>
</html>"""

write_file("public/assets/goalos-incremental-sovereign-proof-work-v67.css", CSS)
for slug, title, subtitle, bullets in PAGES:
    write_file(f"public/{slug}", page_html(slug, title, subtitle, bullets))

routes = [{"title": title, "path": slug, "capability": "sovereign-proof-work-v67", "status": "public-alpha", "claim_level": "architectural-plus-local-evidence-scaffold"} for slug, title, _, _ in PAGES]
capability_index = {
    "version": VERSION,
    "generated_at": NOW,
    "repository": REPO,
    "routes": routes,
    "loop": ["Mission", "Work", "Proof", "Validation", "Verified Experience", "Chronicle", "Reusable Capability", "Settlement Simulation", "Treasury Reinvestment", "Harder Mission"],
    "claim_boundary": {
        "no_achieved_agi": True,
        "no_achieved_asi": True,
        "no_empirical_sota": True,
        "no_guaranteed_roi": True,
        "no_live_settlement_in_local_mode": True,
        "no_wallet_in_local_mode": True,
        "no_user_funds": True,
        "no_autonomous_production_authority": True
    },
    "proof_run_001_status": "planned_public_safe_evidence_docket",
    "next_sentence": "Now we prove it."
}
write_file("public/goalos-sovereign-proof-work-v67-capability-index.json", json.dumps(capability_index, indent=2))

DOCS = {
"README.md": """# GoalOS Incremental Sovereign Proof Work v67\n\nThis layer adds public website pages, docs, schemas, and evidence manifests for the proof-gated universal work machine thesis.\n\nCore line: GoalOS is not merely Turing complete. It is proof-gated open-ended work. Now we prove it.\n\nClaim boundary: public-alpha architecture and implementation scaffold; no achieved AGI/ASI, no empirical SOTA, no live settlement, no user funds, no production authority.\n""",
"HOLY_GRAIL_CANDIDATE_BOUNDARY.md": """# Holy Grail Candidate Boundary\n\nThe strongest honest claim is not that GoalOS has achieved the Holy Grail. The stronger, safer claim is that GoalOS is architecturally pointed at one of the rare prizes: proof-gated open-ended autonomous work that can produce verified experience, reusable capability, settlement signals, and safer compounding intelligence.\n\nThe phrase is earned through Proof Run 001 and repeated Evidence Dockets.\n""",
"PROOF_DEBT_TO_AGIJOBS_DISPATCH.md": """# Proof Debt to AGI Jobs Dispatch\n\nWhen the LLM reaches the edge of reliable proof, GoalOS should not guess harder. It creates proof debt. Proof debt becomes AGI Jobs with worker roles, validator roles, acceptance tests, blocked claims, replay requirements, and ProofBundle return templates.\n""",
"PROOFBUNDLE_CHRONICLE_GATE.md": """# ProofBundle to Chronicle Gate\n\nChronicle memory is not a notes folder. It is accepted institutional memory. Promotion requires a mission contract, benchmark contract, Evidence Docket, explicit proof debt, review route, replay path, and human-review hold for high-impact outcomes.\n""",
"AGIALPHA_SETTLEMENT_THERMOSTAT.md": """# $AGIALPHA Settlement Thermostat\n\n$AGIALPHA is framed here as a proof-settlement control rail. It can coordinate budgets, escrow, stakes, proof bonds, reviewer rewards, slashing, alpha-Work Units, reputation, challenge windows, and treasury reinvestment only when proof passes.\n""",
"PROOF_RUN_001_EVIDENCE_ROOM.md": """# Proof Run 001 Evidence Room\n\nProof Run 001 should publish a public-safe Evidence Docket: real objective, mission contract, claims matrix, proof debt, AGI Jobs, ProofBundle templates, baseline comparison, cost/risk ledger, validator report template, replay path, blocked claims, and reviewer honesty box.\n""",
"RSI_MOVE37_GOVERNANCE_ROOM.md": """# RSI / Move-37 Governance Room\n\nHigh novelty raises skepticism. Move-37 handling is a deterministic state transition: recognize, reproduce, stress-test, persistence gate, dossier. OMNI may influence exploration allocation but never outcome authority.\n""",
"EXTERNAL_REPLAY_REVIEWER_ROOM.md": """# External Replay and Reviewer Room\n\nA stronger claim requires external replay. Reviewers should see the objective, artifacts, environment assumptions, replay steps, validator criteria, failure cases, and a frank honesty box explaining what would falsify the claim.\n""",
"SOVEREIGN_MACHINE_ECONOMY_FLYWHEEL.md": """# Sovereign Machine Economy Flywheel\n\nThe flywheel is: verified machine labor → reusable capability → productive capacity → harder missions → stronger future machine labor. It is a strategic horizon and testable direction, not a present achievement claim.\n"""
}
for name, content in DOCS.items():
    write_file(f"docs/ascension-v67/{name}", content + f"\n\nGenerated: {NOW}\n")

trust_jobs = [
    {"job_id":"agijob-v67-trust-001","title":"Verify AI vendor trust-room claims against supplied evidence","validator":"Procurement proof reviewer","acceptance_tests":["Every top claim maps to evidence or is blocked","Privacy and data-boundary claims are separated from security claims"]},
    {"job_id":"agijob-v67-trust-002","title":"Build buyer-readiness risk ledger and reviewer questions","validator":"Enterprise AI buyer reviewer","acceptance_tests":["Risk ledger contains blocked claims","Reviewer questions are answerable from evidence"]}
]
solar_jobs = [
    {"job_id":"agijob-v67-solar-001","title":"Validate hospital campus load, tariff, resilience, and interconnection assumptions","validator":"Energy infrastructure reviewer","acceptance_tests":["Load assumptions are explicit","Tariff/interconnection proof debt is listed"]},
    {"job_id":"agijob-v67-solar-002","title":"Create financing-model sensitivity table and permitting proof debt register","validator":"Project finance reviewer","acceptance_tests":["Sensitivity table includes capex, rates, savings, and resilience value","Permitting assumptions remain blocked until evidenced"]}
]
write_file("examples/objective-diversity-v67/trust-room-agijobs.json", json.dumps(trust_jobs, indent=2))
write_file("examples/objective-diversity-v67/solar-microgrid-agijobs.json", json.dumps(solar_jobs, indent=2))

EV = {
"evidence-docket-61.json": {"id":"goalos-proof-run-001-v67","title":"Evidence Docket 6.1 — Proof Run 001 Seed","status":"planned","claims_matrix":[{"claim":"GoalOS can structure proof debt as AGI Jobs","status":"supported_structurally"},{"claim":"GoalOS has achieved AGI or ASI","status":"blocked"}],"claim_boundary":CLAIM_BOUNDARY},
"agijobs-seed-queue.json": {"version":VERSION,"jobs":trust_jobs+solar_jobs,"promotion_rule":"No Chronicle promotion unless replay and validation pass."},
"claim-maturity-ladder.json": {"levels":["architectural","local scaffold","public evidence docket","external replay","independent review","delayed outcome"],"current":"architectural-plus-local-scaffold"},
"settlement-thermostat-simulation.json": {"signals":["proof_quality","false_acceptance_rate","replay_failure_rate","risk_level","external_validation"],"actuators":["budget_flow","validator_pressure","settlement_hold","mission_pause","claim_maturity"]},
"reviewer-honesty-box.json": {"questions":["What would falsify the claim?","What remains unsupported?","Which claims are blocked?","Can the result be replayed?"],"status":"required_for_proof_run_001"},
"selection-certificate-draft.json": {"decision":"hold","reason":"Proof Run 001 requires returned ProofBundles, replay result, validator verdict, and human review."},
"rsi-move37-dossier.json": {"move37_policy":"High novelty increases skepticism; reproduce, stress-test, persistence gate, dossier before promotion."}
}
for name, data in EV.items():
    write_file(f"evidence/proof-run-001-v67/{name}", json.dumps(data, indent=2))

SCHEMAS = {
"agijob-v67.schema.json": {"type":"object","required":["job_id","title","objective","acceptance_tests","validator","proofbundle_required"],"properties":{"job_id":{"type":"string"},"title":{"type":"string"},"objective":{"type":"string"},"acceptance_tests":{"type":"array"},"validator":{"type":"string"},"proofbundle_required":{"type":"boolean"}}},
"proofbundle-v67.schema.json": {"type":"object","required":["version","job_id","job_spec_uri","objective","acceptance_tests","outputs","replay_result","validator_verdict","claim_boundary","created_at"],"properties":{"version":{"type":"string"},"job_id":{"type":"string"},"replay_result":{"type":"object"},"validator_verdict":{"type":"string"}}},
"evidence-docket-61-v67.schema.json": {"type":"object","required":["id","title","claims_matrix","proof_debt_register","claim_boundary"],"properties":{"id":{"type":"string"},"claims_matrix":{"type":"array"},"claim_boundary":{"type":"string"}}},
"selection-certificate-v67.schema.json": {"type":"object","required":["decision","proof_valid","eval_pass","rollback_ready","challenge_window"],"properties":{"decision":{"enum":["promote","hold","reject","rollback"]}}}
}
for name, schema in SCHEMAS.items():
    write_file(f"schemas/goalos-v67/{name}", json.dumps(schema, indent=2))

content_manifest = {"version":VERSION,"routes":routes,"docs_path":"docs/ascension-v67/","evidence_path":"evidence/proof-run-001-v67/","schemas_path":"schemas/goalos-v67/","generated_at":NOW}
write_file("content/goalos-incremental-sovereign-proof-work-v67/manifest.json", json.dumps(content_manifest, indent=2))

# Patch route-registry.json robustly
route_registry = PUBLIC / "route-registry.json"
if route_registry.exists():
    try:
        data = json.loads(route_registry.read_text(encoding="utf-8"))
    except Exception:
        data = {"routes": []}
else:
    data = {"routes": []}
if isinstance(data, list):
    existing_paths = {item.get("path") if isinstance(item, dict) else str(item) for item in data}
    for r in routes:
        if r["path"] not in existing_paths:
            data.append(r)
elif isinstance(data, dict):
    data.setdefault("routes", [])
    existing_paths = {item.get("path") if isinstance(item, dict) else str(item) for item in data.get("routes", [])}
    for r in routes:
        if r["path"] not in existing_paths:
            data["routes"].append(r)
    data.setdefault("capability_layers", {})[VERSION] = {"added_at": NOW, "routes": [r["path"] for r in routes]}
backup(route_registry)
route_registry.write_text(json.dumps(data, indent=2), encoding="utf-8")
patched.append("public/route-registry.json")

# Patch content/site_manifest.json
site_manifest = ROOT / "content" / "site_manifest.json"
site_manifest.parent.mkdir(exist_ok=True)
if site_manifest.exists():
    try: sm = json.loads(site_manifest.read_text(encoding="utf-8"))
    except Exception: sm = {}
else: sm = {}
if not isinstance(sm, dict): sm = {"legacy_manifest": sm}
sm.setdefault("incremental_capability_layers", {})[VERSION] = {"generated_at": NOW, "routes": routes}
backup(site_manifest)
site_manifest.write_text(json.dumps(sm, indent=2), encoding="utf-8")
patched.append("content/site_manifest.json")

# Patch sitemap
sitemap = PUBLIC / "sitemap.xml"
entries = "\n".join(f"  <url><loc>./{r['path']}</loc></url>" for r in routes)
if sitemap.exists():
    text = sitemap.read_text(encoding="utf-8", errors="ignore")
    if VERSION not in text:
        block = f"\n  <!-- {VERSION} -->\n{entries}\n"
        text = text.replace("</urlset>", block + "</urlset>") if "</urlset>" in text else text + block
        backup(sitemap)
        sitemap.write_text(text, encoding="utf-8")
        patched.append("public/sitemap.xml")
else:
    sitemap.write_text(f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <!-- {VERSION} -->\n{entries}\n</urlset>\n', encoding="utf-8")
    written.append("public/sitemap.xml")

# Patch navigation block into existing key pages
if UPDATE_NAVIGATION and PATCH_EXISTING:
    nav_html = MARKER_START + "\n<section style=\"margin:48px auto;max-width:1100px;padding:24px;border:1px solid rgba(87,240,255,.35);border-radius:24px;background:rgba(8,16,35,.86);color:#eef6ff;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif\">\n<h2>GoalOS Sovereign Proof Work v67</h2>\n<p><strong>GoalOS is not merely Turing complete. It is proof-gated open-ended work. Now we prove it.</strong></p>\n<p>New incremental capability layer: Proof Debt → AGI Jobs → ProofBundles → Evidence Docket → Chronicle Gate → Sovereign Machine Economy Flywheel.</p>\n<p>" + " ".join(f'<a style=\"color:#67ffbd;margin-right:12px\" href=\"{html.escape(r["path"])}\">{html.escape(r["title"])}</a>' for r in routes[:6]) + "</p>\n</section>\n" + MARKER_END
    for rel in ["public/index.html", "public/goalos.html", "public/all-pages.html", "public/site-map.html"]:
        path = ROOT / rel
        if path.exists():
            text = path.read_text(encoding="utf-8", errors="ignore")
            if MARKER_START not in text:
                backup(path)
                if "</body>" in text:
                    text = text.replace("</body>", nav_html + "\n</body>")
                else:
                    text += "\n" + nav_html
                path.write_text(text, encoding="utf-8")
                patched.append(rel)

issue_body = f"""# GoalOS Incremental Sovereign Proof Work v67 Installed\n\nThe autonomous action added the v67 capability layer.\n\nAdded routes:\n\n""" + "\n".join(f"- `/{r['path']}` — {r['title']}" for r in routes) + f"\n\nSafety: additive install, no wallet, no user funds, no live settlement in local mode, no achieved AGI/ASI claim.\n\nRun ID: {RUN_ID}\nGenerated: {NOW}\n"
write_file("issue-bodies/goalos-incremental-sovereign-proof-work-v67.md", issue_body)

report = {"version": VERSION, "generated_at": NOW, "repository": REPO, "github_run_id": RUN_ID, "sha": SHA, "ref": REF, "allow_overwrite": ALLOW_OVERWRITE, "update_navigation": UPDATE_NAVIGATION, "patch_existing_pages": PATCH_EXISTING, "written": written, "skipped": skipped, "patched": patched, "backups": backups, "routes_added": [r["path"] for r in routes], "claim_boundary": capability_index["claim_boundary"], "safety": {"additive_install": True, "no_deletions_intended": True, "no_wallet": True, "no_user_funds": True, "no_live_settlement": True, "no_external_calls_in_generated_pages": True}}
(REPORTS / "goalos-incremental-sovereign-proof-work-v67-install-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
md = f"# GoalOS Incremental Sovereign Proof Work v67 Install Report\n\nStatus: installed.\n\nWritten: {len(written)} files. Patched: {len(patched)} files. Skipped: {len(skipped)} files.\n\n## Routes\n" + "\n".join(f"- `/{r['path']}` — {r['title']}" for r in routes) + f"\n\n## Boundary\n\n{CLAIM_BOUNDARY}\n\n## Gate rule\n\n{GATE_RULE}\n"
(REPORTS / "goalos-incremental-sovereign-proof-work-v67-install-report.md").write_text(md, encoding="utf-8")
print(json.dumps(report, indent=2))
