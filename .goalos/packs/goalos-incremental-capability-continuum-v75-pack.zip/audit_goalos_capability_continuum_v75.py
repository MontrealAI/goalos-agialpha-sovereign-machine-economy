#!/usr/bin/env python3
import os, json, re, sys
from pathlib import Path
from datetime import datetime, timezone

REPO = Path.cwd()
NOW = datetime.now(timezone.utc).isoformat()
TRUE = {"true","1","yes","y","on"}
def env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None: return default
    return str(value).strip().lower() in TRUE
FAIL = env_bool('FAIL_ON_AUDIT_ERROR', True)
issues = []
warnings = []
checks = {}

index_path = REPO / 'public/goalos-capability-continuum-v75-index.json'
if not index_path.exists():
    issues.append('Missing public/goalos-capability-continuum-v75-index.json')
    routes = []
else:
    index = json.loads(index_path.read_text(encoding='utf-8'))
    routes = index.get('routes', [])
    checks['route_count'] = len(routes)

required_pages = [route['path'].lstrip('/') for route in routes] or [
    'capability-continuum-v75.html', 'goalos-product-lineage-v75.html', 'objective-diversity-lab-v75.html',
    'proof-debt-job-router-v75.html', 'agijobmanager-bridge-room-v75.html', 'proofbundle-import-validator-v75.html',
    'evidence-docket-61-dashboard-v75.html', 'rsi-governance-move37-v75.html', 'alpha-work-unit-settlement-v75.html',
    'external-reviewer-replay-v75.html', 'release-bundle-vault-v75.html', 'now-we-prove-it-v75.html'
]
for rel in required_pages:
    path = REPO / 'public' / rel
    if not path.exists():
        issues.append(f'Missing page: public/{rel}')
    else:
        text = path.read_text(encoding='utf-8', errors='ignore')
        if 'does not claim achieved AGI' not in text:
            issues.append(f'Missing achieved-AGI claim boundary in public/{rel}')
        if 'no wallet' not in text.lower() or 'no transaction' not in text.lower():
            issues.append(f'Missing local wallet/transaction boundary in public/{rel}')
        forbidden = ['fetch(', 'XMLHttpRequest', 'sendBeacon', 'window.ethereum', 'localStorage', 'sessionStorage', '<script src=', 'googleapis.com', 'googletagmanager']
        hits = [f for f in forbidden if f in text]
        if hits:
            issues.append(f'Forbidden local/external reference in public/{rel}: {hits}')

required_files = [
    'docs/capability-continuum-v75/README.md',
    'docs/capability-continuum-v75/PROOF_DEBT_TO_AGIJOBS.md',
    'evidence/proof-run-001-v75/mission-contract.json',
    'evidence/proof-run-001-v75/proof-debt-register.json',
    'evidence/proof-run-001-v75/agi-job-queue.json',
    'evidence/proof-run-001-v75/evidence-docket-61.json',
    'evidence/proof-run-001-v75/proofbundle-template.json',
    'evidence/proof-run-001-v75/capability-promotion-gate.json',
    'schemas/goalos-v75/agijob.schema.json',
    'schemas/goalos-v75/proofbundle.schema.json',
    'content/goalos-capability-continuum-v75/site_layer_manifest.json'
]
for rel in required_files:
    if not (REPO / rel).exists():
        issues.append(f'Missing required artifact: {rel}')

# Bundle vault check.
bundle_dir = REPO / 'public/downloads/goalos-release-bundles-v75'
if not bundle_dir.exists():
    issues.append('Missing bundle vault directory')
else:
    bundles = list(bundle_dir.glob('*.zip'))
    checks['bundle_count'] = len(bundles)
    if len(bundles) < 5:
        issues.append(f'Expected at least 5 lineage bundle ZIPs, found {len(bundles)}')

# Gate status check.
gate_path = REPO / 'evidence/proof-run-001-v75/capability-promotion-gate.json'
if gate_path.exists():
    try:
        gate = json.loads(gate_path.read_text(encoding='utf-8'))
        if gate.get('status') != 'HOLD':
            issues.append('Capability Promotion Gate must remain HOLD until replay and validator evidence exist')
    except Exception as exc:
        issues.append(f'Could not parse capability promotion gate: {exc}')

checks['issues'] = issues
checks['warnings'] = warnings
checks['generated_at'] = NOW
checks['status'] = 'pass' if not issues else 'fail'
checks['claim_boundary_preserved'] = not any('claim boundary' in i.lower() for i in issues)
checks['wallet_boundary_preserved'] = not any('wallet/transaction' in i.lower() for i in issues)

reports = REPO / 'reports'
reports.mkdir(exist_ok=True)
(reports / 'goalos-capability-continuum-v75-audit-report.json').write_text(json.dumps(checks, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
md = ['# GoalOS Capability Continuum v75 audit report', '', f'Generated: {NOW}', '', f"Status: **{checks['status'].upper()}**", '', f"Routes checked: {checks.get('route_count', 0)}", f"Bundles found: {checks.get('bundle_count', 0)}", '']
if issues:
    md += ['## Issues'] + [f'- {i}' for i in issues]
else:
    md += ['## Result', 'PASS — required pages, docs, evidence, schemas, bundle vault, and claim/local-mode boundaries are present.']
if warnings:
    md += ['', '## Warnings'] + [f'- {w}' for w in warnings]
(reports / 'goalos-capability-continuum-v75-audit-report.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
print(json.dumps(checks, indent=2))
if issues and FAIL:
    sys.exit(1)
