#!/usr/bin/env python3
import os, json, shutil, hashlib, html, re
from pathlib import Path
from datetime import datetime, timezone

VERSION = "v75"
SLUG = "capability-continuum-v75"
MARKER = "GOALOS_INCREMENTAL_CAPABILITY_CONTINUUM_V75"
REPO = Path.cwd()
PACK_ROOT = Path(__file__).resolve().parent
NOW = datetime.now(timezone.utc).isoformat()

BUNDLES = [
  {
    "file": "goalos-v34-production-final-autonomous-proof-gated-open-ended-work-machine-everything-bundle(2).zip",
    "safe_name": "goalos-v34-production-final-autonomous-proof-gated-open-ended-work-machine-everything-bundle-2-.zip",
    "sha256": "a3cb92c840d303c3003a178be677aebf70b139cc3fbee684f0bf8b1ca444c7f3",
    "bytes": 588911,
    "human_size_kb": 575.1
  },
  {
    "file": "goalos-v35-dynamic-final-autonomous-proof-gated-open-ended-work-machine-everything-bundle(2).zip",
    "safe_name": "goalos-v35-dynamic-final-autonomous-proof-gated-open-ended-work-machine-everything-bundle-2-.zip",
    "sha256": "4d2ab157da605d3a5ab6b7c0472846c115b68fa6807b81563f03fd99847a60e4",
    "bytes": 558847,
    "human_size_kb": 545.7
  },
  {
    "file": "goalos-v36-production-final-dynamic-autonomous-proof-gated-open-ended-work-machine-customer-download(1)(2).zip",
    "safe_name": "goalos-v36-production-final-dynamic-autonomous-proof-gated-open-ended-work-machine-customer-download-1-2-.zip",
    "sha256": "1f07a87c3867f39008d7ca6d83da8e1096b88f340f0bbdec6dc3599a799febd1",
    "bytes": 623168,
    "human_size_kb": 608.6
  },
  {
    "file": "goalos-v37-ascension-dynamic-production-final-autonomous-proof-gated-open-ended-work-machine-everything-bundle(2).zip",
    "safe_name": "goalos-v37-ascension-dynamic-production-final-autonomous-proof-gated-open-ended-work-machine-everything-bundle-2-.zip",
    "sha256": "290dc18686c9b699c72df4990371d821cf9e5202fc2e912251aebfcc4f5493af",
    "bytes": 217078,
    "human_size_kb": 212.0
  },
  {
    "file": "goalos-v37-complete-standalone-product-console-everything-bundle(1).zip",
    "safe_name": "goalos-v37-complete-standalone-product-console-everything-bundle-1-.zip",
    "sha256": "2bae66c90e0acca2861c1e21fa8e24445b938fdc26b79c74606a19a79a5d48e0",
    "bytes": 135934,
    "human_size_kb": 132.7
  },
  {
    "file": "goalos-v38-production-final-correctness-verified-standalone-product-console-everything-bundle(2).zip",
    "safe_name": "goalos-v38-production-final-correctness-verified-standalone-product-console-everything-bundle-2-.zip",
    "sha256": "f07481e3522cf7b45b95fd067f085b17e1190c00ba08c7f9f8d80e2f9e77c1da",
    "bytes": 257803,
    "human_size_kb": 251.8
  }
]

TRUE = {"true","1","yes","y","on"}
def env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return str(value).strip().lower() in TRUE

ALLOW_OVERWRITE = env_bool('ALLOW_OVERWRITE', False)
UPDATE_NAVIGATION = env_bool('UPDATE_NAVIGATION', True)
PATCH_EXISTING_PAGES = env_bool('PATCH_EXISTING_PAGES', True)
RUN_ID = os.environ.get('GOALOS_RUN_ID') or os.environ.get('GITHUB_RUN_ID') or 'local'
SHA = os.environ.get('GOALOS_SHA') or os.environ.get('GITHUB_SHA') or 'local'
REPOSITORY = os.environ.get('GOALOS_REPOSITORY') or os.environ.get('GITHUB_REPOSITORY') or 'MontrealAI/goalos-agialpha-sovereign-machine-economy'

installed, skipped, patched, copied = [], [], [], []

def ensure_parent(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)

def write_text(rel, text, overwrite=None):
    if overwrite is None: overwrite = ALLOW_OVERWRITE
    path = REPO / rel
    ensure_parent(path)
    if path.exists() and not overwrite:
        skipped.append(rel)
        return False
    path.write_text(text, encoding='utf-8')
    installed.append(rel)
    return True

def write_json(rel, obj, overwrite=None):
    write_text(rel, json.dumps(obj, indent=2, ensure_ascii=False) + "\n", overwrite)

def copy_file(src, rel, overwrite=None):
    if overwrite is None: overwrite = ALLOW_OVERWRITE
    dst = REPO / rel
    ensure_parent(dst)
    if dst.exists() and not overwrite:
        skipped.append(rel)
        return False
    shutil.copy2(src, dst)
    copied.append(rel)
    return True

def page(title, eyebrow, summary, sections, primary_links=None):
    primary_links = primary_links or []
    nav = ''.join(f'<a href="{html.escape(href)}">{html.escape(label)}</a>' for label, href in primary_links)
    body_sections = []
    for sec in sections:
        cards = ''.join(f'<div class="card"><h3>{html.escape(c[0])}</h3><p>{html.escape(c[1])}</p></div>' for c in sec.get('cards', []))
        bullets = ''.join(f'<li>{html.escape(b)}</li>' for b in sec.get('bullets', []))
        table = ''
        if sec.get('table'):
            heads = ''.join(f'<th>{html.escape(h)}</th>' for h in sec['table']['headers'])
            rows = ''
            for row in sec['table']['rows']:
                rows += '<tr>' + ''.join(f'<td>{html.escape(str(cell))}</td>' for cell in row) + '</tr>'
            table = f'<div class="tablewrap"><table><thead><tr>{heads}</tr></thead><tbody>{rows}</tbody></table></div>'
        body_sections.append(f"""
        <section class="panel">
          <p class="kicker">{html.escape(sec.get('eyebrow','GoalOS'))}</p>
          <h2>{html.escape(sec['title'])}</h2>
          <p>{html.escape(sec.get('text',''))}</p>
          {('<ul>'+bullets+'</ul>') if bullets else ''}
          {cards}
          {table}
        </section>""")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)} · GoalOS</title>
<meta name="description" content="GoalOS incremental capability layer: proof-gated open-ended work, AGI Jobs, ProofBundles, Evidence Dockets, and claim-bounded capability promotion.">
<style>
:root {{ --bg:#07111f; --panel:#0d1a2d; --panel2:#10263f; --text:#f6fbff; --muted:#a8bad1; --line:rgba(255,255,255,.15); --cyan:#68fff1; --gold:#ffe082; --green:#9eff8e; --violet:#b28cff; --pink:#ff72be; }}
* {{ box-sizing:border-box; }} body {{ margin:0; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background:radial-gradient(circle at 20% 0%, #183b3a, transparent 30%), radial-gradient(circle at 80% 0%, #2e2459, transparent 35%), linear-gradient(180deg,#06101c,#08131f 50%,#060b12); color:var(--text); line-height:1.6; }}
a {{ color:var(--cyan); text-decoration:none; }} a:hover {{ text-decoration:underline; }}
.shell {{ width:min(1180px,92vw); margin:0 auto; }}
.header {{ position:sticky; top:0; z-index:5; backdrop-filter:blur(16px); background:rgba(4,10,18,.72); border-bottom:1px solid var(--line); }}
.header .shell {{ display:flex; align-items:center; justify-content:space-between; gap:1rem; padding:1rem 0; flex-wrap:wrap; }}
.brand {{ display:flex; gap:.75rem; align-items:center; font-weight:900; letter-spacing:.18em; text-transform:uppercase; font-size:.82rem; }}
.mark {{ width:38px; height:38px; border-radius:13px; display:grid; place-items:center; color:#06111d; font-size:1.25rem; font-weight:900; background:conic-gradient(from 90deg, var(--cyan), var(--violet), var(--gold), var(--green), var(--cyan)); box-shadow:0 0 35px rgba(104,255,241,.45); }}
.nav {{ display:flex; gap:.6rem; flex-wrap:wrap; }} .nav a {{ border:1px solid var(--line); border-radius:999px; padding:.55rem .8rem; background:rgba(255,255,255,.06); font-weight:800; font-size:.85rem; }}
.hero {{ padding:5.5rem 0 3rem; }} .eyebrow,.kicker {{ color:var(--cyan); text-transform:uppercase; letter-spacing:.32em; font-weight:900; font-size:.78rem; }}
h1 {{ font-size:clamp(3rem,9vw,7.5rem); line-height:.9; margin:.75rem 0 1rem; letter-spacing:-.08em; max-width:1100px; }}
.hero p {{ max-width:900px; color:var(--muted); font-size:clamp(1.05rem,2vw,1.35rem); }}
.ctas {{ display:flex; gap:.8rem; flex-wrap:wrap; margin-top:1.5rem; }} .button {{ display:inline-flex; align-items:center; gap:.5rem; padding:.85rem 1rem; border-radius:999px; border:1px solid rgba(104,255,241,.45); background:rgba(104,255,241,.12); color:var(--text); font-weight:900; }}
.grid {{ display:grid; grid-template-columns:repeat(12,1fr); gap:1rem; margin:2rem 0 4rem; }}
.panel {{ grid-column:span 12; border:1px solid var(--line); background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035)); border-radius:28px; padding:1.4rem; box-shadow:0 20px 70px rgba(0,0,0,.28); }}
.panel h2 {{ margin:.25rem 0 .75rem; font-size:clamp(1.5rem,3vw,2.4rem); letter-spacing:-.03em; }} .panel p {{ color:var(--muted); }}
.card {{ border:1px solid var(--line); border-radius:20px; padding:1rem; margin:.75rem 0; background:rgba(255,255,255,.05); }} .card h3 {{ margin:.1rem 0 .35rem; color:var(--gold); }}
ul {{ padding-left:1.2rem; }} li {{ margin:.35rem 0; color:#d7e6f5; }}
.tablewrap {{ overflow:auto; border-radius:18px; border:1px solid var(--line); margin-top:1rem; }} table {{ width:100%; border-collapse:collapse; min-width:720px; }} th,td {{ padding:.8rem; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }} th {{ color:var(--gold); background:rgba(255,255,255,.08); }} td {{ color:#d8e8f8; }}
.boundary {{ border-color:rgba(255,224,130,.45); background:linear-gradient(180deg,rgba(255,224,130,.12),rgba(255,255,255,.035)); }}
.footer {{ padding:3rem 0 5rem; color:var(--muted); }}
@media (min-width: 860px) {{ .half {{ grid-column:span 6; }} .third {{ grid-column:span 4; }} }}
</style>
</head>
<body>
<header class="header"><div class="shell"><div class="brand"><span class="mark">α</span><span>GoalOS · AGIALPHA Ascension</span></div><nav class="nav">{nav}</nav></div></header>
<main class="shell">
<section class="hero"><p class="eyebrow">{html.escape(eyebrow)}</p><h1>{html.escape(title)}</h1><p>{html.escape(summary)}</p><div class="ctas"><a class="button" href="capability-continuum-v75.html">Capability Continuum</a><a class="button" href="release-bundle-vault-v75.html">Bundle Vault</a><a class="button" href="now-we-prove-it-v75.html">Now We Prove It</a></div></section>
<section class="grid">{''.join(body_sections)}<section class="panel boundary"><p class="kicker">Claim boundary</p><h2>Proof-gated, not overclaimed.</h2><p>GoalOS does not claim achieved AGI, achieved ASI, empirical SOTA, guaranteed ROI, legal/security/compliance certification, live settlement in local mode, wallet execution in local mode, or autonomous production authority. The correct claim is architectural and operational: GoalOS turns objectives into proof debt, proof debt into AGI Jobs, ProofBundles into Evidence Dockets, and validated evidence into reusable capability only after gates pass.</p></section></section>
</main><footer class="footer"><div class="shell">GoalOS Capability Continuum v75 · generated additively · no backend · no wallet · no transaction · no user funds · no live settlement.</div></footer>
</body></html>"""

links = [
    ("Home", "index.html"), ("GoalOS", "goalos.html"), ("All Pages", "all-pages.html"),
    ("Proof Run 001", "proof-run-001-command-center-v70.html"), ("Bundle Vault", "release-bundle-vault-v75.html")
]

bundle_rows = [[m['file'], f"{m['human_size_kb']} KB", m['sha256'][:16] + '…', f"downloads/goalos-release-bundles-v75/{m['safe_name']}"] for m in BUNDLES]

pages = {
"capability-continuum-v75.html": page("Capability Continuum v75", "Incremental Proof-Grail Capability Layer", "An additive command center that connects the V34→V38 standalone product lineage to Proof Run 001, AGI Jobs dispatch, Evidence Docket 6.1, ProofBundle return gates, RSI governance, and the next public proof loop.", [
    {"title":"What this layer adds", "text":"It turns the existing website into a more complete proof-facing operating room without deleting existing pages.", "cards":[("Continuum", "Shows how V34, V35, V36, V37, and V38 bundles evolve toward a unified proof-gated open-ended work machine."),("Dispatch", "Makes proof debt operational by converting missing evidence into AGI Jobs with validator roles and ProofBundle return paths."),("Review", "Adds public-safe replay, reviewer, and evidence room surfaces so Proof Run 001 can be inspected rather than merely announced.")]},
    {"title":"The loop", "text":"GoalOS is not merely Turing complete. It is proof-gated open-ended work.", "bullets":["Mission → Work → Proof → Validation → Verified Experience → Chronicle → Reusable Capability.", "Only accepted proof can influence future work.", "Only validated work can move toward settlement-facing boundaries.", "Now we prove it." ]},
], links),
"goalos-product-lineage-v75.html": page("GoalOS Product Lineage v75", "Release bundle lineage", "A public-safe lineage map for the uploaded V34, V35, V36, V37, and V38 product bundles, preserved as downloadable artifacts and summarized as a capability ladder.", [
    {"title":"Release bundle vault", "text":"The action copies the attached bundles into a website download vault and records SHA-256 hashes for review.", "table":{"headers":["Bundle", "Size", "Hash prefix", "Website path"], "rows":bundle_rows}},
    {"title":"Why this matters", "text":"The repository should preserve prior work as evidence, not overwrite it. Each bundle is a checkpoint in the proof machine lineage.", "bullets":["V34/V35: autonomous proof-gated work-machine foundations.", "V36: dynamic production customer download lineage.", "V37: ascension and standalone console lineage.", "V38: correctness-verified standalone product console lineage."]}
], links),
"objective-diversity-lab-v75.html": page("Objective Diversity Lab v75", "Dynamic mission compiler proof", "A visible standard for proving that different objectives generate materially different domains, claims, proof debt, AGI Jobs, ProofBundle templates, reviewer types, and Evidence Dockets.", [
    {"title":"Hard acceptance test", "text":"GoalOS should fail if unrelated objectives produce essentially identical job queues.", "table":{"headers":["Objective", "Expected domain", "Expected AGI Jobs"], "rows":[["AI vendor trust room buyer readiness", "AI Governance / Trust / Procurement", "claim evidence mapping, data boundary review, buyer-readiness review, external attestation"],["Solar microgrid financing model for hospital campus", "Energy / Infrastructure / Finance", "site/load assumptions, tariff/interconnection, financing sensitivity, resilience baseline, permitting proof debt"]]}},
    {"title":"Why it matters", "text":"A proof machine must be objective-native. Otherwise it is only a static dashboard with impressive wording.", "bullets":["Different objectives must produce different proof debt.", "Different proof debt must produce different jobs.", "Different jobs must require different validators.", "Different Evidence Dockets must block different claims."]}
], links),
"proof-debt-job-router-v75.html": page("Proof Debt → AGI Jobs Router v75", "Missing evidence becomes executable work", "This room makes the key mechanism explicit: when an LLM output is unsupported, GoalOS does not guess harder; it creates proof debt and dispatches AGI Jobs.", [
    {"title":"Dispatch matrix", "text":"Proof debt becomes work with owners, validator routes, acceptance tests, and ProofBundle requirements.", "table":{"headers":["Proof debt", "AGI Job", "Validator route", "Promotion rule"], "rows":[["Unsupported vendor claim", "Attach evidence and source provenance", "Procurement reviewer + AGI Node Validator", "Blocked until Evidence Docket update"],["Missing replay path", "Prepare replay manifest and logs", "External reviewer", "No replay, no promotion"],["Settlement-facing claim", "Simulate settlement boundary and proof controls", "Sentinel + legal/token reviewer", "No ProofBundle, no settlement"]]}},
    {"title":"Operating sentence", "text":"The LLM drafts. GoalOS identifies proof debt. AGI Jobs execute missing proof. ProofBundles return. Validators decide what can be trusted."}
], links),
"agijobmanager-bridge-room-v75.html": page("AGIJobManager Bridge Room v75", "Local specs, separated settlement", "A clean boundary page for AGIJobManager-ready artifacts: local GoalOS prepares job specs and transaction intents; live escrow, validation, disputes, and settlement remain a separate human-confirmed dApp boundary.", [
    {"title":"Local mode", "text":"GoalOS local/public website mode generates job specs, packet templates, validator rubrics, completion URI plans, and ProofBundle import manifests.", "bullets":["No wallet connection.", "No transaction broadcast.", "No user funds.", "No live settlement.", "No hidden approvals."]},
    {"title":"Future dApp boundary", "text":"Wallet connection, escrow, validator voting, disputes, and settlement belong only in a separated, clearly labeled, human-confirmed AGIJobManager interface."}
], links),
"proofbundle-import-validator-v75.html": page("ProofBundle Import Validator v75", "Return path for proof", "A ProofBundle is the evidence package returned by an AGI Job. Without replay_result and validator_verdict, Chronicle promotion remains HOLD.", [
    {"title":"Minimum fields", "text":"A valid ProofBundle must be parseable, tied to a job, and reviewable.", "bullets":["version, job_id, job_spec_uri, objective, acceptance_tests, policy_context", "inputs, outputs, output hashes or artifact pointers", "logs or trace summary, replay_result, validator_verdict", "claim boundary, risk ledger, attestation, created_at"]},
    {"title":"Gate behavior", "text":"The system may import draft proof, but it must not promote capability without replay and validation."}
], links),
"evidence-docket-61-dashboard-v75.html": page("Evidence Docket 6.1 Dashboard v75", "Proof room, not marketing page", "The Evidence Docket ties claims to provenance, baselines, proof packets, proof debt, blocked claims, cost/risk ledgers, replay paths, reviewer questions, and claim boundaries.", [
    {"title":"Docket contents", "text":"Every public proof run should expose what passed, what failed, what remains blocked, and what evidence is still missing.", "cards":[("Claims matrix", "Each major claim has status: supported, structural, needs evidence, blocked, or reviewer-ready."),("Proof debt register", "Unsupported claims become job-ready evidence tasks."),("Public/private boundary", "Public proof commitments are separated from private intelligence, private traces, secrets, and customer data.")]},
    {"title":"Proof Run 001 status", "text":"Current status remains public-alpha / command-ready. Stronger claims unlock only after real Evidence Dockets, replay, validator reports, delayed outcomes, and independent review."}
], links),
"rsi-governance-move37-v75.html": page("RSI Governance + Move-37 Gate v75", "Search control is not outcome authority", "This room adds deterministic invention-governance language to the public site: exploration may propose; evidence, risk, baselines, persistence, replay, and validators decide.", [
    {"title":"RSI gates", "text":"High novelty raises skepticism. Breakthroughs are audited state transitions, not narratives.", "bullets":["Recognize novelty and advantage thresholds.", "Reproduce candidate and baseline with fixed seeds or equivalent replay instructions.", "Stress-test under policy shocks and alternative assumptions.", "Require persistence and package a dossier before promotion."]},
    {"title":"ECI discipline", "text":"Confidence cannot inflate from simulated reasoning alone. Executed, replayed, stress-tested, or externally validated evidence is required for stronger claims."}
], links),
"alpha-work-unit-settlement-v75.html": page("α‑Work Unit + $AGIALPHA Thermostat v75", "Proof makes economics consequential", "$AGIALPHA is not the intelligence. In the architecture, it is the economic control rail around verified work, used only under strict claim and legal boundaries.", [
    {"title":"Thermostat model", "text":"Proof quality, false acceptance, replay failures, risk, validator latency, and dispute rate become control signals.", "table":{"headers":["Signal", "Potential actuator", "Boundary"], "rows":[["Proof quality rises", "More budget can flow", "Only after validation"],["False acceptance rises", "Validator pressure / slashing policy increases", "Simulation until live dApp review"],["Replay fails", "Settlement and promotion stop", "No replay, no settlement"],["Risk rises", "Mission class pauses", "Human review required"]]}},
    {"title":"Token boundary", "text":"This page does not represent $AGIALPHA as equity, profit rights, dividends, ownership, or guaranteed economic return."}
], links),
"external-reviewer-replay-v75.html": page("External Reviewer Replay Room v75", "From architecture to inspected proof", "This room defines the outside-review path: what a reviewer needs to inspect, replay, challenge, reject, or accept a GoalOS proof run.", [
    {"title":"Reviewer package", "text":"A useful reviewer room should contain task manifests, baselines, AGI Jobs, ProofBundles, replay instructions, cost/risk ledger, claim matrix, blocked claims, and an honesty box.", "bullets":["What would falsify this claim?", "What evidence is missing?", "What can be replayed?", "What cannot be trusted yet?", "What should remain blocked?"]},
    {"title":"Human review rule", "text":"External validation is not asserted until reviewer evidence exists and is cited in the Evidence Docket."}
], links),
"release-bundle-vault-v75.html": page("Release Bundle Vault v75", "Downloadable lineage archive", "The action publishes the attached V34→V38 bundles as public downloadable artifacts so the site can preserve product lineage and make release materials easy to inspect.", [
    {"title":"Downloads", "text":"Use these bundles as lineage artifacts and review materials. They are not secrets and should remain claim-bounded.", "table":{"headers":["Bundle", "Size", "SHA-256", "Download path"], "rows":bundle_rows}},
    {"title":"Preservation rule", "text":"Old work is evidence. Do not delete it simply because the system evolves. Add the new layer, preserve the prior lineage, and record hashes."}
], links),
"now-we-prove-it-v75.html": page("Now We Prove It v75", "Proof Run 001 launch room", "The next proof is not another claim. It is a public-safe mission run that reaches DONE=true and publishes an Evidence Docket people can inspect.", [
    {"title":"Proof Run 001 checklist", "text":"The v75 layer creates the public scaffolding for Proof Run 001.", "bullets":["Choose one public-safe high-stakes objective.", "Publish Mission Contract and Benchmark Contract.", "Dispatch proof debt as AGI Jobs.", "Return ProofBundles with replay and validator verdicts.", "Publish Evidence Docket 6.1.", "Keep Capability Promotion Gate on HOLD until evidence passes."]},
    {"title":"Strongest honest line", "text":"GoalOS is architecturally pointed at proof-gated, economically coordinated, open-ended autonomous work. Now we prove it through public Evidence Dockets, replay, review, and measured outcomes."}
], links)
}

# Install pages.
for filename, content in pages.items():
    write_text(f"public/{filename}", content)

# Copy release bundles.
for meta in BUNDLES:
    src = PACK_ROOT / 'bundles' / meta['safe_name']
    if src.exists():
        copy_file(src, f"public/downloads/goalos-release-bundles-v75/{meta['safe_name']}")

# Capability index / route registry.
route_manifest = {
    "version": "goalos.incremental.capability-continuum.v75",
    "generated_at": NOW,
    "repository": REPOSITORY,
    "run_id": RUN_ID,
    "source_sha": SHA,
    "claim_boundary": "Architecture/public-alpha only. No achieved AGI/ASI, no empirical SOTA, no live settlement in local mode, no wallet or transaction in local mode, no guaranteed ROI.",
    "routes": [
        {"title": title.replace(' v75',''), "path": f"/{filename}", "status": "public-safe incremental"}
        for filename, title in [(fn, re.sub(r' · GoalOS.*','', re.search(r'<title>(.*?)</title>', content).group(1))) for fn, content in pages.items()]
    ],
    "bundles": BUNDLES,
    "required_boundaries": ["no backend", "no wallet", "no transaction", "no user funds", "no live settlement", "no achieved AGI", "no achieved ASI", "no empirical SOTA"]
}
write_json("public/goalos-capability-continuum-v75-index.json", route_manifest)
write_json("content/goalos-capability-continuum-v75/site_layer_manifest.json", route_manifest)
write_json("public/capability-continuum-v75-search-index.json", {"items": route_manifest['routes'], "generated_at": NOW})

# Evidence artifacts.
mission_contract = {
    "id": "goalos-proof-run-001-v75",
    "version": "goalos.v75",
    "created_at": NOW,
    "objective": "Prepare GoalOS Proof Run 001 by publishing a claim-bounded capability continuum, release bundle vault, proof-debt-to-AGI-Jobs router, ProofBundle return gate, Evidence Docket 6.1 room, RSI/Move-37 gate, and external replay room.",
    "decision_to_support": "Can the public site move from architecture narrative to first public evidence-producing run without overclaiming?",
    "success_criteria": ["Required pages exist", "Release bundles copied and hashed", "Proof debt converted to AGI Jobs", "Evidence Docket scaffold present", "Capability Promotion Gate remains HOLD until replay and validation pass", "Claim boundary visible"],
    "constraints": ["additive only", "no deletion", "no backend", "no wallet", "no transaction", "no user funds", "no live settlement", "human review required for high-impact outcomes"],
    "done_condition": "public-safe Proof Run 001 scaffolding and audit report generated"
}
proof_debt = [
    {"id":"pd-v75-001", "claim":"GoalOS can preserve product lineage from V34 through V38.", "missing_evidence":"bundle hashes, public vault, release manifest", "job":"agi-job-v75-001"},
    {"id":"pd-v75-002", "claim":"GoalOS generates materially different jobs for unrelated objectives.", "missing_evidence":"objective diversity regression artifacts", "job":"agi-job-v75-002"},
    {"id":"pd-v75-003", "claim":"Local mode keeps no-backend/no-wallet/no-transaction boundary.", "missing_evidence":"boundary audit report", "job":"agi-job-v75-003"},
    {"id":"pd-v75-004", "claim":"Proof Run 001 can accept returned ProofBundles.", "missing_evidence":"ProofBundle template and validator checklist", "job":"agi-job-v75-004"},
    {"id":"pd-v75-005", "claim":"External replay can inspect the run.", "missing_evidence":"reviewer room and replay checklist", "job":"agi-job-v75-005"}
]
agi_jobs = [
    {"job_id":"agi-job-v75-001", "title":"Verify release bundle vault", "worker_role":"AGI Agent or release engineer", "validator_role":"AGI Node Validator or human reviewer", "why_needed":"Product lineage should be preserved as inspectable evidence.", "acceptance_tests":["all expected bundles present", "sha256 hashes recorded", "download paths work"], "promotion_rule":"No release lineage claim without bundle manifest."},
    {"job_id":"agi-job-v75-002", "title":"Run objective diversity regression", "worker_role":"Mission compiler evaluator", "validator_role":"External reviewer", "why_needed":"GoalOS must not generate identical AGI Jobs for unrelated objectives.", "acceptance_tests":["AI trust room and solar microgrid objectives produce different domains", "job-family overlap below threshold"], "promotion_rule":"No objective-native claim without diversity evidence."},
    {"job_id":"agi-job-v75-003", "title":"Audit local/no-wallet boundary", "worker_role":"Sentinel Agent", "validator_role":"Security/privacy reviewer", "why_needed":"The site must not imply live wallet, backend, user-fund, or settlement behavior in local mode.", "acceptance_tests":["no forbidden APIs in generated v75 pages", "boundary text visible", "token claims remain non-investment"], "promotion_rule":"No deployment claim if boundary fails."},
    {"job_id":"agi-job-v75-004", "title":"Prepare ProofBundle return package", "worker_role":"ProofBundle engineer", "validator_role":"ProofBundle validator", "why_needed":"AGI Jobs require return evidence before Chronicle promotion.", "acceptance_tests":["template includes replay_result", "template includes validator_verdict", "promotion remains HOLD if missing"], "promotion_rule":"No Chronicle promotion unless replay and validation pass."},
    {"job_id":"agi-job-v75-005", "title":"Create external replay reviewer room", "worker_role":"Reviewer packet builder", "validator_role":"Independent reviewer", "why_needed":"Holy Grail candidate framing must move toward public evidence, not only narrative.", "acceptance_tests":["review checklist present", "falsification questions present", "Evidence Docket pointer present"], "promotion_rule":"No external validation claim without reviewer evidence."}
]
evidence_docket = {
    "id":"evidence-docket-61-proof-run-001-v75",
    "title":"Evidence Docket 6.1 — Proof Run 001 v75 Scaffold",
    "objective": mission_contract['objective'],
    "claims_matrix":[
        {"claim":"GoalOS v75 adds public Proof Run 001 scaffolding.", "status":"supported structurally", "evidence":"required pages and manifests generated"},
        {"claim":"GoalOS product lineage is preserved.", "status":"supported locally", "evidence":"release bundle hashes and download vault"},
        {"claim":"GoalOS has achieved AGI/ASI or empirical SOTA.", "status":"blocked", "evidence":"not claimed; requires independent evidence beyond this scaffold"},
        {"claim":"$AGIALPHA settlement is live in local mode.", "status":"blocked", "evidence":"local mode is intent/spec only, no wallet/no transaction/no user funds"}
    ],
    "proof_debt_register": proof_debt,
    "agi_jobs_created": [j['job_id'] for j in agi_jobs],
    "blocked_claims_register":["achieved AGI", "achieved ASI", "empirical SOTA", "guaranteed ROI", "live settlement in local mode", "legal/security/compliance certification"],
    "public_private_boundary":"Public pages expose proof scaffolds, hashes, and public-safe manifests. Private prompts, private traces, secrets, customer data, and privileged workpapers do not belong in the public site.",
    "capability_gate":"HOLD until replay_result and validator_verdict evidence exists."
}
proofbundle_template = {
    "version":"goalos.proofbundle.v75.template",
    "job_id":"agi-job-v75-004",
    "job_spec_uri":"local://evidence/proof-run-001-v75/agi-job-queue.json#agi-job-v75-004",
    "job_completion_uri":"local://proofbundles/proof-run-001-v75/agi-job-v75-004.json",
    "objective":mission_contract['objective'],
    "acceptance_tests":["replay_result present", "validator_verdict present", "risk_ledger present", "claim_boundary present"],
    "policy_context":"public-alpha, no-backend, no-wallet, no-transaction local proof mode",
    "inputs":[], "outputs":[], "artifact_pointers":[],
    "logs_or_trace_summary":"to be supplied by AGI Job executor",
    "replay_result":"PENDING",
    "validator_verdict":"PENDING",
    "claim_boundary":"No strong empirical claim before replay and validator verdict.",
    "risk_ledger":[],
    "worker_signature_or_attestation":"PENDING",
    "created_at":NOW
}
capability_gate = {
    "gate_id":"capability-promotion-gate-v75",
    "status":"HOLD",
    "reason":"Proof Run 001 scaffold is generated, but replay_result and validator_verdict are pending.",
    "required_to_pass":["Mission Contract", "Benchmark Contract", "Evidence Docket", "ProofBundle with replay_result", "validator_verdict", "claim boundary", "external review path"],
    "forbidden_promotions":["achieved AGI", "achieved ASI", "empirical SOTA", "live settlement", "guaranteed ROI"]
}
validation_report = {
    "version":"goalos.validation.v75",
    "generated_at":NOW,
    "dynamic_generation_from_user_input_required": True,
    "different_objectives_generate_different_jobs_required": True,
    "proofbundle_validator_required": True,
    "agijob_queue": True,
    "claim_boundary_preserved": True,
    "wallet_boundary_preserved": True,
    "transaction_policy":"intent/spec only in local engine; optional live dApp separated",
    "forbidden_local_mode_boundary":["fetch(", "XMLHttpRequest", "sendBeacon", "window.ethereum", "localStorage", "sessionStorage"]
}

write_json("evidence/proof-run-001-v75/mission-contract.json", mission_contract)
write_json("evidence/proof-run-001-v75/proof-debt-register.json", proof_debt)
write_json("evidence/proof-run-001-v75/agi-job-queue.json", agi_jobs)
write_json("evidence/proof-run-001-v75/proofbundle-template.json", proofbundle_template)
write_json("evidence/proof-run-001-v75/evidence-docket-61.json", evidence_docket)
write_json("evidence/proof-run-001-v75/capability-promotion-gate.json", capability_gate)
write_json("evidence/proof-run-001-v75/release-bundle-manifest.json", {"bundles": BUNDLES, "generated_at": NOW})
write_json("evidence/proof-run-001-v75/validation-report.json", validation_report)

# Examples: objective-specific outputs.
write_json("examples/objective-diversity-v75/ai-vendor-trust-room/mission-summary.json", {
    "objective":"Evaluate whether an AI vendor trust room is buyer-ready for enterprise procurement and prepare a reviewer-ready proof package.",
    "domain":"AI Governance / Trust / Procurement",
    "jobs":["Attach evidence for top vendor claims", "Map security/privacy/compliance boundary", "Compare trust room against buyer-readiness checklist", "Prepare external reviewer attestation packet"]
})
write_json("examples/objective-diversity-v75/solar-hospital-microgrid/mission-summary.json", {
    "objective":"Design a solar microgrid financing model for a hospital campus.",
    "domain":"Energy / Infrastructure / Finance",
    "jobs":["Verify site/load/tariff assumptions", "Model financing sensitivity", "Validate hospital resilience requirements", "Map permitting and interconnection proof debt"]
})

# Schemas.
common_schema_header = {"$schema":"https://json-schema.org/draft/2020-12/schema", "additionalProperties": True}
write_json("schemas/goalos-v75/agijob.schema.json", {**common_schema_header, "title":"GoalOS v75 AGI Job", "type":"object", "required":["job_id","title","worker_role","validator_role","acceptance_tests","promotion_rule"]})
write_json("schemas/goalos-v75/proofbundle.schema.json", {**common_schema_header, "title":"GoalOS v75 ProofBundle", "type":"object", "required":["version","job_id","job_spec_uri","objective","acceptance_tests","replay_result","validator_verdict","claim_boundary","risk_ledger","created_at"]})
write_json("schemas/goalos-v75/evidence-docket-61.schema.json", {**common_schema_header, "title":"Evidence Docket 6.1", "type":"object", "required":["id","title","objective","claims_matrix","proof_debt_register","blocked_claims_register","public_private_boundary"]})
write_json("schemas/goalos-v75/release-bundle.schema.json", {**common_schema_header, "title":"GoalOS v75 Release Bundle Manifest", "type":"object", "required":["bundles"]})

# Docs.
docs = {
"docs/capability-continuum-v75/README.md":"""# GoalOS Capability Continuum v75\n\nGoalOS is not merely Turing complete. It is proof-gated open-ended work. This incremental layer preserves the V34→V38 product lineage, adds a public release-bundle vault, and connects Proof Run 001 to AGI Jobs, ProofBundles, Evidence Docket 6.1, RSI governance, and external replay.\n\n## Boundary\n\nThis layer does not claim achieved AGI, achieved ASI, empirical SOTA, guaranteed ROI, live settlement in local mode, or production authority.\n""",
"docs/capability-continuum-v75/PROOF_DEBT_TO_AGIJOBS.md":"""# Proof Debt to AGI Jobs\n\nThe LLM drafts. GoalOS identifies proof debt. AGI Jobs execute missing proof. ProofBundles return. Validators decide what can be trusted.\n\nMissing evidence is no longer a vague TODO; it becomes executable work with acceptance tests, validator routes, blocked claims, and return artifacts.\n""",
"docs/capability-continuum-v75/OBJECTIVE_DIVERSITY_STANDARD.md":"""# Objective Diversity Standard\n\nGoalOS must generate materially different missions, claims, proof debt, AGI Jobs, ProofBundle templates, Evidence Dockets, and reviewer routes for unrelated objectives. The canonical regression pair is AI vendor trust room buyer readiness versus solar microgrid financing for a hospital campus.\n""",
"docs/capability-continuum-v75/AGIJOBMANAGER_BOUNDARY.md":"""# AGIJobManager Boundary\n\nLocal GoalOS prepares AGIJobManager-ready job specs, completion URI templates, validator rubrics, and ProofBundle import manifests. Live wallet connection, escrow, validator voting, disputes, and settlement belong to a separate human-confirmed dApp boundary.\n""",
"docs/capability-continuum-v75/PROOFBUNDLE_RETURN_GATE.md":"""# ProofBundle Return Gate\n\nA ProofBundle must include replay_result and validator_verdict. If either is missing, capability promotion remains HOLD. No ProofBundle, no settlement. No replay, no promotion.\n""",
"docs/capability-continuum-v75/EVIDENCE_DOCKET_61_PUBLIC_ROOM.md":"""# Evidence Docket 6.1 Public Room\n\nThe Evidence Docket is a proof room, not a marketing page. It contains claims, source provenance, proof packets, proof debt, blocked claims, risk ledger, baseline comparison, replay path, reviewer questions, public/private boundary, and claim boundary.\n""",
"docs/capability-continuum-v75/RSI_MOVE37_GATE.md":"""# RSI Move-37 Gate\n\nSearch control is not outcome authority. High novelty increases skepticism. A Move-37 candidate must be recognized, reproduced, stress-tested, shown persistent, and packaged as a dossier before institutional promotion.\n""",
"docs/capability-continuum-v75/ALPHA_WORK_UNIT_THERMOSTAT.md":"""# α-Work Unit Thermostat\n\nα‑Work Units are a proof-accounting concept for verified work. $AGIALPHA is treated as a utility/control rail in the architecture, not equity, not dividends, not profit rights, and not a guaranteed return.\n""",
"docs/capability-continuum-v75/EXTERNAL_REPLAY_REVIEWER_ROOM.md":"""# External Replay Reviewer Room\n\nA reviewer should be able to inspect the mission contract, proof debt, AGI Jobs, ProofBundles, Evidence Docket, cost/risk ledger, replay instructions, blocked claims, and falsification questions. External validation is not claimed until external evidence exists.\n""",
"docs/capability-continuum-v75/NOW_WE_PROVE_IT.md":"""# Now We Prove It\n\nThe next proof is Proof Run 001: a public-safe run with Mission Contract, Benchmark Contract, AGI Jobs, returned ProofBundles, Evidence Docket 6.1, reviewer room, and a Capability Promotion Gate that remains HOLD until replay and validation pass.\n""",
"docs/capability-continuum-v75/AUTONOMOUS_PUBLICATION_RULE.md":"""# Autonomous Publication Rule\n\nThe workflow is additive. It generates pages, reports, and artifacts; audits boundaries; refuses destructive deletions; commits or opens a PR; and deploys Pages only after audit. It must not move tokens, broadcast transactions, publish unsupported claims, or remove claim boundaries.\n"""
}
for rel, text in docs.items(): write_text(rel, text)

# Markdown index for website visitors.
write_text("public/capability-continuum-v75-readme.md", "# GoalOS Capability Continuum v75\n\nSee `capability-continuum-v75.html` and `release-bundle-vault-v75.html`.\n")

# Safe navigation patch.
def nav_block():
    links_html = ''.join(f'<a href="{href}">{label}</a>' for label, href in [
        ("Capability Continuum v75", "capability-continuum-v75.html"),
        ("Proof Debt → AGI Jobs", "proof-debt-job-router-v75.html"),
        ("Evidence Docket 6.1", "evidence-docket-61-dashboard-v75.html"),
        ("Bundle Vault", "release-bundle-vault-v75.html"),
        ("Now We Prove It", "now-we-prove-it-v75.html")
    ])
    return f"""\n<!-- {MARKER}_START -->\n<section id="goalos-capability-continuum-v75" style="margin:3rem auto;max-width:1180px;padding:1.25rem;border:1px solid rgba(104,255,241,.35);border-radius:24px;background:rgba(5,15,28,.88);color:#f6fbff;font-family:Inter,system-ui,sans-serif;">\n  <p style="margin:0 0 .35rem;color:#68fff1;font-weight:900;letter-spacing:.18em;text-transform:uppercase;">New incremental capability layer</p>\n  <h2 style="margin:.2rem 0 .7rem;font-size:clamp(1.6rem,3vw,2.6rem);">GoalOS Capability Continuum v75</h2>\n  <p style="color:#bdd0e4;max-width:820px;">Proof-gated open-ended work, release-bundle lineage, Proof Run 001 scaffolding, AGI Jobs dispatch, ProofBundle return gates, Evidence Docket 6.1, RSI governance, and external replay — added without deleting existing site content.</p>\n  <div style="display:flex;gap:.6rem;flex-wrap:wrap;margin-top:1rem;">{links_html}</div>\n  <p style="color:#ffe082;margin-top:1rem;">Boundary: no achieved AGI/ASI claim, no empirical SOTA claim, no wallet or transaction in local mode, no live settlement, no guaranteed ROI.</p>\n</section>\n<!-- {MARKER}_END -->\n"""

def patch_page(rel):
    if not PATCH_EXISTING_PAGES: return
    path = REPO / rel
    if not path.exists(): return
    text = path.read_text(encoding='utf-8', errors='ignore')
    if MARKER in text:
        skipped.append(rel + ' (nav already present)')
        return
    block = nav_block()
    lower = text.lower()
    idx = lower.rfind('</body>')
    if idx >= 0:
        new_text = text[:idx] + block + text[idx:]
    else:
        new_text = text + block
    path.write_text(new_text, encoding='utf-8')
    patched.append(rel)

if UPDATE_NAVIGATION:
    for rel in ["public/index.html", "public/goalos.html", "public/goalos-product-console.html", "public/all-pages.html", "public/site-map.html"]:
        patch_page(rel)

# Reports.
report = {
    "version":"goalos.incremental.capability-continuum.v75.install",
    "generated_at":NOW,
    "run_id":RUN_ID,
    "repository":REPOSITORY,
    "installed":installed,
    "copied":copied,
    "patched":patched,
    "skipped":skipped,
    "pages":list(pages.keys()),
    "bundles":BUNDLES,
    "boundary":"Additive; no backend, no wallet, no transaction, no user funds, no live settlement; no achieved AGI/ASI or empirical SOTA claim."
}
write_json("reports/goalos-capability-continuum-v75-install-report.json", report, overwrite=True)
md = "# GoalOS Capability Continuum v75 install report\n\n" + \
     f"Generated: {NOW}\n\n" + \
     f"Installed files: {len(installed)}\n\nCopied files: {len(copied)}\n\nPatched existing pages: {len(patched)}\n\nSkipped files: {len(skipped)}\n\n" + \
     "## New pages\n" + ''.join(f"- `public/{p}`\n" for p in pages) + \
     "\n## Boundary\n\nNo achieved AGI/ASI, no empirical SOTA, no wallet/transaction in local mode, no user funds, no live settlement, no guaranteed ROI.\n"
write_text("reports/goalos-capability-continuum-v75-install-report.md", md, overwrite=True)
print(json.dumps({"installed":len(installed),"copied":len(copied),"patched":len(patched),"skipped":len(skipped)}, indent=2))
