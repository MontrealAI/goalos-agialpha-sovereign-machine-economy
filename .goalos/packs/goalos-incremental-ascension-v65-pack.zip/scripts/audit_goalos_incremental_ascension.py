#!/usr/bin/env python3
from pathlib import Path
import json, os, re, sys
ROOT=Path.cwd(); MARKER='GOALOS_INCREMENTAL_ASCENSION_V65'; VERSION='v65'
required=[
 'public/proof-gated-universal-work-machine-v65.html','public/proof-run-001-command-room-v65.html','public/proof-debt-agijobs-compiler-v65.html','public/agialpha-proof-economy-thermostat-v65.html','public/evidence-docket-public-room-v65.html','public/verified-experience-chronicle-v65.html','public/ascension-evidence-hub-v65.html','public/assets/goalos-incremental-ascension-v65.css','public/assets/goalos-incremental-ascension-v65.js','docs/ascension/PROOF_GATED_UNIVERSAL_WORK_MACHINE.md','evidence/proof-run-001-v65/manifest.json','schemas/agijob-v65.schema.json']
forbidden=['fetch(','XMLHttpRequest','sendBeacon','window.ethereum','localStorage','sessionStorage','https://fonts.googleapis.com','<script src="http','<script src="//','<link rel="stylesheet" href="http']
errors=[]; warnings=[]
for rel in required:
    if not (ROOT/rel).exists(): errors.append(f'missing required file: {rel}')
for rel in ['public/index.html','public/goalos.html','public/all-pages.html']:
    if not (ROOT/rel).exists(): warnings.append(f'expected existing site file not found: {rel}')
for rel in required:
    p=ROOT/rel
    if p.exists() and p.suffix.lower() in ['.html','.js','.css','.md','.json']:
        text=p.read_text(encoding='utf-8',errors='ignore')
        if p.suffix.lower()=='.html' and MARKER not in text: errors.append(f'missing managed marker in {rel}')
        if p.suffix.lower()=='.html':
            for needle in ['does not claim achieved AGI','No ProofBundle, no settlement','No backend','No wallet','No transaction']:
                if needle not in text: errors.append(f'missing boundary phrase `{needle}` in {rel}')
        if rel.startswith('public/assets/goalos-incremental') or rel.startswith('public/proof') or rel.startswith('public/agi') or rel.startswith('public/evidence') or rel.startswith('public/verified') or rel.startswith('public/ascension'):
            for f in forbidden:
                if f in text: errors.append(f'forbidden local standalone/API token `{f}` in {rel}')
report={'version':VERSION,'marker':MARKER,'status':'fail' if errors else 'pass','errors':errors,'warnings':warnings,'required_files_checked':len(required),'claim_boundary_preserved':not errors,'deletes':'none'}
out=ROOT/'reports'; out.mkdir(exist_ok=True)
(out/'goalos-incremental-ascension-v65-audit-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
md=['# GoalOS Incremental Ascension V65 Audit Report','',f'Status: **{report["status"].upper()}**','','## Errors']
md += [f'- {e}' for e in errors] or ['- None']
md += ['','## Warnings'] + ([f'- {w}' for w in warnings] or ['- None'])
md += ['','## Boundary','No backend, no wallet, no transaction, no achieved AGI/ASI claim, no empirical SOTA claim, human review required.']
(out/'goalos-incremental-ascension-v65-audit-report.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
if errors and os.getenv('FAIL_ON_AUDIT_ERROR','true').lower()=='true': sys.exit(1)
