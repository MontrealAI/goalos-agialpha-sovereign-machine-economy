#!/usr/bin/env python3
from pathlib import Path
import os, json, shutil, datetime, re
MARKER='GOALOS_INCREMENTAL_ASCENSION_V65'
VERSION='v65'
BASE_URL='https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/'
ROUTES=[{"path": "proof-gated-universal-work-machine-v65.html", "title": "Proof-Gated Universal Work Machine", "tag": "Holy Grail Candidate", "desc": "GoalOS as a proof-gated universal work machine: open-ended autonomous work, Evidence Dockets, ProofBundles, Chronicle, and settlement boundaries."}, {"path": "proof-run-001-command-room-v65.html", "title": "Proof Run 001 Command Room", "tag": "Next Proof", "desc": "The public-safe plan for moving from architecture to inspectable Evidence Docket proof."}, {"path": "proof-debt-agijobs-compiler-v65.html", "title": "Proof Debt → AGI Jobs Compiler", "tag": "Dynamic Tool", "desc": "A browser-local compiler that turns unsupported claims and missing evidence into objective-specific AGI Jobs."}, {"path": "agialpha-proof-economy-thermostat-v65.html", "title": "$AGIALPHA Proof Economy Thermostat", "tag": "Settlement Boundary", "desc": "How proof quality, validator pressure, challenge windows, and settlement logic become economic control signals without overclaiming."}, {"path": "evidence-docket-public-room-v65.html", "title": "Evidence Docket 6.1 Public Room", "tag": "Proof Room", "desc": "Claims, proof debt, risks, ProofBundles, blocked claims, verifier questions, and public/private boundaries."}, {"path": "verified-experience-chronicle-v65.html", "title": "Verified Experience Chronicle", "tag": "Compounding Memory", "desc": "How validated work becomes Chronicle memory, reusable capability, and harder future missions."}, {"path": "ascension-evidence-hub-v65.html", "title": "Ascension Evidence Hub", "tag": "Evidence Hub", "desc": "Public index of new pages, docs, routes, proof run artifacts, and incremental capability status."}]
ROOT=Path.cwd()
SRC=Path(__file__).resolve().parents[1]/'payload'
ALLOW=os.getenv('ALLOW_OVERWRITE','false').lower()=='true'
UPDATE_NAV=os.getenv('UPDATE_NAV','true').lower()=='true'
PATCH_EXISTING=os.getenv('PATCH_EXISTING_PAGES','true').lower()=='true'
RUN_ID=os.getenv('GITHUB_RUN_ID','local')
BACKUP_DIR=ROOT/'.goalos'/'backups'/f'incremental-ascension-{VERSION}'/RUN_ID
added=[]; overwritten=[]; skipped=[]; patched=[]; backups=[]

def backup(path):
    if not path.exists(): return None
    dest=BACKUP_DIR/path.relative_to(ROOT)
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dest)
    backups.append(str(dest.relative_to(ROOT)))
    return dest

def managed(path):
    try: return MARKER in path.read_text(encoding='utf-8',errors='ignore')
    except Exception: return False

def copy_tree():
    for src in SRC.rglob('*'):
        if src.is_dir(): continue
        rel=src.relative_to(SRC); dst=ROOT/rel; dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists():
            if ALLOW or managed(dst):
                backup(dst); shutil.copy2(src,dst); overwritten.append(str(rel))
            else:
                skipped.append(str(rel))
        else:
            shutil.copy2(src,dst); added.append(str(rel))

def nav_block():
    links=''.join([f'<a href="./{r["path"]}" style="display:inline-block;margin:4px 8px 4px 0;padding:11px 14px;border-radius:999px;background:rgba(85,242,231,.12);border:1px solid rgba(85,242,231,.35);color:inherit;text-decoration:none;font-weight:800">{r["title"]}</a>' for r in ROUTES[:6]])
    return f'''<!-- {MARKER}_NAV_START -->\n<section data-goalos-managed="{MARKER}" style="margin:32px auto;padding:24px;max-width:1180px;border:1px solid rgba(255,224,122,.35);border-radius:24px;background:linear-gradient(135deg,rgba(255,224,122,.12),rgba(85,242,231,.08));font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:inherit">\n  <strong style="display:block;font-size:22px;margin-bottom:8px">New: GoalOS Incremental Ascension V65</strong>\n  <p style="line-height:1.55;margin:0 0 14px">Proof-gated universal work machine, Proof Run 001 command room, Proof Debt → AGI Jobs compiler, Evidence Docket public room, and Chronicle compounding layer. Existing pages preserved.</p>\n  {links}\n</section>\n<!-- {MARKER}_NAV_END -->'''

def patch_file(rel):
    path=ROOT/rel
    if not path.exists(): return
    text=path.read_text(encoding='utf-8',errors='ignore')
    block=nav_block()
    start=f'<!-- {MARKER}_NAV_START -->'; end=f'<!-- {MARKER}_NAV_END -->'
    if start in text and end in text:
        new=re.sub(re.escape(start)+r'.*?'+re.escape(end),block,text,flags=re.S)
    elif '</body>' in text:
        new=text.replace('</body>',block+'\n</body>',1)
    else:
        new=text+'\n'+block+'\n'
    if new!=text:
        backup(path); path.write_text(new,encoding='utf-8'); patched.append(rel)

def patch_sitemap():
    p=ROOT/'public/sitemap.xml'
    urls=''.join([f'  <url><loc>{BASE_URL}{r["path"]}</loc></url>\n' for r in ROUTES])
    if p.exists():
        text=p.read_text(encoding='utf-8',errors='ignore')
        missing=[r for r in ROUTES if r['path'] not in text]
        if not missing: return
        insert=''.join([f'  <url><loc>{BASE_URL}{r["path"]}</loc></url>\n' for r in missing])
        new=text.replace('</urlset>',insert+'</urlset>') if '</urlset>' in text else text+'\n'+insert
        backup(p); p.write_text(new,encoding='utf-8'); patched.append('public/sitemap.xml')
    else:
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+urls+'</urlset>\n',encoding='utf-8')
        added.append('public/sitemap.xml')

def write_report():
    report={'version':VERSION,'marker':MARKER,'created_at':datetime.datetime.utcnow().isoformat()+'Z','run_id':RUN_ID,'added':added,'overwritten':overwritten,'skipped_existing_unmanaged':skipped,'patched':patched,'backups':backups,'routes':ROUTES,'policy':{'allow_overwrite':ALLOW,'update_nav':UPDATE_NAV,'patch_existing_pages':PATCH_EXISTING,'deletes':'none'}}
    out=ROOT/'reports'; out.mkdir(exist_ok=True)
    (out/'goalos-incremental-ascension-v65-install-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    md=['# GoalOS Incremental Ascension V65 Install Report','',f'- Added: {len(added)}',f'- Patched: {len(patched)}',f'- Overwritten managed/allowed: {len(overwritten)}',f'- Skipped existing unmanaged: {len(skipped)}','','## Routes']
    md += [f'- `{r["path"]}` — {r["title"]}' for r in ROUTES]
    md += ['','## Safety','No files were deleted. Existing files were patched only by explicit marker insertion or preserved when unmanaged.']
    (out/'goalos-incremental-ascension-v65-install-report.md').write_text('\n'.join(md)+'\n',encoding='utf-8')

copy_tree()
if UPDATE_NAV and PATCH_EXISTING:
    for rel in ['public/index.html','public/goalos.html','public/all-pages.html','public/site-map.html']:
        patch_file(rel)
patch_sitemap()
write_report()
print(json.dumps({'status':'ok','added':len(added),'patched':len(patched),'skipped':len(skipped)},indent=2))
