#!/usr/bin/env python3
import os, shutil
from pathlib import Path

EXCLUDE_DIRS = {'.git', '.github', '.goalos', '_goalos_pack', '_site', 'node_modules', '.venv', '__pycache__'}
EXCLUDE_PREFIXES = ('GoalOS-One-Click-Autopilot-Upload',)

def copy_tree(src, dst, overwrite=False):
    if not src.exists(): return 0
    count = 0
    for p in src.rglob('*'):
        rel = p.relative_to(src)
        if any(part in EXCLUDE_DIRS for part in rel.parts): continue
        if p.is_dir(): continue
        if p.name.startswith('.git'): continue
        target = dst/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and not overwrite:
            continue
        shutil.copy2(p, target); count += 1
    return count

def main():
    repo = Path(os.environ.get('GITHUB_WORKSPACE','.')).resolve()
    site = repo/'_site'
    if site.exists(): shutil.rmtree(site)
    site.mkdir(parents=True)
    base = None
    # Prefer an existing public site unless its index is the generated default and root/docs had a homepage.
    public_index = repo/'public/index.html'
    root_index = repo/'index.html'
    docs_index = repo/'docs/index.html'
    public_text = public_index.read_text(encoding='utf-8', errors='ignore') if public_index.exists() else ''
    if public_index.exists() and 'goalos-default-index="true"' not in public_text:
        base = repo/'public'
    elif docs_index.exists():
        base = repo/'docs'
    elif root_index.exists():
        base = repo
    elif (repo/'public').exists():
        base = repo/'public'
    else:
        base = repo
    if base == repo:
        # Copy root site carefully, then merge public additions without overwriting root home.
        for item in repo.iterdir():
            if item.name in EXCLUDE_DIRS or item.name.startswith('.') or item.name in {'scripts','tests'}: continue
            if item.is_file() and item.suffix.lower() in {'.html','.css','.js','.json','.svg','.png','.jpg','.jpeg','.webp','.ico','.txt','.xml'}:
                shutil.copy2(item, site/item.name)
            elif item.is_dir() and item.name in {'assets','downloads','images','img','css','js','media'}:
                copy_tree(item, site/item.name, overwrite=False)
    else:
        copy_tree(base, site, overwrite=False)
    # Merge installed public files, preserving existing index if present.
    copy_tree(repo/'public', site, overwrite=False)
    (site/'.nojekyll').write_text('', encoding='utf-8')
    print(f'Built Pages artifact at {site} from base {base}')
if __name__ == '__main__': main()
