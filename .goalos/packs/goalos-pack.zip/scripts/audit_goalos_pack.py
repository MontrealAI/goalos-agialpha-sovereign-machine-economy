#!/usr/bin/env python3
import json, os, re, sys, datetime
from pathlib import Path

FORBIDDEN = ["fetch(", "XMLHttpRequest", "sendBeacon", "window.ethereum", "localStorage", "sessionStorage", "<script src", "fonts.googleapis", "http://", "https://"]
REQUIRED = [
    "public/goalos.html",
    "public/goalos-product-console.html",
    "public/capabilities/index.html",
    "public/capabilities/goalos-v38/index.html",
    "public/standalone-reviewer-proof-room.html",
    "public/proof-event-001-ai-trust-room-vs-vendor-faq.html",
    "public/downloads/index.html",
    "public/strategic-communications/index.html",
    "public/assets/goalos-route-registry.json",
    "evidence/proof-event-001/evidence-docket-61.json",
    "reports/goalos-v38-validation.json",
]

def main():
    repo = Path(os.environ.get("GITHUB_WORKSPACE", ".")).resolve()
    errors, warnings = [], []
    for rel in REQUIRED:
        if not (repo/rel).exists(): errors.append(f"missing required file: {rel}")
    console = repo/"public/goalos-product-console.html"
    text = console.read_text(encoding="utf-8", errors="ignore") if console.exists() else ""
    hits = {term: text.count(term) for term in FORBIDDEN if text.count(term)}
    # Allow JSON schema identifier only outside standalone; console must remain clean.
    if hits: errors.append(f"forbidden standalone references: {hits}")
    if "achieved AGI" not in text or "No backend" not in text:
        warnings.append("standalone boundary language may be incomplete")
    strategic = repo/"public/strategic-communications/index.html"
    strategic_text = strategic.read_text(encoding="utf-8", errors="ignore") if strategic.exists() else ""
    if strategic.exists() and "AI creates output. GoalOS creates proof" not in strategic_text:
        errors.append("strategic communications page missing canonical proof positioning")
    if strategic.exists() and "does not claim achieved AGI" not in strategic_text:
        warnings.append("strategic communications claim boundary may be incomplete")
    docs = list((repo/"docs").glob("*.md")) if (repo/"docs").exists() else []
    if len(docs) < 40: errors.append(f"documentation series too small: {len(docs)} docs found")
    downloads = list((repo/"public/downloads").glob("*.zip")) if (repo/"public/downloads").exists() else []
    if len(downloads) < 1: errors.append("no downloadable ZIP artifacts found under public/downloads")
    route = repo/"public/assets/goalos-route-registry.json"
    if route.exists():
        try:
            data = json.loads(route.read_text(encoding="utf-8"))
            if len(data.get("routes", [])) < 5: errors.append("route registry has too few routes")
        except Exception as e: errors.append(f"route registry JSON parse failed: {e}")
    result = {
        "audited_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z",
        "status": "pass" if not errors else "fail",
        "required_file_count": len(REQUIRED),
        "documentation_documents": len(docs),
        "download_artifacts": [p.name for p in downloads],
        "forbidden_local_standalone_hits": hits,
        "claim_boundary_preserved": not hits,
        "wallet_boundary_preserved": "window.ethereum" not in hits,
        "errors": errors,
        "warnings": warnings,
    }
    (repo/"reports").mkdir(exist_ok=True)
    (repo/"reports/goalos-autopilot-audit-report.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    md = ["# GoalOS Autopilot Audit Report", "", f"Status: **{result['status'].upper()}**", "", f"Docs: {len(docs)}", f"Download artifacts: {len(downloads)}", "", "## Errors", *(f"- {e}" for e in errors), "", "## Warnings", *(f"- {w}" for w in warnings)]
    (repo/"reports/goalos-autopilot-audit-report.md").write_text("\n".join(md)+"\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    fail = os.environ.get("GOALOS_FAIL_ON_AUDIT_ERROR", "true").lower() == "true"
    if errors and fail: sys.exit(1)
if __name__ == "__main__": main()
