#!/usr/bin/env python3
import argparse, json, os, shutil, datetime
from pathlib import Path

MARK = "GOALOS_AUTOPILOT_MANAGED"

def read_text(p):
    try: return p.read_text(encoding="utf-8", errors="ignore")
    except Exception: return ""

def is_managed(p):
    if not p.exists() or p.is_dir(): return False
    if p.suffix.lower() in {".html", ".md", ".json", ".txt", ".css", ".js"}:
        return MARK in read_text(p)
    return False

def copy_additive(src_root, repo, allow_overwrite=False):
    report = {"created": [], "updated": [], "skipped_existing": [], "same": []}
    for src in sorted(src_root.rglob("*")):
        if src.is_dir(): continue
        rel = src.relative_to(src_root)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            if dst.read_bytes() == src.read_bytes():
                report["same"].append(str(rel)); continue
            if allow_overwrite or is_managed(dst):
                shutil.copy2(src, dst); report["updated"].append(str(rel)); continue
            report["skipped_existing"].append(str(rel)); continue
        shutil.copy2(src, dst)
        report["created"].append(str(rel))
    return report

def patch_homepage(repo):
    block = '''
<!-- GOALOS_AUTOPILOT_LINK_START -->
<section style="margin:32px auto;padding:24px;max-width:1100px;border:1px solid rgba(255,224,122,.35);border-radius:24px;background:linear-gradient(135deg,rgba(255,224,122,.12),rgba(85,242,231,.08));font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:inherit">
  <strong style="display:block;font-size:22px;margin-bottom:8px">GoalOS AGIALPHA Ascension is installed.</strong>
  <p style="line-height:1.55;margin:0 0 14px">Open the proof-gated work machine: objective → mission → proof debt → AGI Jobs → ProofBundles → Evidence Docket → Chronicle hold.</p>
  <a href="./goalos.html" style="display:inline-block;margin:4px 8px 4px 0;padding:11px 14px;border-radius:999px;background:#ffe07a;color:#061018;text-decoration:none;font-weight:800">Open GoalOS</a>
  <a href="./goalos-product-console.html" style="display:inline-block;margin:4px 8px 4px 0;padding:11px 14px;border-radius:999px;border:1px solid currentColor;color:inherit;text-decoration:none;font-weight:800">Open V38 Console</a>
  <a href="./strategic-communications/" style="display:inline-block;margin:4px 8px 4px 0;padding:11px 14px;border-radius:999px;border:1px solid currentColor;color:inherit;text-decoration:none;font-weight:800">Open Strategic Communications</a>
</section>
<!-- GOALOS_AUTOPILOT_LINK_END -->
'''
    candidates = [repo/"index.html", repo/"docs/index.html", repo/"public/index.html"]
    target = next((p for p in candidates if p.exists()), None)
    if not target:
        return {"patched": False, "reason": "no existing homepage; payload public/index.html will be used"}
    text = read_text(target)
    if "GOALOS_AUTOPILOT_LINK_START" in text:
        return {"patched": False, "reason": f"homepage already has GoalOS link: {target}"}
    if len(text) > 900_000:
        return {"patched": False, "reason": f"homepage too large for safe patch: {target}"}
    lower = text.lower()
    if "</body>" in lower:
        idx = lower.rfind("</body>")
        text = text[:idx] + block + text[idx:]
    else:
        text += block
    target.write_text(text, encoding="utf-8")
    return {"patched": True, "path": str(target.relative_to(repo))}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--pack", default="_goalos_pack")
    ap.add_argument("--allow-overwrite", default="false")
    args = ap.parse_args()
    repo = Path(args.repo).resolve(); pack = Path(args.pack).resolve()
    payload = pack/"payload"
    if not payload.exists(): raise SystemExit(f"Payload not found: {payload}")
    allow = str(args.allow_overwrite).lower() == "true"
    report = copy_additive(payload, repo, allow)
    home = patch_homepage(repo)
    (repo/".goalos").mkdir(exist_ok=True)
    final = {"installed_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z", "allow_overwrite": allow, "copy_report": report, "homepage": home, "claim_boundary":"No achieved AGI/ASI, SOTA, certification, live settlement, wallet authorization, or guaranteed ROI claim."}
    (repo/".goalos/autopilot-installed.json").write_text(json.dumps(final, indent=2), encoding="utf-8")
    (repo/"reports").mkdir(exist_ok=True)
    (repo/"reports/goalos-autopilot-install-report.json").write_text(json.dumps(final, indent=2), encoding="utf-8")
    md = ["# GoalOS Autopilot Install Report", "", f"Installed at: `{final['installed_at']}`", "", "## Summary", "", f"Created: {len(report['created'])}", f"Updated: {len(report['updated'])}", f"Skipped existing protected files: {len(report['skipped_existing'])}", f"Homepage patch: {home}", "", "## Claim boundary", "", final['claim_boundary']]
    (repo/"reports/goalos-autopilot-install-report.md").write_text("\n".join(md)+"\n", encoding="utf-8")
    print(json.dumps(final, indent=2))
if __name__ == "__main__": main()
