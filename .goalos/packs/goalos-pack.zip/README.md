# GoalOS Autopilot Pack

This inner pack is executed by `.github/workflows/goalos-autopilot.yml`.

It installs the GoalOS V38 public website layer, docs, schemas, evidence, downloads, reports, and route registry without deleting existing website files.


## v2 Strategic Communications Add-on

Adds `public/strategic-communications/index.html`, `docs/45_STRATEGIC_COMMUNICATIONS_PRESENTATION.md`, and a route-registry entry. Installation remains additive and preserves existing non-GoalOS files unless allow_overwrite is explicitly true.
