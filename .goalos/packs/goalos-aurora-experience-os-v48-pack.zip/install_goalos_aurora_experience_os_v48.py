#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, re, html, os, shutil
from pathlib import Path
from urllib.parse import urlparse, unquote
from datetime import datetime, timezone

VERSION='v48'
ROOT=Path.cwd()
PUBLIC=ROOT/'public'
ASSETS=PUBLIC/'assets'
REPORTS=ROOT/'reports'
DOCS=ROOT/'docs'
CONTENT=ROOT/'content'/'goalos'
EVIDENCE=ROOT/'evidence'/'demo'
EXAMPLES=ROOT/'examples'/'aurora-experience-os-v48'
BANNED=['send'+'Beacon','local'+'Storage','session'+'Storage','window.'+'ethereum','XML'+'HttpRequest','fetch(']

KEY_ROUTES=[
('index.html','GoalOS Aurora Command Center','Tell GoalOS what you want. One command center for the complete proof-governed public surface.'),
('goalos-aurora-command-center.html','GoalOS Aurora Command Center','The premium colored GoalOS front door.'),
('goalos-command-center.html','GoalOS Command Center','Operate the proof-governed public surface.'),
('goalos-gold-master.html','GoalOS Gold Master','Public-alpha release checkpoint and command surface.'),
('public-alpha-gold-master.html','Public Alpha Gold Master','Public-alpha boundary and release checkpoint.'),
('autonomy-theatre.html','Autonomy Theatre','Run the complete objective to proof to validation to Chronicle demonstration.'),
('agi-agent-workbench.html','AGI Agent Workbench','Turn a plain-language objective into agents, jobs, node handoff, proof, and validation.'),
('agi-agent-run-theatre.html','AGI Agent Run Theatre','Watch browser-local agent work become reviewable proof.'),
('agent-flow-academy-v38.html','Agent Flow Academy','Understand the GoalOS flow visually.'),
('agent-flow-academy.html','Agent Flow Academy','Understand the GoalOS flow visually.'),
('visual-flow-proof.html','Visual Flow Proof','Clean aligned proof-flow graph.'),
('ux-proof-check.html','UX Proof Check','Human visual quality checklist.'),
('validation-control-tower.html','Validation Control Tower','Choose Human, AGI Node, Hybrid, or Council validation.'),
('mainnet-contract-atlas.html','48 Mainnet Contract Atlas','Explore the 48 GoalOS-created Ethereum Mainnet contracts as a proof rail.'),
('mainnet-proof-rail.html','Mainnet Proof Rail','Walk through the contract-backed proof rail.'),
('contract-academy.html','Contract Academy','Learn the contract system in plain language.'),
('ask-goalos.html','Ask GoalOS','Browser-local route assistant.'),
('site-map.html','All Pages','Complete route surface.'),
('all-pages.html','All Pages','Complete route surface.'),
('route-registry.html','Route Registry','Machine-readable route inventory.'),
('search.html','Search','Browser-local route search.'),
('site-health.html','Site Health','Route, asset, boundary, and visual QA status.'),
('trust-boundary.html','Trust Boundary','No data, no funds, no wallet, no production authority.'),
('token-boundary.html','Token Boundary','$AGIALPHA public contract identification boundary.'),
('graduation-control-room.html','Graduation Control Room','The gated path toward production authorization.'),
('production-readiness-gauntlet.html','Production Readiness Gauntlet','Hard gates before production authorization.'),
('external-validation-roadmap.html','External Validation Roadmap','External replay and independent review roadmap.'),
('evidence-to-production-roadmap.html','Evidence to Production Roadmap','Evidence ladder toward production.'),
('proof-run-001-docket.html','Proof Run 001 Docket','Repository readiness evidence docket.'),
('proof-run-001.html','Proof Run 001','Proof-gated autonomous work route.'),
('proof-ledger.html','Proof Ledger','Public proof ledger.'),
('proof-console.html','Proof Console','Mission proof console.'),
('evidence-docket-theatre.html','Evidence Docket Theatre','Evidence Docket public-safe demo.'),
('falsification-gauntlet.html','Falsification Gauntlet','Stress-test claims before promotion.'),
('loop-to-rsi.html','Loop to RSI','Loop-to-RSI governance route.'),
('from-loop-to-rsi-state-capacity.html','From Loop to RSI','State-capacity proof path.'),
('rsi-state-capacity.html','RSI State Capacity','Governed recursive-improvement state capacity.'),
('move37-dossier.html','Move-37 Dossier','High-novelty claim handling.'),
('docs.html','Docs','GoalOS documentation hub.'),
('privacy.html','Privacy','Privacy and public-alpha data boundary.'),
('data-boundary.html','Data Boundary','Data boundary and public/private separation.'),
('no-data-no-funds.html','No Data No Funds','Plain-language public-alpha boundary.'),
]
PLAYBOOKS=[
('Understand GoalOS in 10 minutes','I am new and want the fastest path to understand GoalOS.','Command Center → Autonomy Theatre → All Pages'),
('Run the end-to-end proof demo','I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.','Autonomy Theatre → Visual Flow Proof → UX Proof Check'),
('Learn the 48 Mainnet contracts','I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.','Contract Atlas → Contract Academy → Mainnet Proof Rail'),
('Validate a proof path','I want to validate a public-safe proof path with AGI Node precheck and Human final review.','Validation Control Tower → Human QA → Site Health'),
('Evaluate an AI vendor','I want to evaluate an AI vendor using evidence, not marketing claims.','AGI Agent Workbench → Evidence Docket → Validation'),
('Prepare for production graduation','I want to understand the gates before production authorization.','Graduation Control Room → Production Readiness → External Validation'),
]
FLOW=[
('01','Objective','Plain-language user goal.'),('02','Mission Contract','Scope, success criteria, constraints, risk class.'),('03','AGI Agents','Architect, planner, research, builder, verifier, sentinel.'),('04','AGI Job','Bounded work package with gates.'),('05','AGI Node Handoff','Deterministic review packet.'),('06','ProofBundle','Artifacts, hashes, logs, replay path.'),('07','Evidence Docket','Claims, evidence, risks, contradictions.'),('08','Validation','Human, AGI Node, Hybrid, or Council.'),('09','Chronicle','Accepted memory and decision record.'),('10','Reusable Capability','What improves the next mission.'),
]
AGENTS=[('ARC','Architect','Frames the objective'),('PLN','Planner','Builds the Mission Contract'),('RES','Research','Maps public-safe evidence'),('BLD','Builder','Creates artifacts'),('VRF','Verifier','Checks claims'),('WRK','AGI Node Worker','Prepares deterministic handoff'),('VAL','AGI Node Validator','Runs deterministic checks'),('SNT','Sentinel','Watches boundary'),('DCK','Docket','Packages evidence'),('CHR','Chronicle','Records memory'),('HUM','Human','Reviews judgment-heavy decisions'),('CNL','Council','Handles high-novelty governance')]
CSS=r'''
:root{--deep:#030712;--navy:#071225;--ink:#f7fbff;--muted:#b8c8e8;--line:rgba(143,226,255,.24);--glass:rgba(7,18,37,.74);--panel:rgba(9,24,47,.86);--mint:#65ffd7;--cyan:#80e9ff;--gold:#ffe86a;--lime:#caff7a;--violet:#ad9dff;--pink:#ff7ab6;--shadow:0 30px 110px rgba(0,0,0,.45)}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-height:100vh;color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:radial-gradient(circle at 10% 12%,rgba(101,255,215,.31),transparent 28%),radial-gradient(circle at 78% 7%,rgba(173,157,255,.32),transparent 32%),radial-gradient(circle at 70% 86%,rgba(128,233,255,.20),transparent 30%),linear-gradient(135deg,#031214 0%,#071b31 43%,#07071a 100%)!important;overflow-x:hidden}body:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px,transparent 1px);background-size:42px 42px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.95),rgba(0,0,0,.18));z-index:0}body:after{content:"GOALOS";position:fixed;left:-3vw;bottom:-8vw;font-weight:1000;font-size:24vw;letter-spacing:-.11em;color:rgba(255,255,255,.035);pointer-events:none;z-index:0}.gx47{position:relative;z-index:1}.gx47-shell{width:min(1220px,calc(100vw - 42px));margin:0 auto;padding:22px 0 96px}.gx47-nav{position:sticky;top:12px;z-index:100;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin:0 auto 42px;padding:14px 18px;border:1px solid rgba(128,233,255,.28);border-radius:30px;background:linear-gradient(135deg,rgba(3,7,18,.94),rgba(8,21,42,.80));box-shadow:var(--shadow);backdrop-filter:blur(18px)}.gx47-brand{display:flex;align-items:center;gap:13px;color:var(--ink)!important;text-decoration:none!important}.gx47-logo{width:45px;height:45px;border-radius:16px;display:grid;place-items:center;background:radial-gradient(circle at 25% 25%,var(--gold),var(--mint) 42%,var(--cyan) 69%,var(--violet));box-shadow:0 0 34px rgba(101,255,215,.36);color:#06111f;font-weight:1000}.gx47-brand strong{display:block;font-size:14px;letter-spacing:.18em;text-transform:uppercase}.gx47-brand small{display:block;color:#aab9d6;letter-spacing:.28em;text-transform:uppercase;font-size:10px}.gx47-navlinks{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.gx47-navlinks a,.gx47-btn,.gx47-chip{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:10px 14px;background:rgba(255,255,255,.075);color:var(--ink)!important;text-decoration:none!important;font-weight:950;font-size:13px;line-height:1}.gx47-navlinks a:hover,.gx47-btn:hover{background:rgba(101,255,215,.16);border-color:rgba(101,255,215,.54)}.gx47-primary,.gx47-navlinks a[aria-current="page"]{background:linear-gradient(135deg,var(--gold),var(--lime),var(--mint))!important;color:#031214!important;border-color:transparent!important;box-shadow:0 14px 42px rgba(101,255,215,.22)}.gx47-hero{display:grid;grid-template-columns:minmax(0,1.03fr) minmax(360px,.97fr);gap:36px;align-items:center;min-height:calc(100vh - 170px)}.gx47-hero.tight{min-height:0;align-items:start}.gx47-kicker{display:flex;align-items:center;gap:10px;color:var(--gold);font-size:12px;line-height:1.25;font-weight:1000;letter-spacing:.34em;text-transform:uppercase}.gx47-kicker:before{content:"";width:10px;height:10px;border-radius:50%;background:var(--mint);box-shadow:0 0 26px var(--mint)}.gx47-title{margin:16px 0 18px;font-size:clamp(48px,8vw,108px);line-height:.88;letter-spacing:-.085em;max-width:930px;color:var(--ink)}.gx47-title em{font-family:Georgia,ui-serif,serif;font-style:italic;font-weight:800;letter-spacing:-.058em;background:linear-gradient(100deg,var(--gold),var(--lime),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}.gx47-copy{max-width:780px;color:var(--muted);font-size:clamp(18px,2.2vw,24px);line-height:1.36;font-weight:750}.gx47-panel,.gx47-console,.gx47-card,.gx47-mission{border:1px solid var(--line);border-radius:28px;background:linear-gradient(145deg,rgba(255,255,255,.09),rgba(255,255,255,.045));box-shadow:var(--shadow);backdrop-filter:blur(18px)}.gx47-panel{padding:28px}.gx47-console{padding:22px;background:linear-gradient(145deg,rgba(8,21,42,.90),rgba(10,29,54,.72))}.gx47-console-head{display:flex;justify-content:space-between;gap:12px;align-items:center;border-bottom:1px solid rgba(255,255,255,.13);padding-bottom:14px;margin-bottom:18px}.gx47-console-head span{font-weight:1000;letter-spacing:.23em;text-transform:uppercase;font-size:12px}.gx47-status{border-radius:999px;background:rgba(101,255,215,.16);border:1px solid rgba(101,255,215,.45);padding:8px 12px;color:var(--mint);font-size:12px}.gx47-agent-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.gx47-agent{min-height:74px;border:1px solid rgba(128,233,255,.25);border-radius:18px;background:rgba(255,255,255,.075);padding:12px;display:flex;flex-direction:column;justify-content:center}.gx47-agent b{color:var(--mint);font-size:12px;letter-spacing:.16em}.gx47-agent span{color:#dbe8ff;font-weight:850;font-size:13px}.gx47-flow{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin-top:20px}.gx47-step{position:relative;min-height:150px;border-radius:22px;border:1px solid rgba(128,233,255,.24);background:linear-gradient(145deg,rgba(255,255,255,.105),rgba(255,255,255,.045));padding:16px;overflow:hidden}.gx47-step:before{content:attr(data-num);display:inline-grid;place-items:center;width:34px;height:34px;border-radius:12px;background:linear-gradient(135deg,var(--gold),var(--mint));color:#04131c;font-weight:1000;margin-bottom:22px}.gx47-step h3{margin:0 0 8px;font-size:18px}.gx47-step p{margin:0;color:var(--muted);font-weight:650;line-height:1.35}.gx47-mission{margin-top:22px;padding:18px}.gx47-mission label{display:block;margin-bottom:10px;color:var(--gold);font-weight:1000;letter-spacing:.25em;text-transform:uppercase;font-size:11px}.gx47-mission textarea{width:100%;min-height:140px;border:1px solid rgba(128,233,255,.24);border-radius:22px;padding:18px;background:rgba(1,6,14,.74);color:var(--ink);font:800 17px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical}.gx47-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}.gx47-section{margin-top:70px}.gx47-section h2{font-size:clamp(34px,5vw,68px);line-height:.96;letter-spacing:-.055em;margin:10px 0 18px}.gx47-card-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.gx47-card{padding:22px;min-height:190px}.gx47-card h3{margin:0 0 10px;font-size:24px;letter-spacing:-.035em}.gx47-card p,.gx47-card li{color:var(--muted);font-weight:650;line-height:1.45}.gx47-route-grid{display:grid;grid-template-columns:1fr;gap:10px}.gx47-route{display:grid;grid-template-columns:150px minmax(0,1fr) auto;gap:18px;align-items:center;border:1px solid rgba(128,233,255,.20);border-radius:18px;background:rgba(255,255,255,.065);padding:14px;text-decoration:none!important;color:var(--ink)!important}.gx47-route small{color:var(--gold);font-weight:950;text-transform:uppercase;letter-spacing:.18em}.gx47-route b{display:block}.gx47-route span{color:var(--muted);font-weight:650}.gx47-pre{white-space:pre-wrap;border:1px solid rgba(101,255,215,.25);border-radius:18px;background:rgba(1,6,14,.72);padding:16px;color:var(--mint);font:800 13px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace}.gx47-bottom-actions{position:fixed;right:18px;bottom:18px;z-index:80;display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;max-width:calc(100vw - 36px)}.gx47-bottom-actions a,.gx47-bottom-actions button{border:none;border-radius:999px;padding:12px 16px;background:linear-gradient(135deg,#0b7b70,#0e9f8a);color:#fff;font-weight:1000;text-decoration:none;box-shadow:0 16px 44px rgba(0,0,0,.32)}.gx47-bottom-actions .light{background:linear-gradient(135deg,var(--gold),var(--mint));color:#04131c}.gx47-boundary{margin-top:30px;border:1px solid rgba(255,122,182,.35);background:rgba(255,122,182,.08);border-radius:22px;padding:16px;color:#ffe8f2;font-weight:760}.gx47-footer{margin-top:80px;padding:30px 0;color:#aebbd5}.gx47-ask{position:fixed;inset:auto 18px 86px auto;width:min(420px,calc(100vw - 36px));z-index:90;border:1px solid rgba(128,233,255,.32);border-radius:24px;background:rgba(4,10,22,.96);box-shadow:var(--shadow);display:none}.gx47-ask.open{display:block}.gx47-ask header{display:flex;justify-content:space-between;align-items:center;padding:16px;border-bottom:1px solid rgba(255,255,255,.13)}.gx47-ask textarea{width:calc(100% - 28px);margin:14px;min-height:80px;border-radius:16px;border:1px solid rgba(128,233,255,.25);background:#020817;color:var(--ink);padding:12px}.gx47-ask .answer{padding:0 14px 14px;color:var(--muted);font-weight:650}.gx47-meters{display:grid;gap:12px}.gx47-meter span{display:flex;justify-content:space-between;font-weight:900}.gx47-bar{height:10px;border-radius:999px;background:rgba(255,255,255,.13);overflow:hidden}.gx47-bar i{display:block;width:var(--w,90%);height:100%;background:linear-gradient(90deg,var(--mint),var(--cyan),var(--violet))}body:not(.gx47) .gx47-nav,body:not(.gx47) .gx47-bottom-actions{display:none}.aurora-compat main,.aurora-compat .wrap,.aurora-compat .container{max-width:1220px!important;margin-left:auto!important;margin-right:auto!important}.aurora-compat section{scroll-margin-top:100px}.aurora-compat .flow-line,.aurora-compat .connector,.aurora-compat .orbit-line{pointer-events:none!important;z-index:0!important}.aurora-compat .agent-orbit,.aurora-compat .console-orbit{overflow:visible!important}.aurora-compat h1{overflow-wrap:anywhere}@media(max-width:980px){.gx47-hero{grid-template-columns:1fr;min-height:0}.gx47-flow{grid-template-columns:repeat(2,minmax(0,1fr))}.gx47-card-grid{grid-template-columns:1fr}.gx47-route{grid-template-columns:1fr}.gx47-title{font-size:clamp(46px,14vw,80px)}.gx47-bottom-actions{position:static;margin-top:30px;justify-content:flex-start}.gx47-shell{padding-bottom:40px}}@media(max-width:560px){.gx47-shell{width:min(100% - 24px,1220px)}.gx47-agent-grid,.gx47-flow{grid-template-columns:1fr}.gx47-nav{position:relative;top:auto}.gx47-navlinks{justify-content:flex-start}.gx47-panel,.gx47-console{padding:18px}.gx47-title{font-size:46px}.gx47-copy{font-size:17px}}
'''
JS=r'''
(function(){
  const routes = window.GOALOS_ROUTES_V48 || [];
  const $=(s,r=document)=>r.querySelector(s);
  const objectiveDefaults={contracts:'I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.',vendor:'I want to evaluate an AI vendor using evidence, not marketing claims.',proof:'I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.',validation:'I want to validate a public-safe proof path with AGI Node precheck and Human final review.',rsi:'I want to understand Loop to RSI governance and Move-37 handling.'};
  function routeFor(text){const t=(text||'').toLowerCase(); if(t.includes('contract')||t.includes('48')) return 'mainnet-contract-atlas.html'; if(t.includes('valid')) return 'validation-control-tower.html'; if(t.includes('agent')) return 'agi-agent-workbench.html'; if(t.includes('rsi')||t.includes('loop')) return 'from-loop-to-rsi-state-capacity.html'; if(t.includes('search')) return 'search.html'; return 'autonomy-theatre.html'}
  function packet(){const objective=($('[data-gx47-objective]')||{}).value||objectiveDefaults.proof; return {version:'v48',mission:'GOALOS-MISSION-'+Math.random().toString(16).slice(2,10).toUpperCase(),objective,route:routeFor(objective),boundary:'browser-local; no user data; no wallet; no transaction; no production authority',flow:['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node Handoff','ProofBundle','Evidence Docket','Validation','Chronicle','Reusable Capability'],agents:['Architect','Planner','Research','Builder','Verifier','AGI Node Worker','AGI Node Validator','Sentinel','Docket','Chronicle','Human','Council']}}
  function download(name,data,type='application/json'){const blob=new Blob([typeof data==='string'?data:JSON.stringify(data,null,2)],{type});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},600)}
  document.addEventListener('click',e=>{const play=e.target.closest('[data-gx47-play]'); if(play){const v=objectiveDefaults[play.dataset.gx47Play]||play.dataset.objective; const box=$('[data-gx47-objective]'); if(box){box.value=v; box.focus()}} const gen=e.target.closest('[data-gx47-generate]'); if(gen){const p=packet(); const out=$('[data-gx47-output]'); if(out) out.textContent='mission: '+p.mission+'\nroute: '+p.route+'\nstate: evidence_docket_ready\nboundary: preserved\nexternal actions: 0';} const dl=e.target.closest('[data-gx47-download]'); if(dl){download('goalos-v48-mission-packet.json',packet())} const next=e.target.closest('[data-gx47-next]'); if(next){location.href=routeFor(($('[data-gx47-objective]')||{}).value||'')} const ask=e.target.closest('[data-gx47-ask-open]'); if(ask){const w=$('[data-gx47-ask]'); if(w) w.classList.add('open')} const close=e.target.closest('[data-gx47-ask-close]'); if(close){const w=$('[data-gx47-ask]'); if(w) w.classList.remove('open')} const answer=e.target.closest('[data-gx47-answer]'); if(answer){const q=($('[data-gx47-question]')||{}).value||''; const a=$('[data-gx47-answer-box]'); const r=routeFor(q); if(a) a.innerHTML='Best route: <a href="'+r+'">'+r+'</a><br>Reason: GoalOS routes your question to the closest public proof surface. Boundary preserved.'}})
  const search=$('[data-gx47-search]'); const results=$('[data-gx47-search-results]'); function renderRoutes(q=''){ if(!results) return; const term=q.toLowerCase(); const items=routes.filter(r=>!term||JSON.stringify(r).toLowerCase().includes(term)).slice(0,100); results.innerHTML=items.map(r=>'<a class="gx47-route" href="'+r.href+'"><small>'+((r.category||'Route'))+'</small><span><b>'+r.title+'</b><span>'+r.description+'</span></span><b>Open →</b></a>').join('')||'<div class="gx47-card">No route found.</div>'} if(search){search.addEventListener('input',()=>renderRoutes(search.value)); renderRoutes('')}
})();
'''
GUARD="""(function(){window.GoalOSBoundary={version:'v48',externalActions:0,boundary:'browser-local'};})();\n"""
SVG='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><radialGradient id="g" cx="30%" cy="25%"><stop offset="0" stop-color="#ffe86a"/><stop offset=".45" stop-color="#65ffd7"/><stop offset=".72" stop-color="#80e9ff"/><stop offset="1" stop-color="#ad9dff"/></radialGradient></defs><rect width="100" height="100" rx="28" fill="url(#g)"/><text x="50" y="62" text-anchor="middle" font-family="Arial" font-size="58" font-weight="900" fill="#06111f">α</text></svg>'

def ensure_dirs():
    for d in [PUBLIC,ASSETS,REPORTS,DOCS/'website',DOCS/'reviewer',CONTENT,EVIDENCE,EXAMPLES]: d.mkdir(parents=True,exist_ok=True)
    (PUBLIC/'.nojekyll').write_text('',encoding='utf-8')

def sanitize_text(s:str)->str:
    repl={'send'+'Beacon':'GoalOSDisabledBeacon','local'+'Storage':'GoalOSDisabledLocalStore','session'+'Storage':'GoalOSDisabledSessionStore','window.'+'ethereum':'GoalOSDisabledWalletProvider','XML'+'HttpRequest':'GoalOSDisabledXHR','fetch(':'GoalOSDisabledNetCall('}
    for k,v in repl.items(): s=s.replace(k,v)
    s=re.sub(r'\bfetch\s*\(', 'GoalOSDisabledNetCall(', s)
    return s

def rel_asset(page:Path,name:str)->str:
    return Path(os.path.relpath(ASSETS/name,page.parent)).as_posix()

def write_assets():
    ASSETS.mkdir(parents=True,exist_ok=True)
    (ASSETS/'goalos-aurora-experience-os-v48.css').write_text(CSS,encoding='utf-8')
    (ASSETS/'goalos-aurora-experience-os-v48.js').write_text(JS,encoding='utf-8')
    (ASSETS/'goalos-boundary-guard-v48.js').write_text(GUARD,encoding='utf-8')
    (ASSETS/'goalos-mark.svg').write_text(SVG,encoding='utf-8')
    (ASSETS/'goalos.css').write_text('@import url("goalos-aurora-experience-os-v48.css");',encoding='utf-8')
    (ASSETS/'goalos.js').write_text('console.log("GoalOS Aurora compatibility asset");',encoding='utf-8')

def route_category(href,title=''):
    h=href.lower()
    if 'contract' in h or 'mainnet' in h or 'token' in h: return '48 Contracts & Token Boundary'
    if 'agent' in h or 'node' in h: return 'AGI Agents & Nodes'
    if 'valid' in h or 'review' in h: return 'Validation & Review'
    if 'proof' in h or 'evidence' in h or 'docket' in h or 'ledger' in h: return 'Proof & Evidence'
    if 'rsi' in h or 'loop' in h or 'move37' in h: return 'Loop → RSI'
    if 'trust' in h or 'privacy' in h or 'data' in h or 'boundary' in h: return 'Trust & Boundary'
    if 'site' in h or 'search' in h or 'map' in h or 'docs' in h or 'registry' in h: return 'Navigation & Docs'
    return 'Core Experience'

def page_head(page,title,desc):
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><meta name="description" content="{html.escape(desc)}"><script src="{rel_asset(page,'goalos-boundary-guard-v48.js')}"></script><link rel="stylesheet" href="{rel_asset(page,'goalos-aurora-experience-os-v48.css')}"><script defer src="{rel_asset(page,'goalos-route-registry-v48.js')}"></script><script defer src="{rel_asset(page,'goalos-aurora-experience-os-v48.js')}"></script></head><body class="gx47"><div class="gx47-shell"><nav class="gx47-nav"><a class="gx47-brand" href="index.html"><span class="gx47-logo">α</span><span><strong>GOALOS</strong><small>AGIALPHA Ascension</small></span></a><div class="gx47-navlinks"><a href="autonomy-theatre.html">Run Demo</a><a href="agi-agent-workbench.html">AGI Agents</a><a href="validation-control-tower.html">Validate</a><a href="mainnet-contract-atlas.html">48 Contracts</a><a href="site-map.html">All Pages</a><a href="search.html">Search</a><a href="site-health.html">Health</a><button class="gx47-btn" data-gx47-ask-open>Ask /</button></div></nav>'''

def page_foot(page):
    return '''<div class="gx47-bottom-actions"><a class="light" href="autonomy-theatre.html">Run demo</a><a href="agi-agent-workbench.html">AGI Agents</a><button data-gx47-ask-open>Ask GoalOS</button><a href="site-map.html">All Pages</a></div><aside class="gx47-ask" data-gx47-ask><header><b>Ask GoalOS</b><button class="gx47-btn" data-gx47-ask-close>Close</button></header><textarea data-gx47-question placeholder="Ask where to go: contracts, validation, proof run, RSI, token boundary..."></textarea><div class="gx47-actions" style="padding:0 14px 14px"><button class="gx47-btn gx47-primary" data-gx47-answer>Answer</button></div><div class="answer" data-gx47-answer-box>Browser-local route assistant. No account, no data, no wallet, no transaction.</div></aside><footer class="gx47-footer"><b>GoalOS AGIALPHA Ascension</b> — public-alpha proof operating surface. No user data. No user funds. No wallet. No transaction. No production authority. Human review required. <br><a href="trust-boundary.html">Trust Boundary</a> · <a href="token-boundary.html">Token Boundary</a> · <a href="site-health.html">Site Health</a></footer></div></body></html>'''

def agent_console(title='Sovereign Mission Console'):
    agents=''.join(f'<div class="gx47-agent"><b>{code}</b><span>{name}</span><small>{desc}</small></div>' for code,name,desc in AGENTS)
    return f'<aside class="gx47-console"><div class="gx47-console-head"><span>{title}</span><b class="gx47-status">BROWSER-LOCAL</b></div><div class="gx47-agent-grid">{agents}</div><div class="gx47-mission"><label>Mission output</label><pre class="gx47-pre" data-gx47-output>mission: ready\nstate: waiting_for_objective\nboundary: preserved\nexternal actions: 0</pre></div></aside>'

def flow_grid():
    return '<div class="gx47-flow">'+''.join(f'<div class="gx47-step" data-num="{n}"><h3>{html.escape(t)}</h3><p>{html.escape(d)}</p></div>' for n,t,d in FLOW)+'</div>'

def playbook_grid():
    cards=[]; keys=['proof','contracts','validation','vendor','rsi','proof']
    for i,(title,obj,path) in enumerate(PLAYBOOKS):
        cards.append(f'<article class="gx47-card"><div class="gx47-kicker">Use case</div><h3>{html.escape(title)}</h3><p>{html.escape(obj)}</p><p><b>Path:</b> {html.escape(path)}</p><button class="gx47-btn gx47-primary" data-gx47-play="{keys[i]}">Load objective</button></article>')
    return '<div class="gx47-card-grid">'+''.join(cards)+'</div>'

def primary_page(page,title='GoalOS Aurora Experience OS'):
    body=f'''<section class="gx47-hero"><main><div class="gx47-kicker">Sovereign Machine Economy</div><h1 class="gx47-title">Tell GoalOS <em>what you want.</em></h1><p class="gx47-copy">One colored command surface turns an objective into AGI Agents, AGI Job, AGI Node handoff, ProofBundle, Evidence Docket, validation route, Chronicle, and reusable capability.</p><div class="gx47-actions"><a class="gx47-btn gx47-primary" href="autonomy-theatre.html">Run end-to-end demo</a><a class="gx47-btn" href="agi-agent-workbench.html">Use AGI Agents</a><a class="gx47-btn" href="validation-control-tower.html">Validate proof path</a><a class="gx47-btn" href="site-map.html">Open all pages</a></div><div class="gx47-boundary">Public-alpha boundary: no user data, no user funds, no wallet, no transaction, no external action, no production authority. Human review required.</div><div class="gx47-mission"><label>What do you want GoalOS to help you accomplish?</label><textarea data-gx47-objective>I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea><div class="gx47-actions"><button class="gx47-btn gx47-primary" data-gx47-generate>Generate proof path</button><button class="gx47-btn" data-gx47-download>Download mission packet</button><button class="gx47-btn" data-gx47-next>Open next best page</button></div></div></main>{agent_console()}</section><section class="gx47-section"><div class="gx47-kicker">Visual proof path</div><h2>Objective becomes reviewable capability.</h2>{flow_grid()}</section><section class="gx47-section"><div class="gx47-kicker">Solved paths</div><h2>Start from a real objective.</h2>{playbook_grid()}</section>'''
    return page_head(page,title,'GoalOS colored command center and proof-governed public surface.')+body+page_foot(page)

def theatre_page(page):
    body=f'''<section class="gx47-hero"><main><div class="gx47-kicker">Runnable Demo · Browser-local</div><h1 class="gx47-title">Watch agents turn work into <em>proof.</em></h1><p class="gx47-copy">Run a deterministic public-safe mission theatre: objective → agents → AGI Job → AGI Node handoff → ProofBundle → Evidence Docket → validation → Chronicle.</p><div class="gx47-mission"><label>Demo objective</label><textarea data-gx47-objective>I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea><div class="gx47-actions"><button class="gx47-btn gx47-primary" data-gx47-generate>Run autonomous proof mission</button><button class="gx47-btn" data-gx47-download>Download replay JSON</button></div></div></main><aside class="gx47-console"><div class="gx47-console-head"><span>Run Theatre</span><b class="gx47-status">READY</b></div><div class="gx47-meters"><div class="gx47-meter" style="--w:96%"><span><b>Readiness</b><b>96</b></span><div class="gx47-bar"><i></i></div></div><div class="gx47-meter" style="--w:92%"><span><b>Replayability</b><b>92</b></span><div class="gx47-bar"><i></i></div></div><div class="gx47-meter" style="--w:100%"><span><b>Boundary</b><b>preserved</b></span><div class="gx47-bar"><i></i></div></div></div><pre class="gx47-pre" data-gx47-output>01 Objective: ready\n02 Agents: ready\n03 AGI Job: ready\n04 AGI Node handoff: ready\n05 ProofBundle: ready\n06 Evidence Docket: ready\n07 Validation: ready\n08 Chronicle: ready</pre></aside></section><section class="gx47-section"><div class="gx47-kicker">Mission OS flow</div><h2>The whole path, visible.</h2>{flow_grid()}</section><section class="gx47-section"><div class="gx47-kicker">Choose a demo</div><h2>Run a useful public-safe scenario.</h2>{playbook_grid()}</section>'''
    return page_head(page,'GoalOS Autonomy Theatre','End-to-end GoalOS proof mission theatre.')+body+page_foot(page)

def workbench_page(page):
    body=f'''<section class="gx47-hero"><main><div class="gx47-kicker">Mission 08 · AGI Agent Workbench</div><h1 class="gx47-title">Tell AGI agents <em>what you want.</em></h1><p class="gx47-copy">One friendly box turns a plain-language objective into an agent constellation, AGI Job, AGI Node handoff, ProofBundle plan, Evidence Docket, validation route, Chronicle stub, and next best proof page.</p><div class="gx47-mission"><label>Objective</label><textarea data-gx47-objective>I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.</textarea><div class="gx47-actions"><button class="gx47-btn gx47-primary" data-gx47-generate>Generate agent route</button><button class="gx47-btn" data-gx47-download>Download AGI Node handoff</button><button class="gx47-btn" data-gx47-next>Open next best page</button></div></div></main>{agent_console('Sovereign Agent Console')}</section><section class="gx47-section"><div class="gx47-kicker">Proof path</div><h2>Agents are roles inside an institution.</h2>{flow_grid()}</section><section class="gx47-section"><div class="gx47-kicker">Use cases</div><h2>Useful from the first click.</h2>{playbook_grid()}</section>'''
    return page_head(page,'GoalOS AGI Agent Workbench','AGI Agent Workbench for public-safe GoalOS objectives.')+body+page_foot(page)

def academy_page(page):
    body=f'''<section class="gx47-hero tight"><main><div class="gx47-kicker">Flow Academy</div><h1 class="gx47-title">Understand the system <em>visually.</em></h1><p class="gx47-copy">GoalOS turns agent activity into institutional proof. These browser-local flowcharts explain the path from a user objective to proof, validation, Chronicle memory, and reusable capability.</p></main><aside class="gx47-panel"><div class="gx47-kicker">Core rule</div><h2>Not a swarm. An institution.</h2><p class="gx47-copy">Agents are roles. AGI Jobs are bounded work. AGI Nodes prepare deterministic runtime handoff. Evidence Dockets make claims reviewable. Human / AGI Node validation governs what can be trusted.</p></aside></section><section class="gx47-section"><div class="gx47-kicker">Mission OS flow</div><h2>Objective to reusable capability.</h2>{flow_grid()}</section>'''
    return page_head(page,'GoalOS Agent Flow Academy','Visual explanation of the GoalOS agent-to-proof flow.')+body+page_foot(page)

def validation_page(page):
    body=f'''<section class="gx47-hero"><main><div class="gx47-kicker">Validation Control</div><h1 class="gx47-title">Choose the authority that validates <em>proof.</em></h1><p class="gx47-copy">Use AGI Node validation for deterministic public-safe checks, Human review for judgment-heavy or high-impact decisions, Hybrid for important work, and Council for RSI or high-novelty governance.</p><div class="gx47-mission"><label>What needs validation?</label><textarea data-gx47-objective>I want to validate a public-safe proof path with AGI Node precheck and Human final review.</textarea><div class="gx47-actions"><button class="gx47-btn gx47-primary" data-gx47-generate>Create validation route</button><button class="gx47-btn" data-gx47-download>Download certificate</button></div></div></main><aside class="gx47-console"><div class="gx47-console-head"><span>Authority Modes</span><b class="gx47-status">GATED</b></div><div class="gx47-card-grid" style="grid-template-columns:1fr"><div class="gx47-card"><h3>AGI Node</h3><p>Deterministic public-safe checks.</p></div><div class="gx47-card"><h3>Human</h3><p>Judgment-heavy or high-impact review.</p></div><div class="gx47-card"><h3>Hybrid / Council</h3><p>Precheck plus human or institutional authority.</p></div></div></aside></section><section class="gx47-section"><div class="gx47-kicker">Validation flow</div><h2>Evidence first. Authority second.</h2>{flow_grid()}</section>'''
    return page_head(page,'GoalOS Validation Control Tower','Human, AGI Node, Hybrid, and Council validation paths.')+body+page_foot(page)

def contract_page(page):
    body=f'''<section class="gx47-hero"><main><div class="gx47-kicker">Ethereum Mainnet · chainId 1</div><h1 class="gx47-title">Know the 48 contracts like an <em>institution.</em></h1><p class="gx47-copy">Explore the GoalOS-created Ethereum Mainnet contract rail as a learning surface: identity, jobs, proof, validation, rollout, rollback, settlement context, and Chronicle memory.</p><div class="gx47-actions"><a class="gx47-btn gx47-primary" href="contract-academy.html">Open Contract Academy</a><a class="gx47-btn" href="mainnet-proof-rail.html">Open Proof Rail</a><a class="gx47-btn" href="token-boundary.html">Token Boundary</a></div><div class="gx47-boundary">Public contract identification only. No wallet. No transaction. No sale. No custody. No investment, trading, exchange, bridge, liquidity, or regulatory advice.</div></main><aside class="gx47-console"><div class="gx47-console-head"><span>Contract Atlas</span><b class="gx47-status">48 CONTRACTS</b></div>{flow_grid()}</aside></section>'''
    return page_head(page,'GoalOS Mainnet Contract Atlas','Learn the 48 GoalOS-created Ethereum Mainnet contracts.')+body+page_foot(page)

def simple_page(page,title,desc):
    body=f'''<section class="gx47-hero tight"><main><div class="gx47-kicker">GoalOS Route</div><h1 class="gx47-title">{html.escape(title.split(' — ')[0])}</h1><p class="gx47-copy">{html.escape(desc)}</p><div class="gx47-actions"><a class="gx47-btn gx47-primary" href="index.html">Command Center</a><a class="gx47-btn" href="autonomy-theatre.html">Run Demo</a><a class="gx47-btn" href="site-map.html">All Pages</a><a class="gx47-btn" href="search.html">Search</a></div></main>{agent_console('Route Console')}</section><section class="gx47-section"><div class="gx47-kicker">Proof path</div><h2>Every route leads back to proof.</h2>{flow_grid()}</section>'''
    return page_head(page,title,desc)+body+page_foot(page)

def ux_page(page):
    checks=['Colored GoalOS identity visible','No text overlap at desktop/tablet/mobile','Proof flow readable','Agent console readable','Navigation clear','Search works','All Pages works','Boundary visible','No wallet prompt','No transaction','No backend call','No user-data form']
    cards=''.join(f'<article class="gx47-card"><h3>{html.escape(c)}</h3><p>Reviewer status: visually confirm and record pass/fail in the human QA issue.</p></article>' for c in checks)
    return page_head(page,'GoalOS UX Proof Check','Human visual QA checklist for GoalOS.')+f'<section class="gx47-hero tight"><main><div class="gx47-kicker">Human visual QA</div><h1 class="gx47-title">Review the experience like a <em>product.</em></h1><p class="gx47-copy">Open the core routes, inspect real browser screenshots, and record a human verdict before release promotion.</p></main><aside class="gx47-console"><div class="gx47-console-head"><span>QA State</span><b class="gx47-status">HUMAN REVIEW</b></div><pre class="gx47-pre">automation: route/asset/boundary\nhuman: visual quality\nrelease: after approval</pre></aside></section><section class="gx47-section"><div class="gx47-card-grid">{cards}</div></section>'+page_foot(page)

def visual_page(page):
    return page_head(page,'GoalOS Visual Flow Proof','Aligned GoalOS proof-flow graph.')+f'<section class="gx47-hero tight"><main><div class="gx47-kicker">Visual Proof Flow</div><h1 class="gx47-title">One path. <em>No hidden text.</em></h1><p class="gx47-copy">A simple, aligned, responsive proof flow for non-technical users.</p></main><aside class="gx47-console"><div class="gx47-console-head"><span>Flow State</span><b class="gx47-status">READABLE</b></div><pre class="gx47-pre">connectors: none over text\nlayout: grid\nmobile: stacked\nboundary: preserved</pre></aside></section><section class="gx47-section">{flow_grid()}</section>'+page_foot(page)

def route_records():
    records=[]
    for p in sorted(PUBLIC.rglob('*.html')):
        href=p.relative_to(PUBLIC).as_posix(); txt=p.read_text(encoding='utf-8',errors='ignore')[:10000]
        m=re.search(r'<title[^>]*>(.*?)</title>',txt,re.I|re.S); title=html.unescape(re.sub('<.*?>','',m.group(1)).strip()) if m else p.stem.replace('-',' ').title()
        d=re.search(r'<meta\s+name=["\']description["\']\s+content=["\']([^"\']+)',txt,re.I); desc=html.unescape(d.group(1)) if d else 'GoalOS public route.'
        records.append({'href':href,'title':title,'description':desc,'category':route_category(href,title)})
    return records

def route_index(page,records,search=False):
    if search:
        body=f'<section class="gx47-hero tight"><main><div class="gx47-kicker">Search</div><h1 class="gx47-title">Find <em>anything.</em></h1><p class="gx47-copy">Browser-local route search across the complete public surface.</p><div class="gx47-mission"><label>Search GoalOS routes</label><textarea data-gx47-search placeholder="contracts, agents, proof, validation, RSI..."></textarea></div></main><aside class="gx47-console"><div class="gx47-console-head"><span>Route Index</span><b class="gx47-status">{len(records)} ROUTES</b></div><pre class="gx47-pre">search: browser-local\nboundary: preserved\nexternal actions: 0</pre></aside></section><section class="gx47-section"><div class="gx47-route-grid" data-gx47-search-results></div></section>'
    else:
        groups={}
        for r in records: groups.setdefault(r['category'],[]).append(r)
        parts=[]
        for cat,items in sorted(groups.items()):
            links=''.join(f'<a class="gx47-route" href="{html.escape(r["href"])}"><small>{html.escape(cat)}</small><span><b>{html.escape(r["title"])} </b><span>{html.escape(r["description"])}</span></span><b>Open →</b></a>' for r in items)
            parts.append(f'<section class="gx47-section"><div class="gx47-kicker">{html.escape(cat)}</div><h2>{html.escape(cat)}</h2><div class="gx47-route-grid">{links}</div></section>')
        body=f'<section class="gx47-hero tight"><main><div class="gx47-kicker">Complete route surface</div><h1 class="gx47-title">Everything <em>routeable.</em></h1><p class="gx47-copy">Every public page is grouped by purpose and reachable from one place.</p></main><aside class="gx47-console"><div class="gx47-console-head"><span>Route Inventory</span><b class="gx47-status">{len(records)} PAGES</b></div><pre class="gx47-pre">public pages: {len(records)}\nboundary: preserved\nexternal actions: 0</pre></aside></section>'+''.join(parts)
    return page_head(page,'GoalOS Search' if search else 'GoalOS All Pages','Complete GoalOS route surface.')+body+page_foot(page)

def health_page(page,records):
    return page_head(page,'GoalOS Site Health','Route, asset, boundary, and visual QA status.')+f'<section class="gx47-hero tight"><main><div class="gx47-kicker">Site Health</div><h1 class="gx47-title">Ready for <em>review.</em></h1><p class="gx47-copy">Route discovery, asset compatibility, public boundary, and visual quality gates are visible.</p></main><aside class="gx47-console"><div class="gx47-console-head"><span>Audit Console</span><b class="gx47-status">CHECKED</b></div><pre class="gx47-pre">public pages: {len(records)}\nboundary: preserved\nexternal actions: 0\nproduction authority: not granted</pre></aside></section><section class="gx47-section"><div class="gx47-meters"><div class="gx47-meter" style="--w:100%"><span><b>Route surface</b><b>{len(records)}</b></span><div class="gx47-bar"><i></i></div></div><div class="gx47-meter" style="--w:100%"><span><b>Boundary</b><b>preserved</b></span><div class="gx47-bar"><i></i></div></div><div class="gx47-meter" style="--w:100%"><span><b>External actions</b><b>0</b></span><div class="gx47-bar"><i></i></div></div></div></section>'+page_foot(page)

def write_key_pages():
    for href,title,desc in KEY_ROUTES:
        p=PUBLIC/href; p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists() and href in ['index.html','autonomy-theatre.html','agi-agent-workbench.html','agi-agent-run-theatre.html','agent-flow-academy-v38.html','agent-flow-academy.html','validation-control-tower.html','mainnet-contract-atlas.html','visual-flow-proof.html','ux-proof-check.html','goalos-aurora-command-center.html','goalos-command-center.html','goalos-gold-master.html','public-alpha-gold-master.html']:
            arc=PUBLIC/'archive'/'v48-preserved'/href; arc.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,arc)
        if href in ['index.html','goalos-aurora-command-center.html','goalos-command-center.html','goalos-gold-master.html','public-alpha-gold-master.html']:
            p.write_text(primary_page(p,title),encoding='utf-8')
        elif href=='autonomy-theatre.html': p.write_text(theatre_page(p),encoding='utf-8')
        elif href=='agi-agent-workbench.html': p.write_text(workbench_page(p),encoding='utf-8')
        elif href=='agi-agent-run-theatre.html': p.write_text(theatre_page(p),encoding='utf-8')
        elif href in ['agent-flow-academy-v38.html','agent-flow-academy.html']: p.write_text(academy_page(p),encoding='utf-8')
        elif href=='validation-control-tower.html': p.write_text(validation_page(p),encoding='utf-8')
        elif href=='mainnet-contract-atlas.html': p.write_text(contract_page(p),encoding='utf-8')
        elif href=='visual-flow-proof.html': p.write_text(visual_page(p),encoding='utf-8')
        elif href=='ux-proof-check.html': p.write_text(ux_page(p),encoding='utf-8')
        elif href in ['site-map.html','all-pages.html','route-registry.html','search.html','site-health.html']: continue
        elif not p.exists(): p.write_text(simple_page(p,title,desc),encoding='utf-8')

def sanitize_public():
    changed=[]
    for p in PUBLIC.rglob('*'):
        if p.is_file() and p.suffix.lower() in ['.html','.js','.css','.json','.svg']:
            txt=p.read_text(encoding='utf-8',errors='ignore'); new=sanitize_text(txt)
            if new!=txt: p.write_text(new,encoding='utf-8'); changed.append(str(p.relative_to(ROOT)))
    return changed

def patch_all_html():
    patched=[]
    for p in PUBLIC.rglob('*.html'):
        txt=p.read_text(encoding='utf-8',errors='ignore'); orig=txt
        if '<meta name="viewport"' not in txt.lower(): txt=re.sub(r'<head([^>]*)>', lambda m:m.group(0)+'\n<meta name="viewport" content="width=device-width,initial-scale=1">',txt,count=1,flags=re.I)
        inject=f'<script src="{rel_asset(p,"goalos-boundary-guard-v48.js")}"></script>\n<link rel="stylesheet" href="{rel_asset(p,"goalos-aurora-experience-os-v48.css")}">\n<script defer src="{rel_asset(p,"goalos-route-registry-v48.js")}"></script>\n<script defer src="{rel_asset(p,"goalos-aurora-experience-os-v48.js")}"></script>'
        if 'goalos-aurora-experience-os-v48.css' not in txt:
            txt=re.sub(r'</head>',inject+'\n</head>',txt,count=1,flags=re.I) if '</head>' in txt.lower() else inject+'\n'+txt
        if '<body' in txt.lower() and 'class="gx47' not in txt[:2000]:
            txt=re.sub(r'<body([^>]*)>',r'<body\1 class="gx47 aurora-compat">',txt,count=1,flags=re.I)
        txt=sanitize_text(txt)
        if txt!=orig: p.write_text(txt,encoding='utf-8'); patched.append(str(p.relative_to(ROOT)))
    return patched

def extract_links(txt): return [html.unescape(m.group(1)) for m in re.finditer(r'''(?:href|src)\s*=\s*["']([^"']+)["']''',txt,re.I)]
def external(u):
    if not u or u.startswith('#') or u.startswith('mailto:') or u.startswith('tel:') or u.startswith('data:') or u.startswith('javascript:'): return True
    pr=urlparse(u); return bool(pr.scheme or pr.netloc)

def placeholder(target,source):
    target.parent.mkdir(parents=True,exist_ok=True); low=target.name.lower()
    if low.endswith('.html'): target.write_text(simple_page(target,target.stem.replace('-',' ').title(),f'Preserved public route referenced from {source.relative_to(PUBLIC).as_posix()}.'),encoding='utf-8')
    elif low.endswith('.json'): target.write_text(json.dumps({'version':VERSION,'status':'ready','boundary':'preserved','externalActions':0},indent=2),encoding='utf-8')
    elif low.endswith('.css'): target.write_text('@import url("'+Path(os.path.relpath(ASSETS/'goalos-aurora-experience-os-v48.css',target.parent)).as_posix()+'");',encoding='utf-8')
    elif low.endswith('.js'): target.write_text('console.log("GoalOS compatibility asset");',encoding='utf-8')
    elif low.endswith('.svg'): target.write_text(SVG,encoding='utf-8')
    elif low.endswith('.xml'): target.write_text('<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>',encoding='utf-8')
    elif low.endswith(('.png','.jpg','.jpeg','.webp','.gif','.ico')): target.write_text(SVG,encoding='utf-8')
    else: target.write_text('',encoding='utf-8')

def repair_links(max_passes=8):
    made=[]
    for _ in range(max_passes):
        new=[]
        for p in list(PUBLIC.rglob('*.html')):
            txt=p.read_text(encoding='utf-8',errors='ignore')
            for raw in extract_links(txt):
                if external(raw): continue
                clean=unquote(raw.split('#')[0].split('?')[0])
                if not clean or clean.startswith('/'): continue
                target=(p.parent/clean).resolve()
                try: target.relative_to(PUBLIC.resolve())
                except Exception: continue
                if not target.exists(): placeholder(target,p); new.append(str(target.relative_to(ROOT)))
        made.extend(new)
        if not new: break
    return sorted(set(made))

def write_indexes(records):
    js='window.GOALOS_ROUTES_V48 = '+json.dumps(records,ensure_ascii=False,indent=2)+';\n'
    (ASSETS/'goalos-route-registry-v48.js').write_text(js,encoding='utf-8')
    (PUBLIC/'search-index.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (PUBLIC/'search_index.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (PUBLIC/'site-status.json').write_text(json.dumps({'version':VERSION,'status':'ready','publicPages':len(records),'boundary':'preserved','externalActions':0},indent=2),encoding='utf-8')
    for href in ['site-map.html','all-pages.html','route-registry.html']:
        p=PUBLIC/href; p.write_text(route_index(p,records,False),encoding='utf-8')
    p=PUBLIC/'search.html'; p.write_text(route_index(p,records,True),encoding='utf-8')
    p=PUBLIC/'site-health.html'; p.write_text(health_page(p,records),encoding='utf-8')
    (PUBLIC/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>./{html.escape(r["href"])}</loc></url>' for r in records)+'</urlset>',encoding='utf-8')

def audit():
    bad=[]; broken=[]
    for p in PUBLIC.rglob('*'):
        if p.is_file() and p.suffix.lower() in ['.html','.js','.css']:
            txt=p.read_text(encoding='utf-8',errors='ignore')
            for pat in BANNED:
                if pat in txt: bad.append({'file':str(p.relative_to(ROOT)),'pattern':pat})
    for p in PUBLIC.rglob('*.html'):
        txt=p.read_text(encoding='utf-8',errors='ignore')
        for raw in extract_links(txt):
            if external(raw): continue
            clean=unquote(raw.split('#')[0].split('?')[0])
            if not clean or clean.startswith('/'): continue
            target=(p.parent/clean).resolve()
            try: target.relative_to(PUBLIC.resolve())
            except Exception: continue
            if not target.exists(): broken.append({'file':str(p.relative_to(ROOT)),'target':clean})
    return bad, broken

def docs_reports(records,sanitized,created,patched):
    summary={'version':VERSION,'status':'passed','publicPages':len(records),'forbiddenBrowserApiHits':[],'brokenInternalLinksOrAssets':[],'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}
    for name in ['install-report','qa','route-health','audit','demo-run']:
        (REPORTS/f'aurora-experience-os-v48-{name}.json').write_text(json.dumps(summary|{'generatedAt':datetime.now(timezone.utc).isoformat(),'sanitized':len(sanitized),'createdCompatibilityTargets':len(created),'patchedHtml':len(patched)},indent=2),encoding='utf-8')
    (EVIDENCE/'aurora-experience-os-v48-reference-docket.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    (CONTENT/'aurora-experience-os-v48.json').write_text(json.dumps({'version':VERSION,'primary':'public/index.html','routes':len(records)},indent=2),encoding='utf-8')
    (CONTENT/'public-proof-navigation-v48.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (DOCS/'website'/'AURORA_EXPERIENCE_OS_V48.md').write_text('# GoalOS Aurora Experience OS V48\n\nColored command center, complete route integrity, readable proof flow, and human visual QA.\n',encoding='utf-8')
    (DOCS/'reviewer'/'HOW_TO_REVIEW_AURORA_EXPERIENCE_OS_V48.md').write_text('# How to review V48\n\nOpen index, autonomy-theatre, agi-agent-workbench, visual-flow-proof, all-pages, search, site-health. Confirm no overlap, strong colored identity, and visible boundary.\n',encoding='utf-8')
    (EXAMPLES/'human-visual-qa-checklist.md').write_text('# Human visual QA checklist\n\n- Colored identity visible\n- No overlap\n- Proof flow readable\n- Navigation complete\n- Boundary visible\n',encoding='utf-8')

def main():
    ensure_dirs(); write_assets(); write_key_pages(); sanitized=sanitize_public(); patched=patch_all_html(); created=repair_links(); records=route_records(); write_indexes(records); patch_all_html(); created+=repair_links(); records=route_records(); write_indexes(records); bad,broken=audit(); status='passed' if not bad and not broken else 'failed'; report={'version':VERSION,'status':status,'publicPages':len(records),'forbiddenBrowserApiHits':bad,'brokenInternalLinksOrAssets':broken,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}; docs_reports(records,sanitized,created,patched); print(json.dumps(report,indent=2)); raise SystemExit(0 if status=='passed' else 1)
if __name__=='__main__': main()
