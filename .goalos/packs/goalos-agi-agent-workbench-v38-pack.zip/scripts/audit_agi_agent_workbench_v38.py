#!/usr/bin/env python3
from pathlib import Path
import json, re, datetime
ROOT=Path.cwd(); PUBLIC=ROOT/'public'
FORBIDDEN=['fetch(','XMLHttpRequest','sendBeacon','localStorage','sessionStorage','window.ethereum']
forbidden=[]
for f in [PUBLIC/'assets/goalos-agi-agent-workbench-v38.js',PUBLIC/'assets/goalos-agi-agent-workbench-data-v38.js']:
    if f.exists():
        t=f.read_text(encoding='utf-8',errors='ignore')
        for term in FORBIDDEN:
            if term in t: forbidden.append({'file':str(f),'term':term})
href_re=re.compile(r'href=["\']([^"\']+\.html(?:#[^"\']*)?)["\']',re.I)
broken=[]
for h in PUBLIC.glob('*.html'):
    t=h.read_text(encoding='utf-8',errors='ignore')
    for m in href_re.findall(t):
        u=m.split('#')[0]
        if not u or u.startswith(('http','mailto:','tel:')): continue
        if '/' in u and not u.startswith('./'): continue
        name=Path(u).name
        if name and not (PUBLIC/name).exists(): broken.append({'from':h.name,'to':name})
status='passed' if not forbidden and not broken else 'failed'
report={'version':'v38','status':status,'forbiddenBrowserApiHits':forbidden,'brokenInternalHtmlLinks':broken,'publicPages':len(list(PUBLIC.glob('*.html'))),'generatedAt':datetime.datetime.utcnow().isoformat()+'Z'}
(ROOT/'reports').mkdir(exist_ok=True); (ROOT/'reports/agi-agent-workbench-v38-qa.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
raise SystemExit(0 if status=='passed' else 1)
