#!/usr/bin/env python3
from pathlib import Path
import json, datetime
ROOT=Path.cwd()
public=ROOT/'public'
required=['agi-agent-workbench.html','agi-agent-run-theatre.html','agi-agent-use-case-gallery.html','agent-flow-academy-v38.html','assets/goalos-agi-agent-workbench-v38.js','assets/goalos-agi-agent-workbench-v38.css','assets/goalos-agi-agent-workbench-data-v38.js']
missing=[x for x in required if not (public/x).exists()]
report={'version':'v38','status':'passed' if not missing else 'failed','missing':missing,'demoObjectives':['I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.','I want to run a public-safe proof mission.','I want to evaluate an AI vendor using evidence, not marketing claims.','I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.'],'generatedAt':datetime.datetime.utcnow().isoformat()+'Z'}
(ROOT/'reports').mkdir(exist_ok=True)
(ROOT/'reports/agi-agent-workbench-v38-demo-run.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
