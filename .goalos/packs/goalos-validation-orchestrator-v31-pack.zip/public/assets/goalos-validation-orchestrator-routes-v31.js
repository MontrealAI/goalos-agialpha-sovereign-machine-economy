window.GOALOS_V31_ROUTES=[
  {
    "title": "GoalOS Mission Studio",
    "url": "goalos.html",
    "category": "Mission",
    "keywords": "objective mission contract evidence docket action graph ask goalos"
  },
  {
    "title": "Validation Orchestrator",
    "url": "validation-orchestrator.html",
    "category": "Validation",
    "keywords": "human agi node validator hybrid council validation authority"
  },
  {
    "title": "Ask GoalOS",
    "url": "ask-goalos.html",
    "category": "Concierge",
    "keywords": "chat question answer redirect route"
  },
  {
    "title": "Use Case Playbooks",
    "url": "use-case-playbooks.html",
    "category": "Use cases",
    "keywords": "playbook examples non technical"
  },
  {
    "title": "Mainnet Contract Atlas",
    "url": "mainnet-contract-atlas.html",
    "category": "Contracts",
    "keywords": "48 ethereum mainnet contracts atlas"
  },
  {
    "title": "Mainnet Proof Rail",
    "url": "mainnet-proof-rail.html",
    "category": "Contracts",
    "keywords": "48 contracts proof rail"
  },
  {
    "title": "Contract Academy",
    "url": "contract-academy.html",
    "category": "Contracts",
    "keywords": "learn contracts academy"
  },
  {
    "title": "Proof Run 001 Docket",
    "url": "proof-run-001-docket.html",
    "category": "Evidence",
    "keywords": "proof run docket claims matrix validator packet"
  },
  {
    "title": "Loop to RSI State Capacity",
    "url": "from-loop-to-rsi-state-capacity.html",
    "category": "RSI",
    "keywords": "loop rsi state capacity governance"
  },
  {
    "title": "Trust Boundary",
    "url": "trust-boundary.html",
    "category": "Boundary",
    "keywords": "privacy no data no funds no wallet"
  },
  {
    "title": "Token Boundary",
    "url": "token-boundary.html",
    "category": "Boundary",
    "keywords": "AGIALPHA not available no sale no custody"
  },
  {
    "title": "Site Map",
    "url": "site-map.html",
    "category": "Navigation",
    "keywords": "all pages route map"
  },
  {
    "title": "Search",
    "url": "search.html",
    "category": "Navigation",
    "keywords": "search command palette"
  },
  {
    "title": "Site Health",
    "url": "site-health.html",
    "category": "Navigation",
    "keywords": "route integrity site health"
  }
];
window.GOALOS_V31_PLAYBOOKS=[
  {
    "id": "pb01",
    "title": "AGI Node validates the 48 Mainnet Contract Atlas",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate whether the public 48 Ethereum Mainnet Contract Atlas is complete, claim-bounded, routeable, and ready for non-technical review.",
    "why": "A non-technical visitor should be able to understand the contract proof rail without wallets, transactions, or hidden assumptions.",
    "steps": [
      "Check expected contract route exists",
      "Check token boundary wording",
      "Check reviewer routes and downloads"
    ],
    "routes": [
      "mainnet-contract-atlas.html",
      "mainnet-proof-rail.html",
      "contract-academy.html",
      "token-boundary.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb02",
    "title": "Human validates a public claim before publication",
    "authority": "Human",
    "risk": "HIGH",
    "prompt": "Prepare a human review packet for a high-impact public GoalOS claim before it appears on the website, social post, or release notes.",
    "why": "Judgment-heavy claims should not be finalized by automation alone.",
    "steps": [
      "Extract claim",
      "Check evidence burden",
      "Flag legal/financial/security implications"
    ],
    "routes": [
      "proof-run-001-docket.html",
      "trust-boundary.html",
      "claim-boundary.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb03",
    "title": "Hybrid validates an AI vendor or tool",
    "authority": "Hybrid",
    "risk": "MEDIUM",
    "prompt": "Evaluate an AI vendor using evidence instead of marketing claims: route it through AGI Node precheck and human final review.",
    "why": "Procurement decisions need fast evidence checks plus accountable human judgment.",
    "steps": [
      "Generate claims matrix",
      "AGI Node checks completeness",
      "Human reviews risk and decision context"
    ],
    "routes": [
      "validation-orchestrator.html",
      "proof-run-001-docket.html",
      "demo-ecosystem-registry.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb04",
    "title": "Council validates Loop to RSI governance",
    "authority": "Council",
    "risk": "STRATEGIC",
    "prompt": "Prepare Architect / Validator Council review for a Loop to RSI governance packet with replay, baselines, persistence, and Move-37 handling.",
    "why": "Recursive-improvement claims require high-assurance governance, not a single reviewer.",
    "steps": [
      "Check deterministic pipeline framing",
      "Require replay and baseline discipline",
      "Require dossier packaging"
    ],
    "routes": [
      "from-loop-to-rsi-state-capacity.html",
      "validation-orchestrator.html",
      "proof-run-001-docket.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb05",
    "title": "AGI Node validates token boundary wording",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate the $AGIALPHA token boundary page: public contract identification only, not available from GoalOS, no sale, no custody, no wallet support, no investment advice.",
    "why": "Token confusion creates user and regulatory risk. Deterministic wording checks are ideal for an AGI Node precheck.",
    "steps": [
      "Check no-sale language",
      "Check no-custody language",
      "Check no-wallet language"
    ],
    "routes": [
      "token-boundary.html",
      "trust-boundary.html",
      "privacy.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb06",
    "title": "Hybrid validates a controlled pilot program",
    "authority": "Hybrid",
    "risk": "MEDIUM",
    "prompt": "Design and validate a controlled pilot where every serious pilot ends with an Evidence Docket, validator review, and follow-up status.",
    "why": "Pilots become useful only when evidence, gates, and follow-up state are recorded.",
    "steps": [
      "Define pilot scope",
      "AGI Node checks docket requirements",
      "Human approves risk and success criteria"
    ],
    "routes": [
      "pilot-program.html",
      "proof-run-001-docket.html",
      "validation-orchestrator.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb07",
    "title": "AGI Node validates site route integrity",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate that all public GoalOS pages are navigable, routeable, and have a path back to Tell GoalOS, Ask GoalOS, Search, and All Pages.",
    "why": "Users should never get lost in a large proof surface.",
    "steps": [
      "Scan page list",
      "Check internal HTML links",
      "Check quick routes"
    ],
    "routes": [
      "site-map.html",
      "search.html",
      "site-health.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb08",
    "title": "Hybrid validates a defensive cybersecurity proof mission",
    "authority": "Hybrid",
    "risk": "HIGH",
    "prompt": "Prepare validation for a defensive, repo-owned cybersecurity proof mission with no external scans, no exploit execution, no malware, no unsafe automerge, and human review.",
    "why": "Security work needs automation for checks and human authority for remediation decisions.",
    "steps": [
      "Enforce defensive-only boundary",
      "AGI Node checks safety invariants",
      "Human reviews remediation scope"
    ],
    "routes": [
      "validation-orchestrator.html",
      "trust-boundary.html",
      "proof-run-001-docket.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb09",
    "title": "Human validates a procurement proof record",
    "authority": "Human",
    "risk": "HIGH",
    "prompt": "Prepare a procurement decision package: evidence, alternatives, risks, claim boundaries, and final human approval before action.",
    "why": "Procurement decisions involve real money and institutional accountability.",
    "steps": [
      "Map decision",
      "Collect evidence requirements",
      "Identify risk and alternatives"
    ],
    "routes": [
      "validation-orchestrator.html",
      "proof-run-001-docket.html",
      "trust-boundary.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb10",
    "title": "AGI Node validates Evidence Docket completeness",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate that an Evidence Docket includes manifest, claims matrix, baselines, proof packets, evaluator notes, risk/cost ledgers, replay path, and public/private boundary.",
    "why": "Completeness is a deterministic check that AGI Nodes can perform quickly.",
    "steps": [
      "Check required docket sections",
      "Check claim boundary",
      "Check route to replay/reviewer pages"
    ],
    "routes": [
      "proof-run-001-docket.html",
      "validation-orchestrator.html",
      "site-health.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb11",
    "title": "Council validates a Move-37 candidate",
    "authority": "Council",
    "risk": "STRATEGIC",
    "prompt": "Prepare Council validation for a high-novelty Move-37 candidate: reproduce, stress-test, persistence gate, and dossier packaging before any promotion.",
    "why": "High novelty raises the proof burden. It should not lower it.",
    "steps": [
      "Recognize novelty and advantage claim",
      "Require reproduction",
      "Require stress tests"
    ],
    "routes": [
      "from-loop-to-rsi-state-capacity.html",
      "validation-orchestrator.html",
      "proof-run-001-docket.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb12",
    "title": "AGI Node validates privacy and data boundary",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate that the site does not ask users for personal, customer, credential, wallet, payment, seed phrase, trade-secret, or confidential data.",
    "why": "The public site should be proof-native, not data-hungry.",
    "steps": [
      "Check boundary pages",
      "Check no-data language",
      "Check no-wallet language"
    ],
    "routes": [
      "privacy.html",
      "data-boundary.html",
      "no-data-no-funds.html",
      "trust-boundary.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb13",
    "title": "Human validates a strategic opportunity proof mission",
    "authority": "Human",
    "risk": "HIGH",
    "prompt": "Map a strategic opportunity into a proof mission and require human review before any external action or public claim.",
    "why": "Strategic choices depend on context, judgment, and accountability.",
    "steps": [
      "Define decision to support",
      "Separate evidence from assumptions",
      "Map proof gates"
    ],
    "routes": [
      "goalos.html",
      "validation-orchestrator.html",
      "proof-run-001-docket.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb14",
    "title": "Hybrid validates reusable capability promotion",
    "authority": "Hybrid",
    "risk": "MEDIUM",
    "prompt": "Validate whether accepted work can become reusable capability: proof history, rollback target, scope, risk class, and reviewer notes required.",
    "why": "Capabilities should compound only after evidence and rollback readiness.",
    "steps": [
      "Check proof history",
      "Check scope and rollback",
      "AGI Node performs completeness check"
    ],
    "routes": [
      "capability-compounding-lab.html",
      "validation-orchestrator.html",
      "proof-run-001-docket.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb15",
    "title": "AGI Node validates Mainnet proof rail learning path",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate that a new user can learn the Mainnet proof rail end-to-end: Atlas, Proof Rail, Contract Academy, Token Boundary, and Review path.",
    "why": "A useful Mainnet contract surface should be learnable, not merely present.",
    "steps": [
      "Check route sequence",
      "Check plain-language explanations",
      "Check token boundary link"
    ],
    "routes": [
      "mainnet-contract-atlas.html",
      "mainnet-proof-rail.html",
      "contract-academy.html",
      "token-boundary.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb16",
    "title": "Hybrid prepares external reviewer replay",
    "authority": "Hybrid",
    "risk": "MEDIUM",
    "prompt": "Prepare an external reviewer replay packet with public-safe artifacts, route map, claims matrix, and human review boundary.",
    "why": "External review requires clear artifacts and a bounded claim surface.",
    "steps": [
      "Package public-safe artifacts",
      "AGI Node checks route completeness",
      "Human confirms review instructions"
    ],
    "routes": [
      "proof-run-001-docket.html",
      "validation-orchestrator.html",
      "site-map.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb17",
    "title": "Council validates governance escalation",
    "authority": "Council",
    "risk": "STRATEGIC",
    "prompt": "Prepare Architect / Validator Council escalation for a strategic governance change that affects validation authority, proof gates, or public claims.",
    "why": "Governance changes require explicit authority, challengeability, and rollback.",
    "steps": [
      "Check authority boundary",
      "Check rollback readiness",
      "Prepare Council packet"
    ],
    "routes": [
      "validation-orchestrator.html",
      "trust-boundary.html",
      "proof-run-001-docket.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  },
  {
    "id": "pb18",
    "title": "AGI Node validates documentation completeness",
    "authority": "AGI Node",
    "risk": "LOW",
    "prompt": "Validate that documentation gives non-technical users a clear start path, use cases, proof examples, and boundary warnings.",
    "why": "Documentation is part of the operating system. Users need a clear path to value.",
    "steps": [
      "Check docs route",
      "Check use-case playbooks",
      "Check Ask GoalOS route"
    ],
    "routes": [
      "docs.html",
      "use-case-playbooks.html",
      "ask-goalos.html",
      "site-map.html"
    ],
    "outputs": [
      "Validation Certificate",
      "Attestation",
      "Reviewer Brief",
      "Action Graph"
    ]
  }
];
