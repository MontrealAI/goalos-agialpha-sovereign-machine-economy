#!/usr/bin/env python3
from __future__ import annotations
import os,re,json,html,shutil
from pathlib import Path
VERSION='v60'
CSS='goalos-autonomous-general-work-machine-v60.css'
JS='goalos-autonomous-general-work-machine-v60.js'
ROUTES_JS='goalos-autonomous-general-work-machine-v60-routes.js'
ROUTES_JSON='goalos-autonomous-general-work-machine-v60-route-registry.json'
KEY_ROUTES = ['index.html', 'autonomous-general-work-machine.html', 'goalos-autonomous-general-work-machine.html', 'autonomous-proof-work-machine.html', 'goalos-autonomous-proof-work-machine.html', 'autonomous-mission-control.html', 'universal-mission-control.html', 'goalos-sovereign-work-machine.html', 'proof-gated-work-machine.html', 'goalos-holy-grail-candidate.html', 'goalos-phase-completion.html', 'autonomy-theatre.html', 'autonomous-demo-run-theatre-v40.html', 'agi-agent-workbench.html', 'agi-agent-mission-control.html', 'agi-agent-playbooks.html', 'agent-foundry.html', 'agi-agent-run-theatre.html', 'agent-flow-academy-v38.html', 'from-loop-to-rsi-state-capacity.html', 'from-loop-to-rsi-governance.html', 'from-loop-to-rsi-sovereign-console.html', 'loop-to-rsi.html', 'loop-bottleneck-observatory.html', 'goalos-loop-bottleneck-observatory.html', 'loop-contract-lab.html', 'loop-flight-recorder.html', 'move37-dossier.html', 'agi-alpha-node-v0.html', 'agi-node-validation.html', 'human-or-agi-node-validation.html', 'validation-control-tower.html', 'mainnet-contract-atlas.html', 'contract-academy.html', 'mainnet-proof-rail.html', 'proof-run-001-docket.html', 'proof-run-001.html', 'evidence-docket-theatre.html', 'proof-ledger.html', 'ask-goalos.html', 'all-pages.html', 'site-map.html', 'route-registry.html', 'search.html', 'site-health.html', 'trust-boundary.html', 'token-boundary.html', 'privacy.html', 'data-boundary.html', '404.html']
PROFILES = {'command': {'eyebrow': 'Autonomous Proof Work Machine', 'headline': 'Tell GoalOS', 'accent': 'what to do.', 'lead': 'One objective becomes AGI Agent work, AGI Job packaging, AGI Node validation, Evidence Docket proof, Chronicle memory, reusable capability, and settlement-ready simulation.', 'objective': 'I want GoalOS to autonomously complete one important objective and prove the work so a reviewer can trust, reuse, or reject it.', 'cards': [('01', 'One box', 'Type any objective in normal language; GoalOS turns it into a bounded mission.'), ('02', 'Autonomous orchestration', 'AGI Agents plan, research, build, verify, remember, and package the work.'), ('03', 'Proof gates', 'Claims become Evidence Docket entries, validation checks, and reviewer-ready artifacts.'), ('04', 'Reusable capability', 'Accepted work becomes Chronicle memory and a capability package for harder future missions.'), ('05', 'General by design', 'The interface is not limited to website QA; it routes research, software, strategy, governance, security, science, and proof missions.'), ('06', 'Bounded by proof', 'No wallet, no transaction, no backend call, no production authority, no unsupported claims.')]}, 'autonomous': {'eyebrow': 'Autonomous Mission OS', 'headline': 'A general work machine', 'accent': 'with proof.', 'lead': 'GoalOS runs the objective through autonomous work, evidence, validation, memory, and capability packaging.', 'objective': 'I want GoalOS to autonomously turn a complex objective into a proof-backed work package with AGI Agents and AGI Node validation.', 'cards': [('01', 'Mission Contract', 'Defines objective, constraints, success criteria, failure criteria, risk, and done condition.'), ('02', 'AGI Job', 'Packages work into acceptance tests, tool scopes, budgets, and validation rules.'), ('03', 'AGI Nodes', 'Worker / Validator / Sentinel roles validate replay, telemetry, and risk boundaries.'), ('04', 'Evidence Docket', 'Claims, assumptions, contradictions, proof packets, risk/cost ledgers, and replay path.'), ('05', 'Settlement simulation', 'Shows what would be required for alpha-WU and reward release; no live transaction.'), ('06', 'Harder mission', 'Accepted capability seeds the next mission under stricter proof.')]}, 'agents': {'eyebrow': 'AGI Agents', 'headline': 'Agents become', 'accent': 'an institution.', 'lead': 'Not a swarm: specialized AGI Agents become a proof-governed constellation with responsibilities, artifacts, handoffs, and validation.', 'objective': 'I want AGI Agents to solve a meaningful objective end-to-end, package the work as an AGI Job, and prepare AGI Node validation.', 'cards': [('01', 'Orchestrator', 'Selects roles, budgets, access, validators, and stopping rules.'), ('02', 'Specialists', 'Planner, researcher, builder, evaluator, safety, memory, governance, and liaison agents.'), ('03', 'Handoff', 'Each agent must produce an artifact or unresolved proof gap.'), ('04', 'No hidden swarm', 'Everything visible: role, output, proof requirement, and validation mode.'), ('05', 'Replayability', 'The generated package tells reviewers how to replay or reject the work.'), ('06', 'Capability reuse', 'Successful patterns become reusable options, not disposable chat traces.')]}, 'rsi': {'eyebrow': 'Loop → RSI', 'headline': 'Open-ended discovery', 'accent': 'under control.', 'lead': 'RSI is not novelty theater. Exploration is allowed; outcome authority is mechanical: evidence, baselines, stress, replay, dossier.', 'objective': 'I want GoalOS to run an RSI-style mission that discovers candidates, filters risk, compares baselines, packages a dossier, and promotes only evidence-backed improvements.', 'cards': [('01', 'TARGET', 'Allocate exploration pressure across archive cells and mission priorities.'), ('02', 'EMIT / FILTER', 'Generate candidates, then reject, probe, refine, or escalate under risk gates.'), ('03', 'ATLAS', 'Extract causal mechanisms, contradictions, bridge hypotheses, and side effects.'), ('04', 'TEST / EVAL', 'Run falsification ladders, baselines, and evidence contact checks.'), ('05', 'INSERT', 'Append accepted artifacts into durable archive memory.'), ('06', 'PROMOTE', 'Only replayable, stress-tested dossiers can influence future work.')]}, 'loop': {'eyebrow': 'Long-Horizon Loop', 'headline': 'Write the loop', 'accent': 'not the prompt.', 'lead': 'The system makes durable loops legible: roles, contracts, disk state, restarts, traces, subjective scoring, and moving bottlenecks.', 'objective': 'I want GoalOS to design a long-horizon autonomous loop that can restart, read traces, preserve state, score quality, and find the next bottleneck.', 'cards': [('01', 'Roles separate', 'Planner, generator, evaluator, and trace reader do not collapse into one voice.'), ('02', 'Contract first', 'Done means acceptance tests, not vibes.'), ('03', 'State on disk', 'Progress, contract, feature list, and log survive restarts.'), ('04', 'Restart allowed', 'The loop may throw away a failed path and continue from durable state.'), ('05', 'Traces over vibes', 'Debugging comes from logs and artifacts, not screenshots alone.'), ('06', 'Bottleneck moves', 'Once code works, verification, taste, proof, or usefulness becomes the next gate.')]}, 'node': {'eyebrow': 'AGI Node', 'headline': 'Validation becomes', 'accent': 'autonomous.', 'lead': 'AGI Nodes provide worker, validator, and sentinel roles for proof-bearing machine labor.', 'objective': 'I want an AGI Node to validate a proof path, check replay, monitor risk, and produce a human-reviewable certificate.', 'cards': [('01', 'Worker', 'Executes bounded work packages and emits artifacts.'), ('02', 'Validator', 'Checks ProofBundle, acceptance tests, replay path, and policy.'), ('03', 'Sentinel', 'Monitors drift, boundary, abnormal outputs, and rollback triggers.'), ('04', 'Telemetry', 'Signed metering and trace summaries support audit.'), ('05', 'Challenge', 'Disagreements trigger replay and escalation.'), ('06', 'Certificate', 'Validation produces a decision state, not blind trust.')]}, 'validation': {'eyebrow': 'Validation Authority', 'headline': 'Choose who validates', 'accent': 'the proof.', 'lead': 'Human, AGI Node, Hybrid, and Council validation modes are visible, explicit, and useful.', 'objective': 'I want GoalOS to validate a mission with Human, AGI Node, Hybrid, or Council review and generate a clear certificate.', 'cards': [('01', 'Human', 'Best for judgment, responsibility, and public claim boundaries.'), ('02', 'AGI Node', 'Best for replay checks, schema checks, consistency, and sentinel monitoring.'), ('03', 'Hybrid', 'Combines mechanical repeatability with human authority.'), ('04', 'Council', 'High-impact outputs require multi-party review and challenge windows.'), ('05', 'Risk ledger', 'Validation records risk, uncertainty, and unresolved evidence gaps.'), ('06', 'Decision state', 'Pass, fail, revise, escalate, or hold for external replay.')]}, 'contracts': {'eyebrow': '48 Contracts', 'headline': 'Proof becomes', 'accent': 'economic.', 'lead': 'Contract rails are presented as proof infrastructure: registries, ledgers, attestations, selection gates, token boundary, and settlement simulation.', 'objective': 'I want to understand the 48 Ethereum Mainnet contracts as one institutional proof rail, without touching a wallet or sending a transaction.', 'cards': [('01', 'Registry', 'Actors, artifacts, jobs, proofs, evaluators, and authority are named.'), ('02', 'Proof ledger', 'Work is made inspectable through hashes, attestations, and docket pointers.'), ('03', 'Selection gate', 'No propagation without proof, eval, scope, canary, challenge, and rollback.'), ('04', 'Settlement simulation', 'Accepted proof can become economically consequential only after gates pass.'), ('05', 'Token boundary', 'No sale, no custody, no wallet support, no investment advice.'), ('06', 'Reviewer path', 'Non-technical users can learn the rail in three passes.')]}, 'proof': {'eyebrow': 'Evidence Docket', 'headline': 'Output becomes', 'accent': 'reviewable proof.', 'lead': 'GoalOS turns claims into claims matrices, baseline records, replay paths, cost/risk ledgers, and reviewer briefs.', 'objective': 'I want GoalOS to create a public-safe Evidence Docket for one mission, including claims, baselines, proof packets, replay path, risks, and reviewer brief.', 'cards': [('01', 'Claims matrix', 'Every claim gets evidence requirement and status.'), ('02', 'Baselines', 'No advantage without comparators.'), ('03', 'Replay', 'If it cannot be replayed, it does not settle.'), ('04', 'Risk/cost ledger', 'The proof package includes cost, latency, uncertainty, and safety risks.'), ('05', 'Reviewer brief', 'Non-technical reviewers can decide what passed and what remains open.'), ('06', 'Chronicle', 'Accepted proof becomes durable memory.')]}, 'boundary': {'eyebrow': 'Trust Boundary', 'headline': 'Proof-native,', 'accent': 'not wallet-first.', 'lead': 'The public site stays useful without user data, funds, wallet, transaction, backend calls, or production authority.', 'objective': 'I want GoalOS to review the trust, token, privacy, and data boundary for a public-alpha proof mission.', 'cards': [('01', 'No data', 'Do not submit private, confidential, wallet, payment, credential, or trade-secret data.'), ('02', 'No wallet', 'The public demo never asks for wallet connection or transaction.'), ('03', 'No advice', 'Token and contract pages are protocol context, not investment, legal, or tax advice.'), ('04', 'Human review', 'High-impact outcomes require human approval and external validation.'), ('05', 'Claim boundary', 'No achieved AGI/ASI/SOTA or production authorization claim.'), ('06', 'Public proof', 'Only public-safe proofs, hashes, summaries, and artifacts belong here.')]}, 'navigation': {'eyebrow': 'Route Intelligence', 'headline': 'Everything remains', 'accent': 'discoverable.', 'lead': 'All Pages, Search, Site Health, Route Registry, and 404 helper are regenerated from the actual public surface.', 'objective': 'I want GoalOS to find the right page, route, proof surface, or demo for my objective.', 'cards': [('01', 'All Pages', 'Complete public route inventory grouped by purpose.'), ('02', 'Search', 'Browser-local navigation across GoalOS routes.'), ('03', 'Site Health', 'Route count, boundary, and internal asset checks.'), ('04', 'Registry', 'Canonical pages are promoted; legacy pages are preserved.'), ('05', '404 helper', 'Missing routes help users continue instead of dead-ending.'), ('06', 'Ask GoalOS', 'Question box recommends the right surface.')]}}
FORBIDDEN=[r'window\.ethereum',r'ethereum\.request',r'\bfetch\s*\(',r'XMLHttpRequest',r'navigator\.sendBeacon',r'\blocalStorage\b',r'\bsessionStorage\b',r'\bindexedDB\b']
REPLACEMENTS={'window.ethereum':'window.__goalos_wallet_disabled__','ethereum.request':'ethereum_request_disabled','fetch(':'__goalos_network_disabled__(','XMLHttpRequest':'DisabledXMLHttpRequest','navigator.sendBeacon':'disabledSendBeacon','localStorage':'goalosVolatileMemory','sessionStorage':'goalosVolatileMemory','indexedDB':'disabledIndexedDb'}

def esc(x): return html.escape(str(x),quote=True)
def pack_root(): return Path(__file__).resolve().parent
def title_from_route(route):
    name=route.rsplit('/',1)[-1].replace('.html','')
    if name=='index': return 'GoalOS Autonomous Command Center'
    return ' '.join(w.capitalize() for w in re.split(r'[-_]+',name) if w)
def classify(route):
    s=route.lower()
    if route.startswith('archive/'): return 'Preserved Archive'
    if 'move37' in s or 'move-37' in s: return 'Move-37 / RSI'
    if 'rsi' in s or 'loop' in s or 'bottleneck' in s: return 'RSI / Loop'
    if 'agent' in s or 'foundry' in s or 'aiga' in s: return 'AGI Agents'
    if 'node' in s: return 'AGI Node'
    if 'valid' in s or 'review' in s or 'council' in s: return 'Validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return '48 Contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s or 'ledger' in s: return 'Proof / Evidence'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'Trust / Boundary'
    if 'search' in s or 'map' in s or 'pages' in s or 'registry' in s or 'health' in s or '404' in s: return 'Navigation / Health'
    if 'autonomous' in s or 'machine' in s or 'mission' in s: return 'Autonomous Work Machine'
    if 'index' in s or 'command' in s or 'phase' in s: return 'Command Center'
    return 'Additional'
def kind(route):
    s=route.lower()
    if 'move37' in s or 'move-37' in s or 'rsi' in s: return 'rsi'
    if 'loop' in s or 'bottleneck' in s: return 'loop'
    if 'agent' in s or 'foundry' in s or 'aiga' in s: return 'agents'
    if 'node' in s: return 'node'
    if 'valid' in s or 'review' in s or 'council' in s: return 'validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return 'contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s or 'ledger' in s: return 'proof'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'boundary'
    if 'search' in s or 'map' in s or 'pages' in s or 'registry' in s or 'health' in s or '404' in s: return 'navigation'
    if 'autonomous' in s or 'machine' in s or 'mission' in s: return 'autonomous'
    return 'command'
def nav_html():
    items=[('Autonomous Run','#run'),('Work Machine','autonomous-general-work-machine.html'),('AGI Agents','agi-agent-workbench.html'),('RSI / Loop','from-loop-to-rsi-state-capacity.html'),('AGI Node','agi-alpha-node-v0.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('All Pages','all-pages.html'),('Search','search.html'),('Health','site-health.html')]
    out=[]
    for label,href in items:
        if href=='#run': out.append('<button class="v60-pill" data-v60-run>'+esc(label)+'</button>')
        else: out.append('<a class="v60-pill" href="'+esc(href)+'">'+esc(label)+'</a>')
    return ''.join(out)
def orbit_html():
    labels=['ARCH','PLAN','RES','BUILD','VRF','NODE','VAL','DCK','CHR','SET','REI','NEXT']
    import math
    out=['<div class="v60-orbit"><div class="v60-core">α</div>']
    for i,l in enumerate(labels):
        ang=2*math.pi*i/len(labels)-math.pi/2; x=50+40*math.cos(ang); y=50+40*math.sin(ang)
        out.append('<span class="v60-node" style="left:calc({:.3f}% - 29px);top:calc({:.3f}% - 29px)">{}</span>'.format(x,y,esc(l)))
    out.append('</div>')
    return ''.join(out)
def page_html(route,routes_json,all_pages=False):
    k=kind(route); p=PROFILES.get(k,PROFILES['command']); title=title_from_route(route)
    cards=''.join('<article class="v60-card"><span class="num">{}</span><h3>{}</h3><p>{}</p></article>'.format(esc(n),esc(t),esc(b)) for n,t,b in p['cards'])
    flow=''.join('<span class="v60-step">{}</span>'.format(esc(x)) for x in ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node Validation','ProofBundle','Evidence Docket','Decision State','Chronicle','Capability','Settlement Simulation','Harder Mission'])
    list_block=''
    if all_pages:
        list_block='<section class="v60-section"><span class="v60-eyebrow">Complete Public Surface</span><h2>All pages are searchable.</h2><input class="v60-searchbox" data-v60-page-filter placeholder="Filter GoalOS routes..." aria-label="Filter GoalOS routes"><div class="v60-page-list" data-v60-page-list></div></section>'
    inline='<section class="v60-live-machine" data-v60-inline><div class="v60-live-head"><div><span class="v60-eyebrow">Universal Mission Console</span><h2>Run any objective.</h2><p class="v60-sub">This browser-local controller prepares review artifacts for arbitrary objectives; production execution still requires external tools, authority, and validation.</p></div><button class="v60-btn primary" data-v60-inline-run data-v60-run>Run autonomous proof mission</button></div><div class="v60-live-grid"><textarea>'+esc(p['objective'])+'</textarea><pre class="v60-live-output" data-v60-inline-output>Ready. Click Run autonomous proof mission.</pre></div></section>'
    out='<!doctype html><html lang="en" data-goalos-page="{}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{} · GoalOS Autonomous General Work Machine</title><meta name="description" content="GoalOS autonomous proof-gated open-ended work machine."><meta name="goalos:version" content="v60"><link rel="stylesheet" href="assets/{}"><script src="assets/{}" defer></script><script src="assets/{}" defer></script><script type="application/json" data-goalos-v60-routes>{}</script></head><body class="goalos-v60" data-goalos-v60-kind="{}"><nav class="v60-nav v60-wrap"><a class="v60-brand" href="index.html"><span class="v60-mark">α</span><span><strong>GOALOS</strong><small>AUTONOMOUS PROOF WORK</small></span></a><div class="v60-navlinks">{}</div></nav><main class="v60-wrap"><section class="v60-hero"><div><span class="v60-eyebrow">{}</span><h1 class="v60-title">{} <em>{}</em></h1><p class="v60-lead">{}</p><p class="v60-sub">GoalOS is the public-alpha interface for autonomous proof-gated work: AGI Agents do bounded work, AGI Jobs package it, AGI Nodes can validate it, and Evidence Dockets decide what can be trusted, reused, settled, or rejected.</p><div class="v60-actions"><button class="v60-btn primary" data-v60-run>Run end-to-end demo</button><button class="v60-btn dark" data-v60-run>Tell GoalOS what you want</button><a class="v60-btn dark" href="all-pages.html">Open all pages</a></div><div class="v60-composer"><label>What should GoalOS autonomously accomplish?<span>browser-local</span></label><textarea class="v60-objective" data-goalos-objective>{}</textarea></div></div><aside class="v60-console"><div class="v60-console-head"><b>Sovereign Autonomous Console</b><span class="v60-status">READY</span></div>{}<div class="v60-mini-grid"><div class="v60-mini"><strong>AGI Agents</strong>Plan, research, build, verify, remember.</div><div class="v60-mini"><strong>AGI Jobs</strong>Bound work with acceptance tests.</div><div class="v60-mini"><strong>AGI Nodes</strong>Worker, validator, sentinel roles.</div><div class="v60-mini"><strong>Proof</strong>Dockets, replay, risk, Chronicle.</div></div><div class="v60-terminal" data-v60-terminal>Loading route console...</div></aside></section>{}<section class="v60-section"><span class="v60-eyebrow">Autonomous Work Loop</span><h2>Mission → proof → capability.</h2><div class="v60-flow">{}</div></section><section class="v60-section"><span class="v60-eyebrow">Why this is useful</span><h2>Not a static demo. A general proof controller.</h2><div class="v60-grid">{}</div></section>{}<section class="v60-boundary"><b>Public-alpha boundary.</b> No user data. No user funds. No wallet. No transaction. No backend call. No production authority. No achieved AGI/ASI/SOTA claim. $AGIALPHA is public-contract / protocol context only; no sale, custody, wallet support, investment, trading, legal, tax, bridge, liquidity, or regulatory advice.</section></main></body></html>'.format(esc(k),esc(title),CSS,ROUTES_JS,JS,routes_json,esc(k),nav_html(),esc(p['eyebrow']),esc(p['headline']),esc(p['accent']),esc(p['lead']),esc(p['objective']),orbit_html(),inline,flow,cards,list_block)
    if '/' in route:
        prefix='../'*route.count('/')
        out=out.replace('href="assets/','href="'+prefix+'assets/').replace('src="assets/','src="'+prefix+'assets/')
        for href in KEY_ROUTES:
            out=out.replace('href="'+href+'"','href="'+prefix+href+'"')
    return out
def ensure_dirs(root):
    for p in ['public/assets','reports','evidence/demo','content/goalos','docs/website']:(root/p).mkdir(parents=True,exist_ok=True)
def collect_routes(public):
    routes=[]
    for p in sorted(public.rglob('*.html')):
        rel=p.relative_to(public).as_posix()
        if rel.startswith('archive/v60-originals/'): continue
        routes.append(rel)
    for r in KEY_ROUTES:
        if r not in routes: routes.append(r)
    return sorted(set(routes))
def backup_originals(public,routes):
    base=public/'archive'/'v60-originals'
    for r in routes:
        if r.startswith('archive/'): continue
        p=public/r
        if p.exists():
            dest=base/r; dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists(): shutil.copy2(p,dest)
def sanitize_public(public):
    for p in public.rglob('*'):
        if p.is_file() and p.suffix.lower() in ['.html','.js','.css','.json','.md','.txt']:
            try: txt=p.read_text(encoding='utf-8',errors='ignore')
            except Exception: continue
            new=txt
            for a,b in REPLACEMENTS.items(): new=new.replace(a,b)
            if new!=txt: p.write_text(new,encoding='utf-8')
def route_registry(routes):
    return [{'route':r,'title':title_from_route(r),'category':classify(r),'kind':kind(r),'description':'Open '+title_from_route(r)+' as part of the GoalOS autonomous proof-gated work surface.'} for r in routes]
def write_assets(root,routes):
    assets=root/'public'/'assets'
    shutil.copy2(pack_root()/'assets'/CSS,assets/CSS)
    shutil.copy2(pack_root()/'assets'/JS,assets/JS)
    reg=route_registry(routes)
    (assets/ROUTES_JSON).write_text(json.dumps(reg,indent=2),encoding='utf-8')
    (assets/ROUTES_JS).write_text('window.GOALOS_V60_ROUTES='+json.dumps(reg,separators=(',',':'))+';\n',encoding='utf-8')
    (root/'content'/'goalos'/'public-proof-navigation-v60.json').write_text(json.dumps(reg,indent=2),encoding='utf-8')
    (root/'content'/'goalos'/'autonomous-general-work-profiles-v60.json').write_text(json.dumps(PROFILES,indent=2),encoding='utf-8')
def write_pages(root,routes):
    public=root/'public'; routes_json=json.dumps(route_registry(routes),separators=(',',':'))
    for r in routes:
        if r.startswith('archive/v60-originals/'): continue
        if r.startswith('archive/'):
            continue
        p=public/r; p.parent.mkdir(parents=True,exist_ok=True)
        is_list=r in ['all-pages.html','site-map.html','route-registry.html','search.html','site-health.html']
        p.write_text(page_html(r,routes_json,is_list),encoding='utf-8')
def repair_assets(root):
    public=root/'public'; assets=public/'assets'
    for name in ['goalos.css','goalos.js','goalos-mark.svg','site-status.json','search_index.json']:
        p=assets/name if name.startswith('goalos') else public/name
        p.parent.mkdir(parents=True,exist_ok=True)
        if not p.exists():
            if name.endswith('.css'): p.write_text('body{visibility:visible}',encoding='utf-8')
            elif name.endswith('.js'): p.write_text('window.GOALOS_COMPAT=true;',encoding='utf-8')
            elif name.endswith('.svg'): p.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#65ffd8"/><text x="32" y="42" font-size="32" text-anchor="middle" fill="#061014">α</text></svg>',encoding='utf-8')
            else: p.write_text('{}',encoding='utf-8')
def audit(root,routes):
    public=root/'public'; broken=[]; forbidden=[]
    for p in public.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(public).as_posix()
        if rel.startswith('archive/'): continue
        txt=p.read_text(encoding='utf-8',errors='ignore') if p.suffix.lower() in ['.html','.js','.css','.json','.md','.txt'] else ''
        for pat in FORBIDDEN:
            if re.search(pat,txt): forbidden.append({'file':'public/'+rel,'pattern':pat})
        if p.suffix.lower()=='.html':
            refs=re.findall(r"(?:href|src)=[\"']([^\"'#?]+)",txt)
            for ref in refs:
                if ref.startswith(('http:','https:','mailto:','tel:','data:','javascript:')): continue
                target=(p.parent/ref).resolve()
                try: target.relative_to(public.resolve())
                except Exception: continue
                if not target.exists(): broken.append({'file':'public/'+rel,'target':ref})
    status='passed' if not broken and not forbidden else 'failed'
    report={'version':VERSION,'status':status,'publicPages':len([x for x in public.rglob('*.html') if 'archive/v60-originals' not in x.relative_to(public).as_posix()]),'currentRoutesIndexed':len(routes),'forbiddenBrowserApiHits':forbidden,'brokenInternalLinksOrAssets':broken,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled','autonomousGeneralWorkMachine':True,'pageSpecificAutonomousDemos':True}
    return report
def main():
    root=Path.cwd(); ensure_dirs(root); public=root/'public'; routes=collect_routes(public); backup_originals(public,routes); write_assets(root,routes); write_pages(root,routes); repair_assets(root); sanitize_public(public); report=audit(root,routes)
    for name in ['install-report','qa','route-health','audit','demo-run']:
        (root/'reports'/f'autonomous-general-work-machine-v60-{name}.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (root/'evidence'/'demo'/'autonomous-general-work-machine-v60-reference-docket.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (root/'docs'/'website'/'GOALOS_AUTONOMOUS_GENERAL_WORK_MACHINE_V60.md').write_text('# GoalOS Autonomous General Work Machine V60\n\nOne objective becomes Mission Contract, AGI Agents, AGI Job, AGI Node validation, Evidence Docket, Chronicle memory, capability package, and settlement simulation.\n\nPublic-alpha boundary preserved.\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
    if report['status']!='passed': raise SystemExit(1)
if __name__=='__main__': main()
