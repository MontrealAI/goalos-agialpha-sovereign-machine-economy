window.GOALOS_VALIDATION_ROUTES = [
  {
    "title": "GoalOS Mission Studio",
    "url": "goalos.html",
    "category": "Mission",
    "description": "Tell GoalOS what you want and generate a proof path."
  },
  {
    "title": "Ask GoalOS",
    "url": "ask-goalos.html",
    "category": "Assistant",
    "description": "Browser-local question window and route assistant."
  },
  {
    "title": "Mainnet Contract Atlas",
    "url": "mainnet-contract-atlas.html",
    "category": "Contracts",
    "description": "Explore the 48 Ethereum Mainnet contracts."
  },
  {
    "title": "Proof Run 001 Docket",
    "url": "proof-run-001-docket.html",
    "category": "Evidence",
    "description": "Review the first public proof docket."
  },
  {
    "title": "Loop to RSI State Capacity",
    "url": "from-loop-to-rsi-state-capacity.html",
    "category": "RSI",
    "description": "Understand deterministic invention governance."
  },
  {
    "title": "Token Boundary",
    "url": "token-boundary.html",
    "category": "Boundary",
    "description": "$AGIALPHA public contract identification only."
  },
  {
    "title": "Trust Boundary",
    "url": "trust-boundary.html",
    "category": "Boundary",
    "description": "No user data, no funds, no wallet, no transaction."
  },
  {
    "title": "All Pages",
    "url": "site-map.html",
    "category": "Navigation",
    "description": "Browse every public GoalOS page."
  }
];
