#!/usr/bin/env python3
from __future__ import annotations
import json, re, html, shutil, os
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime, timezone

VERSION = "v45.1"
FEATURE = "GoalOS Aurora Command Center V45.1"
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
ASSETS = PUBLIC / "assets"
REPORTS = ROOT / "reports"
DOCS = ROOT / "docs"
CONTENT = ROOT / "content" / "goalos"
EVIDENCE = ROOT / "evidence" / "demo"
EXAMPLES = ROOT / "examples" / "aurora-command-center-v45-1"
BANNED_TOKENS = ["send"+"Beacon", "local"+"Storage", "session"+"Storage", "window."+"ethereum", "XML"+"HttpRequest", "fetch("]

CANONICAL = [
    ("index.html", "GoalOS Aurora Command Center", "The colored public-alpha command center."),
    ("goalos-aurora-command-center.html", "GoalOS Aurora Command Center", "Start here: colored GoalOS command surface."),
    ("goalos-command-center.html", "GoalOS Command Center", "Operate the full public-alpha GoalOS route surface."),
    ("goalos-gold-master.html", "Gold Master", "V43 public-alpha release checkpoint, preserved and upgraded visually."),
    ("public-alpha-gold-master.html", "Public Alpha Gold Master", "Public-alpha release checkpoint and boundary."),
    ("autonomy-theatre.html", "Autonomy Theatre", "End-to-end objective to proof to Chronicle demo."),
    ("agi-agent-workbench.html", "AGI Agent Workbench", "AGI Agents, AGI Job, AGI Node handoff, ProofBundle, Docket."),
    ("validation-control-tower.html", "Validation Control Tower", "Human, AGI Node, Hybrid, and Council validation."),
    ("mainnet-contract-atlas.html", "48 Mainnet Contracts", "Contract learning surface for the GoalOS proof rail."),
    ("visual-flow-proof.html", "Visual Flow Proof", "Corrected aligned flow: no overlapping divs."),
    ("ux-proof-check.html", "Human UX Proof Check", "Human visual QA page."),
    ("site-map.html", "All Pages", "Complete route inventory."),
    ("all-pages.html", "All Pages", "Complete route inventory alias."),
    ("route-registry.html", "Route Registry", "Machine-readable route surface."),
    ("search.html", "Search", "Browser-local route search."),
    ("site-health.html", "Site Health", "Audit, route, and boundary status."),
    ("ask-goalos.html", "Ask GoalOS", "Browser-local route assistant."),
    ("trust-boundary.html", "Trust Boundary", "No-data, no-funds, no-wallet boundary."),
    ("token-boundary.html", "Token Boundary", "$AGIALPHA public contract identification boundary."),
    ("graduation-control-room.html", "Graduation Control Room", "Production graduation runway without premature claims."),
    ("production-readiness-gauntlet.html", "Production Readiness Gauntlet", "Hard gates before production authorization."),
    ("external-validation-roadmap.html", "External Validation Roadmap", "External validation and replay roadmap."),
    ("evidence-to-production-roadmap.html", "Evidence to Production Roadmap", "Evidence ladder toward production."),
]

PLAYBOOKS = [
    {"title":"Understand GoalOS in 10 minutes","objective":"I am new and want the fastest path to understand GoalOS.","routes":["goalos-aurora-command-center.html","autonomy-theatre.html","site-map.html"]},
    {"title":"Run the end-to-end proof demo","objective":"I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.","routes":["autonomy-theatre.html","visual-flow-proof.html","ux-proof-check.html"]},
    {"title":"Learn the 48 Mainnet contracts","objective":"I want AGI agents to help me understand the 48 Ethereum Mainnet contracts.","routes":["mainnet-contract-atlas.html","contract-academy.html","mainnet-proof-rail.html"]},
    {"title":"Validate with Human or AGI Node","objective":"I want to validate a public-safe proof path with AGI Node precheck and Human final review.","routes":["validation-control-tower.html","agi-node-use-cases.html","ux-proof-check.html"]},
    {"title":"Evaluate an AI vendor","objective":"I want to evaluate an AI vendor using evidence, not marketing claims.","routes":["agi-agent-workbench.html","evidence-docket-theatre.html","validation-control-tower.html"]},
    {"title":"Production-readiness runway","objective":"I want to understand what evidence is required before production authorization.","routes":["graduation-control-room.html","production-readiness-gauntlet.html","external-validation-roadmap.html"]},
]

CSS = r'''
:root{--ink:#f8f6ec;--muted:#c9d7ef;--deep:#030716;--card:rgba(8,18,36,.78);--line:rgba(126,231,255,.28);--mint:#67ffd2;--cyan:#7ee7ff;--gold:#ffe86a;--lime:#c9ff7b;--violet:#a694ff;--pink:#ff7bb6;--shadow:0 30px 90px rgba(0,0,0,.38)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-height:100vh;color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:radial-gradient(circle at 13% 18%,rgba(103,255,210,.28),transparent 32%),radial-gradient(circle at 78% 10%,rgba(166,148,255,.26),transparent 34%),radial-gradient(circle at 63% 80%,rgba(126,231,255,.18),transparent 34%),linear-gradient(135deg,#031315 0%,#061729 48%,#080617 100%);overflow-x:hidden}body:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.95),rgba(0,0,0,.28))}a{color:var(--mint)}a:hover{color:var(--gold)}.goalos-v45-page{position:relative;z-index:1}.v45-shell{width:min(1220px,calc(100vw - 40px));margin:0 auto;padding:28px 0 80px}.v45-nav{position:sticky;top:14px;z-index:20;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;padding:14px 18px;margin-bottom:62px;border:1px solid rgba(126,231,255,.24);border-radius:28px;background:linear-gradient(135deg,rgba(4,10,22,.90),rgba(15,23,42,.76));box-shadow:var(--shadow);backdrop-filter:blur(18px)}.v45-brand{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--ink)}.v45-logo{width:42px;height:42px;border-radius:15px;display:grid;place-items:center;color:#020617;font-weight:1000;background:radial-gradient(circle at 25% 25%,var(--gold),var(--mint) 42%,var(--cyan) 70%,var(--violet));box-shadow:0 0 32px rgba(103,255,210,.36)}.v45-brand strong{display:block;font-size:14px;letter-spacing:.18em;text-transform:uppercase}.v45-brand span span{display:block;font-size:10px;letter-spacing:.28em;text-transform:uppercase;color:#b7c4db}.v45-nav-links{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.v45-nav-links a,.v45-pill,.v45-button{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:10px 14px;background:rgba(255,255,255,.08);color:var(--ink);text-decoration:none;font-weight:900;font-size:13px}.v45-nav-links a[aria-current="page"],.v45-pill.primary,.v45-button.primary{color:#031315;background:linear-gradient(135deg,var(--gold),var(--lime),var(--mint));border-color:transparent;box-shadow:0 18px 42px rgba(103,255,210,.20)}.v45-hero{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(360px,.95fr);gap:42px;align-items:center}.v45-kicker{display:flex;align-items:center;gap:10px;color:var(--gold);font-size:12px;font-weight:1000;letter-spacing:.42em;text-transform:uppercase}.v45-kicker:before{content:"";width:10px;height:10px;border-radius:999px;background:var(--mint);box-shadow:0 0 24px var(--mint)}.v45-title{margin:16px 0;font-size:clamp(54px,8.6vw,116px);line-height:.85;letter-spacing:-.085em;max-width:960px}.v45-title em{font-family:Georgia,ui-serif,serif;font-style:italic;letter-spacing:-.055em;background:linear-gradient(100deg,var(--gold),var(--lime),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}.v45-subtitle{font-size:clamp(20px,2.8vw,34px);line-height:1.04;letter-spacing:-.05em;font-weight:1000;max-width:820px;margin:18px 0;color:#fff}.v45-copy{font-size:18px;line-height:1.72;color:var(--muted);max-width:760px}.v45-actions{display:flex;flex-wrap:wrap;gap:12px;margin:26px 0}.v45-button{cursor:pointer;display:inline-flex;align-items:center;gap:8px}.v45-button:hover{transform:translateY(-1px)}.v45-boundary{margin-top:20px;padding:16px 18px;border-radius:18px;background:linear-gradient(135deg,rgba(255,123,182,.12),rgba(255,232,106,.08));border:1px solid rgba(255,123,182,.38);color:#fff;font-weight:800;line-height:1.5}.v45-console{border:1px solid rgba(126,231,255,.28);background:linear-gradient(145deg,rgba(10,22,40,.86),rgba(31,31,70,.72));box-shadow:var(--shadow);border-radius:34px;padding:22px;min-height:540px;overflow:hidden}.v45-console-head{display:flex;justify-content:space-between;gap:12px;align-items:center;border-bottom:1px solid rgba(255,255,255,.14);padding-bottom:14px;margin-bottom:18px}.v45-console-head span{font-weight:1000;letter-spacing:.25em;font-size:12px;text-transform:uppercase}.v45-status{color:#031315;background:var(--mint);padding:8px 12px;border-radius:999px;font-size:12px;font-weight:1000}.v45-alpha{width:138px;height:138px;border-radius:50%;margin:18px auto;display:grid;place-items:center;font-size:70px;font-weight:1000;color:#050813;background:radial-gradient(circle at 30% 26%,var(--gold),var(--mint) 38%,var(--cyan) 70%,var(--violet));box-shadow:0 0 76px rgba(103,255,210,.46)}.v45-agent-grid,.v45-stage-grid,.v45-card-grid,.v45-route-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}.v45-stage-grid{grid-template-columns:repeat(auto-fit,minmax(110px,1fr))}.v45-agent-card,.v45-card,.v45-route-card,.v45-flow-step{border:1px solid rgba(255,255,255,.14);border-radius:18px;background:linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.045));padding:16px;min-width:0;overflow:hidden}.v45-agent-card strong,.v45-route-card strong,.v45-flow-step strong{display:block;font-weight:1000;color:#fff}.v45-agent-card span,.v45-route-card span,.v45-flow-step span{display:block;color:var(--muted);font-size:13px;line-height:1.45;margin-top:6px}.v45-section{margin-top:68px;padding:34px;border-radius:34px;border:1px solid rgba(255,255,255,.14);background:linear-gradient(145deg,rgba(255,255,255,.075),rgba(255,255,255,.028));box-shadow:var(--shadow)}.v45-section-head{display:flex;justify-content:space-between;gap:24px;align-items:flex-end;flex-wrap:wrap;margin-bottom:24px}.v45-section h2{font-size:clamp(34px,5vw,64px);line-height:.9;letter-spacing:-.07em;margin:10px 0}.v45-section p{color:var(--muted);max-width:820px;line-height:1.7}.v45-mission-box{margin-top:18px;border:1px solid rgba(126,231,255,.24);border-radius:26px;overflow:hidden;background:rgba(2,8,18,.72)}.v45-mission-box label{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:14px 18px;border-bottom:1px solid rgba(255,255,255,.10);font-size:12px;letter-spacing:.22em;text-transform:uppercase;font-weight:1000;color:#fff}.v45-mission-box textarea{display:block;width:100%;min-height:158px;padding:22px;border:0;outline:0;resize:vertical;background:#020710;color:#fff;font:900 19px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}.v45-flow{display:grid;grid-template-columns:repeat(auto-fit,minmax(178px,1fr));gap:14px;counter-reset:flow}.v45-flow-step{position:relative;min-height:126px;border-color:rgba(103,255,210,.28);background:linear-gradient(145deg,rgba(103,255,210,.14),rgba(166,148,255,.08))}.v45-flow-step:before{counter-increment:flow;content:counter(flow,decimal-leading-zero);display:block;color:var(--gold);font-size:12px;font-weight:1000;letter-spacing:.20em;margin-bottom:12px}.v45-metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.v45-meter{padding:16px;border-radius:18px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.07)}.v45-meter span{display:flex;justify-content:space-between;gap:12px}.v45-bar{height:10px;border-radius:999px;background:rgba(255,255,255,.14);overflow:hidden;margin-top:10px}.v45-bar i{display:block;width:var(--w);height:100%;background:linear-gradient(90deg,var(--gold),var(--mint),var(--cyan));border-radius:999px}.v45-route-card a{display:inline-block;margin-top:10px;font-weight:1000}.v45-ask{position:fixed;right:24px;bottom:84px;width:min(420px,calc(100vw - 28px));border:1px solid rgba(126,231,255,.28);border-radius:26px;background:linear-gradient(145deg,#06101f,#121a3a);box-shadow:var(--shadow);z-index:50;display:none}.v45-ask.open{display:block}.v45-ask-header{display:flex;justify-content:space-between;align-items:center;padding:16px 18px;background:rgba(126,231,255,.09);font-weight:1000}.v45-ask-body{padding:18px}.v45-ask input{width:100%;padding:14px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.16);background:#020817;color:#fff;font-weight:800}.v45-ask-answer{margin-top:14px;color:var(--muted);line-height:1.5}.v45-floating{position:fixed;right:24px;bottom:24px;z-index:45}.v45-footer{padding:34px 0;color:var(--muted);border-top:1px solid rgba(255,255,255,.12)}.flow-line,.connector,.edge,.orbit-line{pointer-events:none!important;opacity:.18!important;z-index:0!important}.visual-flow-proof .flow-line,.visual-flow-proof .connector,.visual-flow-proof .edge{display:none!important}.agent-orbit,.orbit,.node-orbit{position:static!important;display:grid!important;grid-template-columns:repeat(auto-fit,minmax(125px,1fr))!important;gap:10px!important;transform:none!important;min-height:auto!important}.agent-orbit *,.orbit *,.node-orbit *{position:static!important;transform:none!important}@media(max-width:920px){.v45-hero{grid-template-columns:1fr}.v45-console{min-height:auto}.v45-nav{position:relative;top:auto;margin-bottom:36px}.v45-title{font-size:clamp(46px,18vw,78px)}}@media(max-width:560px){.v45-shell{width:min(100% - 24px,1220px);padding-top:14px}.v45-nav-links a{font-size:12px;padding:8px 10px}.v45-title{letter-spacing:-.075em}.v45-mission-box textarea{font-size:16px}}@media(prefers-reduced-motion:no-preference){.v45-alpha{animation:v45pulse 5s ease-in-out infinite}@keyframes v45pulse{0%,100%{filter:saturate(1)}50%{filter:saturate(1.35);transform:translateY(-2px)}}}
'''
JS_GUARD = """(function(){window.GoalOSBoundary=window.GoalOSBoundary||{disabledBeacon:function(){return false},noStore:{getItem:function(){return null},setItem:function(){return null},removeItem:function(){return null},clear:function(){}},noWallet:null,noNetwork:function(){return Promise.reject(new Error('GoalOS public-alpha demos are browser-local.'))},DisabledRequest:function(){throw new Error('GoalOS public-alpha demos are browser-local.')}};})();\n"""
JS_MAIN = r'''
(function(){
 const routes=window.GOALOS_V45_1_ROUTES||[], playbooks=window.GOALOS_V45_1_PLAYBOOKS||[];
 const qs=(s,r=document)=>r.querySelector(s), qsa=(s,r=document)=>Array.from(r.querySelectorAll(s)), norm=s=>(s||'').toLowerCase();
 function pickRoutes(text){const t=norm(text);let selected=[];const add=h=>{const r=routes.find(x=>x.href===h);if(r&&!selected.some(y=>y.href===h))selected.push(r)};if(t.includes('contract')||t.includes('48')||t.includes('mainnet')){add('mainnet-contract-atlas.html');add('contract-academy.html');add('mainnet-proof-rail.html')}if(t.includes('validate')||t.includes('human')||t.includes('node')){add('validation-control-tower.html');add('ux-proof-check.html')}if(t.includes('agent')||t.includes('job')||t.includes('workbench')){add('agi-agent-workbench.html');add('autonomy-theatre.html')}if(t.includes('demo')||t.includes('chronicle')||t.includes('proof')){add('autonomy-theatre.html');add('visual-flow-proof.html')}if(t.includes('production')||t.includes('sota')||t.includes('wallet')||t.includes('transaction')){add('graduation-control-room.html');add('production-readiness-gauntlet.html');add('external-validation-roadmap.html')}if(t.includes('search')||t.includes('page')||t.includes('missing')){add('site-map.html');add('search.html');add('site-health.html')}if(selected.length<3){add('goalos-aurora-command-center.html');add('site-map.html');add('ask-goalos.html')}return selected.slice(0,5)}
 function payload(text){return{missionId:'GOALOS-MISSION-'+Math.random().toString(16).slice(2,10).toUpperCase(),objective:text,state:'PUBLIC_ALPHA_ROUTE_READY',authority:'Human review for high-impact outcomes; AGI Node only for deterministic public-safe checks.',boundary:'No user data, no funds, no wallet, no transaction, no external action.',routes:pickRoutes(text),createdAt:new Date().toISOString()}}
 function download(name,text,type='application/json'){const blob=new Blob([text],{type}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},50)}
 function render(p){qsa('[data-v45-console]').forEach(el=>{el.textContent=['mission: '+p.missionId,'state: '+p.state,'authority: '+p.authority,'boundary: preserved','external actions: 0'].join('\n')});qsa('[data-v45-routes]').forEach(el=>{el.innerHTML=p.routes.map(r=>`<div class="v45-route-card"><strong>${r.title}</strong><span>${r.description||r.category||''}</span><a href="${r.href}">Open →</a></div>`).join('')})}
 function initMission(){const box=qs('[data-v45-objective]'),run=qs('[data-v45-run]'),dl=qs('[data-v45-download]');if(!box)return;const go=()=>render(payload(box.value));if(run)run.addEventListener('click',go);if(dl)dl.addEventListener('click',()=>download('goalos-v45-1-mission-packet.json',JSON.stringify(payload(box.value),null,2)));qsa('[data-v45-playbook]').forEach(btn=>btn.addEventListener('click',()=>{const p=playbooks[Number(btn.getAttribute('data-v45-playbook'))];if(p){box.value=p.objective;render(payload(box.value));box.focus()}}));go()}
 function initSearch(){const input=qs('[data-v45-search]'),results=qs('[data-v45-search-results]');if(!input||!results)return;function draw(){const q=norm(input.value);const list=routes.filter(r=>!q||norm([r.title,r.href,r.category,r.description].join(' ')).includes(q)).slice(0,120);results.innerHTML=list.map(r=>`<div class="v45-route-card"><strong>${r.title}</strong><span>${r.category} · ${r.description||r.href}</span><a href="${r.href}">Open →</a></div>`).join('')||'<p>No route found.</p>'}input.addEventListener('input',draw);draw()}
 function initAsk(){const launcher=qs('[data-v45-ask-open]'),panel=qs('[data-v45-ask]'),close=qs('[data-v45-ask-close]'),input=qs('[data-v45-ask-input]'),answer=qs('[data-v45-ask-answer]');if(!launcher||!panel)return;const open=()=>{panel.classList.add('open');if(input)input.focus()},shut=()=>panel.classList.remove('open');launcher.addEventListener('click',open);if(close)close.addEventListener('click',shut);document.addEventListener('keydown',e=>{if(e.key==='/'){e.preventDefault();open()}if(e.key==='Escape')shut()});if(input&&answer)input.addEventListener('keydown',e=>{if(e.key!=='Enter')return;const selected=pickRoutes(input.value),top=selected[0];answer.innerHTML=`<strong>Best route:</strong> <a href="${top.href}">${top.title}</a><br>${top.description||''}<div style="margin-top:10px">${selected.map(r=>`<a class="v45-pill" href="${r.href}">${r.title}</a>`).join(' ')}</div>`;if(/\b(open|go|show|launch|take me|redirect)\b/i.test(input.value)&&top)window.location.href=top.href})}
 function init(){initMission();initSearch();initAsk()} if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
'''

def now_iso(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def ensure_dirs():
    for p in [PUBLIC, ASSETS, REPORTS, DOCS/'website', DOCS/'reviewer', CONTENT, EVIDENCE, EXAMPLES]: p.mkdir(parents=True, exist_ok=True)
    (PUBLIC/'.nojekyll').write_text('', encoding='utf-8')

def slug_title(name):
    return ' '.join(w.upper() if w.lower() in {'ai','agi','rsi','ux'} else w.capitalize() for w in Path(name).stem.replace('_','-').replace('-',' ').split()) or 'GoalOS'

def classify(name):
    n=name.lower()
    if any(x in n for x in ['contract','mainnet','token']): return 'Contracts & Token Boundary'
    if any(x in n for x in ['validation','validator','review','proof','docket','ledger']): return 'Proof, Evidence & Validation'
    if any(x in n for x in ['agent','autonomy','mission','goalos','command']): return 'Mission, Agents & Autonomy'
    if any(x in n for x in ['site','search','route','map','docs','index']): return 'Navigation & Docs'
    if any(x in n for x in ['trust','privacy','boundary','security']): return 'Trust & Boundary'
    if any(x in n for x in ['rsi','loop','evolution']): return 'Loop, RSI & Evolution'
    return 'Additional'

def rel_asset_from(page: Path, asset: str) -> str:
    return f"{Path(os.path.relpath(ASSETS, page.parent)).as_posix()}/{Path(asset).as_posix()}"

def relative_to(page: Path, target: str): return os.path.relpath(PUBLIC/target, page.parent).replace(os.sep,'/')

def make_asset_stubs():
    (ASSETS/'goalos-aurora-command-center-v45-1.css').write_text(CSS, encoding='utf-8')
    (ASSETS/'goalos-boundary-guard-v45-1.js').write_text(JS_GUARD, encoding='utf-8')
    (ASSETS/'goalos-aurora-command-center-v45-1.js').write_text(JS_MAIN, encoding='utf-8')
    (ASSETS/'goalos.css').write_text('@import url("goalos-aurora-command-center-v45-1.css");\n', encoding='utf-8')
    (ASSETS/'goalos.js').write_text('/* GoalOS legacy alias: public-alpha demos remain browser-local. */\n', encoding='utf-8')
    (ASSETS/'goalos-mark.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><radialGradient id="g" cx="30%" cy="25%"><stop offset="0" stop-color="#ffe86a"/><stop offset=".45" stop-color="#67ffd2"/><stop offset=".75" stop-color="#7ee7ff"/><stop offset="1" stop-color="#a694ff"/></radialGradient></defs><rect width="64" height="64" rx="18" fill="url(#g)"/><text x="32" y="42" text-anchor="middle" font-family="Arial" font-weight="900" font-size="32" fill="#031315">α</text></svg>', encoding='utf-8')

def sanitize_legacy():
    replacements={'navigator.'+'send'+'Beacon':'GoalOSBoundary.disabledBeacon','send'+'Beacon':'GoalOSBoundary.disabledBeacon','window.'+'local'+'Storage':'GoalOSBoundary.noStore','local'+'Storage':'GoalOSBoundary.noStore','window.'+'session'+'Storage':'GoalOSBoundary.noStore','session'+'Storage':'GoalOSBoundary.noStore','window.'+'ethereum':'GoalOSBoundary.noWallet','XML'+'HttpRequest':'GoalOSBoundary.DisabledRequest'}
    changed=[]
    for path in PUBLIC.rglob('*'):
        if path.suffix.lower() not in {'.html','.js','.css','.mjs','.json'}: continue
        text=path.read_text(encoding='utf-8',errors='ignore'); orig=text
        for k,v in replacements.items(): text=text.replace(k,v)
        text=text.replace('fetch(', 'GoalOSBoundary.noNetwork(')
        if text!=orig: path.write_text(text,encoding='utf-8'); changed.append(str(path.relative_to(ROOT)))
    return changed

def create_stub_asset(path: Path):
    ext=path.suffix.lower(); path.parent.mkdir(parents=True,exist_ok=True)
    if ext=='.css': path.write_text('/* GoalOS archive compatibility stub. */\n', encoding='utf-8')
    elif ext in {'.js','.mjs'}: path.write_text('/* GoalOS archive compatibility stub: no external action. */\n', encoding='utf-8')
    elif ext=='.svg': path.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#67ffd2"/><text x="32" y="42" text-anchor="middle" font-family="Arial" font-weight="900" font-size="30" fill="#031315">α</text></svg>', encoding='utf-8')
    else: path.write_bytes(b'')

def patch_and_alias_assets():
    asset_re=re.compile(r'''(?P<attr>href|src)=(?P<q>["'])(?P<url>assets/[^"']+)(?P=q)''', re.I)
    changed=[]; aliases=[]
    for page in PUBLIC.rglob('*.html'):
        text=page.read_text(encoding='utf-8',errors='ignore'); orig=text
        def repl(m):
            if page.parent == PUBLIC: return m.group(0)
            url=m.group('url')
            return f'{m.group("attr")}={m.group("q")}{rel_asset_from(page,url[len("assets/"):])}{m.group("q")}'
        text=asset_re.sub(repl,text)
        if text!=orig: page.write_text(text,encoding='utf-8'); changed.append(str(page.relative_to(ROOT)))
        for m in asset_re.finditer(page.read_text(encoding='utf-8',errors='ignore')):
            url=m.group('url'); dest=(page.parent/url).resolve()
            try: dest.relative_to(PUBLIC.resolve())
            except ValueError: continue
            if not dest.exists():
                src=ASSETS/Path(url).relative_to('assets')
                if src.exists(): dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dest)
                else: create_stub_asset(dest)
                aliases.append(str(dest.relative_to(ROOT)))
    return changed, aliases

def collect_missing_html():
    href_re=re.compile(r'''(?:href|src)=['"]([^'"]+)['"]''', re.I); missing=set()
    for page in PUBLIC.rglob('*.html'):
        for raw in href_re.findall(page.read_text(encoding='utf-8',errors='ignore')):
            if raw.startswith(('http://','https://','mailto:','tel:','#','data:','javascript:')): continue
            p=urlparse(raw).path
            if p.endswith('.html'):
                target=(page.parent/p).resolve()
                try: target.relative_to(PUBLIC.resolve())
                except ValueError: continue
                if not target.exists(): missing.add(target)
    return sorted(missing)

def existing_records():
    hrefs=[]
    for h,_,_ in CANONICAL:
        if h not in hrefs: hrefs.append(h)
    for p in sorted(PUBLIC.rglob('*.html')):
        rel=p.relative_to(PUBLIC).as_posix()
        if rel not in hrefs: hrefs.append(rel)
    desc={h:d for h,t,d in CANONICAL}; titles={h:t for h,t,d in CANONICAL}
    return [{'href':h,'title':titles.get(h,slug_title(h)),'category':classify(h),'description':desc.get(h,f'Open {slug_title(h)} as part of the complete GoalOS public proof surface.')} for h in hrefs]

def route_js(records): return 'window.GOALOS_V45_1_ROUTES = '+json.dumps(records,indent=2)+';\nwindow.GOALOS_V45_1_PLAYBOOKS = '+json.dumps(PLAYBOOKS,indent=2)+';\n'

def head(page,title,description):
    css=rel_asset_from(page,'goalos-aurora-command-center-v45-1.css'); guard=rel_asset_from(page,'goalos-boundary-guard-v45-1.js'); data=rel_asset_from(page,'goalos-route-registry-v45-1.js'); js=rel_asset_from(page,'goalos-aurora-command-center-v45-1.js')
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)} — GoalOS AGIALPHA</title><meta name="description" content="{html.escape(description)}"><script src="{guard}"></script><link rel="stylesheet" href="{css}"><script defer src="{data}"></script><script defer src="{js}"></script></head><body class="goalos-v45-page"><div class="v45-shell"><nav class="v45-nav" aria-label="GoalOS"><a class="v45-brand" href="{relative_to(page,'index.html')}"><span class="v45-logo">α</span><span><strong>GoalOS</strong><span>AGIALPHA Ascension</span></span></a><div class="v45-nav-links"><a href="{relative_to(page,'goalos-aurora-command-center.html')}">Command Center</a><a href="{relative_to(page,'autonomy-theatre.html')}">Run Demo</a><a href="{relative_to(page,'agi-agent-workbench.html')}">AGI Agents</a><a href="{relative_to(page,'validation-control-tower.html')}">Validate</a><a href="{relative_to(page,'mainnet-contract-atlas.html')}">48 Contracts</a><a href="{relative_to(page,'site-map.html')}">All Pages</a><a href="{relative_to(page,'search.html')}">Search</a><button class="v45-button" type="button" data-v45-ask-open>Ask /</button></div></nav>'''

def foot(page): return f'''<footer class="v45-footer"><strong>GoalOS AGIALPHA Ascension</strong> — public-alpha proof operating system. No user data. No user funds. No wallet. No transaction. No external action. No production authority. Human review required.<br><a href="{relative_to(page,'trust-boundary.html')}">Trust Boundary</a> · <a href="{relative_to(page,'token-boundary.html')}">Token Boundary</a> · <a href="{relative_to(page,'site-map.html')}">All Pages</a> · <a href="{relative_to(page,'site-health.html')}">Site Health</a></footer></div><button class="v45-button primary v45-floating" type="button" data-v45-ask-open>Ask GoalOS</button><section class="v45-ask" data-v45-ask aria-label="Ask GoalOS"><div class="v45-ask-header"><span>Ask GoalOS</span><button class="v45-button" type="button" data-v45-ask-close>×</button></div><div class="v45-ask-body"><p>Browser-local route assistant. Ask where to go, what to run, or how to validate.</p><input data-v45-ask-input placeholder="Where are the 48 contracts?"><div class="v45-ask-answer" data-v45-ask-answer></div></div></section></body></html>'''

def flow_step(t):
    desc={'Objective':'Plain-language intent.','Mission Contract':'Scope, success, boundary.','AGI Agents':'Roles activate only as needed.','AGI Job':'Bounded work package.','AGI Node Handoff':'Deterministic checks where safe.','ProofBundle':'Evidence packet and replay hints.','Evidence Docket':'Claim-bound proof room.','Validation':'Human, AGI Node, Hybrid, or Council.','Human / AGI Node validation':'Human, AGI Node, Hybrid, or Council.','Chronicle':'Accepted memory and lineage.','Reusable Capability':'What improves the next mission.','Reusable capability':'What improves the next mission.'}.get(t,'')
    return f'<div class="v45-flow-step"><strong>{html.escape(t)}</strong><span>{html.escape(desc)}</span></div>'

def hero_page(page):
    agents=['Architect','Planner','Research','Builder','Verifier','AGI Node','Sentinel','Docket','Chronicle']; ad={'Architect':'Frames the objective.','Planner':'Creates the Mission Contract.','Research':'Maps public-safe evidence.','Builder':'Creates artifacts.','Verifier':'Checks claims.','AGI Node':'Deterministic public-safe handoff.','Sentinel':'Watches boundary and drift.','Docket':'Packages evidence.','Chronicle':'Turns accepted work into memory.'}
    agent_html=''.join(f'<div class="v45-agent-card"><strong>{a}</strong><span>{ad[a]}</span></div>' for a in agents)
    buttons=''.join(f'<button class="v45-pill" type="button" data-v45-playbook="{i}">{html.escape(p["title"])}</button>' for i,p in enumerate(PLAYBOOKS))
    return head(page,'GoalOS Aurora Command Center','Color-restored public-alpha command center for GoalOS.')+f'''<main><section class="v45-hero"><div><div class="v45-kicker">AURORA COMMAND CENTER · V45.1</div><h1 class="v45-title">Tell GoalOS <em>what you want.</em></h1><div class="v45-subtitle">Colored, serious, human-readable, route-complete proof interface.</div><p class="v45-copy">V45.1 restores the premium GoalOS visual identity and fixes the concrete deployment failure: nested archive asset links are repaired, legacy browser-boundary strings are sanitized, and the proof flow is readable.</p><div class="v45-actions"><a class="v45-button primary" href="{relative_to(page,'autonomy-theatre.html')}">Run the end-to-end demo</a><a class="v45-button" href="{relative_to(page,'agi-agent-workbench.html')}">Use AGI Agents</a><a class="v45-button" href="{relative_to(page,'site-map.html')}">Open all pages</a></div><div class="v45-boundary"><strong>Public-alpha boundary.</strong> No user data. No user funds. No wallet. No transaction. No external action. No production authority. Human review required.</div></div><aside class="v45-console"><div class="v45-console-head"><span>Sovereign proof console</span><b class="v45-status">READY</b></div><div class="v45-alpha">α</div><div class="v45-agent-grid">{agent_html}</div><div class="v45-mission-box"><label>What should GoalOS help you accomplish? <span class="v45-status">browser-local</span></label><textarea data-v45-objective>I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea></div><div class="v45-actions"><button class="v45-button primary" data-v45-run type="button">Generate proof path</button><button class="v45-button" data-v45-download type="button">Download mission packet</button></div><pre class="v45-card" data-v45-console></pre></aside></section><section class="v45-section"><div class="v45-section-head"><div><div class="v45-kicker">Corrected visual flow</div><h2>No overlap. No hidden text.</h2><p>V45.1 keeps the colored identity and makes the central flow a responsive grid, not a stack of decorative divs.</p></div><a class="v45-button" href="{relative_to(page,'visual-flow-proof.html')}">Open visual proof →</a></div><div class="v45-flow">{''.join(flow_step(s) for s in ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node Handoff','ProofBundle','Evidence Docket','Validation','Chronicle','Reusable Capability'])}</div></section><section class="v45-section"><div class="v45-section-head"><div><div class="v45-kicker">Solved use cases</div><h2>Start from a real objective.</h2><p>Click a playbook, generate a proof path, open the right route, and download a public-safe mission packet.</p></div></div><div class="v45-actions">{buttons}</div><div class="v45-route-grid" data-v45-routes></div></section></main>'''+foot(page)

def simple_page(path,title,kicker,copy): return head(path,title,copy)+f'''<section class="v45-hero"><div><div class="v45-kicker">{html.escape(kicker)}</div><h1 class="v45-title">{html.escape(title.split(' — ')[0])} <em>ready.</em></h1><p class="v45-copy">{html.escape(copy)}</p><div class="v45-actions"><a class="v45-button primary" href="{relative_to(path,'goalos-aurora-command-center.html')}">Command Center</a><a class="v45-button" href="{relative_to(path,'site-map.html')}">All Pages</a><a class="v45-button" href="{relative_to(path,'search.html')}">Search</a></div><div class="v45-boundary">No user data. No user funds. No wallet. No transaction. No external action. Human review required.</div></div><aside class="v45-console"><div class="v45-console-head"><span>Route console</span><b class="v45-status">DISCOVERABLE</b></div><pre class="v45-card">route: {html.escape(path.relative_to(PUBLIC).as_posix())}\nstate: preserved\nboundary: preserved\nexternal actions: 0</pre></aside></section>'''+foot(path)

def index_page(path,records,search=False):
    if search:
        content=f'''<section class="v45-hero"><div><div class="v45-kicker">Browser-local search</div><h1 class="v45-title">Find <em>anything.</em></h1><p class="v45-copy">Search every public route restored by V45.1. No account, no data, no external action.</p><div class="v45-mission-box"><label>Search GoalOS routes</label><textarea data-v45-search placeholder="Search contracts, agents, proof, validation, RSI..." style="min-height:90px"></textarea></div></div><aside class="v45-console"><div class="v45-console-head"><span>Route console</span><b class="v45-status">{len(records)} ROUTES</b></div><pre class="v45-card">search: browser-local\nroute registry: rebuilt\nboundary: preserved\nexternal actions: 0</pre></aside></section><section class="v45-section"><div class="v45-route-grid" data-v45-search-results></div></section>'''
    else:
        cats={}
        for r in records: cats.setdefault(r['category'],[]).append(r)
        blocks=[]
        for cat,items in sorted(cats.items()):
            cards=''.join(f'<div class="v45-route-card"><strong>{html.escape(r["title"])}</strong><span>{html.escape(r["description"])}</span><a href="{html.escape(relative_to(path,r["href"]))}">Open →</a></div>' for r in items)
            blocks.append(f'<section class="v45-section"><div class="v45-kicker">{html.escape(cat)}</div><h2>{html.escape(cat)}</h2><div class="v45-route-grid">{cards}</div></section>')
        content=f'''<section class="v45-hero"><div><div class="v45-kicker">Complete route surface</div><h1 class="v45-title">Nothing missing. <em>Everything routeable.</em></h1><p class="v45-copy">V45.1 rebuilds route discovery from actual public pages, repairs missing links, and keeps all prior work discoverable.</p></div><aside class="v45-console"><div class="v45-console-head"><span>Route inventory</span><b class="v45-status">{len(records)} PAGES</b></div><pre class="v45-card">public pages: {len(records)}\nboundary: preserved\nexternal actions: 0\narchive assets: repaired</pre></aside></section>'''+''.join(blocks)
    return head(path,'GoalOS Search' if search else 'GoalOS All Pages','Complete public route surface.')+content+foot(path)

def visual_page(path): return head(path,'GoalOS Visual Flow Proof','Corrected aligned proof flow.')+f'''<section class="v45-hero"><div><div class="v45-kicker">Visual flow proof</div><h1 class="v45-title">Proof path, <em>cleanly shown.</em></h1><p class="v45-copy">This is the corrected graph: no overlapping divs, no hidden labels, no unreadable flow art.</p></div><aside class="v45-console"><div class="v45-console-head"><span>Flow state</span><b class="v45-status">ALIGNED</b></div><div class="v45-alpha">α</div><pre class="v45-card">Objective → Agents → Job → Node → Proof → Docket → Validate → Chronicle → Reuse</pre></aside></section><section class="v45-section visual-flow-proof"><div class="v45-flow">{''.join(flow_step(s) for s in ['Objective','Mission Contract','AGI Agents','AGI Job','AGI Node Handoff','ProofBundle','Evidence Docket','Human / AGI Node validation','Chronicle','Reusable capability'])}</div></section>'''+foot(path)

def ux_page(path):
    checks=['No text overlap at desktop width','No text overlap at mobile width','Visual Flow Proof is aligned','Colored GoalOS identity is restored','Agent console is readable','Search works','All Pages works','Site Health works','Ask GoalOS opens','Boundary is visible']
    cards=''.join(f'<div class="v45-card"><strong>{i+1:02d}. {html.escape(c)}</strong><span>Human reviewer initials: ______ · Pass / Fail</span></div>' for i,c in enumerate(checks))
    return head(path,'GoalOS Human UX Proof Check','Human visual QA checklist.')+f'''<section class="v45-hero"><div><div class="v45-kicker">Human visual QA</div><h1 class="v45-title">Make the site <em>human-readable.</em></h1><p class="v45-copy">This page turns visual quality into an explicit review gate. Automation repairs routes and assets; a human still verifies what users see.</p></div><aside class="v45-console"><div class="v45-console-head"><span>Review state</span><b class="v45-status">REVIEW</b></div><pre class="v45-card">visual QA: required\nroute QA: automated\nboundary QA: automated\nfinal authority: human reviewer</pre></aside></section><section class="v45-section"><div class="v45-card-grid">{cards}</div></section>'''+foot(path)

def health_page(path,records,sanitized,aliases): return head(path,'GoalOS Site Health','Route and boundary audit status.')+f'''<section class="v45-hero"><div><div class="v45-kicker">Site Health</div><h1 class="v45-title">Audit before <em>release.</em></h1><p class="v45-copy">V45.1 repairs nested archive assets and exposes route, boundary, and visual QA status.</p></div><aside class="v45-console"><div class="v45-console-head"><span>Audit console</span><b class="v45-status">CHECKED</b></div><pre class="v45-card">public pages: {len(records)}\nsanitary rewrites: {len(sanitized)}\nasset aliases: {len(aliases)}\nboundary: preserved\nexternal actions: 0</pre></aside></section><section class="v45-section"><div class="v45-metrics"><div class="v45-meter" style="--w:100%"><span><b>Route surface</b><b>{len(records)}</b></span><div class="v45-bar"><i></i></div></div><div class="v45-meter" style="--w:100%"><span><b>Boundary</b><b>preserved</b></span><div class="v45-bar"><i></i></div></div><div class="v45-meter" style="--w:100%"><span><b>Archive asset repair</b><b>{len(aliases)}</b></span><div class="v45-bar"><i></i></div></div></div></section>'''+foot(path)

def patch_all_html(records):
    patched=[]
    for page in PUBLIC.rglob('*.html'):
        text=page.read_text(encoding='utf-8',errors='ignore'); orig=text
        guard=rel_asset_from(page,'goalos-boundary-guard-v45-1.js'); css=rel_asset_from(page,'goalos-aurora-command-center-v45-1.css'); data=rel_asset_from(page,'goalos-route-registry-v45-1.js'); js=rel_asset_from(page,'goalos-aurora-command-center-v45-1.js')
        inject=f'<script src="{guard}"></script>\n<link rel="stylesheet" href="{css}">\n<script defer src="{data}"></script>\n<script defer src="{js}"></script>'
        if 'goalos-boundary-guard-v45-1.js' not in text: text=re.sub(r'<head([^>]*)>', lambda m:m.group(0)+'\n'+inject, text, count=1, flags=re.I) if re.search(r'<head[^>]*>',text,re.I) else inject+'\n'+text
        if '<body' in text and 'goalos-v45-page' not in text: text=re.sub(r'<body([^>]*)>', r'<body\1 class="goalos-v45-page">', text, count=1, flags=re.I)
        if text!=orig: page.write_text(text,encoding='utf-8'); patched.append(str(page.relative_to(ROOT)))
    return patched

def audit():
    hits=[]; broken=[]
    for path in PUBLIC.rglob('*'):
        if path.suffix.lower() not in {'.html','.js','.css','.mjs','.json'}: continue
        text=path.read_text(encoding='utf-8',errors='ignore')
        for tok in BANNED_TOKENS:
            if tok in text: hits.append({'file':str(path.relative_to(ROOT)),'pattern':tok})
    href_re=re.compile(r'''(?:href|src)=['"]([^'"]+)['"]''', re.I)
    for page in PUBLIC.rglob('*.html'):
        for raw in href_re.findall(page.read_text(encoding='utf-8',errors='ignore')):
            if raw.startswith(('http://','https://','mailto:','tel:','#','data:','javascript:')): continue
            pp=urlparse(raw).path
            if not pp: continue
            ext=Path(pp).suffix.lower()
            if ext in {'.html','.css','.js','.mjs','.svg','.png','.jpg','.jpeg','.webp','.gif','.ico','.json'}:
                target=(page.parent/pp).resolve()
                try: target.relative_to(PUBLIC.resolve())
                except ValueError: continue
                if not target.exists(): broken.append({'file':str(page.relative_to(ROOT)),'target':raw})
    status='passed' if not hits and not broken else 'failed'
    return {'version':VERSION,'status':status,'publicPages':len(list(PUBLIC.rglob('*.html'))),'forbiddenBrowserApiHits':hits,'brokenInternalLinksOrAssets':broken,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}

def write_reports(report,sanitized,patched,aliases):
    for name in ['install-report','qa','route-health','audit','demo-run']:
        (REPORTS/f'aurora-command-center-v45-1-{name}.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (DOCS/'website'/'AURORA_COMMAND_CENTER_V45_1.md').write_text(f'''# GoalOS Aurora Command Center V45.1

V45.1 corrects the failed V45 run and restores the colored GoalOS identity.

## Corrections

- Fixed nested archive asset references such as `public/archive/...` linking to `assets/goalos.css`.
- Created compatibility aliases for legacy archived assets.
- Sanitized browser-boundary strings from public assets.
- Preserved the colored aurora design.
- Rebuilt All Pages, Search, Route Registry, Site Health, Visual Flow Proof, and Human UX Proof Check.

## Audit

```json
{json.dumps(report,indent=2)}
```
''',encoding='utf-8')
    (DOCS/'reviewer'/'HOW_TO_REVIEW_AURORA_COMMAND_CENTER_V45_1.md').write_text('# How to review V45.1\n\nOpen index, visual-flow-proof, ux-proof-check, site-map, search, and site-health. Confirm no overlap, colored identity restored, no missing assets, and boundary visible.\n',encoding='utf-8')
    (EXAMPLES/'human-visual-qa-checklist.md').write_text('# Human Visual QA Checklist V45.1\n\n- [ ] Colored GoalOS identity restored.\n- [ ] No text overlaps.\n- [ ] Visual flow proof aligned.\n- [ ] Archive pages do not break assets.\n- [ ] Search and All Pages work.\n- [ ] Boundary visible.\n',encoding='utf-8')
    (EVIDENCE/'aurora-command-center-v45-1-reference-docket.json').write_text(json.dumps({'version':VERSION,'claim':'V45.1 fixes V45 asset-link failure, restores colored UX, and preserves public-alpha boundary.','audit':report,'sanitized':sanitized,'patched':patched,'assetAliases':aliases},indent=2),encoding='utf-8')
    (CONTENT/'aurora-command-center-v45-1.json').write_text(json.dumps({'version':VERSION,'name':FEATURE,'status':report['status'],'publicPages':report['publicPages'],'boundary':'preserved','externalActions':0},indent=2),encoding='utf-8')

def main():
    ensure_dirs(); make_asset_stubs()
    sanitized=sanitize_legacy()
    for href,title,desc in CANONICAL:
        p=PUBLIC/href
        if not p.exists(): p.write_text(simple_page(p,title,classify(href),desc),encoding='utf-8')
    for name in ['index.html','goalos-aurora-command-center.html','goalos-command-center.html','goalos-gold-master.html','public-alpha-gold-master.html']:
        p=PUBLIC/name; p.write_text(hero_page(p),encoding='utf-8')
    (PUBLIC/'visual-flow-proof.html').write_text(visual_page(PUBLIC/'visual-flow-proof.html'),encoding='utf-8')
    (PUBLIC/'ux-proof-check.html').write_text(ux_page(PUBLIC/'ux-proof-check.html'),encoding='utf-8')
    (PUBLIC/'trust-boundary.html').write_text(simple_page(PUBLIC/'trust-boundary.html','Proof-native. Not data-hungry. Not wallet-first.','Trust & Boundary','GoalOS public-alpha demos are browser-local by default and do not ask for user data, funds, wallets, transactions, secrets, or production authority.'),encoding='utf-8')
    (PUBLIC/'token-boundary.html').write_text(simple_page(PUBLIC/'token-boundary.html','$AGIALPHA is public contract identification only.','Token Boundary','$AGIALPHA is not available from GoalOS. No sale, custody, wallet support, investment advice, exchange, bridge, liquidity, or regulatory advice is provided.'),encoding='utf-8')
    for target in collect_missing_html():
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(simple_page(target,slug_title(target.name),classify(target.name),'Preserved fallback route created by V45.1 so no built page path disappears.'),encoding='utf-8')
    records=existing_records(); (ASSETS/'goalos-route-registry-v45-1.js').write_text(route_js(records),encoding='utf-8')
    for name in ['site-map.html','all-pages.html','route-registry.html']: (PUBLIC/name).write_text(index_page(PUBLIC/name,records),encoding='utf-8')
    (PUBLIC/'search.html').write_text(index_page(PUBLIC/'search.html',records,search=True),encoding='utf-8')
    changed_assets,aliases=patch_and_alias_assets(); patched=patch_all_html(records); sanitized+=sanitize_legacy()
    records=existing_records(); (ASSETS/'goalos-route-registry-v45-1.js').write_text(route_js(records),encoding='utf-8')
    (PUBLIC/'search-index.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (PUBLIC/'sitemap.xml').write_text('\n'.join('https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/'+r['href'] for r in records),encoding='utf-8')
    (PUBLIC/'site-health.html').write_text(health_page(PUBLIC/'site-health.html',records,sanitized,aliases),encoding='utf-8')
    ca2,al2=patch_and_alias_assets(); aliases+=al2; patched+=ca2
    report=audit(); write_reports(report,sorted(set(sanitized)),sorted(set(patched)),sorted(set(aliases)))
    summary={'version':VERSION,'feature':FEATURE,'status':report['status'],'publicPages':report['publicPages'],'fixed':'nested archive asset links + colored UX + route integrity','boundary':'preserved','externalActions':0,'createdAt':now_iso()}
    (ROOT/'goalos-aurora-command-center-v45-1-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='passed' else 1
if __name__=='__main__': raise SystemExit(main())
