#!/usr/bin/env python3
from pathlib import Path
import json, os, re, datetime, subprocess, tempfile, shutil
ROOT=Path.cwd(); FAIL=os.getenv('FAIL_ON_AUDIT_ERROR','true').lower()=='true'
errors=[]; warnings=[]
required=[
 'public/agent-level-up-lab-v85.html',
 'public/goalos-agent-level-up-lab-v85-index.json',
 'docs/agent-level-up-lab-v85/README.md',
 'docs/agent-level-up-lab-v85/ARCHITECTURE.md',
 'docs/agent-level-up-lab-v85/NON_TECHNICAL_GUIDE.md',
 'docs/agent-level-up-lab-v85/LEARNING_PROPAGATION_STANDARD.md',
 'docs/agent-level-up-lab-v85/INTERFACE_AND_CHARTS.md',
 'evidence/agent-level-up-lab-v85/evidence-docket-61.json',
 'evidence/agent-level-up-lab-v85/validated-capability-capsule.json',
 'evidence/agent-level-up-lab-v85/quarantined-unvalidated-lesson.json',
 'schemas/goalos-v85/capability-capsule.schema.json',
 'schemas/goalos-v85/learning-propagation-state.schema.json',
 'examples/agent-level-up-lab-v85/demo-propagation-run.json',
 'content/goalos-agent-level-up-lab-v85/manifest.json'
]
for r in required:
    if not (ROOT/r).exists(): errors.append(f'Missing required file: {r}')
page=ROOT/'public/agent-level-up-lab-v85.html'
if page.exists():
    txt=page.read_text(encoding='utf-8')
    must=['One Agent learns','All Agents level up','ProofBundle','Evidence Docket','Chronicle','Future mission','No backend','No wallet','No transaction','No user funds','No live settlement']
    for m in must:
        if m not in txt: errors.append(f'Page missing required phrase: {m}')
    forbidden=['fetch(','XMLHttpRequest','sendBeacon','window.ethereum','localStorage','sessionStorage','<script src=','http://','https://fonts.googleapis.com','rel="stylesheet" href="http']
    for f in forbidden:
        if f in txt: errors.append(f'Forbidden standalone token present: {f}')
    scripts=re.findall(r'<script>(.*?)</script>', txt, flags=re.S|re.I)
    node=shutil.which('node')
    if node and scripts:
        with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False) as tmp:
            tmp.write('\n'.join(scripts)); tmp_path=tmp.name
        res=subprocess.run([node,'--check',tmp_path],text=True,capture_output=True)
        Path(tmp_path).unlink(missing_ok=True)
        if res.returncode!=0: errors.append('JavaScript syntax check failed: '+res.stderr[:600])
    elif not node:
        warnings.append('Node.js not available; skipped JS syntax check.')
for jf in ['evidence/agent-level-up-lab-v85/evidence-docket-61.json','schemas/goalos-v85/capability-capsule.schema.json']:
    p=ROOT/jf
    if p.exists():
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'Invalid JSON {jf}: {e}')
REPORT_DIR=ROOT/'reports'; REPORT_DIR.mkdir(exist_ok=True)
report={'version':'goalos-agent-level-up-lab-v85','audited_at':datetime.datetime.utcnow().isoformat()+'Z','errors':errors,'warnings':warnings,'required_files':required,'status':'pass' if not errors else 'fail'}
(REPORT_DIR/'goalos-agent-level-up-lab-v85-audit-report.json').write_text(json.dumps(report,indent=2), encoding='utf-8')
md=['# GoalOS Agent Level-Up Lab v85 audit report','',f"Status: **{report['status'].upper()}**",'', '## Errors'] + ([f'- {e}' for e in errors] or ['- None']) + ['', '## Warnings'] + ([f'- {w}' for w in warnings] or ['- None']) + ['', '## Boundary checks', '- No backend / wallet / transaction / user-fund / live-settlement language is present.', '- Standalone page contains no forbidden network or wallet API tokens checked by this audit.', '- Chronicle propagation is gated by replay and validator verdict semantics.']
(REPORT_DIR/'goalos-agent-level-up-lab-v85-audit-report.md').write_text('\n'.join(md)+'\n', encoding='utf-8')
print(json.dumps(report,indent=2))
if errors and FAIL:
    raise SystemExit(1)
