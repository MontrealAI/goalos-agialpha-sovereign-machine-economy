#!/usr/bin/env python3
from pathlib import Path
import os, shutil, json, datetime, hashlib

ROOT = Path.cwd()
PAYLOAD = Path(__file__).resolve().parent / 'payload'
VERSION = 'v85'
MARK_START = '<!-- GOALOS_AGENT_LEVEL_UP_LAB_V85_NAV_START -->'
MARK_END = '<!-- GOALOS_AGENT_LEVEL_UP_LAB_V85_NAV_END -->'
ALLOW_OVERWRITE = os.getenv('ALLOW_OVERWRITE','false').lower() == 'true'
UPDATE_NAV = os.getenv('UPDATE_NAVIGATION','true').lower() == 'true'
PATCH_EXISTING = os.getenv('PATCH_EXISTING_PAGES','true').lower() == 'true'
REPORT_DIR = ROOT / 'reports'
REPORT_DIR.mkdir(exist_ok=True)

NAV_BLOCK = f'''\n{MARK_START}\n<section style="margin:28px auto;padding:22px;border:1px solid rgba(96,255,224,.28);border-radius:22px;background:rgba(8,14,29,.72);color:#eef7ff;max-width:1120px;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif">\n  <h2 style="margin:0 0 8px;font-size:1.45rem">One Agent learns. All Agents level up.</h2>\n  <p style="margin:0 0 14px;color:#b8c5e6">Open the GoalOS Agent Level-Up Lab to see how validated capability becomes bounded Chronicle memory and future-mission influence.</p>\n  <p style="margin:0;display:flex;gap:10px;flex-wrap:wrap">\n    <a href="agent-level-up-lab-v85.html" style="color:#06101b;background:linear-gradient(135deg,#ffd86b,#8dff9e,#60ffe0);text-decoration:none;border-radius:999px;padding:10px 14px;font-weight:900">Open Agent Level-Up Lab v85</a>\n    <a href="goalos-agent-level-up-lab-v85-index.json" style="color:#60ffe0">Capability index</a>\n  </p>\n</section>\n{MARK_END}\n'''

copied=[]; skipped=[]; patched=[]

def sha256(p):
    h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()

def copy_payload():
    for src in PAYLOAD.rglob('*'):
        if src.is_dir(): continue
        rel = src.relative_to(PAYLOAD)
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and not ALLOW_OVERWRITE:
            # allow refresh of our exact v85 page/index/reports if SHA matches or markers are ours? safer: skip.
            skipped.append(str(rel)); continue
        shutil.copy2(src, dst)
        copied.append(str(rel))

def patch_file(rel):
    p = ROOT / rel
    if not p.exists() or not p.is_file(): return
    try:
        txt = p.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        return
    if MARK_START in txt and MARK_END in txt:
        before = txt.split(MARK_START)[0]
        after = txt.split(MARK_END,1)[1]
        new = before + NAV_BLOCK.strip('\n') + after
    elif '</body>' in txt.lower():
        idx = txt.lower().rfind('</body>')
        new = txt[:idx] + NAV_BLOCK + txt[idx:]
    else:
        new = txt + NAV_BLOCK
    if new != txt:
        p.write_text(new, encoding='utf-8')
        patched.append(rel)

def patch_navigation():
    if not (UPDATE_NAV and PATCH_EXISTING): return
    candidates = ['public/index.html','public/goalos.html','public/site-map.html','public/all-pages.html','public/search.html']
    for c in candidates: patch_file(c)

def ensure_root_nojekyll():
    (ROOT/'public').mkdir(exist_ok=True)
    (ROOT/'public/.nojekyll').write_text('', encoding='utf-8')
    if not (ROOT/'.nojekyll').exists():
        (ROOT/'.nojekyll').write_text('', encoding='utf-8')

def write_report():
    report = {
        'version':'goalos-agent-level-up-lab-v85',
        'installed_at':datetime.datetime.utcnow().isoformat()+'Z',
        'copied_files':copied,
        'skipped_existing_files':skipped,
        'patched_pages':patched,
        'allow_overwrite':ALLOW_OVERWRITE,
        'page':'public/agent-level-up-lab-v85.html',
        'claim_boundary':'public-alpha; no achieved AGI/ASI; no empirical SOTA; no live settlement; no wallet; no user funds',
    }
    (REPORT_DIR/'goalos-agent-level-up-lab-v85-install-report.json').write_text(json.dumps(report,indent=2), encoding='utf-8')
    md = ['# GoalOS Agent Level-Up Lab v85 install report','',f"Installed at: `{report['installed_at']}`",'', '## Added capability','', 'One Agent learns. All Agents level up — only after ProofBundle, replay, validator verdict, Evidence Docket, and Chronicle gates pass.','', '## Public page','', '`public/agent-level-up-lab-v85.html`','', '## Copied files']
    md += [f'- `{x}`' for x in copied] or ['- No new files copied.']
    md += ['', '## Skipped existing files'] + ([f'- `{x}`' for x in skipped] or ['- None'])
    md += ['', '## Patched pages'] + ([f'- `{x}`' for x in patched] or ['- None'])
    md += ['', '## Boundary', '', 'No backend, no wallet, no transaction, no user funds, no live settlement, no achieved AGI/ASI claim, no empirical SOTA claim, no autonomous production authority claim.']
    (REPORT_DIR/'goalos-agent-level-up-lab-v85-install-report.md').write_text('\n'.join(md)+'\n', encoding='utf-8')

copy_payload(); ensure_root_nojekyll(); patch_navigation(); write_report()
print(f'GoalOS Agent Level-Up Lab v85 installed. Copied={len(copied)} skipped={len(skipped)} patched={len(patched)}')

