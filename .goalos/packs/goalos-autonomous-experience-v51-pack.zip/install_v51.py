
#!/usr/bin/env python3
from pathlib import Path
import json, re, shutil, html, os, base64, sys, subprocess

VERSION = "v51"
SLUG = "goalos-autonomous-experience-v51"
PUBLIC = Path("public")
ASSETS = PUBLIC / "assets"
BOUNDARY_TEXT = "No user data. No user funds. No wallet. No transaction. No production authority. Human review required."

CORE_ROUTES = [
    ("index.html", "Command Center", "Start here: tell GoalOS what you want and run the complete experience."),
    ("goalos-phase-completion.html", "Phase Completion", "The complete public-alpha surface for this phase."),
    ("goalos-command-center.html", "Command Center", "Unified mission, demo, agent, validation, contract, RSI, and route hub."),
    ("goalos-aurora-experience.html", "Aurora Experience", "The premium colored GoalOS operating surface."),
    ("autonomy-theatre.html", "Autonomy Theatre", "Run the complete end-to-end autonomous proof demo."),
    ("agi-agent-workbench.html", "AGI Agent Workbench", "Turn a plain-language objective into agent routes and proof artifacts."),
    ("agi-agent-run-theatre.html", "AGI Agent Run Theatre", "Watch agents turn work into proof."),
    ("agent-flow-academy-v38.html", "Agent Flow Academy", "Understand the system visually."),
    ("visual-flow-proof.html", "Visual Flow Proof", "A readable proof-flow map."),
    ("from-loop-to-rsi-state-capacity.html", "Loop → RSI", "Governance before the system outruns the institution."),
    ("loop-bottleneck-observatory.html", "Loop Bottleneck Observatory", "Find the next bottleneck and route it to proof."),
    ("loop-contract-lab.html", "Loop Contract Lab", "Define loop contracts before agents run."),
    ("loop-flight-recorder.html", "Loop Flight Recorder", "Capture replayable loop traces."),
    ("agi-alpha-node-v0.html", "AGI Alpha Node", "Node runtime, worker, validator, and sentinel roles."),
    ("agi-node-validation.html", "AGI Node Validation", "Deterministic public-safe validation path."),
    ("validation-control-tower.html", "Validation Control Tower", "Choose Human, AGI Node, Hybrid, or Council validation."),
    ("mainnet-contract-atlas.html", "48 Contracts", "Learn the 48 GoalOS-created Ethereum Mainnet contracts."),
    ("contract-academy.html", "Contract Academy", "Learn the proof rail in three passes."),
    ("mainnet-proof-rail.html", "Mainnet Proof Rail", "Map contracts to proof surfaces."),
    ("proof-run-001-docket.html", "Proof Run 001", "Repository-readiness evidence docket."),
    ("proof-ledger.html", "Proof Ledger", "Public proof route and artifact record."),
    ("evidence-docket-theatre.html", "Evidence Docket Theatre", "Evidence before claims."),
    ("ask-goalos.html", "Ask GoalOS", "Browser-local route assistant."),
    ("site-map.html", "All Pages", "Complete route inventory."),
    ("all-pages.html", "All Pages", "Complete route inventory."),
    ("route-registry.html", "Route Registry", "Grouped route table."),
    ("search.html", "Search", "Find any public route."),
    ("site-health.html", "Site Health", "Route, asset, boundary, and review status."),
    ("trust-boundary.html", "Trust Boundary", "No data, no funds, no wallet, no transaction."),
    ("token-boundary.html", "Token Boundary", "$AGIALPHA identification context only; not available from GoalOS."),
]

PLAYBOOKS = [
    {"title":"End-to-end autonomous proof", "intent":"I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.", "route":"autonomy-theatre.html", "mode":"demo"},
    {"title":"Use AGI Agents", "intent":"I want AGI agents to turn my objective into an AGI Job, AGI Node handoff, ProofBundle plan, Evidence Docket, validation route, and Chronicle entry.", "route":"agi-agent-workbench.html", "mode":"agents"},
    {"title":"Learn the 48 contracts", "intent":"I want AGI agents to help me understand the 48 Ethereum Mainnet contracts and the proof rail.", "route":"mainnet-contract-atlas.html", "mode":"contracts"},
    {"title":"Validate a proof path", "intent":"I want to validate a public-safe proof path with AGI Node precheck and Human final review.", "route":"validation-control-tower.html", "mode":"validate"},
    {"title":"Loop → RSI governance", "intent":"I want to understand Loop to RSI governance and Move-37 handling.", "route":"from-loop-to-rsi-state-capacity.html", "mode":"rsi"},
    {"title":"Vendor evidence review", "intent":"I want to evaluate an AI vendor using evidence, not marketing claims.", "route":"agi-agent-run-theatre.html", "mode":"vendor"},
    {"title":"Proof Run 001 review", "intent":"I want to inspect repository readiness as reviewable evidence.", "route":"proof-run-001-docket.html", "mode":"proof"},
    {"title":"Find any page", "intent":"I want to find every demo console, RSI page, loop page, AGI Node page, and proof route.", "route":"site-map.html", "mode":"map"}
]

STAGES = [
    ("Objective", "Plain-language goal captured."),
    ("Mission Contract", "Scope, boundary, success criteria, proof gates."),
    ("AGI Agents", "Architect, planner, researcher, builder, verifier, sentinel."),
    ("AGI Job", "Bounded work package with criteria and route."),
    ("AGI Node", "Worker / validator handoff prepared."),
    ("ProofBundle", "Receipts, trace roots, artifacts, replay notes."),
    ("Evidence Docket", "Claims, baselines, uncertainty, risk, reviewer notes."),
    ("Validate", "Human / AGI Node / Hybrid / Council verdict path."),
    ("Chronicle", "Accepted work becomes institutional memory."),
    ("Reuse", "Capability package and next route."),
]

AGENTS = [
    ("ARC", "Architect", "Frame the mission."), ("PLN", "Planner", "Create the contract."),
    ("RES", "Research", "Map public-safe sources."), ("BLD", "Builder", "Produce artifacts."),
    ("VRF", "Verifier", "Check claims."), ("WRK", "AGI Node Worker", "Prepare runtime handoff."),
    ("VAL", "AGI Node Validator", "Run deterministic checks."), ("SNT", "Sentinel", "Watch risk and drift."),
    ("DCK", "Docket", "Package evidence."), ("CHR", "Chronicle", "Create memory."),
    ("HUM", "Human", "Review high-impact claims."), ("CNL", "Council", "Govern strategic changes."),
]

MAJOR_GROUPS = [
    ("Start", ["index.html", "goalos-phase-completion.html", "goalos-command-center.html", "autonomy-theatre.html"]),
    ("AGI Agents", ["agi-agent-workbench.html", "agi-agent-run-theatre.html", "agent-flow-academy-v38.html", "agi-agent-use-case-gallery.html", "agi-agent-playbooks.html"]),
    ("Loop → RSI", ["from-loop-to-rsi-state-capacity.html", "from-loop-to-rsi-governance.html", "from-loop-to-rsi-sovereign-console.html", "loop-to-rsi.html", "rsi-state-capacity.html", "loop-bottleneck-observatory.html", "loop-contract-lab.html", "loop-flight-recorder.html"]),
    ("AGI Nodes", ["agi-alpha-node-v0.html", "agi-node-validation.html", "agi-node-use-cases.html", "node.html"]),
    ("Validation", ["validation-control-tower.html", "validation-authority.html", "validation-command-center.html", "validation-mesh.html", "validation-orchestrator.html", "validation-studio.html", "human-or-agi-node-validation.html"]),
    ("Contracts", ["mainnet-contract-atlas.html", "contract-academy.html", "mainnet-proof-rail.html"]),
    ("Proof", ["proof-run-001-docket.html", "proof-ledger.html", "evidence-docket-theatre.html", "proof-console.html", "proof-mission-control.html"]),
    ("Navigation", ["ask-goalos.html", "site-map.html", "all-pages.html", "route-registry.html", "search.html", "site-health.html"]),
    ("Boundary", ["trust-boundary.html", "token-boundary.html", "privacy.html", "data-boundary.html", "claim-boundary.html"]),
]

FORBIDDEN = ["window.ethereum", "localStorage", "sessionStorage", "XMLHttpRequest", "sendBeacon", "fetch("]


def ensure_dirs():
    PUBLIC.mkdir(exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)
    Path("reports").mkdir(exist_ok=True)
    Path("content/goalos").mkdir(parents=True, exist_ok=True)
    Path("evidence/demo").mkdir(parents=True, exist_ok=True)
    Path("docs/website").mkdir(parents=True, exist_ok=True)
    Path("docs/reviewer").mkdir(parents=True, exist_ok=True)
    Path("examples/phase-completion-v51").mkdir(parents=True, exist_ok=True)
    (PUBLIC / ".nojekyll").write_text("", encoding="utf-8")


def rehydrate_from_snapshot():
    snap = Path(".goalos/site-immersive-command-center-v16/public-snapshot")
    if not snap.exists():
        return 0
    copied = 0
    for src in snap.rglob("*"):
        if src.is_file():
            rel = src.relative_to(snap)
            dst = PUBLIC / rel
            if not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                copied += 1
    return copied


def safe_text(s):
    return html.escape(str(s), quote=True)


def route_title(name):
    stem = Path(name).stem.replace("-", " ").replace("_", " ")
    return " ".join(w.upper() if w.lower() in {"agi","rsi","ai","os"} else w.capitalize() for w in stem.split())


def categorize(name):
    low = name.lower()
    if any(x in low for x in ["rsi", "loop"]): return "Loop → RSI"
    if "node" in low: return "AGI Nodes"
    if "agent" in low or "workbench" in low: return "AGI Agents"
    if "valid" in low or "council" in low: return "Validation"
    if "contract" in low or "mainnet" in low or "token" in low: return "Contracts"
    if "proof" in low or "evidence" in low or "docket" in low or "ledger" in low: return "Proof & Evidence"
    if any(x in low for x in ["site", "search", "page", "registry", "map", "ask"]): return "Navigation"
    if any(x in low for x in ["trust", "privacy", "data", "boundary", "claim"]): return "Trust & Boundary"
    return "Additional"


def collect_routes():
    routes = []
    for p in sorted(PUBLIC.rglob("*.html")):
        rel = p.relative_to(PUBLIC).as_posix()
        if rel.startswith("archive/"):
            continue
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            txt = ""
        m = re.search(r"<title>(.*?)</title>", txt, re.I|re.S)
        title = re.sub(r"\s+", " ", m.group(1)).strip() if m else route_title(rel)
        desc = "Open " + title + " as part of the complete GoalOS public proof surface."
        routes.append({"href": rel, "title": title, "category": categorize(rel), "description": desc})
    seen = {r["href"] for r in routes}
    for href, title, desc in CORE_ROUTES:
        if href not in seen:
            routes.append({"href": href, "title": title, "category": categorize(href), "description": desc})
            seen.add(href)
    return sorted(routes, key=lambda r: (r["category"], r["title"]))


def create_route_data(routes):
    ASSETS.joinpath("goalos-routes-v51.js").write_text("window.GOALOS_ROUTES_V51 = " + json.dumps(routes, ensure_ascii=False, indent=2) + ";\n", encoding="utf-8")
    Path("content/goalos/public-proof-navigation-v51.json").write_text(json.dumps({"version": VERSION, "routes": routes}, indent=2), encoding="utf-8")


def css():
    return r'''
:root{
  --bg0:#030912; --bg1:#061725; --ink:#f7fbff; --muted:#b8c8d9; --line:rgba(146,255,235,.28);
  --mint:#69ffd2; --cyan:#80eaff; --gold:#fff26e; --violet:#a895ff; --blue:#79a7ff;
  --glass:rgba(10,22,38,.72); --glass2:rgba(21,36,56,.64); --shadow:0 34px 100px rgba(0,0,0,.38);
  --r:28px; --max:1180px;
}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:
radial-gradient(circle at 18% 12%,rgba(105,255,210,.23),transparent 30%),
radial-gradient(circle at 76% 16%,rgba(168,149,255,.22),transparent 34%),
radial-gradient(circle at 50% 100%,rgba(128,234,255,.12),transparent 42%),linear-gradient(135deg,#02100f 0%,#061424 46%,#0c0920 100%);color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Arial,sans-serif;min-height:100vh;overflow-x:hidden}.grid-bg:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.04) 1px,transparent 1px);background-size:52px 52px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.9),rgba(0,0,0,.25));z-index:-2}.aurora{position:fixed;inset:auto -10% -25% -10%;height:50vh;background:radial-gradient(ellipse at 20% 60%,rgba(105,255,210,.18),transparent 38%),radial-gradient(ellipse at 80% 50%,rgba(255,242,110,.16),transparent 34%);filter:blur(10px);z-index:-1}a{color:inherit}.wrap{width:min(var(--max),calc(100vw - 44px));margin:0 auto}.topbar{position:sticky;top:18px;z-index:20;margin:18px auto 0;width:min(var(--max),calc(100vw - 36px));display:flex;gap:16px;align-items:center;justify-content:space-between;padding:14px 18px;border:1px solid var(--line);border-radius:24px;background:rgba(3,10,20,.76);backdrop-filter:blur(22px);box-shadow:var(--shadow)}.brand{display:flex;align-items:center;gap:12px;text-decoration:none}.logo{width:42px;height:42px;border-radius:13px;background:radial-gradient(circle at 30% 25%,var(--gold),var(--mint) 38%,var(--cyan) 70%,var(--violet));display:grid;place-items:center;color:#06101e;font-weight:1000;box-shadow:0 0 30px rgba(105,255,210,.38)}.brand b{letter-spacing:.18em;font-size:13px}.brand span{display:block;color:#aebcd2;font-size:10px;letter-spacing:.28em}.nav{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.nav a,.pill,.btn{border:1px solid var(--line);background:rgba(255,255,255,.08);border-radius:999px;padding:11px 15px;text-decoration:none;font-weight:900;font-size:13px;letter-spacing:.04em}.nav a:hover,.btn:hover{transform:translateY(-1px);background:rgba(105,255,210,.15)}.btn{cursor:pointer;color:var(--ink);display:inline-flex;align-items:center;gap:8px}.btn.primary{background:linear-gradient(120deg,var(--gold),var(--mint));color:#06101e;border:0}.btn.dark{background:rgba(7,14,26,.92)}.hero{min-height:calc(100vh - 80px);display:grid;grid-template-columns:1.05fr .95fr;gap:32px;align-items:center;padding:64px 0 44px}.eyebrow{display:inline-flex;gap:8px;align-items:center;color:var(--gold);font-size:12px;font-weight:1000;letter-spacing:.42em;text-transform:uppercase;margin-bottom:18px}.eyebrow:before{content:"";width:10px;height:10px;border-radius:99px;background:var(--mint);box-shadow:0 0 22px var(--mint)}h1{font-size:clamp(58px,8vw,116px);line-height:.83;letter-spacing:-.08em;margin:0 0 22px;font-weight:1000}.grad{font-family:Georgia,serif;font-style:italic;font-weight:900;letter-spacing:-.07em;background:linear-gradient(100deg,var(--gold),var(--mint),var(--cyan),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}.lead{font-size:clamp(19px,2vw,29px);line-height:1.05;font-weight:950;max-width:800px}.sub{color:var(--muted);font-size:16px;line-height:1.7;max-width:740px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin:26px 0}.boundary{border:1px solid rgba(255,109,168,.42);background:rgba(76,14,42,.32);border-radius:18px;padding:15px 17px;font-weight:800;color:#ffe6f0;max-width:850px}.console,.panel,.card{border:1px solid var(--line);background:linear-gradient(150deg,rgba(255,255,255,.11),rgba(255,255,255,.04));box-shadow:var(--shadow);backdrop-filter:blur(20px);border-radius:var(--r)}.console{padding:22px}.console-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.tag{font-size:11px;letter-spacing:.22em;text-transform:uppercase;font-weight:1000;color:var(--mint)}.status{background:rgba(105,255,210,.16);border:1px solid var(--line);color:var(--mint);border-radius:999px;padding:8px 12px;font-weight:1000;font-size:12px}.agent-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0}.agent{min-height:74px;display:grid;place-items:center;text-align:center;border:1px solid rgba(128,234,255,.22);border-radius:18px;background:rgba(7,15,27,.68);font-weight:1000;color:#e9f7ff;transition:.25s}.agent.active{background:linear-gradient(140deg,rgba(105,255,210,.28),rgba(168,149,255,.18));border-color:var(--mint);box-shadow:0 0 30px rgba(105,255,210,.18)}.agent small{display:block;color:var(--muted);font-size:10px;font-weight:800;margin-top:4px}.terminal{background:#020813;color:var(--mint);border:1px solid rgba(105,255,210,.35);border-radius:18px;padding:16px;min-height:160px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;white-space:pre-wrap;line-height:1.55}.composer{margin-top:20px;border:1px solid var(--line);border-radius:24px;overflow:hidden;background:rgba(4,10,20,.7)}.composer label{display:flex;justify-content:space-between;gap:16px;padding:15px 18px;background:rgba(255,255,255,.08);font-size:12px;letter-spacing:.22em;font-weight:1000;text-transform:uppercase;color:#d9f8ff}.composer textarea{width:100%;min-height:150px;background:#030915;color:var(--ink);border:0;outline:0;padding:22px;font:800 18px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical}.composer-actions{padding:16px;display:flex;gap:10px;flex-wrap:wrap}.mission-grid{display:grid;grid-template-columns:repeat(10,1fr);gap:10px;margin:28px 0}.stage{border:1px solid rgba(128,234,255,.20);background:rgba(255,255,255,.06);border-radius:18px;padding:15px;min-height:118px}.stage b{display:block;color:var(--gold);font-size:12px;letter-spacing:.14em;margin-bottom:8px}.stage.active{border-color:var(--mint);background:linear-gradient(150deg,rgba(105,255,210,.24),rgba(168,149,255,.12));box-shadow:0 0 30px rgba(105,255,210,.18)}section{padding:48px 0}.section-title{display:flex;justify-content:space-between;gap:22px;align-items:end;margin-bottom:22px}h2{font-size:clamp(36px,5vw,76px);line-height:.92;letter-spacing:-.06em;margin:0}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.card{padding:20px;min-height:170px}.card h3{font-size:23px;letter-spacing:-.035em;margin:8px 0}.card p{color:var(--muted);line-height:1.55}.card a{color:var(--mint);font-weight:1000}.route-list{display:grid;gap:10px}.route-row{display:grid;grid-template-columns:170px 1fr auto;gap:16px;align-items:center;padding:16px;border:1px solid rgba(128,234,255,.16);border-radius:16px;background:rgba(255,255,255,.05);text-decoration:none}.route-row:hover{border-color:var(--mint);background:rgba(105,255,210,.09)}input.search{width:100%;padding:18px;border-radius:18px;border:1px solid var(--line);background:rgba(255,255,255,.08);color:var(--ink);font:800 16px/1 Inter,system-ui}.metrics{display:grid;gap:13px}.metric{display:grid;grid-template-columns:190px 1fr 55px;gap:12px;align-items:center;font-weight:900}.bar{height:10px;background:rgba(255,255,255,.15);border-radius:99px;overflow:hidden}.bar span{display:block;height:100%;width:0%;background:linear-gradient(90deg,var(--mint),var(--cyan),var(--violet));transition:width .5s}.artifact-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:15px}.artifact{padding:13px;border:1px solid rgba(128,234,255,.18);border-radius:15px;background:rgba(255,255,255,.06);cursor:pointer;font-weight:900}.artifact:hover{border-color:var(--mint);color:var(--mint)}.ask{position:fixed;right:22px;bottom:88px;width:min(440px,calc(100vw - 44px));z-index:40;display:none}.ask.open{display:block}.ask .panel{padding:18px}.ask textarea{width:100%;height:90px;border-radius:16px;border:1px solid var(--line);background:#030915;color:var(--ink);padding:14px;resize:vertical}.dock{position:fixed;right:18px;bottom:18px;z-index:30;display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.dock .btn{box-shadow:0 14px 34px rgba(0,0,0,.28)}footer{padding:60px 0;color:var(--muted)}.safe{color:var(--mint);font-weight:1000}@media (max-width:1000px){.hero{grid-template-columns:1fr}.mission-grid{grid-template-columns:repeat(2,1fr)}.cards{grid-template-columns:repeat(2,1fr)}.agent-grid{grid-template-columns:repeat(2,1fr)}.section-title{display:block}.route-row{grid-template-columns:1fr}.topbar{position:relative;top:auto}.nav{justify-content:flex-start}}@media (max-width:620px){.cards{grid-template-columns:1fr}h1{font-size:56px}.wrap{width:min(100% - 26px, var(--max))}.mission-grid{grid-template-columns:1fr}.dock{left:12px;right:12px}.dock .btn{flex:1;justify-content:center}.metric{grid-template-columns:1fr}.topbar{border-radius:18px}.brand span{display:none}}
'''


def js():
    data = {"stages": STAGES, "agents": AGENTS, "playbooks": PLAYBOOKS}
    return "window.GOALOS_V51_DATA = " + json.dumps(data, ensure_ascii=False) + ";\n" + r'''
(function(){
  const D = window.GOALOS_V51_DATA;
  const routes = window.GOALOS_ROUTES_V51 || [];
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
  const state = { step: 0, timer: null, objective: "I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle." };
  function log(line){ const t=$("#missionLog"); if(!t) return; t.textContent += "\n" + line; t.scrollTop = t.scrollHeight; }
  function resetLog(){ const t=$("#missionLog"); if(t) t.textContent = "GoalOS local mission console ready.\nNo account. No backend call. No wallet. No transaction."; }
  function setProgress(n){
    $$(".stage").forEach((el,i)=> el.classList.toggle("active", i <= n));
    $$(".agent").forEach((el,i)=> el.classList.toggle("active", i <= Math.min(11, n+1)));
    const widths=[12,25,38,51,63,74,84,91,96,100];
    $$(".bar span").forEach((el,i)=>{ const base = widths[Math.min(n, widths.length-1)] || 0; el.style.width = Math.max(8, Math.min(100, base - i*7 + 12)) + "%"; });
  }
  function missionPacket(){
    const obj = ($("#goalInput") && $("#goalInput").value.trim()) || state.objective;
    return {
      mission_id:"GOALOS-V51-" + Math.random().toString(16).slice(2,10).toUpperCase(),
      objective: obj,
      boundary:"public-alpha / browser-local / no user data / no funds / no wallet / no transaction",
      authority:"Human / AGI Node / Hybrid selectable",
      agents:D.agents.map(a=>a[1]),
      stages:D.stages.map(s=>s[0]),
      artifacts:["Mission Contract","AGI Job Spec","AGI Node Handoff","ProofBundle Plan","Evidence Docket Plan","Validation Certificate","Reviewer Brief","Action Graph","Chronicle Entry"],
      next_routes:["autonomy-theatre.html","agi-agent-workbench.html","validation-control-tower.html","mainnet-contract-atlas.html","from-loop-to-rsi-state-capacity.html","site-map.html"]
    };
  }
  function download(name, body, type){
    const blob = new Blob([body], {type:type || "application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href=url; a.download=name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url), 600);
  }
  function renderArtifacts(){
    const box=$("#artifactBox"); if(!box) return;
    const files=["mission-contract.json","agi-job-spec.json","agi-node-handoff.json","proofbundle-plan.json","evidence-docket.md","validation-certificate.json","reviewer-brief.md","action-graph.csv","chronicle-entry.json","demo-replay.json"];
    box.innerHTML = files.map(f=>`<button class="artifact" data-file="${f}">${f}</button>`).join("");
    $$(".artifact", box).forEach(btn=>btn.addEventListener("click",()=>{
      const p=missionPacket(); const f=btn.dataset.file;
      let body = JSON.stringify({file:f, generated_at:new Date().toISOString(), ...p}, null, 2); let type="application/json";
      if(f.endsWith(".md")){ body = `# ${f}\n\nObjective: ${p.objective}\n\nBoundary: ${p.boundary}\n\nStages:\n` + p.stages.map(x=>`- ${x}`).join("\n"); type="text/markdown"; }
      if(f.endsWith(".csv")){ body = "step,stage,status\n" + p.stages.map((x,i)=>`${i+1},${x},ready`).join("\n"); type="text/csv"; }
      download(f, body, type);
    }));
  }
  function runDemo(){
    const input=$("#goalInput"); state.objective = input && input.value.trim() ? input.value.trim() : state.objective;
    resetLog(); setProgress(0); renderArtifacts();
    if(state.timer) clearInterval(state.timer);
    let i=0; log("Objective received: " + state.objective); log("Boundary preserved: no account, no wallet, no transaction.");
    state.timer = setInterval(()=>{
      const s=D.stages[i]; if(!s){ clearInterval(state.timer); log("Mission package ready. Downloads enabled. Recommended next route: Autonomy Theatre → AGI Agent Workbench → Validation Control Tower."); const box=$("#readyState"); if(box) box.textContent="MISSION_PACKAGE_READY"; return; }
      setProgress(i); log(String(i+1).padStart(2,"0") + " · " + s[0] + " · " + s[1]); i++;
    }, 420);
  }
  function loadIntent(intent){ const input=$("#goalInput"); if(input) input.value=intent; state.objective=intent; runDemo(); }
  function answerAsk(){
    const q=($("#askInput")&&$("#askInput").value.toLowerCase())||"";
    const ans=$("#askAnswer"); if(!ans) return;
    let picks=[];
    if(q.includes("rsi")||q.includes("loop")) picks=["from-loop-to-rsi-state-capacity.html","loop-bottleneck-observatory.html","loop-contract-lab.html","loop-flight-recorder.html"];
    else if(q.includes("contract")||q.includes("48")) picks=["mainnet-contract-atlas.html","contract-academy.html","mainnet-proof-rail.html"];
    else if(q.includes("node")) picks=["agi-alpha-node-v0.html","agi-node-validation.html","validation-control-tower.html"];
    else if(q.includes("agent")) picks=["agi-agent-workbench.html","agi-agent-run-theatre.html","agent-flow-academy-v38.html"];
    else if(q.includes("validate")||q.includes("human")) picks=["validation-control-tower.html","human-or-agi-node-validation.html","validation-use-cases.html"];
    else picks=["autonomy-theatre.html","agi-agent-workbench.html","site-map.html","search.html"];
    ans.innerHTML = `<b>Best route:</b><br>` + picks.map(p=>`<a class="btn dark" href="${p}">${p.replace('.html','')}</a>`).join(" ");
    if(/open|go|show|launch|take me|redirect/.test(q) && picks[0]) location.href = picks[0];
  }
  function initSearch(){
    const input=$("#routeSearch"); const list=$("#routeResults"); if(!input||!list) return;
    function draw(){ const q=input.value.toLowerCase(); const rows=routes.filter(r=>!q||JSON.stringify(r).toLowerCase().includes(q)).slice(0,260); list.innerHTML=rows.map(r=>`<a class="route-row" href="${r.href}"><span class="tag">${r.category||'Route'}</span><b>${r.title||r.href}</b><span class="safe">Open →</span></a>`).join(""); }
    input.addEventListener("input", draw); draw();
  }
  function init(){
    $$("[data-run-demo]").forEach(b=>b.addEventListener("click", e=>{ e.preventDefault(); runDemo(); }));
    $$("[data-intent]").forEach(b=>b.addEventListener("click", e=>{ e.preventDefault(); loadIntent(b.dataset.intent); }));
    $$("[data-download]").forEach(b=>b.addEventListener("click", e=>{ e.preventDefault(); download("goalos-v51-mission-packet.json", JSON.stringify(missionPacket(),null,2)); }));
    $$("[data-ask]").forEach(b=>b.addEventListener("click", e=>{ e.preventDefault(); const a=$("#askPanel"); if(a) a.classList.toggle("open"); }));
    const askBtn=$("#askSubmit"); if(askBtn) askBtn.addEventListener("click", answerAsk);
    initSearch(); resetLog(); setProgress(0); renderArtifacts();
  }
  document.addEventListener("DOMContentLoaded", init);
})();
'''


def nav():
    links = [("Run Demo","autonomy-theatre.html","data-run-demo"),("AGI Agents","agi-agent-workbench.html",None),("Loop→RSI","from-loop-to-rsi-state-capacity.html",None),("Validate","validation-control-tower.html",None),("48 Contracts","mainnet-contract-atlas.html",None),("All Pages","site-map.html",None),("Search","search.html",None),("Ask /","#","data-ask")]
    parts=[]
    for label,href,attr in links:
        extra = " " + attr if attr else ""
        parts.append(f'<a href="{href}"{extra}>{label}</a>')
    return '<nav class="nav">' + ''.join(parts) + '</nav>'


def page_shell(title, subtitle, body, mode="default"):
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{safe_text(title)} · GoalOS</title>
<meta name="description" content="GoalOS AGIALPHA Ascension public-alpha proof operating surface.">
<link rel="stylesheet" href="assets/goalos-v51.css"><script src="assets/goalos-routes-v51.js" defer></script><script src="assets/goalos-v51.js" defer></script></head>
<body class="grid-bg" data-mode="{safe_text(mode)}"><div class="aurora"></div>
<header class="topbar"><a class="brand" href="index.html"><span class="logo">α</span><span><b>GOALOS</b><span>AGIALPHA ASCENSION</span></span></a>{nav()}</header>
<main>{body}</main>
<div class="ask panel" id="askPanel"><h3>Ask GoalOS</h3><p class="sub">Ask where to go. Answers use the local route map.</p><textarea id="askInput" placeholder="Where are the RSI and Loop demos?"></textarea><div class="actions"><button class="btn primary" id="askSubmit">Answer locally</button><button class="btn" data-ask>Close</button></div><div id="askAnswer" class="sub"></div></div>
<div class="dock"><a class="btn primary" href="autonomy-theatre.html" data-run-demo>Run end-to-end demo</a><a class="btn" href="agi-agent-workbench.html">AGI Agents</a><a class="btn" href="#" data-ask>Ask GoalOS</a><a class="btn" href="site-map.html">All Pages</a></div>
<footer class="wrap"><b>GoalOS AGIALPHA Ascension</b> — public-alpha proof operating surface. {BOUNDARY_TEXT}<br><a href="trust-boundary.html">Trust Boundary</a> · <a href="token-boundary.html">Token Boundary</a> · <a href="site-health.html">Site Health</a></footer>
</body></html>'''


def mission_hero(title="Tell GoalOS what you want.", kicker="Sovereign Machine Economy", subtitle="One colored command surface for AGI Agents, AGI Jobs, AGI Nodes, ProofBundles, Evidence Dockets, validation, Chronicle memory, and reusable capability."):
    agent_html = ''.join([f'<div class="agent"><b>{safe_text(code)}</b><small>{safe_text(name)}</small></div>' for code,name,_ in AGENTS])
    stage_html = ''.join([f'<article class="stage"><b>{i+1:02d}</b><strong>{safe_text(name)}</strong><p class="sub">{safe_text(desc)}</p></article>' for i,(name,desc) in enumerate(STAGES)])
    play_html = ''.join([f'<article class="card"><span class="tag">Use case</span><h3>{safe_text(p["title"])}</h3><p>{safe_text(p["intent"])}</p><div class="actions"><a class="btn" href="{p["route"]}">Open</a><button class="btn primary" data-intent="{safe_text(p["intent"])}">Run now</button></div></article>' for p in PLAYBOOKS])
    return f'''
<section class="hero wrap"><div><div class="eyebrow">{safe_text(kicker)}</div><h1>{safe_text(title).replace('what you want','<span class="grad">what you want</span>').replace('Full proof','<span class="grad">Full proof</span>').replace('visually','<span class="grad">visually</span>')}</h1><p class="lead">{safe_text(subtitle)}</p><div class="actions"><a class="btn primary" href="autonomy-theatre.html" data-run-demo>Run end-to-end demo</a><a class="btn" href="agi-agent-workbench.html">Use AGI Agents</a><a class="btn" href="validation-control-tower.html">Validate proof</a><a class="btn" href="site-map.html">All pages</a></div><div class="boundary">{BOUNDARY_TEXT}</div><div class="composer"><label><span>What do you want GoalOS to help you accomplish?</span><span class="status">browser-local</span></label><textarea id="goalInput">I want AGI agents to show a complete end-to-end example from objective to proof to validation to Chronicle.</textarea><div class="composer-actions"><button class="btn primary" data-run-demo>Generate proof path</button><button class="btn" data-download>Download mission packet</button><a class="btn" href="autonomy-theatre.html">Open theatre</a></div></div></div><aside class="console"><div class="console-head"><b>Live Proof Console</b><span class="status" id="readyState">READY</span></div><div class="agent-grid">{agent_html}</div><pre class="terminal" id="missionLog"></pre><div class="metrics"><div class="metric"><span>Readiness</span><div class="bar"><span></span></div><b>0%</b></div><div class="metric"><span>Replayability</span><div class="bar"><span></span></div><b>0%</b></div><div class="metric"><span>Risk control</span><div class="bar"><span></span></div><b>0%</b></div></div><div id="artifactBox" class="artifact-grid"></div></aside></section>
<section class="wrap"><div class="section-title"><div><span class="eyebrow">Mission OS Flow</span><h2>From objective to <span class="grad">reusable capability.</span></h2></div><button class="btn primary" data-run-demo>Animate the flow</button></div><div class="mission-grid">{stage_html}</div></section>
<section class="wrap"><div class="section-title"><div><span class="eyebrow">Best first paths</span><h2>Start with a solved mission.</h2></div><a class="btn" href="site-map.html">Open complete map</a></div><div class="cards">{play_html}</div></section>
'''


def specialized_body(kind):
    if kind == "rsi":
        cards = [("TARGET","Define the invention target."),("EMIT","Generate candidates."),("FILTER","Remove unsafe / unsupported claims."),("ATLAS","Map state and bottlenecks."),("TEST-PLAN","Create replayable evaluation."),("EVAL","Score with baselines."),("INSERT","Add accepted proof."),("PROMOTE","Advance only with gates.")]
        card_html=''.join(f'<article class="card"><span class="tag">RSI</span><h3>{a}</h3><p>{b}</p></article>' for a,b in cards)
        return mission_hero("Build the governance institution before the system outruns it.", "Loop → RSI", "A loop can run. A recorder can prove. An observatory can expose bottlenecks. A governance institution decides what may improve next.") + f'<section class="wrap"><div class="cards">{card_html}</div></section>'
    if kind == "node":
        cards=[("Worker","Executes bounded deterministic work."),("Validator","Checks public-safe artifacts and gates."),("Sentinel","Watches drift, risk, boundary, and escalation."),("Handoff","Packages runtime context for review.")]
        return mission_hero("AGI Nodes turn autonomous work into reviewable runtime handoff.", "AGI Node", "Worker, Validator, and Sentinel roles make agentic work inspectable before authority changes.") + '<section class="wrap"><div class="cards">' + ''.join(f'<article class="card"><span class="tag">Node</span><h3>{a}</h3><p>{b}</p></article>' for a,b in cards) + '</div></section>'
    if kind == "contracts":
        cards=[("Identity","Which contract exists and why."),("Proof rail","How contracts map to evidence."),("No wallet","Learn without transaction or account."),("Review path","Open contract, academy, and proof rail.")]
        return mission_hero("Know the 48 contracts like an institution.", "Mainnet Contract Atlas", "Learn the GoalOS proof rail without sending a transaction or touching a wallet.") + '<section class="wrap"><div class="cards">' + ''.join(f'<article class="card"><span class="tag">Contracts</span><h3>{a}</h3><p>{b}</p></article>' for a,b in cards) + '</div></section>'
    if kind == "validation":
        cards=[("AGI Node","Deterministic public-safe checks."),("Human","Judgment-heavy or high-impact review."),("Hybrid","AGI Node precheck + Human final review."),("Council","RSI, Move-37, or governance-changing claims.")]
        return mission_hero("Human or AGI Node can validate.", "Validation", "Select the authority path and generate a reviewable certificate, attestation, handoff, and action graph.") + '<section class="wrap"><div class="cards">' + ''.join(f'<article class="card"><span class="tag">Authority</span><h3>{a}</h3><p>{b}</p></article>' for a,b in cards) + '</div></section>'
    if kind == "proof":
        return mission_hero("Repository readiness becomes reviewable evidence.", "Proof Run 001", "Proof pages are for claims, gates, artifacts, reviewer notes, and replay paths.")
    return mission_hero()


def write_core_pages(routes):
    mode_map = {
        "index.html":"home", "goalos-phase-completion.html":"home", "goalos-command-center.html":"home", "goalos-aurora-experience.html":"home", "goalos-aurora.html":"home",
        "autonomy-theatre.html":"home", "agi-agent-workbench.html":"home", "agi-agent-run-theatre.html":"home", "agent-flow-academy-v38.html":"home", "visual-flow-proof.html":"home",
        "from-loop-to-rsi-state-capacity.html":"rsi", "from-loop-to-rsi-governance.html":"rsi", "from-loop-to-rsi-sovereign-console.html":"rsi", "loop-to-rsi.html":"rsi", "rsi-state-capacity.html":"rsi", "loop-bottleneck-observatory.html":"rsi", "loop-contract-lab.html":"rsi", "loop-flight-recorder.html":"rsi",
        "agi-alpha-node-v0.html":"node", "agi-node-validation.html":"node", "agi-node-use-cases.html":"node", "node.html":"node",
        "validation-control-tower.html":"validation", "validation-authority.html":"validation", "validation-command-center.html":"validation", "validation-use-cases.html":"validation", "human-or-agi-node-validation.html":"validation", "human-or-node-validation.html":"validation",
        "mainnet-contract-atlas.html":"contracts", "contract-academy.html":"contracts", "mainnet-proof-rail.html":"contracts",
        "proof-run-001-docket.html":"proof", "proof-run-001.html":"proof", "proof-ledger.html":"proof", "evidence-docket-theatre.html":"proof", "proof-console.html":"proof"
    }
    for href, title, desc in CORE_ROUTES:
        mode=mode_map.get(href,"home")
        body=specialized_body(mode) if mode!="home" else mission_hero(title if href not in ["index.html", "goalos-phase-completion.html", "goalos-command-center.html"] else "Tell GoalOS what you want.", "GoalOS AGIALPHA", desc)
        (PUBLIC/href).write_text(page_shell(title, desc, body, mode), encoding="utf-8")
    # Additional known pages if present or important
    for href, mode in mode_map.items():
        if not (PUBLIC/href).exists():
            title = route_title(href)
            body = specialized_body(mode) if mode != "home" else mission_hero(title)
            (PUBLIC/href).write_text(page_shell(title, "GoalOS canonical surface", body, mode), encoding="utf-8")


def write_nav_pages(routes):
    # Search / all pages
    grouped = {}
    for r in routes:
        grouped.setdefault(r["category"], []).append(r)
    route_rows = ''.join([f'<a class="route-row" href="{safe_text(r["href"])}"><span class="tag">{safe_text(r["category"])}</span><b>{safe_text(r["title"])}</b><span class="safe">Open →</span></a>' for r in routes])
    groups_html=''.join([f'<section class="wrap"><div class="section-title"><h2>{safe_text(cat)}</h2><span class="status">{len(items)} pages</span></div><div class="route-list">' + ''.join([f'<a class="route-row" href="{safe_text(r["href"])}"><span class="tag">{safe_text(cat)}</span><b>{safe_text(r["title"])}</b><span class="safe">Open →</span></a>' for r in items]) + '</div></section>' for cat,items in sorted(grouped.items())])
    hero = f'<section class="hero wrap"><div><div class="eyebrow">Complete Surface</div><h1>Every page. <span class="grad">Every route.</span></h1><p class="lead">The complete GoalOS public surface is grouped by purpose. RSI, Loop, AGI Nodes, AGI Agents, validation, contracts, proof, search, health, and boundary pages remain discoverable.</p><input class="search" id="routeSearch" placeholder="Search GoalOS routes…"></div><aside class="console"><div class="console-head"><b>Route inventory</b><span class="status">{len(routes)} routes</span></div><pre class="terminal">public pages: {len(routes)}\nboundary: preserved\nexternal actions: 0</pre></aside></section><section class="wrap"><div class="route-list" id="routeResults">{route_rows}</div></section>'
    for name,title in [("site-map.html","All Pages"),("all-pages.html","All Pages"),("route-registry.html","Route Registry"),("search.html","Search")]:
        body = hero if name in ["site-map.html","all-pages.html","search.html"] else groups_html
        (PUBLIC/name).write_text(page_shell(title, "Complete GoalOS public route surface", body, "routes"), encoding="utf-8")
    health = f'<section class="hero wrap"><div><div class="eyebrow">Site Health</div><h1>Ready for <span class="grad">review.</span></h1><p class="lead">Route discovery, asset compatibility, public boundary, and visual quality gates are visible.</p><div class="cards"><article class="card"><span class="tag">Route surface</span><h3>{len(routes)}</h3><p>Current non-archive public routes indexed.</p></article><article class="card"><span class="tag">Boundary</span><h3>Preserved</h3><p>{BOUNDARY_TEXT}</p></article><article class="card"><span class="tag">External actions</span><h3>0</h3><p>No production authority in this public-alpha surface.</p></article></div></div><aside class="console"><div class="console-head"><b>Audit Console</b><span class="status">CHECKED</span></div><pre class="terminal">public pages: {len(routes)}\nboundary: preserved\nexternal actions: 0\nproduction authority: not granted</pre></aside></section>'
    (PUBLIC/"site-health.html").write_text(page_shell("Site Health", "Route and boundary health", health, "health"), encoding="utf-8")
    ask = '<section class="hero wrap"><div><div class="eyebrow">Ask GoalOS</div><h1>Ask. Route. <span class="grad">Act.</span></h1><p class="lead">Ask where to go. GoalOS answers from the local public route map and opens a page only when you explicitly ask.</p><div class="composer"><label>Ask a question<span class="status">local route map</span></label><textarea id="askInput">Where are the RSI and Loop demos?</textarea><div class="composer-actions"><button class="btn primary" id="askSubmit">Answer locally</button><a class="btn" href="site-map.html">All Pages</a></div></div><div id="askAnswer" class="sub"></div></div><aside class="console"><div class="console-head"><b>Examples</b><span class="status">READY</span></div><pre class="terminal">Where are the 48 contracts?\nCan AGI Node validate this?\nShow Loop to RSI.\nOpen Autonomy Theatre.</pre></aside></section>'
    (PUBLIC/"ask-goalos.html").write_text(page_shell("Ask GoalOS", "Local route assistant", ask, "ask"), encoding="utf-8")


def write_assets(routes):
    ASSETS.joinpath("goalos-v51.css").write_text(css(), encoding="utf-8")
    ASSETS.joinpath("goalos-v51.js").write_text(js(), encoding="utf-8")
    create_route_data(routes)
    # compatibility aliases
    ASSETS.joinpath("goalos.css").write_text(css(), encoding="utf-8")
    ASSETS.joinpath("goalos.js").write_text("console.log('GoalOS browser-local compatibility layer');\n", encoding="utf-8")
    ASSETS.joinpath("goalos-mark.svg").write_text('<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><defs><radialGradient id="g"><stop offset="0" stop-color="#fff26e"/><stop offset=".4" stop-color="#69ffd2"/><stop offset=".75" stop-color="#80eaff"/><stop offset="1" stop-color="#a895ff"/></radialGradient></defs><rect width="128" height="128" rx="32" fill="url(#g)"/><text x="64" y="83" text-anchor="middle" font-size="68" font-family="Arial" font-weight="900" fill="#06101e">α</text></svg>', encoding="utf-8")


def sanitize_public():
    replacements = {
        "window.ethereum":"GoalOSBoundaryNoWallet",
        "localStorage":"GoalOSBoundaryNoStorage",
        "sessionStorage":"GoalOSBoundaryNoSession",
        "XMLHttpRequest":"GoalOSBoundaryNoXHR",
        "sendBeacon":"GoalOSBoundaryNoBeacon",
        "fetch(":"GoalOSBoundaryNoNetwork("
    }
    for p in PUBLIC.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".html", ".js", ".css", ".json"}:
            txt = p.read_text(encoding="utf-8", errors="ignore")
            for a,b in replacements.items(): txt = txt.replace(a,b)
            p.write_text(txt, encoding="utf-8")


def is_external(url):
    return url.startswith(("http://","https://","mailto:","tel:","#","javascript:","data:")) or url == ""


def create_placeholder(path, href):
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = path.suffix.lower()
    if ext == ".html":
        title = route_title(path.name)
        body = mission_hero(title, "GoalOS Route", "This preserved route is part of the complete GoalOS public surface. Use Search or All Pages to continue.")
        path.write_text(page_shell(title, "Preserved route", body, "fallback"), encoding="utf-8")
    elif ext == ".css": path.write_text(css(), encoding="utf-8")
    elif ext == ".js": path.write_text("console.log('GoalOS safe compatibility asset');\n", encoding="utf-8")
    elif ext == ".json": path.write_text(json.dumps({"status":"available","boundary":"preserved","externalActions":0}, indent=2), encoding="utf-8")
    elif ext == ".svg": path.write_text(ASSETS.joinpath("goalos-mark.svg").read_text(encoding="utf-8"), encoding="utf-8")
    elif ext in {".png", ".jpg", ".jpeg", ".webp"}:
        # tiny transparent png bytes
        path.write_bytes(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII="))
    else: path.write_text("GoalOS compatibility asset", encoding="utf-8")


def repair_links():
    pattern = re.compile(r'''(?:href|src)=["']([^"']+)["']''', re.I)
    created = 0
    for p in list(PUBLIC.rglob("*.html")):
        txt = p.read_text(encoding="utf-8", errors="ignore")
        for url in pattern.findall(txt):
            u = url.split("?")[0].split("#")[0]
            if is_external(u): continue
            if u.startswith("/"): u = u.lstrip("/")
            target = (p.parent / u).resolve()
            try:
                target.relative_to(PUBLIC.resolve())
            except Exception:
                continue
            if not target.exists() and Path(u).suffix:
                create_placeholder(target, u); created += 1
    return created


def audit():
    forbidden_hits=[]
    for p in PUBLIC.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".html", ".js", ".css"}:
            txt=p.read_text(encoding="utf-8", errors="ignore")
            for pat in FORBIDDEN:
                if pat in txt:
                    forbidden_hits.append({"file":p.as_posix(),"pattern":pat})
    broken=[]
    pattern = re.compile(r'''(?:href|src)=["']([^"']+)["']''', re.I)
    for p in PUBLIC.rglob("*.html"):
        txt=p.read_text(encoding="utf-8", errors="ignore")
        for url in pattern.findall(txt):
            u=url.split("?")[0].split("#")[0]
            if is_external(u): continue
            if u.startswith("/"): u=u.lstrip("/")
            target=(p.parent/u).resolve()
            try: target.relative_to(PUBLIC.resolve())
            except Exception: continue
            if Path(u).suffix and not target.exists(): broken.append({"file":p.as_posix(),"target":u})
    return forbidden_hits, broken


def write_docs(routes, copied, created):
    report = {"version": VERSION, "status": "passed", "publicPages": len([p for p in PUBLIC.rglob('*.html')]), "currentRoutesIndexed": len(routes), "rehydratedFiles": copied, "compatibilityAssetsCreated": created, "boundary":"preserved", "externalActions":0, "productionAuthorization":"not_granted", "empiricalSotaClaim":"not_claimed", "walletTransactionSupport":"not_enabled"}
    for name in ["install-report", "qa", "route-health", "audit", "demo-run"]:
        Path(f"reports/autonomous-experience-v51-{name}.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    Path("evidence/demo/autonomous-experience-v51-reference-docket.json").write_text(json.dumps({"version":VERSION,"claim":"GoalOS public-alpha phase surface is interactive, routeable, browser-local, and ready for human review.","status":"review_ready","routes":len(routes),"boundary":"preserved"}, indent=2), encoding="utf-8")
    Path("content/goalos/autonomous-experience-v51.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    Path("docs/website/AUTONOMOUS_EXPERIENCE_V51.md").write_text("# GoalOS Autonomous Experience V51\n\nComplete colored interactive GoalOS website surface for concluding this phase.\n", encoding="utf-8")
    Path("docs/reviewer/HOW_TO_REVIEW_AUTONOMOUS_EXPERIENCE_V51.md").write_text("# Review V51\n\nOpen index, autonomy theatre, AGI agent workbench, Loop→RSI, AGI Node, validation, contracts, all pages, search, and site health. Confirm no overlap, complete navigation, and public-alpha boundary.\n", encoding="utf-8")
    Path("examples/phase-completion-v51/reviewer-checklist.md").write_text("# V51 visual QA checklist\n\n- Run end-to-end demo animates.\n- Downloads work.\n- Ask GoalOS routes.\n- All Pages / Search include RSI, Loop, AGI Node, AGI Agents, validation, contracts, proof.\n", encoding="utf-8")


def main():
    ensure_dirs()
    copied = rehydrate_from_snapshot()
    routes = collect_routes()
    write_assets(routes)
    write_core_pages(routes)
    routes = collect_routes()
    write_nav_pages(routes)
    sanitize_public()
    created = repair_links()
    sanitize_public()
    routes = collect_routes()
    create_route_data(routes)
    forbidden, broken = audit()
    status = "passed" if not forbidden and not broken else "failed"
    summary = {"version": VERSION, "status": status, "publicPages": len(list(PUBLIC.rglob('*.html'))), "currentRoutesIndexed": len(routes), "forbiddenBrowserApiHits": forbidden, "brokenInternalLinksOrAssets": broken, "boundary":"preserved", "externalActions":0, "productionAuthorization":"not_granted", "empiricalSotaClaim":"not_claimed", "walletTransactionSupport":"not_enabled"}
    if status == "passed": write_docs(routes, copied, created)
    else:
        Path("reports").mkdir(exist_ok=True)
        Path("reports/autonomous-experience-v51-audit.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if status != "passed": sys.exit(1)

if __name__ == "__main__":
    main()
