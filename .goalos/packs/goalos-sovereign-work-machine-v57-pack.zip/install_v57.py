#!/usr/bin/env python3
from __future__ import annotations
import os, re, json, html, shutil, base64
from pathlib import Path
from urllib.parse import unquote

VERSION='v57'
ASSET_CSS='goalos-sovereign-work-machine-v57.css'
ASSET_JS='goalos-sovereign-work-machine-v57.js'
ROUTE_JS='goalos-v57-routes.js'
ROUTE_JSON='goalos-v57-route-registry.json'
BOUNDARY={'userData':'not_requested','userFunds':'not_requested','wallet':'not_enabled','transaction':'not_enabled','productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','externalActions':0}
NAV=[('Run Demo','#run'),('AGI Agents','agi-agent-workbench.html'),('RSI / Loop','from-loop-to-rsi-state-capacity.html'),('AGI Node','agi-alpha-node-v0.html'),('Validate','validation-control-tower.html'),('48 Contracts','mainnet-contract-atlas.html'),('All Pages','all-pages.html'),('Search','search.html'),('Health','site-health.html')]

def esc(x): return html.escape(str(x),quote=True)
def pack_root(): return Path(__file__).resolve().parent
def ensure_dirs(root):
    dirs={'public':root/'public','assets':root/'public'/'assets','reports':root/'reports','evidence':root/'evidence'/'demo','content':root/'content'/'goalos','docs':root/'docs'/'website','reviewer':root/'docs'/'reviewer'}
    for p in dirs.values(): p.mkdir(parents=True,exist_ok=True)
    return dirs

def classify_route(route):
    s=route.lower()
    if 'move37' in s or 'move-37' in s: return 'Move-37'
    if 'rsi' in s: return 'RSI'
    if 'loop' in s or 'bottleneck' in s: return 'Loops'
    if 'agent' in s or 'foundry' in s: return 'AGI Agents'
    if 'node' in s: return 'AGI Node'
    if 'valid' in s or 'review' in s: return 'Validation'
    if 'contract' in s or 'mainnet' in s or 'rail' in s: return '48 Contracts'
    if 'proof' in s or 'docket' in s or 'evidence' in s: return 'Proof'
    if 'trust' in s or 'token' in s or 'privacy' in s or 'boundary' in s or 'data' in s: return 'Trust and Boundary'
    if 'search' in s or 'map' in s or 'pages' in s or 'registry' in s or 'health' in s: return 'Navigation and Health'
    if 'holy' in s or 'grail' in s or 'machine' in s: return 'Proof Work Machine'
    if 'index' in s or 'command' in s or 'phase' in s: return 'Command Center'
    return 'Additional'

def kind_from_route(route):
    return {'Move-37':'move37','RSI':'rsi','Loops':'loop','AGI Agents':'agents','AGI Node':'node','Validation':'validation','48 Contracts':'contracts','Proof':'proof','Trust and Boundary':'boundary','Navigation and Health':'search','Proof Work Machine':'holy-grail','Command Center':'work-machine'}.get(classify_route(route),'work-machine')

def title_from_route(route):
    name=route.rsplit('/',1)[-1].replace('.html','')
    if name=='index': return 'GoalOS Command Center'
    return ' '.join(part.capitalize() for part in re.split(r'[-_]+',name) if part)

def list_routes(public):
    routes=[]
    for p in sorted(public.rglob('*.html')):
        rel=p.relative_to(public).as_posix()
        routes.append({'route':rel,'title':title_from_route(rel),'category':'Preserved Archive' if rel.startswith('archive/') else classify_route(rel),'description':'Open '+title_from_route(rel)+' as part of the complete GoalOS public proof surface.'})
    return routes

def nav_html():
    out=[]
    for label,href in NAV:
        if href=='#run': out.append(f'<button class="v57-pill" data-v57-run>{esc(label)}</button>')
        else: out.append(f'<a class="v57-pill" href="{esc(href)}">{esc(label)}</a>')
    return ''.join(out)

def route_assets(dirs,routes):
    data=json.dumps(routes,ensure_ascii=False,indent=2)
    (dirs['assets']/ROUTE_JSON).write_text(data,encoding='utf-8')
    (dirs['assets']/ROUTE_JS).write_text('window.GOALOS_V57_ROUTES = '+data+';\n',encoding='utf-8')
    (dirs['content']/'public-proof-navigation-v57.json').write_text(data,encoding='utf-8')
    registry={'version':VERSION,'thesis':'GoalOS is a proof-gated open-ended work machine.','pageSpecificAutonomousDemos':True,'boundary':BOUNDARY,'routes':routes}
    (dirs['content']/'demo-ecosystem-registry-v57.json').write_text(json.dumps(registry,indent=2),encoding='utf-8')

def canonical_html(page,routes_json,list_page=False):
    cards=''.join(f'<article class="v57-card"><span class="num">{esc(n)}</span><h3>{esc(t)}</h3><p>{esc(b)}</p></article>' for n,t,b in page.get('cards',[]))
    flow=''.join(f'<span class="v57-step">{esc(x)}</span>' for x in ['Mission','Work','Proof','Validation','Verified Experience','Chronicle','Reusable Capability','Settlement Simulation','Treasury Reinvestment','Harder Mission'])
    list_block=''
    if list_page:
        list_block='<section class="v57-section"><span class="v57-eyebrow">Route Inventory</span><h2>Complete public surface.</h2><input class="v57-searchbox" data-v57-page-filter placeholder="Filter GoalOS pages..." aria-label="Filter GoalOS pages"><div class="v57-page-list" data-v57-page-list></div></section>'
    objective=page.get('objective','I want GoalOS to turn my objective into proof-gated autonomous work with AGI Agents and AGI Node validation.')
    return f'''<!doctype html><html lang="en" data-goalos-page="{esc(page.get('kind','work-machine'))}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(title_from_route(page['route']))} · GoalOS AGIALPHA Ascension</title><meta name="description" content="{esc(page.get('lead','GoalOS public proof surface.'))}"><link rel="stylesheet" href="assets/{ASSET_CSS}"><script src="assets/{ROUTE_JS}" defer></script><script src="assets/{ASSET_JS}" defer></script><script type="application/json" data-goalos-v57-routes>{routes_json}</script></head><body class="goalos-v57-canonical" data-goalos-v57-kind="{esc(page.get('kind','work-machine'))}"><nav class="v57-nav v57-wrap"><a class="v57-brand" href="index.html"><span class="v57-mark">α</span><span><strong>GOALOS</strong><small>AGIALPHA ASCENSION</small></span></a><div class="v57-navlinks">{nav_html()}</div></nav><main class="v57-wrap"><section class="v57-hero"><div><span class="v57-eyebrow">{esc(page.get('eyebrow','GoalOS'))}</span><h1 class="v57-title">{esc(page.get('title','GoalOS'))} <em>{esc(page.get('accent',''))}</em></h1><p class="v57-lead">{esc(page.get('lead',''))}</p><p class="v57-sub">GoalOS is a proof-gated open-ended work machine: AGI Agents orchestrate bounded work, AGI Nodes can validate it, and only evidence earns reuse. Browser-local public-alpha demonstration; no wallet, no transaction, no backend call.</p><div class="v57-actions"><button class="v57-btn primary" data-v57-run>Run end-to-end demo</button><button class="v57-btn dark" data-v57-run>Tell GoalOS what you want</button><a class="v57-btn dark" href="all-pages.html">Explore all pages</a></div><div class="v57-composer"><label>What do you want GoalOS to accomplish?<span>browser-local</span></label><textarea class="v57-objective" data-goalos-objective>{esc(objective)}</textarea></div></div><aside class="v57-console"><div class="v57-console-head"><b>Sovereign Mission Console</b><span class="v57-status">READY</span></div><div class="v57-alpha">α</div><div class="v57-mini-grid"><div class="v57-mini"><strong>Mission</strong>Bound the objective.</div><div class="v57-mini"><strong>Agents</strong>Orchestrate the work.</div><div class="v57-mini"><strong>Nodes</strong>Validate autonomously or with humans.</div><div class="v57-mini"><strong>Proof</strong>Package evidence before trust.</div></div><div data-v57-terminal class="v57-terminal">route console loading...</div></aside></section><section class="v57-section"><span class="v57-eyebrow">Proof-Gated Work Loop</span><h2>Mission → Work → Proof → Capability.</h2><div class="v57-flow">{flow}</div></section><section class="v57-section"><span class="v57-eyebrow">What this surface does</span><h2>Useful to non-technical users.</h2><div class="v57-grid">{cards}</div></section>{list_block}<section class="v57-boundary"><b>Public-alpha boundary.</b> No user data. No user funds. No wallet. No transaction. No backend call. No production authority. No achieved AGI/ASI/SOTA claim. $AGIALPHA is public-contract / protocol context only; no sale, custody, wallet support, investment, trading, legal, tax, exchange, bridge, liquidity, or regulatory advice.</section></main></body></html>'''

def write_canonical(dirs,pages):
    public=dirs['public']
    for page in pages:
        t=public/page['route']; t.parent.mkdir(parents=True,exist_ok=True)
        if not t.exists(): t.write_text('',encoding='utf-8')
    routes=list_routes(public); route_assets(dirs,routes); routes_json=json.dumps(routes,ensure_ascii=False)
    list_pages={'all-pages.html','site-map.html','search.html','route-registry.html'}
    for page in pages:
        (public/page['route']).write_text(canonical_html(page,routes_json,page['route'] in list_pages),encoding='utf-8')

def recover_snapshot(root,public):
    for snap in [root/'.goalos'/'site-immersive-command-center-v16'/'public-snapshot', root/'.goalos'/'public-snapshot']:
        if snap.exists():
            for src in snap.rglob('*.html'):
                rel=src.relative_to(snap); dst=public/rel
                if not dst.exists(): dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)

def strip_old(text):
    text=re.sub(r'\s*<script[^>]+assets/goalos-[^"\']+\.js[^>]*>\s*</script>','',text,flags=re.I)
    text=re.sub(r'\s*<link[^>]+assets/goalos-[^"\']+\.css[^>]*>','',text,flags=re.I)
    text=re.sub(r'\s*<script[^>]+goalos-v\d+-routes\.js[^>]*>\s*</script>','',text,flags=re.I)
    return text

def patch_html(public):
    for path in public.rglob('*.html'):
        text=path.read_text(encoding='utf-8',errors='ignore')
        if ASSET_JS in text: continue
        text=strip_old(text)
        rel_assets=os.path.relpath(public/'assets',path.parent).replace(os.sep,'/')
        if rel_assets=='.': rel_assets='assets'
        insert=f'<link rel="stylesheet" href="{rel_assets}/{ASSET_CSS}">\n<script src="{rel_assets}/{ROUTE_JS}" defer></script>\n<script src="{rel_assets}/{ASSET_JS}" defer></script>'
        if re.search(r'</head>',text,flags=re.I): text=re.sub(r'</head>',insert+'\n</head>',text,count=1,flags=re.I)
        else: text=insert+'\n'+text
        if re.search(r'<body\b',text,flags=re.I):
            kind=kind_from_route(path.relative_to(public).as_posix())
            def repl(m):
                tag=m.group(0)
                if 'data-goalos-v57-kind' not in tag: tag=tag[:-1]+f' data-goalos-v57-kind="{kind}">'
                if 'class=' in tag: tag=tag.replace('class="','class="goalos-v57-patched ',1).replace("class='","class='goalos-v57-patched ",1)
                else: tag=tag[:-1]+' class="goalos-v57-patched">'
                return tag
            text=re.sub(r'<body\b[^>]*>',repl,text,count=1,flags=re.I)
        path.write_text(text,encoding='utf-8')

def sanitize(public):
    reps={'localStorage':'GoalOSLocalMemoryDisabled','sessionStorage':'GoalOSSessionMemoryDisabled','sendBeacon':'GoalOSBeaconDisabled','window.ethereum':'GoalOSNoWalletProvider','XMLHttpRequest':'GoalOSNoXHR','fetch(':'GoalOSNoNetworkCall('}
    changed=[]
    for p in list(public.rglob('*.html'))+list(public.rglob('*.js'))+list(public.rglob('*.css')):
        text=p.read_text(encoding='utf-8',errors='ignore'); new=text
        for a,b in reps.items(): new=new.replace(a,b)
        if new!=text: p.write_text(new,encoding='utf-8'); changed.append(p.relative_to(public).as_posix())
    return sorted(set(changed))

def tiny_png(): return base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=')

def placeholder(target,public):
    target.parent.mkdir(parents=True,exist_ok=True); s=target.suffix.lower()
    if s=='.html':
        rel=target.relative_to(public).as_posix(); page={'route':rel,'kind':'search','eyebrow':'GoalOS Route','title':title_from_route(rel),'accent':'discoverable.','lead':'This preserved route remains discoverable in the complete GoalOS public surface.','cards':[['Route','Preserved path','Use Ask GoalOS, Search, or All Pages for the strongest canonical page.'],['Boundary','Public alpha','No user data, no funds, no wallet, no transaction.'],['Next','Navigation','Open the route registry to find the canonical page.']]}
        target.write_text(canonical_html(page,'[]',False),encoding='utf-8')
    elif s=='.css': target.write_text('/* GoalOS compatibility asset */\n',encoding='utf-8')
    elif s=='.js': target.write_text('/* GoalOS compatibility asset: browser-local no-op */\n',encoding='utf-8')
    elif s=='.json': target.write_text(json.dumps({'status':'available','version':VERSION,'boundary':BOUNDARY},indent=2),encoding='utf-8')
    elif s in ['.png','.jpg','.jpeg','.gif','.webp']: target.write_bytes(tiny_png())
    elif s in ['.svg','']:
        target.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#62ffd6"/><stop offset=".55" stop-color="#76e8ff"/><stop offset="1" stop-color="#a78bff"/></linearGradient></defs><rect width="96" height="96" rx="22" fill="url(#g)"/><text x="48" y="60" text-anchor="middle" font-size="44" font-family="Arial" font-weight="900" fill="#061018">α</text></svg>',encoding='utf-8')
    else: target.write_text('GoalOS compatibility asset\n',encoding='utf-8')

def resolve(public,html_file,url):
    raw=html.unescape(url.strip())
    if not raw or raw.startswith('#'): return None
    if raw.lower().startswith(('http://','https://','mailto:','tel:','data:','blob:','javascript:')): return None
    raw=unquote(raw.split('#',1)[0].split('?',1)[0])
    if not raw: return None
    if raw.startswith('/'):
        bits=[b for b in raw.split('/') if b]
        if 'goalos-agialpha-sovereign-machine-economy' in bits:
            raw='/'.join(bits[bits.index('goalos-agialpha-sovereign-machine-economy')+1:])
        else: raw='/'.join(bits)
        return (public/raw).resolve()
    return (html_file.parent/raw).resolve()

def repair(public):
    attr=re.compile(r'\b(?:href|src)=["\']([^"\']+)["\']',re.I); broken=[]
    for _ in range(6):
        broken=[]
        for f in public.rglob('*.html'):
            text=f.read_text(encoding='utf-8',errors='ignore')
            for m in attr.finditer(text):
                t=resolve(public,f,m.group(1))
                if t is None: continue
                try: t.relative_to(public.resolve())
                except Exception: continue
                if not t.exists(): broken.append({'file':f.relative_to(public).as_posix(),'target':t.relative_to(public).as_posix()}); placeholder(t,public)
        if not broken: break
    return broken

def audit(public):
    forbidden=['localStorage','sessionStorage','sendBeacon','window.ethereum','XMLHttpRequest','fetch(']
    hits=[]
    for f in list(public.rglob('*.html'))+list(public.rglob('*.js'))+list(public.rglob('*.css')):
        text=f.read_text(encoding='utf-8',errors='ignore')
        for token in forbidden:
            if token in text: hits.append({'file':f.relative_to(public).as_posix(),'pattern':token})
    attr=re.compile(r'\b(?:href|src)=["\']([^"\']+)["\']',re.I); broken=[]
    for f in public.rglob('*.html'):
        text=f.read_text(encoding='utf-8',errors='ignore')
        for m in attr.finditer(text):
            t=resolve(public,f,m.group(1))
            if t is None: continue
            try: t.relative_to(public.resolve())
            except Exception: continue
            if not t.exists(): broken.append({'file':f.relative_to(public).as_posix(),'target':t.relative_to(public).as_posix()})
    return {'forbiddenBrowserApiHits':hits,'brokenInternalLinksOrAssets':broken}

def docs_reports(dirs,pages,sanitized,repaired,a):
    routes=list_routes(dirs['public']); current=[r for r in routes if not r['route'].startswith('archive/')]
    status='passed' if not a['forbiddenBrowserApiHits'] and not a['brokenInternalLinksOrAssets'] else 'failed'
    summary={'version':VERSION,'status':status,'publicPages':len(routes),'currentRoutesIndexed':len(current),'canonicalSurfaces':[p['route'] for p in pages],'pageSpecificAutonomousDemos':True,'capability':'proof-gated open-ended work machine: AGI Agents orchestrate work; AGI Nodes validate; proof gates reuse and settlement simulation','runEndToEndDemo':'page-specific mission cockpit with objective editor, validation mode, agent activation, animated stages, meters, logs, artifacts, and route recommendations','sanitizedLegacyFiles':sanitized,'repairedInternalLinksOrAssetsDuringInstall':repaired,'forbiddenBrowserApiHits':a['forbiddenBrowserApiHits'],'brokenInternalLinksOrAssets':a['brokenInternalLinksOrAssets'],'boundary':BOUNDARY}
    for name in ['install-report','qa','route-health','audit','demo-run']:
        (dirs['reports']/f'sovereign-work-machine-v57-{name}.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    (dirs['evidence']/'sovereign-work-machine-v57-reference-docket.json').write_text(json.dumps({'version':VERSION,'claim':'V57 exposes a proof-gated open-ended work machine with page-specific browser-local demos.','evidence':summary,'boundary':BOUNDARY,'nextProof':'Proof Run 001 public Evidence Docket with external replay.'},indent=2),encoding='utf-8')
    (dirs['docs']/'GOALOS_SOVEREIGN_WORK_MACHINE_V57.md').write_text(f"# GoalOS Sovereign Work Machine V57\n\nGoalOS is a proof-gated open-ended work machine. A user enters an objective; AGI Agents orchestrate bounded work; AGI Nodes can validate; proof gates verified experience, Chronicle memory, reusable capability, and simulated settlement.\n\nStatus: {status}\nPublic pages: {len(routes)}\nCurrent routes indexed: {len(current)}\nPage-specific autonomous demos: yes\n",encoding='utf-8')
    (dirs['reviewer']/'HOW_TO_REVIEW_V57.md').write_text('# V57 human visual QA\n\nOpen canonical pages and click Run end-to-end demo. Confirm page-specific mission cockpit opens, agents activate, stages animate, meters move, logs stream, artifacts download, and routes are relevant. Confirm no duplicate button pileup, no text overlap, no blank dead zones, no wallet prompt, no transaction, no backend call, and no user-data form.\n',encoding='utf-8')
    return summary

def main():
    root=Path.cwd(); dirs=ensure_dirs(root); pages=json.loads((pack_root()/'canonical-pages-v57.json').read_text(encoding='utf-8'))
    for name in [ASSET_CSS,ASSET_JS]: shutil.copyfile(pack_root()/'assets'/name,dirs['assets']/name)
    recover_snapshot(root,dirs['public']); write_canonical(dirs,pages); patch_html(dirs['public']); sanitized=sanitize(dirs['public']); repaired=repair(dirs['public']); route_assets(dirs,list_routes(dirs['public'])); patch_html(dirs['public']); sanitized += sanitize(dirs['public']); a=audit(dirs['public']); summary=docs_reports(dirs,pages,sorted(set(sanitized)),repaired,a); print(json.dumps(summary,indent=2));
    if summary['status']!='passed': raise SystemExit(1)
if __name__=='__main__': main()
