#!/usr/bin/env python3
from pathlib import Path
import json, os, re, sys, datetime
ROOT = Path.cwd()
FAIL = str(os.environ.get('FAIL_ON_AUDIT_ERROR','true')).lower() in ('1','true','yes','on')
required = [
 'public/chronicle-gate-lab-v80.html',
 'public/goalos-chronicle-gate-lab-v80-index.json',
 'docs/chronicle-gate-lab-v80/README.md',
 'docs/chronicle-gate-lab-v80/ARCHITECTURE.md',
 'docs/chronicle-gate-lab-v80/NON_TECHNICAL_GUIDE.md',
 'docs/chronicle-gate-lab-v80/CHRONICLE_GATE_STANDARD.md',
 'docs/chronicle-gate-lab-v80/INTERFACE_AND_CHARTS.md',
 'evidence/chronicle-gate-lab-v80/evidence-docket-61.json',
 'evidence/chronicle-gate-lab-v80/sample-proofbundle-valid.json',
 'evidence/chronicle-gate-lab-v80/sample-proofbundle-missing-replay.json',
 'schemas/goalos-v80/proofbundle-chronicle-gate.schema.json',
 'schemas/goalos-v80/chronicle-gate-state.schema.json',
 'examples/chronicle-gate-lab-v80/demo-state-transition.json',
 'content/goalos-chronicle-gate-lab-v80/manifest.json'
]
errors=[]
for p in required:
    if not (ROOT/p).exists():
        errors.append(f'Missing required file: {p}')
html_path=ROOT/'public/chronicle-gate-lab-v80.html'
html=html_path.read_text(encoding='utf-8', errors='ignore') if html_path.exists() else ''
required_phrases=[
 'Only validated results enter',
 'No ProofBundle, no settlement',
 'No replay, no validation',
 'No validation, no Chronicle memory',
 'No backend, no wallet',
 'Proof Gate Funnel',
 'Chronicle Influence Network',
 'Promotion Radar',
 'Proof Economy Thermostat'
]
for phrase in required_phrases:
    if phrase not in html:
        errors.append(f'Missing phrase in HTML: {phrase}')
for forbidden in ['fetch(', 'XMLHttpRequest', 'sendBeacon', 'window.ethereum', 'localStorage', 'sessionStorage', '<script src=', '<link rel="stylesheet"', 'fonts.googleapis']:
    if forbidden in html:
        errors.append(f'Forbidden standalone/browser-local token found: {forbidden}')
# Guard against obvious unsupported positive claims.
unsupported_patterns=[r'GoalOS has achieved AGI', r'GoalOS has achieved ASI', r'claims empirical SOTA', r'guarantees ROI', r'provides live settlement in local mode']
for pat in unsupported_patterns:
    if re.search(pat, html, flags=re.I):
        errors.append(f'Unsupported claim pattern found: {pat}')
try:
    pb=json.loads((ROOT/'evidence/chronicle-gate-lab-v80/sample-proofbundle-valid.json').read_text(encoding='utf-8'))
    for k in ['replay_result','validator_verdict','claim_boundary','risk_ledger']:
        if k not in pb: errors.append(f'Valid proofbundle missing {k}')
except Exception as e:
    errors.append(f'Cannot parse valid sample proofbundle: {e}')
report={'version':'v80','audited_at':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','errors':errors,'status':'pass' if not errors else 'fail','checked_files':required,'principle':'Only validated results can enter Chronicle memory or influence future missions.'}
(ROOT/'reports').mkdir(exist_ok=True)
(ROOT/'reports/goalos-chronicle-gate-lab-v80-audit-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
md='# GoalOS Chronicle Gate Lab v80 audit report\n\n'
md += f"Status: **{report['status'].upper()}**\n\n"
md += '## Errors\n' + ('\n'.join(f'- {e}' for e in errors) if errors else '- none') + '\n\n'
md += '## Boundary checked\nNo backend, no wallet, no transaction, no user funds, no live settlement, no achieved AGI/ASI, no empirical SOTA, no certification, no guaranteed ROI, no autonomous production authority.\n'
(ROOT/'reports/goalos-chronicle-gate-lab-v80-audit-report.md').write_text(md, encoding='utf-8')
print(md)
if errors and FAIL:
    sys.exit(1)
