#!/usr/bin/env python3
from pathlib import Path
import os, shutil, json, datetime

ROOT = Path.cwd()
PACK = Path(__file__).resolve().parent
PAYLOAD = PACK / 'payload'
VERSION = 'v80'
MARKER_START = '<!-- GOALOS-CHRONICLE-GATE-LAB-V80:NAV:START -->'
MARKER_END = '<!-- GOALOS-CHRONICLE-GATE-LAB-V80:NAV:END -->'

def env_bool(name, default=False):
    return str(os.environ.get(name, str(default))).lower() in ('1','true','yes','on')

ALLOW_OVERWRITE = env_bool('ALLOW_OVERWRITE', False)
UPDATE_NAVIGATION = env_bool('UPDATE_NAVIGATION', True)
PATCH_EXISTING_PAGES = env_bool('PATCH_EXISTING_PAGES', True)

added, skipped, patched = [], [], []

def copy_payload():
    for src in PAYLOAD.rglob('*'):
        if src.is_dir():
            continue
        rel = src.relative_to(PAYLOAD)
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and not ALLOW_OVERWRITE:
            skipped.append(str(rel))
            continue
        shutil.copy2(src, dst)
        added.append(str(rel))

def patch_page(path: Path):
    if not path.exists() or not path.is_file():
        return
    text = path.read_text(encoding='utf-8', errors='ignore')
    if MARKER_START in text:
        return
    block = f'''\n{MARKER_START}\n<section style="margin:32px auto;max-width:1120px;padding:22px;border-radius:24px;border:1px solid rgba(81,255,214,.35);background:linear-gradient(135deg,rgba(81,255,214,.10),rgba(169,134,255,.10));font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;">\n  <p style="margin:0 0 8px;color:#51ffd6;font-weight:900;letter-spacing:.16em;text-transform:uppercase;">New GoalOS v80 capability</p>\n  <h2 style="margin:0 0 10px;color:inherit;">Chronicle Gate Lab</h2>\n  <p style="margin:0 0 14px;color:inherit;">Interactive proof firewall showing that only replayed, validator-approved ProofBundles can enter Chronicle memory or influence future missions.</p>\n  <p style="margin:0;"><a href="chronicle-gate-lab-v80.html" style="display:inline-block;padding:11px 14px;border-radius:999px;background:#51ffd6;color:#07111f;font-weight:900;text-decoration:none;">Open Chronicle Gate Lab</a></p>\n</section>\n{MARKER_END}\n'''
    if '</body>' in text:
        text = text.replace('</body>', block + '\n</body>', 1)
    else:
        text += block
    path.write_text(text, encoding='utf-8')
    patched.append(str(path.relative_to(ROOT)))

def update_route_registry():
    registry = ROOT / 'public' / 'goalos-chronicle-gate-lab-v80-index.json'
    if registry.exists():
        data = json.loads(registry.read_text(encoding='utf-8'))
    else:
        data = {}
    data['installed_at'] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'
    data['repository'] = os.environ.get('GOALOS_REPOSITORY','local')
    data['run_id'] = os.environ.get('GOALOS_RUN_ID','local')
    registry.write_text(json.dumps(data, indent=2), encoding='utf-8')
    if str(registry.relative_to(ROOT)) not in added:
        added.append(str(registry.relative_to(ROOT)))

def write_reports():
    report = {
        'version': VERSION,
        'installed_at': datetime.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z',
        'added_or_refreshed': added,
        'skipped_existing': skipped,
        'patched_pages': patched,
        'allow_overwrite': ALLOW_OVERWRITE,
        'principle': 'Only validated results can enter Chronicle memory or influence future missions.',
        'claim_boundary': 'Public-alpha architectural interface; no AGI/ASI/SOTA/certification/ROI/live-settlement claim.'
    }
    (ROOT/'reports').mkdir(exist_ok=True)
    (ROOT/'reports/goalos-chronicle-gate-lab-v80-install-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    md = '# GoalOS Chronicle Gate Lab v80 install report\n\n'
    md += f"Installed at: `{report['installed_at']}`\n\n"
    md += '## Added or refreshed\n' + '\n'.join(f'- `{x}`' for x in added) + '\n\n'
    md += '## Skipped existing files\n' + ('\n'.join(f'- `{x}`' for x in skipped) if skipped else '- none') + '\n\n'
    md += '## Patched pages\n' + ('\n'.join(f'- `{x}`' for x in patched) if patched else '- none') + '\n\n'
    md += '## Boundary\nNo backend, no wallet, no transaction, no user funds, no live settlement, no achieved AGI/ASI, no empirical SOTA, no certification, no guaranteed ROI, no autonomous production authority.\n'
    (ROOT/'reports/goalos-chronicle-gate-lab-v80-install-report.md').write_text(md, encoding='utf-8')

copy_payload()
if UPDATE_NAVIGATION and PATCH_EXISTING_PAGES:
    for name in ['index.html','goalos.html','all-pages.html','site-map.html','evidence.html']:
        patch_page(ROOT/'public'/name)
update_route_registry()
(ROOT/'.nojekyll').write_text('', encoding='utf-8')
(ROOT/'public/.nojekyll').write_text('', encoding='utf-8')
write_reports()
print('GoalOS Chronicle Gate Lab v80 installed.')
print(f'Added/refreshed: {len(added)} | skipped: {len(skipped)} | patched: {len(patched)}')
