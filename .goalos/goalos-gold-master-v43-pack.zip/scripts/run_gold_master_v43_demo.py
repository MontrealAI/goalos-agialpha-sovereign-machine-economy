
import json
from pathlib import Path
routes=json.loads((Path('public/assets/goalos-route-registry-v43.js')).read_text().split('=',1)[1].rsplit(';',1)[0]) if Path('public/assets/goalos-route-registry-v43.js').exists() else []
result={'version':'v43','status':'passed' if routes else 'failed','demo':'gold master can route user to demo, agents, validation, contracts, readiness, all-pages, and search','testIntents':{'new user':'goalos-gold-master.html','end-to-end demo':'autonomy-theatre.html','AGI Agents':'agi-agent-workbench.html','Human or AGI Node validation':'validation-control-tower.html','48 contracts':'mainnet-contract-atlas.html','production readiness':'production-readiness-gauntlet.html'},'routeCount':len(routes)}
Path('reports').mkdir(exist_ok=True)
Path('reports/gold-master-v43-demo-run.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
