
from pathlib import Path
import json, re, shutil
ROOT=Path.cwd(); PACK_ROOT=Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'public'; ASSETS=PUBLIC/'assets'; REPORTS=ROOT/'reports'; CONTENT=ROOT/'content'/'goalos'; EVIDENCE=ROOT/'evidence'/'demo'
for d in [PUBLIC,ASSETS,REPORTS,CONTENT,EVIDENCE]: d.mkdir(parents=True,exist_ok=True)
SRC=PACK_ROOT/'public'
def copytree_merge(src,dst):
    for item in src.rglob('*'):
        rel=item.relative_to(src); target=dst/rel
        if item.is_dir(): target.mkdir(parents=True,exist_ok=True); continue
        target.parent.mkdir(parents=True,exist_ok=True)
        # Refresh V43 assets and primary route surfaces; preserve other existing pages unless absent.
        overwrite = rel.as_posix().startswith('assets/') or rel.name in {'index.html','goalos-command-center.html','goalos-gold-master.html','public-alpha-gold-master.html','graduation-control-room.html','production-readiness-gauntlet.html','external-validation-roadmap.html','quintessential-user-journey.html','gold-master-use-cases.html','evidence-to-production-roadmap.html','site-map.html','all-pages.html','route-registry.html','search.html','site-health.html'}
        if overwrite or not target.exists(): shutil.copy2(item,target)
copytree_merge(SRC,PUBLIC)
(PUBLIC/'.nojekyll').write_text('')
# Copy docs/content/examples/evidence/issue templates from pack
for folder in ['docs','content','examples','evidence','issue-bodies','.github']:
    src=PACK_ROOT/folder; dst=ROOT/folder
    if src.exists():
        for item in src.rglob('*'):
            rel=item.relative_to(src); target=dst/rel
            if item.is_dir(): target.mkdir(parents=True,exist_ok=True)
            else: target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(item,target)
# Load routes
js=(ASSETS/'goalos-route-registry-v43.js').read_text(encoding='utf-8')
routes=json.loads(js.split('=',1)[1].rsplit(';',1)[0])
route_by_slug={r['slug']:r for r in routes}
def title_of(path):
    txt=path.read_text(encoding='utf-8',errors='ignore')[:5000]
    m=re.search(r'<title>(.*?)</title>',txt,re.I|re.S) or re.search(r'<h1[^>]*>(.*?)</h1>',txt,re.I|re.S)
    if m: return re.sub(r'\s+',' ',re.sub('<.*?>','',m.group(1))).replace('— GoalOS','').strip()
    return path.stem.replace('-',' ').title()
def ensure_v43_injection(path):
    text=path.read_text(encoding='utf-8',errors='ignore')
    changed=False
    if 'goalos-gold-master-v43.css' not in text and '</head>' in text:
        text=text.replace('</head>','<link rel="stylesheet" href="assets/goalos-gold-master-v43.css"><script src="assets/goalos-route-registry-v43.js" defer></script><script src="assets/goalos-gold-master-v43.js" defer></script></head>')
        changed=True
    if 'Ask GoalOS' not in text and '</body>' in text:
        text=text.replace('</body>','<button class="float-ask js-open-ask" type="button">Ask GoalOS</button></body>')
        changed=True
    if changed: path.write_text(text,encoding='utf-8')
for p in PUBLIC.glob('*.html'): ensure_v43_injection(p)
# Merge all existing HTML into search-index
entries=[]
for p in sorted(PUBLIC.glob('*.html')):
    r=route_by_slug.get(p.name,{})
    entries.append({'slug':p.name,'url':p.name,'title':r.get('title') or title_of(p),'category':r.get('category','Existing / Preserved'),'description':r.get('desc','Preserved GoalOS public page kept navigable by V43.')})
(PUBLIC/'search-index.json').write_text(json.dumps(entries,indent=2),encoding='utf-8')
base='https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/'
xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join(f'  <url><loc>{base}{e["slug"]}</loc></url>\n' for e in entries)+'</urlset>\n'
(PUBLIC/'sitemap.xml').write_text(xml,encoding='utf-8')
# Audit
missing=[r['slug'] for r in routes if not (PUBLIC/r['slug']).exists()]
broken=[]
for p in PUBLIC.glob('*.html'):
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for href in re.findall(r'href=["\']([^"\']+)["\']',txt):
        if href.startswith(('http://','https://','#','mailto:','javascript:')): continue
        clean=href.split('#',1)[0].split('?',1)[0]
        if clean and clean.endswith('.html') and not (PUBLIC/clean).exists(): broken.append({'page':p.name,'href':href})
forbidden=[]
for p in ASSETS.glob('*.js'):
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for pat in ['fetch(','XMLHttpRequest','sendBeacon','localStorage','sessionStorage','window.ethereum']:
        if pat in txt: forbidden.append({'file':str(p.relative_to(ROOT)),'pattern':pat})
status='passed' if not missing and not broken and not forbidden else 'needs_review'
report={'version':'v43','status':status,'canonicalRoutes':len(routes),'publicPages':len(entries),'missingCanonicalRoutes':missing,'brokenInternalHtmlLinks':broken,'forbiddenBrowserApiHits':forbidden,'boundary':'preserved','externalActions':0,'productionAuthorization':'not_granted','empiricalSotaClaim':'not_claimed','walletTransactionSupport':'not_enabled'}
for name in ['gold-master-v43-install-report.json','gold-master-v43-qa.json','gold-master-v43-route-health.json','gold-master-v43-audit.json']:
    (REPORTS/name).write_text(json.dumps(report,indent=2),encoding='utf-8')
(CONTENT/'public-proof-navigation-v43.json').write_text(json.dumps({'version':'v43','routes':entries},indent=2),encoding='utf-8')
(EVIDENCE/'gold-master-v43-reference-docket.json').write_text(json.dumps({'version':'v43','claim':'Public-alpha Gold Master route surface installed and preserved.','status':status,'reports':['reports/gold-master-v43-route-health.json']},indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
