#!/usr/bin/env python3
from __future__ import annotations
import json, os, re, shutil, hashlib
from datetime import datetime, timezone
from pathlib import Path
from html import escape

VERSION = "goalos-incremental-proof-grail-v1"
MARKER = "GOALOS_INCREMENTAL_PROOF_GRAIL_V1"
UTC_NOW = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
DOCS = ROOT / "docs"
EVIDENCE = ROOT / "evidence" / "proof-run-001"
REPORTS = ROOT / "reports"
CONTENT = ROOT / "content"
ASSETS = PUBLIC / "assets"

TRUE = {"1", "true", "yes", "y", "on"}
UPDATE_NAV = os.getenv("UPDATE_NAVIGATION", "true").lower() in TRUE
ALLOW_OVERWRITE = os.getenv("ALLOW_OVERWRITE", "false").lower() in TRUE
REPO = os.getenv("GOALOS_REPOSITORY", "MontrealAI/goalos-agialpha-sovereign-machine-economy")
RUN_ID = os.getenv("GOALOS_RUN_ID", "local")
SHA = os.getenv("GOALOS_SHA", "local")
REF_NAME = os.getenv("GOALOS_REF_NAME", "main")

for d in [PUBLIC, DOCS, EVIDENCE, REPORTS, ASSETS, CONTENT]:
    d.mkdir(parents=True, exist_ok=True)
(PUBLIC / ".nojekyll").write_text("", encoding="utf-8")
(ROOT / ".nojekyll").write_text("", encoding="utf-8")

written: list[str] = []
skipped: list[str] = []
patched: list[str] = []
backups: list[str] = []

css = f'''/* {MARKER} */
:root{{--g-bg:#071115;--g-card:#0c1d25;--g-ink:#effffb;--g-muted:#a9c8c5;--g-line:rgba(130,255,224,.25);--g-a:#70ffd1;--g-b:#ffef73;--g-c:#8bc4ff;--g-d:#d8a1ff;}}
*{{box-sizing:border-box}} body{{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:radial-gradient(circle at 20% 5%,rgba(112,255,209,.16),transparent 33%),radial-gradient(circle at 80% 0%,rgba(216,161,255,.17),transparent 35%),linear-gradient(135deg,#061314,#121231);color:var(--g-ink);line-height:1.6}}
a{{color:var(--g-a)}} .wrap{{max-width:1180px;margin:0 auto;padding:34px 20px 72px}} .nav{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:42px}} .brand{{display:flex;gap:12px;align-items:center;text-decoration:none;color:inherit;margin-right:auto}} .mark{{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;font-weight:950;background:linear-gradient(135deg,var(--g-a),var(--g-b),var(--g-c));color:#061314;box-shadow:0 0 40px rgba(112,255,209,.25)}} .pill,.btn{{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--g-line);border-radius:999px;padding:10px 14px;text-decoration:none;color:var(--g-ink);background:rgba(255,255,255,.06);font-weight:800}} .btn.primary{{background:linear-gradient(135deg,var(--g-b),var(--g-a));color:#061314;border:0}} .hero{{padding:56px 0 36px}} .kicker{{letter-spacing:.22em;text-transform:uppercase;color:var(--g-a);font-weight:900;font-size:.82rem}} h1{{font-size:clamp(2.7rem,7vw,6.8rem);line-height:.92;margin:.18em 0;letter-spacing:-.07em}} h2{{font-size:clamp(1.7rem,3vw,3rem);line-height:1.05;margin:.3em 0 .45em}} h3{{margin-bottom:.3rem}} .gradient{{background:linear-gradient(90deg,#fff,var(--g-b),var(--g-a),var(--g-c));-webkit-background-clip:text;background-clip:text;color:transparent}} .lead{{font-size:clamp(1.06rem,2vw,1.42rem);max-width:870px;color:#d9f6f2}} .grid{{display:grid;grid-template-columns:repeat(12,1fr);gap:16px;margin:18px 0}} .card{{grid-column:span 4;background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.045));border:1px solid var(--g-line);border-radius:24px;padding:22px;box-shadow:0 18px 60px rgba(0,0,0,.25)}} .wide{{grid-column:span 8}} .full{{grid-column:1/-1}} .mini{{font-size:.95rem;color:var(--g-muted)}} .num{{font-size:2rem;font-weight:950;color:var(--g-b)}} .flow{{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:22px 0}} .step{{border:1px solid var(--g-line);border-radius:18px;padding:14px;background:rgba(255,255,255,.06);font-weight:900}} .table{{width:100%;border-collapse:collapse;border-radius:18px;overflow:hidden;background:rgba(255,255,255,.04)}} .table th,.table td{{border-bottom:1px solid var(--g-line);padding:12px;text-align:left;vertical-align:top}} .table th{{color:var(--g-a);font-size:.82rem;text-transform:uppercase;letter-spacing:.08em}} .boundary{{border-color:rgba(255,239,115,.5);background:linear-gradient(135deg,rgba(255,239,115,.12),rgba(112,255,209,.06))}} code{{background:rgba(0,0,0,.3);padding:.1rem .35rem;border-radius:.35rem}} footer{{margin-top:48px;color:var(--g-muted);font-size:.92rem}} @media(max-width:820px){{.card,.wide{{grid-column:1/-1}}.flow{{grid-template-columns:1fr}}.nav{{position:static}}}}
'''

routes = [
    {"route":"goalos-incremental-capabilities.html","title":"GoalOS Incremental Capabilities · Proof-Grail Layer","category":"Incremental Proof-Grail"},
    {"route":"proof-gated-universal-work-machine.html","title":"Proof-Gated Universal Work Machine · GoalOS","category":"Incremental Proof-Grail"},
    {"route":"agijobs-dispatch-matrix.html","title":"AGI Jobs Dispatch Matrix · GoalOS","category":"Incremental Proof-Grail"},
    {"route":"agialpha-settlement-thermostat.html","title":"$AGIALPHA Settlement Thermostat · GoalOS","category":"Incremental Proof-Grail"},
    {"route":"proof-run-001-command-room.html","title":"Proof Run 001 Command Room · GoalOS","category":"Incremental Proof-Grail"},
    {"route":"sovereign-machine-economy-flywheel.html","title":"Sovereign Machine Economy Flywheel · GoalOS","category":"Incremental Proof-Grail"},
    {"route":"now-we-prove-it.html","title":"Now We Prove It · GoalOS","category":"Incremental Proof-Grail"},
]

nav_links = "".join(f'<a class="pill" href="{r["route"]}">{escape(r["title"].split(" · ")[0])}</a>' for r in routes[:5])

def layout(title: str, kicker: str, headline: str, lead: str, body: str) -> str:
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="goalos:capability" content="{VERSION}"><meta name="description" content="{escape(lead[:155])}"><title>{escape(title)}</title><link rel="stylesheet" href="assets/goalos-incremental-proof-grail-v1.css"></head><body><div class="wrap"><nav class="nav"><a class="brand" href="index.html"><span class="mark">α</span><span><strong>GOALOS</strong><br><small>INCREMENTAL PROOF-GRAIL LAYER</small></span></a><a class="pill" href="goalos.html">GoalOS</a><a class="pill" href="goalos-incremental-capabilities.html">Capabilities</a><a class="pill" href="proof-run-001-command-room.html">Proof Run 001</a><a class="pill" href="all-pages.html">All Pages</a></nav><header class="hero"><div class="kicker">{escape(kicker)}</div><h1>{headline}</h1><p class="lead">{escape(lead)}</p><p><a class="btn primary" href="proof-run-001-command-room.html">Open Proof Run 001</a> <a class="btn" href="agijobs-dispatch-matrix.html">See AGI Jobs Dispatch</a> <a class="btn" href="claim-boundary.html">Claim Boundary</a></p></header>{body}<footer><strong>Claim boundary:</strong> public-alpha, architecture and implementation scaffold. No achieved AGI, ASI, empirical SOTA, guaranteed ROI, production authorization, legal/security/compliance certification, or live settlement claim. Local GoalOS remains no backend, no wallet, no user funds, no automatic transaction, and no autonomous high-impact authority. Generated by {VERSION} on {UTC_NOW}.</footer></div></body></html>'''

def cards(items):
    return '<section class="grid">' + ''.join(f'<article class="card"><div class="kicker">{escape(k)}</div><h3>{escape(t)}</h3><p>{escape(p)}</p></article>' for k,t,p in items) + '</section>'

def html_table(rows, heads):
    h = ''.join(f'<th>{escape(x)}</th>' for x in heads)
    r = ''.join('<tr>' + ''.join(f'<td>{cell}</td>' for cell in row) + '</tr>' for row in rows)
    return f'<table class="table"><thead><tr>{h}</tr></thead><tbody>{r}</tbody></table>'

def safe_write(rel: str, text: str, managed: bool = True):
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not ALLOW_OVERWRITE:
        old = path.read_text(encoding='utf-8', errors='ignore')
        if managed and MARKER in old:
            pass
        else:
            skipped.append(rel)
            return False
    path.write_text(text, encoding='utf-8')
    written.append(rel)
    return True

safe_write('public/assets/goalos-incremental-proof-grail-v1.css', css)

hub_body = cards([
    ("Capability 01", "Proof-gated universal work machine", "Positions GoalOS as open-ended work plus proof, governance, memory, settlement, and reinvestment — not raw Turing completeness."),
    ("Capability 02", "AGI Jobs dispatch matrix", "Turns unreliable or unsupported LLM output into concrete AGI Jobs with acceptance tests, validator routes, and ProofBundle return paths."),
    ("Capability 03", "$AGIALPHA proof thermostat", "Explains budgets, escrow, stakes, proof bonds, challenge windows, validator pressure, α-Work Units, and reinvestment as economic control signals."),
    ("Capability 04", "Proof Run 001 command room", "Makes the next proof operational: real mission, Evidence Docket, replay path, reviewer route, cost/risk ledger, and claim maturity gates."),
    ("Capability 05", "Sovereign machine economy flywheel", "Connects mission, work, proof, validation, Chronicle, reusable capability, settlement, reinvestment, and harder future missions."),
    ("Capability 06", "Now we prove it", "A claim-bounded launch room that makes the ambition memorable without claiming achieved AGI, ASI, or empirical SOTA."),
]) + f'''<section class="card full boundary"><h2>The strongest honest position</h2><p class="lead">GoalOS is not merely Turing complete. It is proof-gated open-ended work: a system pointed at converting autonomous work into verified experience, reusable capability, settlement memory, and safer compounding intelligence.</p><div class="flow"><div class="step">Mission</div><div class="step">Work</div><div class="step">Proof</div><div class="step">Validation</div><div class="step">Capability</div></div><p><strong>Next sentence:</strong> Now we prove it.</p></section>'''
safe_write('public/goalos-incremental-capabilities.html', layout('GoalOS Incremental Capabilities · Proof-Grail Layer','Incremental autonomous capability layer','GoalOS <span class="gradient">adds the proof-grail rail.</span>','An additive website layer for proof-gated universal work, AGI Jobs dispatch, $AGIALPHA settlement control signals, Proof Run 001, and the sovereign machine economy flywheel.', hub_body))

universal_body = f'''<section class="grid"><article class="card wide"><h2>Not raw Turing completeness. Proof-gated work.</h2><p>Raw computation is abundant. The scarce layer is institutional proof: what was attempted, what happened, what evidence exists, what can be replayed, what passed, what failed, what risk remains, what can be reused, what can settle, and what can influence future work.</p></article><article class="card"><div class="num">∞ → ✓</div><h3>Open-ended, but gated</h3><p>GoalOS can point work toward open-ended objectives, but only accepted proof can become Chronicle memory or reusable capability.</p></article></section><section class="grid"><article class="card full"><h2>The exact loop</h2><div class="flow"><div class="step">Mission</div><div class="step">Work</div><div class="step">Proof</div><div class="step">Validation</div><div class="step">Verified Experience</div><div class="step">Chronicle</div><div class="step">Reusable Capability</div><div class="step">Settlement</div><div class="step">Treasury Reinvestment</div><div class="step">Harder Mission</div></div></article></section>''' + cards([
    ("Rule", "No unsupported authority", "A model can answer and an agent can act, but an institution must prove."),
    ("Rule", "No ProofBundle, no settlement", "Settlement-facing work requires replayable proof, validator verdicts, and a challengeable evidence path."),
    ("Rule", "No proof, no evolution", "Only evidence-backed artifacts can influence future missions, capability packages, or Chronicle memory."),
])
safe_write('public/proof-gated-universal-work-machine.html', layout('Proof-Gated Universal Work Machine · GoalOS','Holy Grail candidate, claim-bounded','Proof-gated <span class="gradient">open-ended work.</span>','The rare target is not computation alone. It is computation plus proof, governance, memory, settlement, and reinvestment.', universal_body))

matrix_rows = [
    ['Unsupported factual claim', 'Claim needs sources, dates, provenance, and contradiction check', 'Source verification AGI Job', 'Claims matrix + source provenance + blocked claims update'],
    ['Unclear buyer readiness', 'LLM can draft, but cannot certify enterprise acceptance', 'Procurement reviewer AGI Job', 'Reviewer verdict + buyer-readiness rubric + risk ledger'],
    ['Missing replay', 'Result cannot influence future work until reproduced', 'Replay and variance AGI Job', 'Replay log + variance check + promotion recommendation'],
    ['Settlement-facing claim', 'Economic consequence requires proof and validator gate', 'ProofBundle completion AGI Job', 'ProofBundle with replay_result, validator_verdict, risk ledger'],
    ['High novelty or Move-37 claim', 'Novelty raises skepticism', 'Dossier and stress-test AGI Job', 'Move-37 dossier + stress tests + persistence gate'],
]
matrix_body = f'''<section class="card full"><h2>The dispatch rule</h2><p class="lead">What an LLM cannot reliably prove, verify, replay, validate, source, audit, or certify becomes proof debt. GoalOS converts that proof debt into executable AGI Jobs.</p></section><section class="card full">{html_table(matrix_rows,['LLM weak spot','Proof debt detected','AGI Job dispatched','Required return'])}</section>''' + cards([
    ("Draft", "LLM output is candidate intelligence", "The LLM can propose the mission, claims, and likely evidence needs."),
    ("Gate", "GoalOS detects proof debt", "Unsupported claims, missing replay, missing validation, and unresolved risk are not allowed to become authority."),
    ("Return", "ProofBundles decide what compounds", "AGI Jobs return evidence packages; promotion stays on HOLD until replay and validation pass."),
])
safe_write('public/agijobs-dispatch-matrix.html', layout('AGI Jobs Dispatch Matrix · GoalOS','Missing evidence becomes executable work','LLMs draft. <span class="gradient">GoalOS dispatches proof.</span>','When the model reaches the edge of reliable proof, GoalOS does not guess harder. It creates AGI Jobs.', matrix_body))

thermo_body = cards([
    ("Budget", "Mission budgets", "Budgets flow toward proof-producing work, not confidence alone."),
    ("Escrow", "Proof before payout", "Escrow releases only after validation, replay, and ProofBundle completeness."),
    ("Stake", "Agent and validator stakes", "Stakes create accountability for false completion or dishonest validation."),
    ("Challenge", "Challenge windows", "Disputed work remains unsettled until the proof path clears."),
    ("α-WU", "Verified work units", "α-Work Units should measure validated, replayable, policy-compliant work."),
    ("Reinvest", "Harder future missions", "Accepted proof can fund larger missions and better validators."),
]) + '''<section class="card full boundary"><h2>The thermostat model</h2><div class="flow"><div class="step">Proof quality rises → more budget may flow</div><div class="step">False acceptance rises → validator pressure increases</div><div class="step">Replay fails → settlement stops</div><div class="step">Risk rises → mission class pauses</div><div class="step">External validation succeeds → claim maturity can rise</div></div></section>'''
safe_write('public/agialpha-settlement-thermostat.html', layout('$AGIALPHA Settlement Thermostat · GoalOS','Economic control rail, not intelligence','$AGIALPHA makes <span class="gradient">proof consequential.</span>','GoalOS creates proof. $AGIALPHA can coordinate budgets, stakes, bonds, settlement, slashing, α-Work Units, and reinvestment only when proof passes.', thermo_body))

proof_rows = [
    ['Mission Contract', 'Objective, success/failure criteria, constraints, reviewer route', 'Required before run starts'],
    ['Baseline', 'Report-only or ad-hoc-agent baseline', 'Required to judge improvement'],
    ['Proof Debt Register', 'Every unsupported claim and missing evidence item', 'Required before job dispatch'],
    ['AGI Jobs', 'Executable proof tasks with acceptance tests', 'Required to close evidence gaps'],
    ['ProofBundles', 'Returned proof with replay and validator verdicts', 'Required before promotion'],
    ['Evidence Docket', 'Public-safe proof room', 'Required before public claim maturity rises'],
    ['Cost/Risk Ledger', 'Time, cost, safety, legal, privacy, and settlement boundaries', 'Required for useful decision state'],
    ['External Review', 'Independent reviewer or replay path', 'Required for stronger empirical claims'],
]
proof_body = f'''<section class="card full"><h2>Proof Run 001 is the bridge from architecture to evidence.</h2><p class="lead">Until the first public Evidence Docket exists, GoalOS is a powerful public-alpha architecture. After Proof Run 001, it becomes an evidence-producing system people can inspect.</p></section><section class="card full">{html_table(proof_rows,['Artifact','What it contains','Gate'])}</section>''' + cards([
    ("Status", "Public-alpha proof run", "Architecture live; first public docket remains the decisive next proof."),
    ("Boundary", "No strong claim yet", "No achieved AGI, ASI, empirical SOTA, ROI guarantee, certification, or autonomous production authority."),
    ("Action", "Run, replay, review", "Real mission, baseline, proof bundles, validator report, cost/risk ledger, delayed outcome, and external review."),
])
safe_write('public/proof-run-001-command-room.html', layout('Proof Run 001 Command Room · GoalOS','The next proof','Now <span class="gradient">we prove it.</span>','Proof Run 001 turns the GoalOS thesis into an inspectable Evidence Docket: real mission, real proof debt, AGI Jobs, ProofBundles, replay, validation, and claim-bounded release.', proof_body))

fly_body = '''<section class="card full"><h2>The sovereign machine economy loop</h2><div class="flow"><div class="step">Objective</div><div class="step">Mission Contract</div><div class="step">AGI Agents</div><div class="step">AGI Jobs</div><div class="step">AGI Nodes</div><div class="step">ProofBundles</div><div class="step">Evidence Docket</div><div class="step">Capability Gate</div><div class="step">Settlement</div><div class="step">Reinvestment</div></div></section>''' + cards([
    ("Verified experience", "The compounding unit", "GoalOS preserves not raw text but verified work and evidence-backed patterns."),
    ("Reusable capability", "The institutional asset", "Accepted proof becomes capability packages, reviewer rooms, job templates, and future mission improvements."),
    ("Productive capacity", "The long-horizon flywheel", "Reusable capability can contribute to software, science, compute, infrastructure, useful energy, and stronger future work — as a horizon, not a present achievement claim."),
])
safe_write('public/sovereign-machine-economy-flywheel.html', layout('Sovereign Machine Economy Flywheel · GoalOS','Mission → proof → settlement → reinvestment','Verified work becomes <span class="gradient">reusable capacity.</span>','The sovereign machine economy is the loop where proof-bearing work becomes memory, capability, settlement, and harder future missions.', fly_body))

now_body = '''<section class="card full boundary"><h2>The line</h2><p class="lead">GoalOS is not merely Turing complete. It is proof-gated open-ended work.</p><p>That is the real prize: a system that can coordinate autonomous work, convert it into verified experience, preserve it as institutional memory, settle it only when proof passes, and reinvest into harder future missions.</p><p><strong>Not infinite noise. Not ungoverned autonomy. Not a claim of achieved superintelligence.</strong></p><p>A proof-governed substrate for compounding intelligence.</p><h2>Now we prove it.</h2></section>''' + cards([
    ("Do", "Publish Proof Run 001", "Make the first Evidence Docket inspectable, replayable, and claim-bounded."),
    ("Do", "Keep claims bounded", "Strong claims require baselines, ProofBundles, replay, validator reports, cost/risk ledgers, delayed outcomes, and independent review."),
    ("Do", "Let accepted proof compound", "Only validated evidence can influence Chronicle memory and future missions."),
])
safe_write('public/now-we-prove-it.html', layout('Now We Prove It · GoalOS','Claim-bounded launch room','It is a <span class="gradient">Holy Grail candidate.</span> Now we prove it.','A strong public framing for GoalOS that preserves ambition, proof discipline, and the required non-claim boundaries.', now_body))

index_data = {
    "version": VERSION,
    "generated_at": UTC_NOW,
    "repository": REPO,
    "run_id": RUN_ID,
    "sha": SHA,
    "claim_boundary": {
        "achieved_agi": False,
        "achieved_asi": False,
        "empirical_sota": False,
        "guaranteed_roi": False,
        "legal_security_compliance_certification": False,
        "live_settlement_in_local_mode": False,
        "autonomous_production_authorization": False
    },
    "capabilities": [r["route"] for r in routes],
    "loop": ["Mission", "Work", "Proof", "Validation", "Verified Experience", "Chronicle", "Reusable Capability", "Settlement", "Reinvestment", "Harder Mission"],
    "next_proof": "Proof Run 001: public Evidence Docket with baselines, ProofBundles, replay logs, validator reports, cost/risk ledger, delayed outcomes, and independent review."
}
safe_write('public/incremental-proof-grail-capability-index.json', json.dumps(index_data, indent=2) + '\n')

# Docs
base_meta = f'''---\nstatus: public-alpha\ncapability_layer: {VERSION}\npublic_private: public-safe\nlast_reviewed: {UTC_NOW}\nclaim_level: architectural\n---\n\n'''
docs = {
'INCREMENTAL_PROOF_GRAIL_CAPABILITY_LAYER.md': '''# GoalOS Incremental Proof-Grail Capability Layer\n\nGoalOS is not merely Turing complete. It is proof-gated open-ended work.\n\nThis incremental layer adds public website surfaces for the proof-gated universal work machine, AGI Jobs dispatch matrix, $AGIALPHA settlement thermostat, Proof Run 001 command room, sovereign machine economy flywheel, and the claim-bounded launch frame: Now we prove it.\n\n## Core rule\n\nA model can answer. An agent can act. An institution must prove.\n\n## Non-claims\n\nThis layer does not claim achieved AGI, achieved ASI, empirical SOTA, legal/security/compliance certification, guaranteed ROI, live settlement in local mode, or autonomous production authorization.\n''',
'AGIJOBS_DISPATCH_MATRIX.md': '''# AGI Jobs Dispatch Matrix\n\nWhat an LLM cannot reliably prove, verify, replay, validate, source, audit, or certify becomes proof debt. GoalOS converts that proof debt into executable AGI Jobs.\n\n## Flow\n\nLLM draft → Proof Debt → AGI Job → ProofBundle → Evidence Docket → Capability Gate → Chronicle hold or promotion.\n\n## Dispatch threshold\n\nCreate an AGI Job when missing proof could affect trust, reuse, settlement, publication, payment, safety, compliance, procurement, or future action.\n''',
'AGIALPHA_SETTLEMENT_THERMOSTAT.md': '''# $AGIALPHA Settlement Thermostat\n\n$AGIALPHA is not the intelligence. GoalOS creates proof; $AGIALPHA can make proof economically consequential.\n\nThe settlement thermostat coordinates budgets, escrow, agent stakes, validator stakes, proof bonds, reviewer rewards, slashing, α-Work Units, reputation, challenge windows, treasury reinvestment, and future mission allocation.\n\nNo ProofBundle, no settlement. No replay, no settlement.\n''',
'PROOF_RUN_001_COMMAND_ROOM.md': '''# Proof Run 001 Command Room\n\nProof Run 001 is the bridge from architecture to evidence. The first public Evidence Docket should show a real mission, baseline, proof debt register, AGI Jobs, ProofBundles, replay logs, validator report, cost/risk ledger, claim boundary, and reviewer path.\n\nThe goal is not a stronger slogan. The goal is an inspectable proof package.\n''',
'SOVEREIGN_MACHINE_ECONOMY_FLYWHEEL.md': '''# Sovereign Machine Economy Flywheel\n\nMission → Work → Proof → Validation → Verified Experience → Chronicle → Reusable Capability → Settlement → Treasury Reinvestment → Harder Mission.\n\nThe flywheel is a strategic horizon. It becomes empirical only through repeated Evidence Dockets, replay, validation, cost/risk accounting, and independent review.\n''',
'NOW_WE_PROVE_IT_RELEASE_NOTE.md': '''# Now We Prove It\n\nGoalOS is architecturally pointed at one of the important prizes in AI infrastructure: proof-gated, economically coordinated, open-ended autonomous work that can generate verified experience and reusable capability.\n\nThe next sentence is the standard: now we prove it.\n''',
'WEBSITE_INCREMENTAL_AUTOPILOT_GUIDE.md': '''# Website Incremental Autopilot Guide\n\nThis autopilot is additive. It creates new pages, docs, evidence manifests, reports, route entries, and optional navigation links. It refuses destructive deletion and does not overwrite non-managed files unless allow_overwrite is explicitly set to true.\n\nRecommended first run: direct_commit, deploy_pages true, update_navigation true, allow_overwrite false, fail_on_audit_error true.\n''',
}
for name, text in docs.items():
    safe_write(f'docs/{name}', base_meta + text)

# Evidence manifests
safe_write('evidence/proof-run-001/incremental-proof-run-001-manifest.json', json.dumps({
    "version": VERSION,
    "generated_at": UTC_NOW,
    "mission": "Proof Run 001",
    "required_artifacts": ["Mission Contract", "Baseline", "Proof Debt Register", "AGI Jobs", "ProofBundles", "Evidence Docket", "Cost/Risk Ledger", "Validator Report", "External Replay"],
    "claim_boundary": index_data["claim_boundary"],
    "status": "ready-for-public-safe-proof-run"
}, indent=2) + "\n")
safe_write('evidence/proof-run-001/agijobs-dispatch-matrix.json', json.dumps({
    "version": VERSION,
    "generated_at": UTC_NOW,
    "rule": "Missing evidence becomes executable AGI Jobs.",
    "dispatch_cases": [
        {"llm_weak_spot":"unsupported claim", "job":"source verification", "return":"claim evidence packet"},
        {"llm_weak_spot":"missing replay", "job":"replay and variance check", "return":"replay log"},
        {"llm_weak_spot":"settlement-facing claim", "job":"ProofBundle completion", "return":"validator verdict and risk ledger"}
    ]
}, indent=2) + "\n")
safe_write('evidence/proof-run-001/settlement-thermostat-simulation.json', json.dumps({
    "version": VERSION,
    "simulation_only": True,
    "no_live_settlement": True,
    "signals": ["proof_quality", "false_acceptance_rate", "replay_failure_rate", "risk_class", "external_validation"],
    "actuators": ["mission_budget", "validator_pressure", "challenge_window", "settlement_hold", "treasury_reinvestment_hold"]
}, indent=2) + "\n")

# route registry update with backup

def backup_file(path: Path):
    if path.exists():
        bdir = REPORTS / "backups"
        bdir.mkdir(parents=True, exist_ok=True)
        safe = path.as_posix().replace('/', '__')
        b = bdir / f"{VERSION}-{safe}.bak"
        shutil.copy2(path, b)
        backups.append(str(b.relative_to(ROOT)))

def update_route_registry():
    p = PUBLIC / 'route-registry.json'
    if not p.exists():
        data = {"version": VERSION, "routes": []}
    else:
        data = json.loads(p.read_text(encoding='utf-8'))
    existing = {x.get('route') for x in data.get('routes', []) if isinstance(x, dict)}
    added = []
    for r in routes:
        if r['route'] not in existing:
            data.setdefault('routes', []).append({"route": r['route'], "title": r['title'], "category": r['category'], "canonical": False, "incremental": VERSION})
            added.append(r['route'])
    data.setdefault('incrementalCapabilityLayers', [])
    if VERSION not in [x.get('version') if isinstance(x, dict) else x for x in data['incrementalCapabilityLayers']]:
        data['incrementalCapabilityLayers'].append({"version": VERSION, "generated_at": UTC_NOW, "routes": [r['route'] for r in routes]})
    backup_file(p)
    p.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    patched.append('public/route-registry.json')
update_route_registry()

# content/site_manifest.json update (if present)
def update_site_manifest():
    p = CONTENT / 'site_manifest.json'
    if not p.exists():
        return
    try:
        data = json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        return
    pages = data.setdefault('pages', [])
    existing = {x.get('href') or x.get('route') for x in pages if isinstance(x, dict)}
    for r in routes:
        href = r['route']
        if href not in existing and f"./{href}" not in existing:
            pages.append({"title": r['title'], "href": href, "category": r['category'], "incremental": VERSION})
    data.setdefault('incremental_capabilities', [])
    data['incremental_capabilities'].append({"version": VERSION, "generated_at": UTC_NOW, "routes": [r['route'] for r in routes]})
    backup_file(p)
    p.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    patched.append('content/site_manifest.json')
update_site_manifest()

# sitemap update
sitemap = PUBLIC / 'sitemap.xml'
if sitemap.exists():
    txt = sitemap.read_text(encoding='utf-8', errors='ignore')
    additions = ''
    base = 'https://montrealai.github.io/goalos-agialpha-sovereign-machine-economy/'
    for r in routes:
        loc = base + r['route']
        if loc not in txt:
            additions += f'  <url><loc>{loc}</loc><lastmod>{UTC_NOW[:10]}</lastmod></url>\n'
    if additions:
        backup_file(sitemap)
        if '</urlset>' in txt:
            txt = txt.replace('</urlset>', additions + '</urlset>')
        else:
            txt += '\n' + additions
        sitemap.write_text(txt, encoding='utf-8')
        patched.append('public/sitemap.xml')

# optional navigation patches
nav_block = f'''\n<!-- {MARKER}:NAV_START -->\n<section class="goalos-incremental-proof-grail" style="margin:28px auto;padding:24px;border-radius:24px;border:1px solid rgba(112,255,209,.32);background:linear-gradient(135deg,rgba(112,255,209,.10),rgba(255,239,115,.08));max-width:1120px">\n  <div style="letter-spacing:.18em;text-transform:uppercase;font-weight:900;color:#70ffd1;font-size:.82rem">Incremental proof-grail capability layer</div>\n  <h2 style="margin:.35em 0;font-size:clamp(1.6rem,3vw,2.7rem)">GoalOS is proof-gated open-ended work.</h2>\n  <p style="font-size:1.08rem;max-width:850px">New autonomous pages added: proof-gated universal work machine, AGI Jobs dispatch matrix, $AGIALPHA settlement thermostat, Proof Run 001 command room, sovereign machine economy flywheel, and Now We Prove It.</p>\n  <p>{nav_links}</p>\n</section>\n<!-- {MARKER}:NAV_END -->\n'''

def inject(path: Path, block: str):
    if not path.exists(): return
    txt = path.read_text(encoding='utf-8', errors='ignore')
    if MARKER in txt:
        skipped.append(str(path.relative_to(ROOT)) + ' navigation already present')
        return
    backup_file(path)
    insert_at = txt.lower().rfind('</main>')
    if insert_at == -1:
        insert_at = txt.lower().rfind('</body>')
    if insert_at == -1:
        new = txt + block
    else:
        new = txt[:insert_at] + block + txt[insert_at:]
    path.write_text(new, encoding='utf-8')
    patched.append(str(path.relative_to(ROOT)))

if UPDATE_NAV:
    for rel in ['public/index.html','public/goalos.html','public/all-pages.html','public/site-map.html']:
        inject(ROOT / rel, nav_block)

# reports
report = {
    "version": VERSION,
    "generated_at": UTC_NOW,
    "repository": REPO,
    "github_run_id": RUN_ID,
    "sha": SHA,
    "ref": REF_NAME,
    "allow_overwrite": ALLOW_OVERWRITE,
    "update_navigation": UPDATE_NAV,
    "written": written,
    "patched": patched,
    "skipped": skipped,
    "backups": backups,
    "routes_added": [r['route'] for r in routes],
    "claim_boundary": index_data['claim_boundary'],
    "safety": {
        "no_files_deleted": True,
        "no_wallet": True,
        "no_user_funds": True,
        "no_live_settlement": True,
        "no_external_calls_in_generated_pages": True
    }
}
safe_write('reports/goalos-incremental-proof-grail-v1-install-report.json', json.dumps(report, indent=2) + '\n')
md = [
    f"# GoalOS Incremental Proof-Grail Capability Layer — Install Report",
    "",
    f"Generated: `{UTC_NOW}`",
    f"Repository: `{REPO}`",
    "",
    "## What was added",
    "",
    *[f"- `{r['route']}` — {r['title']}" for r in routes],
    "",
    "## Safety posture",
    "",
    "- Additive install only.",
    "- Existing non-managed files are preserved by default.",
    "- No deletion is allowed by the workflow.",
    "- No backend, wallet, user funds, live settlement, or autonomous production authorization is introduced.",
    "- No achieved AGI, ASI, empirical SOTA, certification, or guaranteed ROI claim is introduced.",
    "",
    "## Next action",
    "",
    "Open `proof-run-001-command-room.html`, choose a public-safe real mission, and publish the first Evidence Docket when the proof path is ready.",
]
safe_write('reports/goalos-incremental-proof-grail-v1-install-report.md', '\n'.join(md) + '\n')
print(json.dumps(report, indent=2))
