# GoalOS Incremental Proof-Grail Capability Pack

This pack is executed by `.github/workflows/goalos-incremental-proof-grail-autopilot.yml`.

It is additive by design. It creates new public pages, docs, proof-run manifests, route entries, audit reports, and optional navigation links. It does not delete existing files and it does not overwrite non-managed files unless `allow_overwrite=true`.
