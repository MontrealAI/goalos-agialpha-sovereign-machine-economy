#!/usr/bin/env python3
from __future__ import annotations
import json, os, sys
from pathlib import Path
from datetime import datetime, timezone

VERSION = "goalos-incremental-proof-grail-v1"
ROOT = Path.cwd()
PUBLIC = ROOT / "public"
REPORTS = ROOT / "reports"
FAIL = os.getenv("FAIL_ON_AUDIT_ERROR", "true").lower() in {"1","true","yes","y","on"}
UTC_NOW = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
required = [
    "public/goalos-incremental-capabilities.html",
    "public/proof-gated-universal-work-machine.html",
    "public/agijobs-dispatch-matrix.html",
    "public/agialpha-settlement-thermostat.html",
    "public/proof-run-001-command-room.html",
    "public/sovereign-machine-economy-flywheel.html",
    "public/now-we-prove-it.html",
    "public/incremental-proof-grail-capability-index.json",
    "docs/INCREMENTAL_PROOF_GRAIL_CAPABILITY_LAYER.md",
    "docs/AGIJOBS_DISPATCH_MATRIX.md",
    "docs/AGIALPHA_SETTLEMENT_THERMOSTAT.md",
    "docs/PROOF_RUN_001_COMMAND_ROOM.md",
    "evidence/proof-run-001/incremental-proof-run-001-manifest.json",
    "reports/goalos-incremental-proof-grail-v1-install-report.json",
]
missing = [p for p in required if not (ROOT / p).exists()]
forbidden = ["fetch(", "XMLHttpRequest", "sendBeacon", "window.ethereum", "localStorage", "sessionStorage", "https://fonts.googleapis", "<script src=\"http", "<script src='http", "<link rel=\"stylesheet\" href=\"http", "<link rel='stylesheet' href='http"]
forbidden_hits = {}
for path in PUBLIC.glob("*.html"):
    if path.name not in {"goalos-incremental-capabilities.html","proof-gated-universal-work-machine.html","agijobs-dispatch-matrix.html","agialpha-settlement-thermostat.html","proof-run-001-command-room.html","sovereign-machine-economy-flywheel.html","now-we-prove-it.html"}:
        continue
    text = path.read_text(encoding='utf-8', errors='ignore')
    hits = [x for x in forbidden if x in text]
    if hits: forbidden_hits[str(path.relative_to(ROOT))] = hits
    for phrase in ["No achieved AGI", "No backend", "no wallet", "no user funds"]:
        if phrase.lower() not in text.lower():
            forbidden_hits.setdefault(str(path.relative_to(ROOT)), []).append(f"missing boundary phrase: {phrase}")
route_ok = False
route_registry_error = None
try:
    data = json.loads((PUBLIC / 'route-registry.json').read_text(encoding='utf-8'))
    existing = {r.get('route') for r in data.get('routes', []) if isinstance(r, dict)}
    route_ok = all(p.split('/',1)[1] in existing for p in required if p.startswith('public/') and p.endswith('.html'))
except Exception as e:
    route_registry_error = str(e)
report = {
    "version": VERSION,
    "generated_at": UTC_NOW,
    "status": "pass" if not missing and not forbidden_hits and route_ok else "fail",
    "missing_required_files": missing,
    "forbidden_or_boundary_hits": forbidden_hits,
    "route_registry_contains_routes": route_ok,
    "route_registry_error": route_registry_error,
    "claim_boundary_preserved": not forbidden_hits,
    "destructive_changes_detected_by_installer": False
}
REPORTS.mkdir(parents=True, exist_ok=True)
(REPORTS / 'goalos-incremental-proof-grail-v1-audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
md = ["# GoalOS Incremental Proof-Grail Capability Layer — Audit Report", "", f"Status: **{report['status'].upper()}**", "", "## Checks", "", f"- Missing files: `{len(missing)}`", f"- Forbidden/boundary hits: `{len(forbidden_hits)}`", f"- Route registry contains new routes: `{route_ok}`", "", "## Boundary", "", "No generated page introduces backend, wallet, user funds, live settlement, autonomous production authorization, achieved AGI/ASI, empirical SOTA, certification, or guaranteed ROI claims."]
(REPORTS / 'goalos-incremental-proof-grail-v1-audit.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
if FAIL and report['status'] != 'pass':
    sys.exit(1)
